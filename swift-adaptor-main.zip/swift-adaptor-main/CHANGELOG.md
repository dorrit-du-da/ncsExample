# Changelog 

All notable changes to this project will be documented in this file. 


The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),

and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).



## [Unreleased] 


## [1.0.3] - 2022-02-25

### Added

FL-260  Get MT535 rest api

FL-259  Get MT940 rest api

FL-248  Trigger MT564 rest api

FL-258  Trigger MT535 rest api

FL-257  Trigger MT940 rest api


### Changed

FL-208  Test Corp Action Messages

FL-235  Add DATE logic to the mt535 and 940 rest apis

FL-245  Update automated tests for changing REST parameters from strings to array


### Deprecated

None


### Removed

None


### Fixed

FL-251  MT564 - Incorrect position for Datetime in field 98B

FL-279  [Rest API] [Trigger MT564] Unhandled case when sending request without exDivDate

FL-278  [Rest API] Trigger MT564 - Cannot send trigger request multiple times


### Security 

None


## [1.0.2] - 2022-02-11

### Added 

FL-240, FL-241 Integrated MT564 and MT566 with SWIFT Adaptor, including automatic generation of SWIFT messages by processing SwiftOutboundMessage contract

FL-200  Added REST API to fetch MT564 messages under /getMT564Messages with mandatory fields exDivDate and assetID

FL-201  Added REST API to fetch MT566 messages under /getMT566Messages with mandatory fields payoutDate and instrumentId


### Changed 

FL-236  Modified REST API parameters to take Arrays for increased flexibility


### Deprecated 

None


### Removed 

None


### Fixed 

None


### Security 

None


## [1.0.1] - 2022-01-28

### Added

FL-222	Create REST API for SWIFT MT547 Settlement Message

FL-216	Create REST API for SWIFT MT545 Settlement Message

FL-193	Rest API for "customer cash statement report" (MT940)

FL-192	Integrate the new finlib MT545 and MT547 to the swift adapter java app

FL-120	Rest API for "statement of security holdings report generation" (MT535)


### Changed

FL-224	Split repositories for AssetBridge and SwiftAdapter

FL-191	General improvement : getters and setters to change app parameters and behavior at runtime

FL-199	SWIFT Java Code enhancement - remove block 3 from all SWIFT message

FL-197	SWIFT Java code enhancement - break SwiftAdaptorService class separate class for each swift msg

FL-190	Move application.properties parameters for the swift adapter

FL-161	Update all SWIFT messages with feedback

FL-163	Automate tests for SWIFT Adaptor updates for the version 1.0.1

FL-143	MT564, MT566 message updates


### Deprecated

None


### Removed

None


### Fixed

FL-229	MT535 Incorrect date in field 98A 

FL-210	MT547 - Different Place Code in field 94F

FL-195	MT535- Lack PREP in field 98C

FL-179	MT940 - Incorrect date format in Field 60M & 62M

FL-178	MT547 - Lack currency code in field 19A

FL-184	Swift adapter changes to MT547, MT545, SwiftOutboundMessage.status: MessageStatus to sync with syndication branch of DA-marketplace


### Security

None



## [1.0.0-alpha] - 2022-01-17

### Added

--- The SWIFT Adapter and Asset Bridge were a single project (https://github.com/DACH-NY/goldman-asset-tokenization
) ---

FL-61		Create the flow of cash deposit and cash withdrawal

FL-70		"Implement function calls for a deployed ERC-20 token, including transfer(), transferFrom(), approve() and balanceOf() "

FL-72		"Implement metamask with wallets, tokens, token transfer, etc."

FL-74		"Code the ERC-20 function in Java: loading library, specify the endpoint and token ID, check balance and perform transfer. Due 12/11/2021. "

FL-80		"POC of swift adapter : observe a daml ledger, detect a change, create a swift message with some fields and put it into a local folder"

FL-93		Implement Automated Test Framework

FL-96		Setup Karate framework - JSON API

FL-99		Integrate Circle CI CI/CD with Karate

FL-101		"Change POC to use new daml module/template, capture the fields, output the message 545"

FL-103		Change POC to be a spring RESTful service + modify output code to be an easily changeable interface implementation

FL-104		Add a new swift message definition to the daml template : MT544

FL-110		"Add functionality to consume contracts waiting on the daml ledger, that were created before the SwiftAdapter started and thus couldnt be captured"

FL-111		"Finalize MT545 daml fields to swift fields mapping, with proper placeholders for missing values"

FL-113		Bridge Cash Withdraw function

FL-117		Reporting MT messages

FL-118		Corporate Action MT messages

FL-120		"Rest API for ""statement of security holdings report generation"" (MT535)"

FL-122		Unit tests for existing code in SWIFT Adaptor

FL-123		"Complete daml template MT544, MT546, MT547 with fields"

FL-124		Build structure of the Java Spring Boot application for the Asset Bridge

FL-125		Containerize the Asset Bridge application by writing Dockerfile script

FL-126		Configure CircleCI script for CI/CD deployment to AWS ECR repo

FL-129		"Build, deploy and integrate Daml ledger using Daml SDK, Sandbox and Daml Navigator"

FL-133		Settlement MT messages

FL-136		Create a readme file for SWIFT Adapter setup

FL-142		Implement GS Bridge v0.0.3

FL-143		"MT564, MT566 message updates"

FL-145		Create Javadoc for SWIFT adapter

FL-150		Integrate Bridge with Daml asset deposit

FL-154		Complete refactoring the Java code according to new Daml file structure

FL-161		Update all SWIFT messages with feedback

FL-163		Automate tests for SWIFT Adaptor updates for the 1.0.0-alpha release

FL-165		Enhance the application's Daml Client connection to the Daml Ledger with auto retries and exception handling

FL-184		"Swift adapter changes to MT547, MT545, SwiftOutboundMessage.status: MessageStatus to sync with syndication branch of DA-marketplace"

FL-186		Application parameters added to application.properties

FL-187		"Selection of what the SwiftAdapter subscribes to (old active contracts, new incoming contracts) and the message types it handles automatically at application start, customizable in application.properties"

FL-188		General improvements of the SwiftAdapter; getters and setters may now be used to change application behavior during runtime


### Changed

None


### Deprecated

None


### Removed

None


### Fixed

None


### Security

None
