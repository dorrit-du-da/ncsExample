# Swift adaptor

**Description**

A Java component that creates ISO 15022 SWIFT messages based on smart contract information from the Daml Ledger.

**Automatic Logic**

The SwiftAdaptorApp subscribes to the transaction service provided by Daml gRPC Ledger API and observes “SwiftOutboundMessage” contracts that are visible to the party set in application.properties. When detecting new contract from the ledger, the SwiftadaptorApp will consume it, creating a new SWIFT message based on contract details and the using exercise the Daml choice “Response” from the SwiftOutboundMessage contract.

This swift message is consumed by a consumer, which is by default a simple function that saves it as a file to the local ./swift_messages folder. The new SwiftOutboundMessage contract on the daml ledger contains the information that was in the initial SwiftOutboundMessage contract, plus a response field with value “PROCESSED” + UNIT or “FAILED” + an error message.

**Automatic Logic : Current support**

Currently the SwiftadaptorApp is only supporting the following outbound Swift Messages:

- MT 545 Receive Against Payment Confirmation
- MT 547 Deliver Against Payment Confirmation
<!-- - MT 544 Receive Free Confirmation
- MT 546 Deliver Free Confirmation
- MT 564 Corporate Action Notification
- MT 566 Corporate Action Confirmation -->

**REST Endpoints**

**REST Endpoints : Current support**

- MT 545 Receive Against Payment Confirmation
- MT 547 Deliver Against Payment Confirmation
- MT 535 Statement of Holdings
- MT 940 End-of-day Bank Account Statement

## Getting Started

**Prerequisites to install on your local PC/Mac**

- Daml SDK v1.18.0 (you may install in the [Daml getting started](https://docs.daml.com/getting-started/installation.html) page)
- Java JDK v11
- Apache Maven v3.8.4

---

**Steps to build and run**

1. In the da-marketplace project, syndication branch, you can build and run the Daml Ledger in a single command :

```
daml start
```

This will build the daml dar, start the daml ledger in sandbox.

2. In Swift Adaptor project, go to the project root folder, and build the Java application with maven using:

```
mvn -DskipTests -Ddockerfile.skip=true clean install
```

Skipping the tests is **mandatory** at this stage, as the application fails if there is no daml ledger to connect to. (We are looking to optimize the connection handling in the upcoming sprint)

3. Run the java application using the jar file:

```
java -jar target/asset-bridge-0.0.1.jar
```

**Stopping the application**

You can stop the daml ledger or the java app using

```
CTRL+C
```

in the respective terminal.

---

**Additional Notes**

1. Many settings can be changed in the application.properties file under src/main/resources
2. For the SwiftadaptorApp, the application will capture all the existing SwiftOutboundMessage contracts and create the swift messages, and then it will wait for new SwiftOutboundMessage contracts to appear on the daml ledger.
