package com.daml.generated.marketplace.clearing.role;

import com.daml.generated.marketplace.clearing.service.Service;
import com.daml.ledger.javaapi.data.DamlRecord;
import com.daml.ledger.javaapi.data.Value;
import java.lang.IllegalArgumentException;
import java.lang.Object;
import java.lang.Override;
import java.lang.String;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

public class TerminateClearingService {
  public static final String _packageId = "636e6e778aedec0710919591e9cb2a9404d6daab0581e4ddc515eeae03256f45";

  public final Service.ContractId custodyServiceCid;

  public TerminateClearingService(Service.ContractId custodyServiceCid) {
    this.custodyServiceCid = custodyServiceCid;
  }

  public static TerminateClearingService fromValue(Value value$) throws IllegalArgumentException {
    Value recordValue$ = value$;
    DamlRecord record$ = recordValue$.asRecord().orElseThrow(() -> new IllegalArgumentException("Contracts must be constructed from Records"));
    List<DamlRecord.Field> fields$ = record$.getFields();
    int numberOfFields = fields$.size();
    if (numberOfFields != 1) {
      throw new IllegalArgumentException("Expected 1 arguments, got " + numberOfFields);
    }
    Service.ContractId custodyServiceCid = new Service.ContractId(fields$.get(0).getValue().asContractId().orElseThrow(() -> new IllegalArgumentException("Expected custodyServiceCid to be of type com.daml.ledger.javaapi.data.ContractId")).getValue());
    return new com.daml.generated.marketplace.clearing.role.TerminateClearingService(custodyServiceCid);
  }

  public DamlRecord toValue() {
    ArrayList<DamlRecord.Field> fields = new ArrayList<DamlRecord.Field>(1);
    fields.add(new DamlRecord.Field("custodyServiceCid", this.custodyServiceCid.toValue()));
    return new DamlRecord(fields);
  }

  @Override
  public boolean equals(Object object) {
    if (this == object) {
      return true;
    }
    if (object == null) {
      return false;
    }
    if (!(object instanceof TerminateClearingService)) {
      return false;
    }
    TerminateClearingService other = (TerminateClearingService) object;
    return this.custodyServiceCid.equals(other.custodyServiceCid);
  }

  @Override
  public int hashCode() {
    return Objects.hash(this.custodyServiceCid);
  }

  @Override
  public String toString() {
    return String.format("com.daml.generated.marketplace.clearing.role.TerminateClearingService(%s)", this.custodyServiceCid);
  }
}
