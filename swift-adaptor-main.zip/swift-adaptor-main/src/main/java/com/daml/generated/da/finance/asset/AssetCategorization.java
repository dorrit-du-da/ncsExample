package com.daml.generated.da.finance.asset;

import com.daml.generated.da.finance.types.Id;
import com.daml.generated.da.internal.template.Archive;
import com.daml.generated.da.set.types.Set;
import com.daml.ledger.javaapi.data.CreateAndExerciseCommand;
import com.daml.ledger.javaapi.data.CreateCommand;
import com.daml.ledger.javaapi.data.CreatedEvent;
import com.daml.ledger.javaapi.data.DamlRecord;
import com.daml.ledger.javaapi.data.ExerciseCommand;
import com.daml.ledger.javaapi.data.Identifier;
import com.daml.ledger.javaapi.data.Party;
import com.daml.ledger.javaapi.data.Template;
import com.daml.ledger.javaapi.data.Text;
import com.daml.ledger.javaapi.data.Value;
import java.lang.Deprecated;
import java.lang.IllegalArgumentException;
import java.lang.Object;
import java.lang.Override;
import java.lang.String;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Objects;
import java.util.Optional;

public final class AssetCategorization extends Template {
  public static final Identifier TEMPLATE_ID = new Identifier("636e6e778aedec0710919591e9cb2a9404d6daab0581e4ddc515eeae03256f45", "DA.Finance.Asset", "AssetCategorization");

  public final Id id;

  public final String assetType;

  public final String assetClass;

  public final Set<String> observers;

  public AssetCategorization(Id id, String assetType, String assetClass, Set<String> observers) {
    this.id = id;
    this.assetType = assetType;
    this.assetClass = assetClass;
    this.observers = observers;
  }

  public CreateCommand create() {
    return new CreateCommand(AssetCategorization.TEMPLATE_ID, this.toValue());
  }

  public CreateAndExerciseCommand createAndExerciseArchive(Archive arg) {
    Value argValue = arg.toValue();
    return new CreateAndExerciseCommand(AssetCategorization.TEMPLATE_ID, this.toValue(), "Archive", argValue);
  }

  public CreateAndExerciseCommand createAndExerciseAssetCategorization_SetObservers(
      AssetCategorization_SetObservers arg) {
    Value argValue = arg.toValue();
    return new CreateAndExerciseCommand(AssetCategorization.TEMPLATE_ID, this.toValue(), "AssetCategorization_SetObservers", argValue);
  }

  public CreateAndExerciseCommand createAndExerciseAssetCategorization_SetObservers(
      Set<String> newObservers) {
    return createAndExerciseAssetCategorization_SetObservers(new AssetCategorization_SetObservers(newObservers));
  }

  public static CreateCommand create(Id id, String assetType, String assetClass,
      Set<String> observers) {
    return new AssetCategorization(id, assetType, assetClass, observers).create();
  }

  public static AssetCategorization fromValue(Value value$) throws IllegalArgumentException {
    Value recordValue$ = value$;
    DamlRecord record$ = recordValue$.asRecord().orElseThrow(() -> new IllegalArgumentException("Contracts must be constructed from Records"));
    List<DamlRecord.Field> fields$ = record$.getFields();
    int numberOfFields = fields$.size();
    if (numberOfFields != 4) {
      throw new IllegalArgumentException("Expected 4 arguments, got " + numberOfFields);
    }
    Id id = Id.fromValue(fields$.get(0).getValue());
    String assetType = fields$.get(1).getValue().asText().orElseThrow(() -> new IllegalArgumentException("Expected assetType to be of type com.daml.ledger.javaapi.data.Text")).getValue();
    String assetClass = fields$.get(2).getValue().asText().orElseThrow(() -> new IllegalArgumentException("Expected assetClass to be of type com.daml.ledger.javaapi.data.Text")).getValue();
    Set<String> observers = Set.<java.lang.String>fromValue(fields$.get(3).getValue(), v$0 -> v$0.asParty().orElseThrow(() -> new IllegalArgumentException("Expected observers to be of type com.daml.ledger.javaapi.data.Party")).getValue());
    return new com.daml.generated.da.finance.asset.AssetCategorization(id, assetType, assetClass, observers);
  }

  public DamlRecord toValue() {
    ArrayList<DamlRecord.Field> fields = new ArrayList<DamlRecord.Field>(4);
    fields.add(new DamlRecord.Field("id", this.id.toValue()));
    fields.add(new DamlRecord.Field("assetType", new Text(this.assetType)));
    fields.add(new DamlRecord.Field("assetClass", new Text(this.assetClass)));
    fields.add(new DamlRecord.Field("observers", this.observers.toValue(v$0 -> new Party(v$0))));
    return new DamlRecord(fields);
  }

  @Override
  public boolean equals(Object object) {
    if (this == object) {
      return true;
    }
    if (object == null) {
      return false;
    }
    if (!(object instanceof AssetCategorization)) {
      return false;
    }
    AssetCategorization other = (AssetCategorization) object;
    return this.id.equals(other.id) && this.assetType.equals(other.assetType) && this.assetClass.equals(other.assetClass) && this.observers.equals(other.observers);
  }

  @Override
  public int hashCode() {
    return Objects.hash(this.id, this.assetType, this.assetClass, this.observers);
  }

  @Override
  public String toString() {
    return String.format("com.daml.generated.da.finance.asset.AssetCategorization(%s, %s, %s, %s)", this.id, this.assetType, this.assetClass, this.observers);
  }

  public static final class ContractId extends com.daml.ledger.javaapi.data.codegen.ContractId<AssetCategorization> {
    public ContractId(String contractId) {
      super(contractId);
    }

    public ExerciseCommand exerciseArchive(Archive arg) {
      Value argValue = arg.toValue();
      return new ExerciseCommand(AssetCategorization.TEMPLATE_ID, this.contractId, "Archive", argValue);
    }

    public ExerciseCommand exerciseAssetCategorization_SetObservers(
        AssetCategorization_SetObservers arg) {
      Value argValue = arg.toValue();
      return new ExerciseCommand(AssetCategorization.TEMPLATE_ID, this.contractId, "AssetCategorization_SetObservers", argValue);
    }

    public ExerciseCommand exerciseAssetCategorization_SetObservers(Set<String> newObservers) {
      return exerciseAssetCategorization_SetObservers(new AssetCategorization_SetObservers(newObservers));
    }
  }

  public static class Contract implements com.daml.ledger.javaapi.data.Contract {
    public final ContractId id;

    public final AssetCategorization data;

    public final Optional<String> agreementText;

    public final java.util.Set<String> signatories;

    public final java.util.Set<String> observers;

    public Contract(ContractId id, AssetCategorization data, Optional<String> agreementText,
        java.util.Set<String> signatories, java.util.Set<String> observers) {
      this.id = id;
      this.data = data;
      this.agreementText = agreementText;
      this.signatories = signatories;
      this.observers = observers;
    }

    public static Contract fromIdAndRecord(String contractId, DamlRecord record$,
        Optional<String> agreementText, java.util.Set<String> signatories,
        java.util.Set<String> observers) {
      ContractId id = new ContractId(contractId);
      AssetCategorization data = AssetCategorization.fromValue(record$);
      return new Contract(id, data, agreementText, signatories, observers);
    }

    @Deprecated
    public static Contract fromIdAndRecord(String contractId, DamlRecord record$) {
      ContractId id = new ContractId(contractId);
      AssetCategorization data = AssetCategorization.fromValue(record$);
      return new Contract(id, data, Optional.empty(), Collections.emptySet(), Collections.emptySet());
    }

    public static Contract fromCreatedEvent(CreatedEvent event) {
      return fromIdAndRecord(event.getContractId(), event.getArguments(), event.getAgreementText(), event.getSignatories(), event.getObservers());
    }

    @Override
    public boolean equals(Object object) {
      if (this == object) {
        return true;
      }
      if (object == null) {
        return false;
      }
      if (!(object instanceof Contract)) {
        return false;
      }
      Contract other = (Contract) object;
      return this.id.equals(other.id) && this.data.equals(other.data) && this.agreementText.equals(other.agreementText) && this.signatories.equals(other.signatories) && this.observers.equals(other.observers);
    }

    @Override
    public int hashCode() {
      return Objects.hash(this.id, this.data, this.agreementText, this.signatories, this.observers);
    }

    @Override
    public String toString() {
      return String.format("com.daml.generated.da.finance.asset.AssetCategorization.Contract(%s, %s, %s, %s, %s)", this.id, this.data, this.agreementText, this.signatories, this.observers);
    }
  }
}
