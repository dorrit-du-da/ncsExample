package com.daml.generated.da.finance.base.rollconvention;

import com.daml.ledger.javaapi.data.Value;
import com.daml.ledger.javaapi.data.Variant;
import java.lang.String;

public abstract class RollConventionEnum {
  public static final String _packageId = "636e6e778aedec0710919591e9cb2a9404d6daab0581e4ddc515eeae03256f45";

  public RollConventionEnum() {
  }

  public abstract Value toValue();

  public static RollConventionEnum fromValue(Value value$) {
    Variant variant$ = value$.asVariant().orElseThrow(() -> new IllegalArgumentException("Expected Variant to build an instance of the Variant com.daml.generated.da.finance.base.rollconvention.RollConventionEnum"));
    if ("EOM".equals(variant$.getConstructor())) {
      return com.daml.generated.da.finance.base.rollconvention.rollconventionenum.EOM.fromValue(variant$);
    }
    if ("DOM".equals(variant$.getConstructor())) {
      return com.daml.generated.da.finance.base.rollconvention.rollconventionenum.DOM.fromValue(variant$);
    }
    throw new IllegalArgumentException("Found unknown constructor variant$.getConstructor() for variant com.daml.generated.da.finance.base.rollconvention.RollConventionEnum, expected one of [EOM, DOM]");
  }
}
