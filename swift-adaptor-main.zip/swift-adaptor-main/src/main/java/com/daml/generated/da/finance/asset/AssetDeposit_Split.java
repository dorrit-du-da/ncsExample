package com.daml.generated.da.finance.asset;

import com.daml.ledger.javaapi.data.DamlCollectors;
import com.daml.ledger.javaapi.data.DamlRecord;
import com.daml.ledger.javaapi.data.Numeric;
import com.daml.ledger.javaapi.data.Value;
import java.lang.IllegalArgumentException;
import java.lang.Object;
import java.lang.Override;
import java.lang.String;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

public class AssetDeposit_Split {
  public static final String _packageId = "636e6e778aedec0710919591e9cb2a9404d6daab0581e4ddc515eeae03256f45";

  public final List<BigDecimal> quantities;

  public AssetDeposit_Split(List<BigDecimal> quantities) {
    this.quantities = quantities;
  }

  public static AssetDeposit_Split fromValue(Value value$) throws IllegalArgumentException {
    Value recordValue$ = value$;
    DamlRecord record$ = recordValue$.asRecord().orElseThrow(() -> new IllegalArgumentException("Contracts must be constructed from Records"));
    List<DamlRecord.Field> fields$ = record$.getFields();
    int numberOfFields = fields$.size();
    if (numberOfFields != 1) {
      throw new IllegalArgumentException("Expected 1 arguments, got " + numberOfFields);
    }
    List<BigDecimal> quantities = fields$.get(0).getValue().asList()
            .map(v$0 -> v$0.toList(v$1 ->
                v$1.asNumeric().orElseThrow(() -> new IllegalArgumentException("Expected v$1 to be of type com.daml.ledger.javaapi.data.Numeric")).getValue()
            ))
            .orElseThrow(() -> new IllegalArgumentException("Expected quantities to be of type com.daml.ledger.javaapi.data.DamlList"))
        ;
    return new com.daml.generated.da.finance.asset.AssetDeposit_Split(quantities);
  }

  public DamlRecord toValue() {
    ArrayList<DamlRecord.Field> fields = new ArrayList<DamlRecord.Field>(1);
    fields.add(new DamlRecord.Field("quantities", this.quantities.stream().collect(DamlCollectors.toDamlList(v$0 -> new Numeric(v$0)))));
    return new DamlRecord(fields);
  }

  @Override
  public boolean equals(Object object) {
    if (this == object) {
      return true;
    }
    if (object == null) {
      return false;
    }
    if (!(object instanceof AssetDeposit_Split)) {
      return false;
    }
    AssetDeposit_Split other = (AssetDeposit_Split) object;
    return this.quantities.equals(other.quantities);
  }

  @Override
  public int hashCode() {
    return Objects.hash(this.quantities);
  }

  @Override
  public String toString() {
    return String.format("com.daml.generated.da.finance.asset.AssetDeposit_Split(%s)", this.quantities);
  }
}
