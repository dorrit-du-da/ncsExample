package com.daml.generated.da.finance.instrument.equity.option;

import com.daml.ledger.javaapi.data.DamlEnum;
import com.daml.ledger.javaapi.data.Value;
import java.lang.IllegalArgumentException;
import java.lang.String;
import java.util.HashMap;
import java.util.Map;

public enum SettlementType {
  CASH,

  PHYSICAL;

  private static final DamlEnum[] __values$ = {new DamlEnum("CASH"), new DamlEnum("PHYSICAL")};

  private static final Map<String, SettlementType> __enums$ = SettlementType.__buildEnumsMap$();

  private static final Map<String, SettlementType> __buildEnumsMap$() {
    Map<String, SettlementType> m = new HashMap<String, SettlementType>();
    m.put("CASH", CASH);
    m.put("PHYSICAL", PHYSICAL);
    return m;
  }

  public static final SettlementType fromValue(Value value$) {
    String constructor$ = value$.asEnum().orElseThrow(() -> new IllegalArgumentException("Expected DamlEnum to build an instance of the Enum SettlementType")).getConstructor();
    if (!SettlementType.__enums$.containsKey(constructor$)) throw new IllegalArgumentException("Expected a DamlEnum with SettlementType constructor, found " + constructor$);
    return (SettlementType) SettlementType.__enums$.get(constructor$);
  }

  public final DamlEnum toValue() {
    return SettlementType.__values$[ordinal()];
  }
}
