package com.daml.generated.marketplace.distribution.syndication.distributor;

import com.daml.generated.da.internal.template.Archive;
import com.daml.generated.da.types.Tuple2;
import com.daml.generated.marketplace.distribution.syndication.bidding.service.Service;
import com.daml.generated.marketplace.distribution.syndication.bookbuilding.service.Request;
import com.daml.ledger.javaapi.data.CreateAndExerciseCommand;
import com.daml.ledger.javaapi.data.CreateCommand;
import com.daml.ledger.javaapi.data.CreatedEvent;
import com.daml.ledger.javaapi.data.DamlRecord;
import com.daml.ledger.javaapi.data.ExerciseByKeyCommand;
import com.daml.ledger.javaapi.data.ExerciseCommand;
import com.daml.ledger.javaapi.data.Identifier;
import com.daml.ledger.javaapi.data.Party;
import com.daml.ledger.javaapi.data.Template;
import com.daml.ledger.javaapi.data.Value;
import java.lang.Deprecated;
import java.lang.IllegalArgumentException;
import java.lang.Object;
import java.lang.Override;
import java.lang.String;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.Set;

public final class Role extends Template {
  public static final Identifier TEMPLATE_ID = new Identifier("636e6e778aedec0710919591e9cb2a9404d6daab0581e4ddc515eeae03256f45", "Marketplace.Distribution.Syndication.Distributor", "Role");

  public final String operator;

  public final String provider;

  public Role(String operator, String provider) {
    this.operator = operator;
    this.provider = provider;
  }

  public CreateCommand create() {
    return new CreateCommand(Role.TEMPLATE_ID, this.toValue());
  }

  public static ExerciseByKeyCommand exerciseByKeyApproveBookBuildingRequest(
      Tuple2<String, String> key, ApproveBookBuildingRequest arg) {
    return new ExerciseByKeyCommand(Role.TEMPLATE_ID, key.toValue(v$0 -> new Party(v$0),v$1 -> new Party(v$1)), "ApproveBookBuildingRequest", arg.toValue());
  }

  public static ExerciseByKeyCommand exerciseByKeyApproveBookBuildingRequest(
      Tuple2<String, String> key, Request.ContractId bookBuildingRequestCid) {
    return Role.exerciseByKeyApproveBookBuildingRequest(key, new ApproveBookBuildingRequest(bookBuildingRequestCid));
  }

  public static ExerciseByKeyCommand exerciseByKeyTerminateBiddingService(
      Tuple2<String, String> key, TerminateBiddingService arg) {
    return new ExerciseByKeyCommand(Role.TEMPLATE_ID, key.toValue(v$0 -> new Party(v$0),v$1 -> new Party(v$1)), "TerminateBiddingService", arg.toValue());
  }

  public static ExerciseByKeyCommand exerciseByKeyTerminateBiddingService(
      Tuple2<String, String> key, Service.ContractId biddingServiceCid) {
    return Role.exerciseByKeyTerminateBiddingService(key, new TerminateBiddingService(biddingServiceCid));
  }

  public static ExerciseByKeyCommand exerciseByKeyApproveBiddingRequest(Tuple2<String, String> key,
      ApproveBiddingRequest arg) {
    return new ExerciseByKeyCommand(Role.TEMPLATE_ID, key.toValue(v$0 -> new Party(v$0),v$1 -> new Party(v$1)), "ApproveBiddingRequest", arg.toValue());
  }

  public static ExerciseByKeyCommand exerciseByKeyApproveBiddingRequest(Tuple2<String, String> key,
      com.daml.generated.marketplace.distribution.syndication.bidding.service.Request.ContractId biddingRequestCid) {
    return Role.exerciseByKeyApproveBiddingRequest(key, new ApproveBiddingRequest(biddingRequestCid));
  }

  public static ExerciseByKeyCommand exerciseByKeyOfferBiddingService(Tuple2<String, String> key,
      OfferBiddingService arg) {
    return new ExerciseByKeyCommand(Role.TEMPLATE_ID, key.toValue(v$0 -> new Party(v$0),v$1 -> new Party(v$1)), "OfferBiddingService", arg.toValue());
  }

  public static ExerciseByKeyCommand exerciseByKeyOfferBiddingService(Tuple2<String, String> key,
      String customer) {
    return Role.exerciseByKeyOfferBiddingService(key, new OfferBiddingService(customer));
  }

  public static ExerciseByKeyCommand exerciseByKeyTerminateRole(Tuple2<String, String> key,
      TerminateRole arg) {
    return new ExerciseByKeyCommand(Role.TEMPLATE_ID, key.toValue(v$0 -> new Party(v$0),v$1 -> new Party(v$1)), "TerminateRole", arg.toValue());
  }

  public static ExerciseByKeyCommand exerciseByKeyTerminateRole(Tuple2<String, String> key) {
    return Role.exerciseByKeyTerminateRole(key, new TerminateRole());
  }

  public static ExerciseByKeyCommand exerciseByKeyTerminateBookBuildingService(
      Tuple2<String, String> key, TerminateBookBuildingService arg) {
    return new ExerciseByKeyCommand(Role.TEMPLATE_ID, key.toValue(v$0 -> new Party(v$0),v$1 -> new Party(v$1)), "TerminateBookBuildingService", arg.toValue());
  }

  public static ExerciseByKeyCommand exerciseByKeyTerminateBookBuildingService(
      Tuple2<String, String> key,
      com.daml.generated.marketplace.distribution.syndication.bookbuilding.service.Service.ContractId bookBuildingServiceCid) {
    return Role.exerciseByKeyTerminateBookBuildingService(key, new TerminateBookBuildingService(bookBuildingServiceCid));
  }

  public static ExerciseByKeyCommand exerciseByKeyArchive(Tuple2<String, String> key, Archive arg) {
    return new ExerciseByKeyCommand(Role.TEMPLATE_ID, key.toValue(v$0 -> new Party(v$0),v$1 -> new Party(v$1)), "Archive", arg.toValue());
  }

  public static ExerciseByKeyCommand exerciseByKeyOfferBookBuildingService(
      Tuple2<String, String> key, OfferBookBuildingService arg) {
    return new ExerciseByKeyCommand(Role.TEMPLATE_ID, key.toValue(v$0 -> new Party(v$0),v$1 -> new Party(v$1)), "OfferBookBuildingService", arg.toValue());
  }

  public static ExerciseByKeyCommand exerciseByKeyOfferBookBuildingService(
      Tuple2<String, String> key, String customer) {
    return Role.exerciseByKeyOfferBookBuildingService(key, new OfferBookBuildingService(customer));
  }

  public CreateAndExerciseCommand createAndExerciseApproveBookBuildingRequest(
      ApproveBookBuildingRequest arg) {
    Value argValue = arg.toValue();
    return new CreateAndExerciseCommand(Role.TEMPLATE_ID, this.toValue(), "ApproveBookBuildingRequest", argValue);
  }

  public CreateAndExerciseCommand createAndExerciseApproveBookBuildingRequest(
      Request.ContractId bookBuildingRequestCid) {
    return createAndExerciseApproveBookBuildingRequest(new ApproveBookBuildingRequest(bookBuildingRequestCid));
  }

  public CreateAndExerciseCommand createAndExerciseTerminateBiddingService(
      TerminateBiddingService arg) {
    Value argValue = arg.toValue();
    return new CreateAndExerciseCommand(Role.TEMPLATE_ID, this.toValue(), "TerminateBiddingService", argValue);
  }

  public CreateAndExerciseCommand createAndExerciseTerminateBiddingService(
      Service.ContractId biddingServiceCid) {
    return createAndExerciseTerminateBiddingService(new TerminateBiddingService(biddingServiceCid));
  }

  public CreateAndExerciseCommand createAndExerciseApproveBiddingRequest(
      ApproveBiddingRequest arg) {
    Value argValue = arg.toValue();
    return new CreateAndExerciseCommand(Role.TEMPLATE_ID, this.toValue(), "ApproveBiddingRequest", argValue);
  }

  public CreateAndExerciseCommand createAndExerciseApproveBiddingRequest(
      com.daml.generated.marketplace.distribution.syndication.bidding.service.Request.ContractId biddingRequestCid) {
    return createAndExerciseApproveBiddingRequest(new ApproveBiddingRequest(biddingRequestCid));
  }

  public CreateAndExerciseCommand createAndExerciseOfferBiddingService(OfferBiddingService arg) {
    Value argValue = arg.toValue();
    return new CreateAndExerciseCommand(Role.TEMPLATE_ID, this.toValue(), "OfferBiddingService", argValue);
  }

  public CreateAndExerciseCommand createAndExerciseOfferBiddingService(String customer) {
    return createAndExerciseOfferBiddingService(new OfferBiddingService(customer));
  }

  public CreateAndExerciseCommand createAndExerciseTerminateRole(TerminateRole arg) {
    Value argValue = arg.toValue();
    return new CreateAndExerciseCommand(Role.TEMPLATE_ID, this.toValue(), "TerminateRole", argValue);
  }

  public CreateAndExerciseCommand createAndExerciseTerminateRole() {
    return createAndExerciseTerminateRole(new TerminateRole());
  }

  public CreateAndExerciseCommand createAndExerciseTerminateBookBuildingService(
      TerminateBookBuildingService arg) {
    Value argValue = arg.toValue();
    return new CreateAndExerciseCommand(Role.TEMPLATE_ID, this.toValue(), "TerminateBookBuildingService", argValue);
  }

  public CreateAndExerciseCommand createAndExerciseTerminateBookBuildingService(
      com.daml.generated.marketplace.distribution.syndication.bookbuilding.service.Service.ContractId bookBuildingServiceCid) {
    return createAndExerciseTerminateBookBuildingService(new TerminateBookBuildingService(bookBuildingServiceCid));
  }

  public CreateAndExerciseCommand createAndExerciseArchive(Archive arg) {
    Value argValue = arg.toValue();
    return new CreateAndExerciseCommand(Role.TEMPLATE_ID, this.toValue(), "Archive", argValue);
  }

  public CreateAndExerciseCommand createAndExerciseOfferBookBuildingService(
      OfferBookBuildingService arg) {
    Value argValue = arg.toValue();
    return new CreateAndExerciseCommand(Role.TEMPLATE_ID, this.toValue(), "OfferBookBuildingService", argValue);
  }

  public CreateAndExerciseCommand createAndExerciseOfferBookBuildingService(String customer) {
    return createAndExerciseOfferBookBuildingService(new OfferBookBuildingService(customer));
  }

  public static CreateCommand create(String operator, String provider) {
    return new Role(operator, provider).create();
  }

  public static Role fromValue(Value value$) throws IllegalArgumentException {
    Value recordValue$ = value$;
    DamlRecord record$ = recordValue$.asRecord().orElseThrow(() -> new IllegalArgumentException("Contracts must be constructed from Records"));
    List<DamlRecord.Field> fields$ = record$.getFields();
    int numberOfFields = fields$.size();
    if (numberOfFields != 2) {
      throw new IllegalArgumentException("Expected 2 arguments, got " + numberOfFields);
    }
    String operator = fields$.get(0).getValue().asParty().orElseThrow(() -> new IllegalArgumentException("Expected operator to be of type com.daml.ledger.javaapi.data.Party")).getValue();
    String provider = fields$.get(1).getValue().asParty().orElseThrow(() -> new IllegalArgumentException("Expected provider to be of type com.daml.ledger.javaapi.data.Party")).getValue();
    return new com.daml.generated.marketplace.distribution.syndication.distributor.Role(operator, provider);
  }

  public DamlRecord toValue() {
    ArrayList<DamlRecord.Field> fields = new ArrayList<DamlRecord.Field>(2);
    fields.add(new DamlRecord.Field("operator", new Party(this.operator)));
    fields.add(new DamlRecord.Field("provider", new Party(this.provider)));
    return new DamlRecord(fields);
  }

  @Override
  public boolean equals(Object object) {
    if (this == object) {
      return true;
    }
    if (object == null) {
      return false;
    }
    if (!(object instanceof Role)) {
      return false;
    }
    Role other = (Role) object;
    return this.operator.equals(other.operator) && this.provider.equals(other.provider);
  }

  @Override
  public int hashCode() {
    return Objects.hash(this.operator, this.provider);
  }

  @Override
  public String toString() {
    return String.format("com.daml.generated.marketplace.distribution.syndication.distributor.Role(%s, %s)", this.operator, this.provider);
  }

  public static final class ContractId extends com.daml.ledger.javaapi.data.codegen.ContractId<Role> {
    public ContractId(String contractId) {
      super(contractId);
    }

    public ExerciseCommand exerciseApproveBookBuildingRequest(ApproveBookBuildingRequest arg) {
      Value argValue = arg.toValue();
      return new ExerciseCommand(Role.TEMPLATE_ID, this.contractId, "ApproveBookBuildingRequest", argValue);
    }

    public ExerciseCommand exerciseApproveBookBuildingRequest(
        Request.ContractId bookBuildingRequestCid) {
      return exerciseApproveBookBuildingRequest(new ApproveBookBuildingRequest(bookBuildingRequestCid));
    }

    public ExerciseCommand exerciseTerminateBiddingService(TerminateBiddingService arg) {
      Value argValue = arg.toValue();
      return new ExerciseCommand(Role.TEMPLATE_ID, this.contractId, "TerminateBiddingService", argValue);
    }

    public ExerciseCommand exerciseTerminateBiddingService(Service.ContractId biddingServiceCid) {
      return exerciseTerminateBiddingService(new TerminateBiddingService(biddingServiceCid));
    }

    public ExerciseCommand exerciseApproveBiddingRequest(ApproveBiddingRequest arg) {
      Value argValue = arg.toValue();
      return new ExerciseCommand(Role.TEMPLATE_ID, this.contractId, "ApproveBiddingRequest", argValue);
    }

    public ExerciseCommand exerciseApproveBiddingRequest(
        com.daml.generated.marketplace.distribution.syndication.bidding.service.Request.ContractId biddingRequestCid) {
      return exerciseApproveBiddingRequest(new ApproveBiddingRequest(biddingRequestCid));
    }

    public ExerciseCommand exerciseOfferBiddingService(OfferBiddingService arg) {
      Value argValue = arg.toValue();
      return new ExerciseCommand(Role.TEMPLATE_ID, this.contractId, "OfferBiddingService", argValue);
    }

    public ExerciseCommand exerciseOfferBiddingService(String customer) {
      return exerciseOfferBiddingService(new OfferBiddingService(customer));
    }

    public ExerciseCommand exerciseTerminateRole(TerminateRole arg) {
      Value argValue = arg.toValue();
      return new ExerciseCommand(Role.TEMPLATE_ID, this.contractId, "TerminateRole", argValue);
    }

    public ExerciseCommand exerciseTerminateRole() {
      return exerciseTerminateRole(new TerminateRole());
    }

    public ExerciseCommand exerciseTerminateBookBuildingService(TerminateBookBuildingService arg) {
      Value argValue = arg.toValue();
      return new ExerciseCommand(Role.TEMPLATE_ID, this.contractId, "TerminateBookBuildingService", argValue);
    }

    public ExerciseCommand exerciseTerminateBookBuildingService(
        com.daml.generated.marketplace.distribution.syndication.bookbuilding.service.Service.ContractId bookBuildingServiceCid) {
      return exerciseTerminateBookBuildingService(new TerminateBookBuildingService(bookBuildingServiceCid));
    }

    public ExerciseCommand exerciseArchive(Archive arg) {
      Value argValue = arg.toValue();
      return new ExerciseCommand(Role.TEMPLATE_ID, this.contractId, "Archive", argValue);
    }

    public ExerciseCommand exerciseOfferBookBuildingService(OfferBookBuildingService arg) {
      Value argValue = arg.toValue();
      return new ExerciseCommand(Role.TEMPLATE_ID, this.contractId, "OfferBookBuildingService", argValue);
    }

    public ExerciseCommand exerciseOfferBookBuildingService(String customer) {
      return exerciseOfferBookBuildingService(new OfferBookBuildingService(customer));
    }
  }

  public static class Contract implements com.daml.ledger.javaapi.data.Contract {
    public final ContractId id;

    public final Role data;

    public final Optional<String> agreementText;

    public final Optional<Tuple2<String, String>> key;

    public final Set<String> signatories;

    public final Set<String> observers;

    public Contract(ContractId id, Role data, Optional<String> agreementText,
        Optional<Tuple2<String, String>> key, Set<String> signatories, Set<String> observers) {
      this.id = id;
      this.data = data;
      this.agreementText = agreementText;
      this.key = key;
      this.signatories = signatories;
      this.observers = observers;
    }

    public static Contract fromIdAndRecord(String contractId, DamlRecord record$,
        Optional<String> agreementText, Optional<Tuple2<String, String>> key,
        Set<String> signatories, Set<String> observers) {
      ContractId id = new ContractId(contractId);
      Role data = Role.fromValue(record$);
      return new Contract(id, data, agreementText, key, signatories, observers);
    }

    @Deprecated
    public static Contract fromIdAndRecord(String contractId, DamlRecord record$) {
      ContractId id = new ContractId(contractId);
      Role data = Role.fromValue(record$);
      return new Contract(id, data, Optional.empty(), Optional.empty(), Collections.emptySet(), Collections.emptySet());
    }

    public static Contract fromCreatedEvent(CreatedEvent event) {
      return fromIdAndRecord(event.getContractId(), event.getArguments(), event.getAgreementText(), event.getContractKey().map(e -> Tuple2.<java.lang.String, java.lang.String>fromValue(e, v$0 -> v$0.asParty().orElseThrow(() -> new IllegalArgumentException("Expected e to be of type com.daml.ledger.javaapi.data.Party")).getValue(), v$1 -> v$1.asParty().orElseThrow(() -> new IllegalArgumentException("Expected e to be of type com.daml.ledger.javaapi.data.Party")).getValue())), event.getSignatories(), event.getObservers());
    }

    @Override
    public boolean equals(Object object) {
      if (this == object) {
        return true;
      }
      if (object == null) {
        return false;
      }
      if (!(object instanceof Contract)) {
        return false;
      }
      Contract other = (Contract) object;
      return this.id.equals(other.id) && this.data.equals(other.data) && this.agreementText.equals(other.agreementText) && this.key.equals(other.key) && this.signatories.equals(other.signatories) && this.observers.equals(other.observers);
    }

    @Override
    public int hashCode() {
      return Objects.hash(this.id, this.data, this.agreementText, this.key, this.signatories, this.observers);
    }

    @Override
    public String toString() {
      return String.format("com.daml.generated.marketplace.distribution.syndication.distributor.Role.Contract(%s, %s, %s, %s, %s, %s)", this.id, this.data, this.agreementText, this.key, this.signatories, this.observers);
    }
  }
}
