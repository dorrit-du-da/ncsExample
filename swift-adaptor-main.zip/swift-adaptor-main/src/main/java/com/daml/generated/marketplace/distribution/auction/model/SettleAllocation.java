package com.daml.generated.marketplace.distribution.auction.model;

import com.daml.generated.da.finance.types.Account;
import com.daml.ledger.javaapi.data.DamlRecord;
import com.daml.ledger.javaapi.data.Numeric;
import com.daml.ledger.javaapi.data.Party;
import com.daml.ledger.javaapi.data.Value;
import java.lang.IllegalArgumentException;
import java.lang.Object;
import java.lang.Override;
import java.lang.String;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

public class SettleAllocation {
  public static final String _packageId = "636e6e778aedec0710919591e9cb2a9404d6daab0581e4ddc515eeae03256f45";

  public final Allocation allocation;

  public final BigDecimal price;

  public final String issuer;

  public final Account issuerReceivableAccount;

  public SettleAllocation(Allocation allocation, BigDecimal price, String issuer,
      Account issuerReceivableAccount) {
    this.allocation = allocation;
    this.price = price;
    this.issuer = issuer;
    this.issuerReceivableAccount = issuerReceivableAccount;
  }

  public static SettleAllocation fromValue(Value value$) throws IllegalArgumentException {
    Value recordValue$ = value$;
    DamlRecord record$ = recordValue$.asRecord().orElseThrow(() -> new IllegalArgumentException("Contracts must be constructed from Records"));
    List<DamlRecord.Field> fields$ = record$.getFields();
    int numberOfFields = fields$.size();
    if (numberOfFields != 4) {
      throw new IllegalArgumentException("Expected 4 arguments, got " + numberOfFields);
    }
    Allocation allocation = Allocation.fromValue(fields$.get(0).getValue());
    BigDecimal price = fields$.get(1).getValue().asNumeric().orElseThrow(() -> new IllegalArgumentException("Expected price to be of type com.daml.ledger.javaapi.data.Numeric")).getValue();
    String issuer = fields$.get(2).getValue().asParty().orElseThrow(() -> new IllegalArgumentException("Expected issuer to be of type com.daml.ledger.javaapi.data.Party")).getValue();
    Account issuerReceivableAccount = Account.fromValue(fields$.get(3).getValue());
    return new com.daml.generated.marketplace.distribution.auction.model.SettleAllocation(allocation, price, issuer, issuerReceivableAccount);
  }

  public DamlRecord toValue() {
    ArrayList<DamlRecord.Field> fields = new ArrayList<DamlRecord.Field>(4);
    fields.add(new DamlRecord.Field("allocation", this.allocation.toValue()));
    fields.add(new DamlRecord.Field("price", new Numeric(this.price)));
    fields.add(new DamlRecord.Field("issuer", new Party(this.issuer)));
    fields.add(new DamlRecord.Field("issuerReceivableAccount", this.issuerReceivableAccount.toValue()));
    return new DamlRecord(fields);
  }

  @Override
  public boolean equals(Object object) {
    if (this == object) {
      return true;
    }
    if (object == null) {
      return false;
    }
    if (!(object instanceof SettleAllocation)) {
      return false;
    }
    SettleAllocation other = (SettleAllocation) object;
    return this.allocation.equals(other.allocation) && this.price.equals(other.price) && this.issuer.equals(other.issuer) && this.issuerReceivableAccount.equals(other.issuerReceivableAccount);
  }

  @Override
  public int hashCode() {
    return Objects.hash(this.allocation, this.price, this.issuer, this.issuerReceivableAccount);
  }

  @Override
  public String toString() {
    return String.format("com.daml.generated.marketplace.distribution.auction.model.SettleAllocation(%s, %s, %s, %s)", this.allocation, this.price, this.issuer, this.issuerReceivableAccount);
  }
}
