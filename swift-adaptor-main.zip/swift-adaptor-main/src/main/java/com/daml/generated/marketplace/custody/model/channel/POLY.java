package com.daml.generated.marketplace.custody.model.channel;

import com.daml.generated.marketplace.custody.model.Channel;
import com.daml.ledger.javaapi.data.DamlRecord;
import com.daml.ledger.javaapi.data.Text;
import com.daml.ledger.javaapi.data.Value;
import com.daml.ledger.javaapi.data.Variant;
import java.lang.IllegalArgumentException;
import java.lang.Object;
import java.lang.Override;
import java.lang.String;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

public class POLY extends Channel {
  public static final String _packageId = "636e6e778aedec0710919591e9cb2a9404d6daab0581e4ddc515eeae03256f45";

  public final String coin;

  public final String address;

  public POLY(String coin, String address) {
    this.coin = coin;
    this.address = address;
  }

  public Variant toValue() {
    ArrayList<DamlRecord.Field> fields = new ArrayList<DamlRecord.Field>(2);
    fields.add(new DamlRecord.Field("coin", new Text(this.coin)));
    fields.add(new DamlRecord.Field("address", new Text(this.address)));
    return new Variant("POLY", new DamlRecord(fields));
  }

  public static POLY fromValue(Value value$) throws IllegalArgumentException {
    Variant variant$ = value$.asVariant().orElseThrow(() -> new IllegalArgumentException("Expected: Variant. Actual: " + value$.getClass().getName()));
    if (!"POLY".equals(variant$.getConstructor())) throw new IllegalArgumentException("Invalid constructor. Expected: POLY. Actual: " + variant$.getConstructor());
    Value recordValue$ = variant$.getValue();
    DamlRecord record$ = recordValue$.asRecord().orElseThrow(() -> new IllegalArgumentException("Contracts must be constructed from Records"));
    List<DamlRecord.Field> fields$ = record$.getFields();
    int numberOfFields = fields$.size();
    if (numberOfFields != 2) {
      throw new IllegalArgumentException("Expected 2 arguments, got " + numberOfFields);
    }
    String coin = fields$.get(0).getValue().asText().orElseThrow(() -> new IllegalArgumentException("Expected coin to be of type com.daml.ledger.javaapi.data.Text")).getValue();
    String address = fields$.get(1).getValue().asText().orElseThrow(() -> new IllegalArgumentException("Expected address to be of type com.daml.ledger.javaapi.data.Text")).getValue();
    return new POLY(coin, address);
  }

  @Override
  public boolean equals(Object object) {
    if (this == object) {
      return true;
    }
    if (object == null) {
      return false;
    }
    if (!(object instanceof POLY)) {
      return false;
    }
    POLY other = (POLY) object;
    return this.coin.equals(other.coin) && this.address.equals(other.address);
  }

  @Override
  public int hashCode() {
    return Objects.hash(this.coin, this.address);
  }

  @Override
  public String toString() {
    return String.format("POLY(%s, %s)", this.coin, this.address);
  }
}
