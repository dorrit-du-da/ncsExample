package com.daml.generated.contingentclaims.observation.observationf;

import com.daml.generated.contingentclaims.observation.ObservationF;
import com.daml.ledger.javaapi.data.DamlRecord;
import com.daml.ledger.javaapi.data.Value;
import com.daml.ledger.javaapi.data.Variant;
import java.lang.IllegalArgumentException;
import java.lang.Object;
import java.lang.Override;
import java.lang.String;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.function.Function;

public class ConstF<t, x, b> extends ObservationF<t, x, b> {
  public static final String _packageId = "636e6e778aedec0710919591e9cb2a9404d6daab0581e4ddc515eeae03256f45";

  public final x value;

  public ConstF(x value) {
    this.value = value;
  }

  public Variant toValue(Function<x, Value> toValuex) {
    ArrayList<DamlRecord.Field> fields = new ArrayList<DamlRecord.Field>(1);
    fields.add(new DamlRecord.Field("value", toValuex.apply(this.value)));
    return new Variant("ConstF", new DamlRecord(fields));
  }

  public static <t, x, b> ConstF<t, x, b> fromValue(Value value$, Function<Value, x> fromValuex)
      throws IllegalArgumentException {
    Variant variant$ = value$.asVariant().orElseThrow(() -> new IllegalArgumentException("Expected: Variant. Actual: " + value$.getClass().getName()));
    if (!"ConstF".equals(variant$.getConstructor())) throw new IllegalArgumentException("Invalid constructor. Expected: ConstF. Actual: " + variant$.getConstructor());
    Value recordValue$ = variant$.getValue();
    DamlRecord record$ = recordValue$.asRecord().orElseThrow(() -> new IllegalArgumentException("Contracts must be constructed from Records"));
    List<DamlRecord.Field> fields$ = record$.getFields();
    int numberOfFields = fields$.size();
    if (numberOfFields != 1) {
      throw new IllegalArgumentException("Expected 1 arguments, got " + numberOfFields);
    }
    x value = fromValuex.apply(fields$.get(0).getValue());
    return new ConstF<t, x, b>(value);
  }

  public Variant toValue(Function<t, Value> toValuet, Function<x, Value> toValuex,
      Function<b, Value> toValueb) {
    ArrayList<DamlRecord.Field> fields = new ArrayList<DamlRecord.Field>(1);
    fields.add(new DamlRecord.Field("value", toValuex.apply(this.value)));
    return new Variant("ConstF", new DamlRecord(fields));
  }

  public static <t, x, b> ConstF<t, x, b> fromValue(Value value$, Function<Value, t> fromValuet,
      Function<Value, x> fromValuex, Function<Value, b> fromValueb) throws
      IllegalArgumentException {
    Variant variant$ = value$.asVariant().orElseThrow(() -> new IllegalArgumentException("Expected: Variant. Actual: " + value$.getClass().getName()));
    if (!"ConstF".equals(variant$.getConstructor())) throw new IllegalArgumentException("Invalid constructor. Expected: ConstF. Actual: " + variant$.getConstructor());
    Value recordValue$ = variant$.getValue();
    DamlRecord record$ = recordValue$.asRecord().orElseThrow(() -> new IllegalArgumentException("Contracts must be constructed from Records"));
    List<DamlRecord.Field> fields$ = record$.getFields();
    int numberOfFields = fields$.size();
    if (numberOfFields != 1) {
      throw new IllegalArgumentException("Expected 1 arguments, got " + numberOfFields);
    }
    x value = fromValuex.apply(fields$.get(0).getValue());
    return new ConstF<t, x, b>(value);
  }

  @Override
  public boolean equals(Object object) {
    if (this == object) {
      return true;
    }
    if (object == null) {
      return false;
    }
    if (!(object instanceof ConstF<?, ?, ?>)) {
      return false;
    }
    ConstF<?, ?, ?> other = (ConstF<?, ?, ?>) object;
    return this.value.equals(other.value);
  }

  @Override
  public int hashCode() {
    return Objects.hash(this.value);
  }

  @Override
  public String toString() {
    return String.format("ConstF(%s)", this.value);
  }
}
