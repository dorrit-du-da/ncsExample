package com.daml.generated.marketplace.distribution.auction.bidding.model.status;

import com.daml.generated.marketplace.distribution.auction.bidding.model.Status;
import com.daml.ledger.javaapi.data.DamlRecord;
import com.daml.ledger.javaapi.data.Numeric;
import com.daml.ledger.javaapi.data.Value;
import com.daml.ledger.javaapi.data.Variant;
import java.lang.IllegalArgumentException;
import java.lang.Object;
import java.lang.Override;
import java.lang.String;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

public class FullAllocation extends Status {
  public static final String _packageId = "636e6e778aedec0710919591e9cb2a9404d6daab0581e4ddc515eeae03256f45";

  public final BigDecimal price;

  public FullAllocation(BigDecimal price) {
    this.price = price;
  }

  public Variant toValue() {
    ArrayList<DamlRecord.Field> fields = new ArrayList<DamlRecord.Field>(1);
    fields.add(new DamlRecord.Field("price", new Numeric(this.price)));
    return new Variant("FullAllocation", new DamlRecord(fields));
  }

  public static FullAllocation fromValue(Value value$) throws IllegalArgumentException {
    Variant variant$ = value$.asVariant().orElseThrow(() -> new IllegalArgumentException("Expected: Variant. Actual: " + value$.getClass().getName()));
    if (!"FullAllocation".equals(variant$.getConstructor())) throw new IllegalArgumentException("Invalid constructor. Expected: FullAllocation. Actual: " + variant$.getConstructor());
    Value recordValue$ = variant$.getValue();
    DamlRecord record$ = recordValue$.asRecord().orElseThrow(() -> new IllegalArgumentException("Contracts must be constructed from Records"));
    List<DamlRecord.Field> fields$ = record$.getFields();
    int numberOfFields = fields$.size();
    if (numberOfFields != 1) {
      throw new IllegalArgumentException("Expected 1 arguments, got " + numberOfFields);
    }
    BigDecimal price = fields$.get(0).getValue().asNumeric().orElseThrow(() -> new IllegalArgumentException("Expected price to be of type com.daml.ledger.javaapi.data.Numeric")).getValue();
    return new FullAllocation(price);
  }

  @Override
  public boolean equals(Object object) {
    if (this == object) {
      return true;
    }
    if (object == null) {
      return false;
    }
    if (!(object instanceof FullAllocation)) {
      return false;
    }
    FullAllocation other = (FullAllocation) object;
    return this.price.equals(other.price);
  }

  @Override
  public int hashCode() {
    return Objects.hash(this.price);
  }

  @Override
  public String toString() {
    return String.format("FullAllocation(%s)", this.price);
  }
}
