package com.daml.generated.da.finance.base.rollconvention;

import com.daml.ledger.javaapi.data.DamlRecord;
import com.daml.ledger.javaapi.data.Int64;
import com.daml.ledger.javaapi.data.Value;
import java.lang.IllegalArgumentException;
import java.lang.Long;
import java.lang.Object;
import java.lang.Override;
import java.lang.String;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

public class Period {
  public static final String _packageId = "636e6e778aedec0710919591e9cb2a9404d6daab0581e4ddc515eeae03256f45";

  public final PeriodEnum period;

  public final Long periodMultiplier;

  public Period(PeriodEnum period, Long periodMultiplier) {
    this.period = period;
    this.periodMultiplier = periodMultiplier;
  }

  public static Period fromValue(Value value$) throws IllegalArgumentException {
    Value recordValue$ = value$;
    DamlRecord record$ = recordValue$.asRecord().orElseThrow(() -> new IllegalArgumentException("Contracts must be constructed from Records"));
    List<DamlRecord.Field> fields$ = record$.getFields();
    int numberOfFields = fields$.size();
    if (numberOfFields != 2) {
      throw new IllegalArgumentException("Expected 2 arguments, got " + numberOfFields);
    }
    PeriodEnum period = PeriodEnum.fromValue(fields$.get(0).getValue());
    Long periodMultiplier = fields$.get(1).getValue().asInt64().orElseThrow(() -> new IllegalArgumentException("Expected periodMultiplier to be of type com.daml.ledger.javaapi.data.Int64")).getValue();
    return new com.daml.generated.da.finance.base.rollconvention.Period(period, periodMultiplier);
  }

  public DamlRecord toValue() {
    ArrayList<DamlRecord.Field> fields = new ArrayList<DamlRecord.Field>(2);
    fields.add(new DamlRecord.Field("period", this.period.toValue()));
    fields.add(new DamlRecord.Field("periodMultiplier", new Int64(this.periodMultiplier)));
    return new DamlRecord(fields);
  }

  @Override
  public boolean equals(Object object) {
    if (this == object) {
      return true;
    }
    if (object == null) {
      return false;
    }
    if (!(object instanceof Period)) {
      return false;
    }
    Period other = (Period) object;
    return this.period.equals(other.period) && this.periodMultiplier.equals(other.periodMultiplier);
  }

  @Override
  public int hashCode() {
    return Objects.hash(this.period, this.periodMultiplier);
  }

  @Override
  public String toString() {
    return String.format("com.daml.generated.da.finance.base.rollconvention.Period(%s, %s)", this.period, this.periodMultiplier);
  }
}
