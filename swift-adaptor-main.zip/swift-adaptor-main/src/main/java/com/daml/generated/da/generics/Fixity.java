package com.daml.generated.da.generics;

import com.daml.ledger.javaapi.data.Value;
import com.daml.ledger.javaapi.data.Variant;
import java.lang.String;

public abstract class Fixity {
  public static final String _packageId = "c0d4d4f403a005dd475fa9ffc964883444508dc762c7010507259956f2c5f2bd";

  public Fixity() {
  }

  public abstract Value toValue();

  public static Fixity fromValue(Value value$) {
    Variant variant$ = value$.asVariant().orElseThrow(() -> new IllegalArgumentException("Expected Variant to build an instance of the Variant com.daml.generated.da.generics.Fixity"));
    if ("Prefix".equals(variant$.getConstructor())) {
      return com.daml.generated.da.generics.fixity.Prefix.fromValue(variant$);
    }
    if ("Infix".equals(variant$.getConstructor())) {
      return com.daml.generated.da.generics.fixity.Infix.fromValue(variant$);
    }
    throw new IllegalArgumentException("Found unknown constructor variant$.getConstructor() for variant com.daml.generated.da.generics.Fixity, expected one of [Prefix, Infix]");
  }
}
