package com.daml.generated.marketplace.distribution.auction.bidding.model;

import com.daml.generated.da.finance.types.Asset;
import com.daml.generated.da.finance.types.Id;
import com.daml.generated.da.internal.template.Archive;
import com.daml.ledger.javaapi.data.CreateAndExerciseCommand;
import com.daml.ledger.javaapi.data.CreateCommand;
import com.daml.ledger.javaapi.data.CreatedEvent;
import com.daml.ledger.javaapi.data.DamlCollectors;
import com.daml.ledger.javaapi.data.DamlRecord;
import com.daml.ledger.javaapi.data.ExerciseCommand;
import com.daml.ledger.javaapi.data.Identifier;
import com.daml.ledger.javaapi.data.Party;
import com.daml.ledger.javaapi.data.Template;
import com.daml.ledger.javaapi.data.Text;
import com.daml.ledger.javaapi.data.Value;
import java.lang.Deprecated;
import java.lang.IllegalArgumentException;
import java.lang.Object;
import java.lang.Override;
import java.lang.String;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.Set;

public final class Auction extends Template {
  public static final Identifier TEMPLATE_ID = new Identifier("636e6e778aedec0710919591e9cb2a9404d6daab0581e4ddc515eeae03256f45", "Marketplace.Distribution.Auction.Bidding.Model", "Auction");

  public final String operator;

  public final String provider;

  public final String customer;

  public final String issuer;

  public final String auctionId;

  public final Asset asset;

  public final Id quotedAssetId;

  public final List<PublishedBid> publishedBids;

  public Auction(String operator, String provider, String customer, String issuer, String auctionId,
      Asset asset, Id quotedAssetId, List<PublishedBid> publishedBids) {
    this.operator = operator;
    this.provider = provider;
    this.customer = customer;
    this.issuer = issuer;
    this.auctionId = auctionId;
    this.asset = asset;
    this.quotedAssetId = quotedAssetId;
    this.publishedBids = publishedBids;
  }

  public CreateCommand create() {
    return new CreateCommand(Auction.TEMPLATE_ID, this.toValue());
  }

  public CreateAndExerciseCommand createAndExerciseArchive(Archive arg) {
    Value argValue = arg.toValue();
    return new CreateAndExerciseCommand(Auction.TEMPLATE_ID, this.toValue(), "Archive", argValue);
  }

  public static CreateCommand create(String operator, String provider, String customer,
      String issuer, String auctionId, Asset asset, Id quotedAssetId,
      List<PublishedBid> publishedBids) {
    return new Auction(operator, provider, customer, issuer, auctionId, asset, quotedAssetId, publishedBids).create();
  }

  public static Auction fromValue(Value value$) throws IllegalArgumentException {
    Value recordValue$ = value$;
    DamlRecord record$ = recordValue$.asRecord().orElseThrow(() -> new IllegalArgumentException("Contracts must be constructed from Records"));
    List<DamlRecord.Field> fields$ = record$.getFields();
    int numberOfFields = fields$.size();
    if (numberOfFields != 8) {
      throw new IllegalArgumentException("Expected 8 arguments, got " + numberOfFields);
    }
    String operator = fields$.get(0).getValue().asParty().orElseThrow(() -> new IllegalArgumentException("Expected operator to be of type com.daml.ledger.javaapi.data.Party")).getValue();
    String provider = fields$.get(1).getValue().asParty().orElseThrow(() -> new IllegalArgumentException("Expected provider to be of type com.daml.ledger.javaapi.data.Party")).getValue();
    String customer = fields$.get(2).getValue().asParty().orElseThrow(() -> new IllegalArgumentException("Expected customer to be of type com.daml.ledger.javaapi.data.Party")).getValue();
    String issuer = fields$.get(3).getValue().asParty().orElseThrow(() -> new IllegalArgumentException("Expected issuer to be of type com.daml.ledger.javaapi.data.Party")).getValue();
    String auctionId = fields$.get(4).getValue().asText().orElseThrow(() -> new IllegalArgumentException("Expected auctionId to be of type com.daml.ledger.javaapi.data.Text")).getValue();
    Asset asset = Asset.fromValue(fields$.get(5).getValue());
    Id quotedAssetId = Id.fromValue(fields$.get(6).getValue());
    List<PublishedBid> publishedBids = fields$.get(7).getValue().asList()
            .map(v$0 -> v$0.toList(v$1 ->
                PublishedBid.fromValue(v$1)
            ))
            .orElseThrow(() -> new IllegalArgumentException("Expected publishedBids to be of type com.daml.ledger.javaapi.data.DamlList"))
        ;
    return new com.daml.generated.marketplace.distribution.auction.bidding.model.Auction(operator, provider, customer, issuer, auctionId, asset, quotedAssetId, publishedBids);
  }

  public DamlRecord toValue() {
    ArrayList<DamlRecord.Field> fields = new ArrayList<DamlRecord.Field>(8);
    fields.add(new DamlRecord.Field("operator", new Party(this.operator)));
    fields.add(new DamlRecord.Field("provider", new Party(this.provider)));
    fields.add(new DamlRecord.Field("customer", new Party(this.customer)));
    fields.add(new DamlRecord.Field("issuer", new Party(this.issuer)));
    fields.add(new DamlRecord.Field("auctionId", new Text(this.auctionId)));
    fields.add(new DamlRecord.Field("asset", this.asset.toValue()));
    fields.add(new DamlRecord.Field("quotedAssetId", this.quotedAssetId.toValue()));
    fields.add(new DamlRecord.Field("publishedBids", this.publishedBids.stream().collect(DamlCollectors.toDamlList(v$0 -> v$0.toValue()))));
    return new DamlRecord(fields);
  }

  @Override
  public boolean equals(Object object) {
    if (this == object) {
      return true;
    }
    if (object == null) {
      return false;
    }
    if (!(object instanceof Auction)) {
      return false;
    }
    Auction other = (Auction) object;
    return this.operator.equals(other.operator) && this.provider.equals(other.provider) && this.customer.equals(other.customer) && this.issuer.equals(other.issuer) && this.auctionId.equals(other.auctionId) && this.asset.equals(other.asset) && this.quotedAssetId.equals(other.quotedAssetId) && this.publishedBids.equals(other.publishedBids);
  }

  @Override
  public int hashCode() {
    return Objects.hash(this.operator, this.provider, this.customer, this.issuer, this.auctionId, this.asset, this.quotedAssetId, this.publishedBids);
  }

  @Override
  public String toString() {
    return String.format("com.daml.generated.marketplace.distribution.auction.bidding.model.Auction(%s, %s, %s, %s, %s, %s, %s, %s)", this.operator, this.provider, this.customer, this.issuer, this.auctionId, this.asset, this.quotedAssetId, this.publishedBids);
  }

  public static final class ContractId extends com.daml.ledger.javaapi.data.codegen.ContractId<Auction> {
    public ContractId(String contractId) {
      super(contractId);
    }

    public ExerciseCommand exerciseArchive(Archive arg) {
      Value argValue = arg.toValue();
      return new ExerciseCommand(Auction.TEMPLATE_ID, this.contractId, "Archive", argValue);
    }
  }

  public static class Contract implements com.daml.ledger.javaapi.data.Contract {
    public final ContractId id;

    public final Auction data;

    public final Optional<String> agreementText;

    public final Set<String> signatories;

    public final Set<String> observers;

    public Contract(ContractId id, Auction data, Optional<String> agreementText,
        Set<String> signatories, Set<String> observers) {
      this.id = id;
      this.data = data;
      this.agreementText = agreementText;
      this.signatories = signatories;
      this.observers = observers;
    }

    public static Contract fromIdAndRecord(String contractId, DamlRecord record$,
        Optional<String> agreementText, Set<String> signatories, Set<String> observers) {
      ContractId id = new ContractId(contractId);
      Auction data = Auction.fromValue(record$);
      return new Contract(id, data, agreementText, signatories, observers);
    }

    @Deprecated
    public static Contract fromIdAndRecord(String contractId, DamlRecord record$) {
      ContractId id = new ContractId(contractId);
      Auction data = Auction.fromValue(record$);
      return new Contract(id, data, Optional.empty(), Collections.emptySet(), Collections.emptySet());
    }

    public static Contract fromCreatedEvent(CreatedEvent event) {
      return fromIdAndRecord(event.getContractId(), event.getArguments(), event.getAgreementText(), event.getSignatories(), event.getObservers());
    }

    @Override
    public boolean equals(Object object) {
      if (this == object) {
        return true;
      }
      if (object == null) {
        return false;
      }
      if (!(object instanceof Contract)) {
        return false;
      }
      Contract other = (Contract) object;
      return this.id.equals(other.id) && this.data.equals(other.data) && this.agreementText.equals(other.agreementText) && this.signatories.equals(other.signatories) && this.observers.equals(other.observers);
    }

    @Override
    public int hashCode() {
      return Objects.hash(this.id, this.data, this.agreementText, this.signatories, this.observers);
    }

    @Override
    public String toString() {
      return String.format("com.daml.generated.marketplace.distribution.auction.bidding.model.Auction.Contract(%s, %s, %s, %s, %s)", this.id, this.data, this.agreementText, this.signatories, this.observers);
    }
  }
}
