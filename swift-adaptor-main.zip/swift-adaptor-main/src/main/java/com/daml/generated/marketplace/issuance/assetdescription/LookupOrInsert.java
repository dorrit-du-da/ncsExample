package com.daml.generated.marketplace.issuance.assetdescription;

import com.daml.generated.contingentclaims.claim.serializable.Claim;
import com.daml.generated.da.finance.types.Id;
import com.daml.ledger.javaapi.data.DamlRecord;
import com.daml.ledger.javaapi.data.Date;
import com.daml.ledger.javaapi.data.Numeric;
import com.daml.ledger.javaapi.data.Value;
import java.lang.IllegalArgumentException;
import java.lang.Object;
import java.lang.Override;
import java.lang.String;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

public class LookupOrInsert {
  public static final String _packageId = "636e6e778aedec0710919591e9cb2a9404d6daab0581e4ddc515eeae03256f45";

  public final Claim<LocalDate, BigDecimal, Id> claims;

  public LookupOrInsert(Claim<LocalDate, BigDecimal, Id> claims) {
    this.claims = claims;
  }

  public static LookupOrInsert fromValue(Value value$) throws IllegalArgumentException {
    Value recordValue$ = value$;
    DamlRecord record$ = recordValue$.asRecord().orElseThrow(() -> new IllegalArgumentException("Contracts must be constructed from Records"));
    List<DamlRecord.Field> fields$ = record$.getFields();
    int numberOfFields = fields$.size();
    if (numberOfFields != 1) {
      throw new IllegalArgumentException("Expected 1 arguments, got " + numberOfFields);
    }
    Claim<LocalDate, BigDecimal, Id> claims = Claim.<java.time.LocalDate, java.math.BigDecimal, com.daml.generated.da.finance.types.Id>fromValue(fields$.get(0).getValue(), v$0 -> v$0.asDate().orElseThrow(() -> new IllegalArgumentException("Expected claims to be of type com.daml.ledger.javaapi.data.Date")).getValue(), v$1 -> v$1.asNumeric().orElseThrow(() -> new IllegalArgumentException("Expected claims to be of type com.daml.ledger.javaapi.data.Numeric")).getValue(), v$2 -> Id.fromValue(v$2));
    return new com.daml.generated.marketplace.issuance.assetdescription.LookupOrInsert(claims);
  }

  public DamlRecord toValue() {
    ArrayList<DamlRecord.Field> fields = new ArrayList<DamlRecord.Field>(1);
    fields.add(new DamlRecord.Field("claims", this.claims.toValue(v$0 -> new Date((int) v$0.toEpochDay()),v$1 -> new Numeric(v$1),v$2 -> v$2.toValue())));
    return new DamlRecord(fields);
  }

  @Override
  public boolean equals(Object object) {
    if (this == object) {
      return true;
    }
    if (object == null) {
      return false;
    }
    if (!(object instanceof LookupOrInsert)) {
      return false;
    }
    LookupOrInsert other = (LookupOrInsert) object;
    return this.claims.equals(other.claims);
  }

  @Override
  public int hashCode() {
    return Objects.hash(this.claims);
  }

  @Override
  public String toString() {
    return String.format("com.daml.generated.marketplace.issuance.assetdescription.LookupOrInsert(%s)", this.claims);
  }
}
