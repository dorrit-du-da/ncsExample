package com.daml.generated.daml.control.recursion;

import com.daml.ledger.javaapi.data.Value;
import com.daml.ledger.javaapi.data.Variant;
import java.lang.String;
import java.util.function.Function;

public abstract class ListF<a, x> {
  public static final String _packageId = "636e6e778aedec0710919591e9cb2a9404d6daab0581e4ddc515eeae03256f45";

  public ListF() {
  }

  public abstract Value toValue(Function<a, Value> toValuea, Function<x, Value> toValuex);

  public static <a, x> ListF<a, x> fromValue(Value value$, Function<Value, a> fromValuea,
      Function<Value, x> fromValuex) {
    Variant variant$ = value$.asVariant().orElseThrow(() -> new IllegalArgumentException("Expected Variant to build an instance of the Variant com.daml.generated.daml.control.recursion.ListF"));
    if ("Nil".equals(variant$.getConstructor())) {
      return com.daml.generated.daml.control.recursion.listf.Nil.fromValue(variant$, fromValuea, fromValuex);
    }
    if ("Cons".equals(variant$.getConstructor())) {
      return com.daml.generated.daml.control.recursion.listf.Cons.fromValue(variant$, fromValuea, fromValuex);
    }
    throw new IllegalArgumentException("Found unknown constructor variant$.getConstructor() for variant com.daml.generated.daml.control.recursion.ListF, expected one of [Nil, Cons]");
  }
}
