package com.daml.generated.contingentclaims.claim.serializable.claim;

import com.daml.generated.contingentclaims.claim.serializable.Claim;
import com.daml.ledger.javaapi.data.Value;
import com.daml.ledger.javaapi.data.Variant;
import java.lang.IllegalArgumentException;
import java.lang.Object;
import java.lang.Override;
import java.lang.String;
import java.util.Objects;
import java.util.function.Function;

public class One<t, x, a> extends Claim<t, x, a> {
  public static final String _packageId = "636e6e778aedec0710919591e9cb2a9404d6daab0581e4ddc515eeae03256f45";

  public final a aValue;

  public One(a aValue) {
    this.aValue = aValue;
  }

  public Variant toValue(Function<a, Value> toValuea) {
    return new Variant("One", toValuea.apply(this.aValue));
  }

  public static <t, x, a> One<t, x, a> fromValue(Value value$, Function<Value, a> fromValuea) throws
      IllegalArgumentException {
    Variant variant$ = value$.asVariant().orElseThrow(() -> new IllegalArgumentException("Expected: Variant. Actual: " + value$.getClass().getName()));
    if (!"One".equals(variant$.getConstructor())) throw new IllegalArgumentException("Invalid constructor. Expected: One. Actual: " + variant$.getConstructor());
    Value variantValue$ = variant$.getValue();
    a body = fromValuea.apply(variantValue$);
    return new One<t, x, a>(body);
  }

  public Variant toValue(Function<t, Value> toValuet, Function<x, Value> toValuex,
      Function<a, Value> toValuea) {
    return new Variant("One", toValuea.apply(this.aValue));
  }

  public static <t, x, a> One<t, x, a> fromValue(Value value$, Function<Value, t> fromValuet,
      Function<Value, x> fromValuex, Function<Value, a> fromValuea) throws
      IllegalArgumentException {
    Variant variant$ = value$.asVariant().orElseThrow(() -> new IllegalArgumentException("Expected: Variant. Actual: " + value$.getClass().getName()));
    if (!"One".equals(variant$.getConstructor())) throw new IllegalArgumentException("Invalid constructor. Expected: One. Actual: " + variant$.getConstructor());
    Value variantValue$ = variant$.getValue();
    a body = fromValuea.apply(variantValue$);
    return new One<t, x, a>(body);
  }

  @Override
  public boolean equals(Object object) {
    if (this == object) {
      return true;
    }
    if (object == null) {
      return false;
    }
    if (!(object instanceof One<?, ?, ?>)) {
      return false;
    }
    One<?, ?, ?> other = (One<?, ?, ?>) object;
    return this.aValue.equals(other.aValue);
  }

  @Override
  public int hashCode() {
    return Objects.hash(this.aValue);
  }

  @Override
  public String toString() {
    return String.format("One(%s)", this.aValue);
  }
}
