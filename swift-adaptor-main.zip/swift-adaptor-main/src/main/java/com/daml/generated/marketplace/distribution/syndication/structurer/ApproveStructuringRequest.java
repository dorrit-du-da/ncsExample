package com.daml.generated.marketplace.distribution.syndication.structurer;

import com.daml.generated.marketplace.distribution.syndication.structuring.service.Request;
import com.daml.ledger.javaapi.data.DamlRecord;
import com.daml.ledger.javaapi.data.Value;
import java.lang.IllegalArgumentException;
import java.lang.Object;
import java.lang.Override;
import java.lang.String;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

public class ApproveStructuringRequest {
  public static final String _packageId = "636e6e778aedec0710919591e9cb2a9404d6daab0581e4ddc515eeae03256f45";

  public final Request.ContractId structuringRequestCid;

  public ApproveStructuringRequest(Request.ContractId structuringRequestCid) {
    this.structuringRequestCid = structuringRequestCid;
  }

  public static ApproveStructuringRequest fromValue(Value value$) throws IllegalArgumentException {
    Value recordValue$ = value$;
    DamlRecord record$ = recordValue$.asRecord().orElseThrow(() -> new IllegalArgumentException("Contracts must be constructed from Records"));
    List<DamlRecord.Field> fields$ = record$.getFields();
    int numberOfFields = fields$.size();
    if (numberOfFields != 1) {
      throw new IllegalArgumentException("Expected 1 arguments, got " + numberOfFields);
    }
    Request.ContractId structuringRequestCid = new Request.ContractId(fields$.get(0).getValue().asContractId().orElseThrow(() -> new IllegalArgumentException("Expected structuringRequestCid to be of type com.daml.ledger.javaapi.data.ContractId")).getValue());
    return new com.daml.generated.marketplace.distribution.syndication.structurer.ApproveStructuringRequest(structuringRequestCid);
  }

  public DamlRecord toValue() {
    ArrayList<DamlRecord.Field> fields = new ArrayList<DamlRecord.Field>(1);
    fields.add(new DamlRecord.Field("structuringRequestCid", this.structuringRequestCid.toValue()));
    return new DamlRecord(fields);
  }

  @Override
  public boolean equals(Object object) {
    if (this == object) {
      return true;
    }
    if (object == null) {
      return false;
    }
    if (!(object instanceof ApproveStructuringRequest)) {
      return false;
    }
    ApproveStructuringRequest other = (ApproveStructuringRequest) object;
    return this.structuringRequestCid.equals(other.structuringRequestCid);
  }

  @Override
  public int hashCode() {
    return Objects.hash(this.structuringRequestCid);
  }

  @Override
  public String toString() {
    return String.format("com.daml.generated.marketplace.distribution.syndication.structurer.ApproveStructuringRequest(%s)", this.structuringRequestCid);
  }
}
