package com.daml.generated.marketplace.issuance.instrument.model;

import com.daml.ledger.javaapi.data.Value;
import com.daml.ledger.javaapi.data.Variant;
import java.lang.String;

public abstract class InterestAmount {
  public static final String _packageId = "636e6e778aedec0710919591e9cb2a9404d6daab0581e4ddc515eeae03256f45";

  public InterestAmount() {
  }

  public abstract Value toValue();

  public static InterestAmount fromValue(Value value$) {
    Variant variant$ = value$.asVariant().orElseThrow(() -> new IllegalArgumentException("Expected Variant to build an instance of the Variant com.daml.generated.marketplace.issuance.instrument.model.InterestAmount"));
    if ("Fixed".equals(variant$.getConstructor())) {
      return com.daml.generated.marketplace.issuance.instrument.model.interestamount.Fixed.fromValue(variant$);
    }
    if ("Float".equals(variant$.getConstructor())) {
      return com.daml.generated.marketplace.issuance.instrument.model.interestamount.Float.fromValue(variant$);
    }
    throw new IllegalArgumentException("Found unknown constructor variant$.getConstructor() for variant com.daml.generated.marketplace.issuance.instrument.model.InterestAmount, expected one of [Fixed, Float]");
  }
}
