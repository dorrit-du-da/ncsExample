package com.daml.generated.marketplace.distribution.auction.bidding.model.status;

import com.daml.generated.marketplace.distribution.auction.bidding.model.Status;
import com.daml.ledger.javaapi.data.DamlRecord;
import com.daml.ledger.javaapi.data.Numeric;
import com.daml.ledger.javaapi.data.Value;
import com.daml.ledger.javaapi.data.Variant;
import java.lang.IllegalArgumentException;
import java.lang.Object;
import java.lang.Override;
import java.lang.String;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

public class PartialAllocation extends Status {
  public static final String _packageId = "636e6e778aedec0710919591e9cb2a9404d6daab0581e4ddc515eeae03256f45";

  public final BigDecimal price;

  public final BigDecimal quantity;

  public PartialAllocation(BigDecimal price, BigDecimal quantity) {
    this.price = price;
    this.quantity = quantity;
  }

  public Variant toValue() {
    ArrayList<DamlRecord.Field> fields = new ArrayList<DamlRecord.Field>(2);
    fields.add(new DamlRecord.Field("price", new Numeric(this.price)));
    fields.add(new DamlRecord.Field("quantity", new Numeric(this.quantity)));
    return new Variant("PartialAllocation", new DamlRecord(fields));
  }

  public static PartialAllocation fromValue(Value value$) throws IllegalArgumentException {
    Variant variant$ = value$.asVariant().orElseThrow(() -> new IllegalArgumentException("Expected: Variant. Actual: " + value$.getClass().getName()));
    if (!"PartialAllocation".equals(variant$.getConstructor())) throw new IllegalArgumentException("Invalid constructor. Expected: PartialAllocation. Actual: " + variant$.getConstructor());
    Value recordValue$ = variant$.getValue();
    DamlRecord record$ = recordValue$.asRecord().orElseThrow(() -> new IllegalArgumentException("Contracts must be constructed from Records"));
    List<DamlRecord.Field> fields$ = record$.getFields();
    int numberOfFields = fields$.size();
    if (numberOfFields != 2) {
      throw new IllegalArgumentException("Expected 2 arguments, got " + numberOfFields);
    }
    BigDecimal price = fields$.get(0).getValue().asNumeric().orElseThrow(() -> new IllegalArgumentException("Expected price to be of type com.daml.ledger.javaapi.data.Numeric")).getValue();
    BigDecimal quantity = fields$.get(1).getValue().asNumeric().orElseThrow(() -> new IllegalArgumentException("Expected quantity to be of type com.daml.ledger.javaapi.data.Numeric")).getValue();
    return new PartialAllocation(price, quantity);
  }

  @Override
  public boolean equals(Object object) {
    if (this == object) {
      return true;
    }
    if (object == null) {
      return false;
    }
    if (!(object instanceof PartialAllocation)) {
      return false;
    }
    PartialAllocation other = (PartialAllocation) object;
    return this.price.equals(other.price) && this.quantity.equals(other.quantity);
  }

  @Override
  public int hashCode() {
    return Objects.hash(this.price, this.quantity);
  }

  @Override
  public String toString() {
    return String.format("PartialAllocation(%s, %s)", this.price, this.quantity);
  }
}
