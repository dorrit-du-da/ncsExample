package com.daml.generated.contingentclaims.claim.serializable.claimf;

import com.daml.generated.contingentclaims.claim.serializable.ClaimF;
import com.daml.ledger.javaapi.data.Value;
import com.daml.ledger.javaapi.data.Variant;
import java.lang.IllegalArgumentException;
import java.lang.Object;
import java.lang.Override;
import java.lang.String;
import java.util.Objects;
import java.util.function.Function;

public class GiveF<t, x, a, b> extends ClaimF<t, x, a, b> {
  public static final String _packageId = "636e6e778aedec0710919591e9cb2a9404d6daab0581e4ddc515eeae03256f45";

  public final b bValue;

  public GiveF(b bValue) {
    this.bValue = bValue;
  }

  public Variant toValue(Function<b, Value> toValueb) {
    return new Variant("GiveF", toValueb.apply(this.bValue));
  }

  public static <t, x, a, b> GiveF<t, x, a, b> fromValue(Value value$,
      Function<Value, b> fromValueb) throws IllegalArgumentException {
    Variant variant$ = value$.asVariant().orElseThrow(() -> new IllegalArgumentException("Expected: Variant. Actual: " + value$.getClass().getName()));
    if (!"GiveF".equals(variant$.getConstructor())) throw new IllegalArgumentException("Invalid constructor. Expected: GiveF. Actual: " + variant$.getConstructor());
    Value variantValue$ = variant$.getValue();
    b body = fromValueb.apply(variantValue$);
    return new GiveF<t, x, a, b>(body);
  }

  public Variant toValue(Function<t, Value> toValuet, Function<x, Value> toValuex,
      Function<a, Value> toValuea, Function<b, Value> toValueb) {
    return new Variant("GiveF", toValueb.apply(this.bValue));
  }

  public static <t, x, a, b> GiveF<t, x, a, b> fromValue(Value value$,
      Function<Value, t> fromValuet, Function<Value, x> fromValuex, Function<Value, a> fromValuea,
      Function<Value, b> fromValueb) throws IllegalArgumentException {
    Variant variant$ = value$.asVariant().orElseThrow(() -> new IllegalArgumentException("Expected: Variant. Actual: " + value$.getClass().getName()));
    if (!"GiveF".equals(variant$.getConstructor())) throw new IllegalArgumentException("Invalid constructor. Expected: GiveF. Actual: " + variant$.getConstructor());
    Value variantValue$ = variant$.getValue();
    b body = fromValueb.apply(variantValue$);
    return new GiveF<t, x, a, b>(body);
  }

  @Override
  public boolean equals(Object object) {
    if (this == object) {
      return true;
    }
    if (object == null) {
      return false;
    }
    if (!(object instanceof GiveF<?, ?, ?, ?>)) {
      return false;
    }
    GiveF<?, ?, ?, ?> other = (GiveF<?, ?, ?, ?>) object;
    return this.bValue.equals(other.bValue);
  }

  @Override
  public int hashCode() {
    return Objects.hash(this.bValue);
  }

  @Override
  public String toString() {
    return String.format("GiveF(%s)", this.bValue);
  }
}
