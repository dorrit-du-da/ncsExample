package com.daml.generated.marketplace.custody.model;

import com.daml.ledger.javaapi.data.Value;
import com.daml.ledger.javaapi.data.Variant;
import java.lang.String;

public abstract class Channel {
  public static final String _packageId = "636e6e778aedec0710919591e9cb2a9404d6daab0581e4ddc515eeae03256f45";

  public Channel() {
  }

  public abstract Value toValue();

  public static Channel fromValue(Value value$) {
    Variant variant$ = value$.asVariant().orElseThrow(() -> new IllegalArgumentException("Expected Variant to build an instance of the Variant com.daml.generated.marketplace.custody.model.Channel"));
    if ("ETH".equals(variant$.getConstructor())) {
      return com.daml.generated.marketplace.custody.model.channel.ETH.fromValue(variant$);
    }
    if ("POLY".equals(variant$.getConstructor())) {
      return com.daml.generated.marketplace.custody.model.channel.POLY.fromValue(variant$);
    }
    if ("SWIFT".equals(variant$.getConstructor())) {
      return com.daml.generated.marketplace.custody.model.channel.SWIFT.fromValue(variant$);
    }
    if ("ONLEDGER".equals(variant$.getConstructor())) {
      return com.daml.generated.marketplace.custody.model.channel.ONLEDGER.fromValue(variant$);
    }
    throw new IllegalArgumentException("Found unknown constructor variant$.getConstructor() for variant com.daml.generated.marketplace.custody.model.Channel, expected one of [ETH, POLY, SWIFT, ONLEDGER]");
  }
}
