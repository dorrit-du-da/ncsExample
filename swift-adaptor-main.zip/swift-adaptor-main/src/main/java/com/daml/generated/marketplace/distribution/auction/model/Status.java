package com.daml.generated.marketplace.distribution.auction.model;

import com.daml.ledger.javaapi.data.Value;
import com.daml.ledger.javaapi.data.Variant;
import java.lang.String;

public abstract class Status {
  public static final String _packageId = "636e6e778aedec0710919591e9cb2a9404d6daab0581e4ddc515eeae03256f45";

  public Status() {
  }

  public abstract Value toValue();

  public static Status fromValue(Value value$) {
    Variant variant$ = value$.asVariant().orElseThrow(() -> new IllegalArgumentException("Expected Variant to build an instance of the Variant com.daml.generated.marketplace.distribution.auction.model.Status"));
    if ("Open".equals(variant$.getConstructor())) {
      return com.daml.generated.marketplace.distribution.auction.model.status.Open.fromValue(variant$);
    }
    if ("PartiallyAllocated".equals(variant$.getConstructor())) {
      return com.daml.generated.marketplace.distribution.auction.model.status.PartiallyAllocated.fromValue(variant$);
    }
    if ("FullyAllocated".equals(variant$.getConstructor())) {
      return com.daml.generated.marketplace.distribution.auction.model.status.FullyAllocated.fromValue(variant$);
    }
    if ("NoValidBids".equals(variant$.getConstructor())) {
      return com.daml.generated.marketplace.distribution.auction.model.status.NoValidBids.fromValue(variant$);
    }
    throw new IllegalArgumentException("Found unknown constructor variant$.getConstructor() for variant com.daml.generated.marketplace.distribution.auction.model.Status, expected one of [Open, PartiallyAllocated, FullyAllocated, NoValidBids]");
  }
}
