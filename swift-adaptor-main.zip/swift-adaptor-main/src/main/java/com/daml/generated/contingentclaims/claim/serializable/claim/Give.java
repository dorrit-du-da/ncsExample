package com.daml.generated.contingentclaims.claim.serializable.claim;

import com.daml.generated.contingentclaims.claim.serializable.Claim;
import com.daml.ledger.javaapi.data.Value;
import com.daml.ledger.javaapi.data.Variant;
import java.lang.IllegalArgumentException;
import java.lang.Object;
import java.lang.Override;
import java.lang.String;
import java.util.Objects;
import java.util.function.Function;

public class Give<t, x, a> extends Claim<t, x, a> {
  public static final String _packageId = "636e6e778aedec0710919591e9cb2a9404d6daab0581e4ddc515eeae03256f45";

  public final Claim<t, x, a> claimValue;

  public Give(Claim<t, x, a> claimValue) {
    this.claimValue = claimValue;
  }

  public Variant toValue(Function<t, Value> toValuet, Function<x, Value> toValuex,
      Function<a, Value> toValuea) {
    return new Variant("Give", this.claimValue.toValue(v$0 -> toValuet.apply(v$0),v$1 -> toValuex.apply(v$1),v$2 -> toValuea.apply(v$2)));
  }

  public static <t, x, a> Give<t, x, a> fromValue(Value value$, Function<Value, t> fromValuet,
      Function<Value, x> fromValuex, Function<Value, a> fromValuea) throws
      IllegalArgumentException {
    Variant variant$ = value$.asVariant().orElseThrow(() -> new IllegalArgumentException("Expected: Variant. Actual: " + value$.getClass().getName()));
    if (!"Give".equals(variant$.getConstructor())) throw new IllegalArgumentException("Invalid constructor. Expected: Give. Actual: " + variant$.getConstructor());
    Value variantValue$ = variant$.getValue();
    Claim<t, x, a> body = Claim.<t, x, a>fromValue(variantValue$, v$0 -> fromValuet.apply(v$0), v$1 -> fromValuex.apply(v$1), v$2 -> fromValuea.apply(v$2));
    return new Give<t, x, a>(body);
  }

  @Override
  public boolean equals(Object object) {
    if (this == object) {
      return true;
    }
    if (object == null) {
      return false;
    }
    if (!(object instanceof Give<?, ?, ?>)) {
      return false;
    }
    Give<?, ?, ?> other = (Give<?, ?, ?>) object;
    return this.claimValue.equals(other.claimValue);
  }

  @Override
  public int hashCode() {
    return Objects.hash(this.claimValue);
  }

  @Override
  public String toString() {
    return String.format("Give(%s)", this.claimValue);
  }
}
