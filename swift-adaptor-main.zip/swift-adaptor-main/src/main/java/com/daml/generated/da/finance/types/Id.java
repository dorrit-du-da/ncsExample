package com.daml.generated.da.finance.types;

import com.daml.generated.da.set.types.Set;
import com.daml.ledger.javaapi.data.DamlRecord;
import com.daml.ledger.javaapi.data.Int64;
import com.daml.ledger.javaapi.data.Party;
import com.daml.ledger.javaapi.data.Text;
import com.daml.ledger.javaapi.data.Value;
import java.lang.IllegalArgumentException;
import java.lang.Long;
import java.lang.Object;
import java.lang.Override;
import java.lang.String;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

public class Id {
  public static final String _packageId = "636e6e778aedec0710919591e9cb2a9404d6daab0581e4ddc515eeae03256f45";

  public final Set<String> signatories;

  public final String label;

  public final Long version;

  public Id(Set<String> signatories, String label, Long version) {
    this.signatories = signatories;
    this.label = label;
    this.version = version;
  }

  public static Id fromValue(Value value$) throws IllegalArgumentException {
    Value recordValue$ = value$;
    DamlRecord record$ = recordValue$.asRecord().orElseThrow(() -> new IllegalArgumentException("Contracts must be constructed from Records"));
    List<DamlRecord.Field> fields$ = record$.getFields();
    int numberOfFields = fields$.size();
    if (numberOfFields != 3) {
      throw new IllegalArgumentException("Expected 3 arguments, got " + numberOfFields);
    }
    Set<String> signatories = Set.<java.lang.String>fromValue(fields$.get(0).getValue(), v$0 -> v$0.asParty().orElseThrow(() -> new IllegalArgumentException("Expected signatories to be of type com.daml.ledger.javaapi.data.Party")).getValue());
    String label = fields$.get(1).getValue().asText().orElseThrow(() -> new IllegalArgumentException("Expected label to be of type com.daml.ledger.javaapi.data.Text")).getValue();
    Long version = fields$.get(2).getValue().asInt64().orElseThrow(() -> new IllegalArgumentException("Expected version to be of type com.daml.ledger.javaapi.data.Int64")).getValue();
    return new com.daml.generated.da.finance.types.Id(signatories, label, version);
  }

  public DamlRecord toValue() {
    ArrayList<DamlRecord.Field> fields = new ArrayList<DamlRecord.Field>(3);
    fields.add(new DamlRecord.Field("signatories", this.signatories.toValue(v$0 -> new Party(v$0))));
    fields.add(new DamlRecord.Field("label", new Text(this.label)));
    fields.add(new DamlRecord.Field("version", new Int64(this.version)));
    return new DamlRecord(fields);
  }

  @Override
  public boolean equals(Object object) {
    if (this == object) {
      return true;
    }
    if (object == null) {
      return false;
    }
    if (!(object instanceof Id)) {
      return false;
    }
    Id other = (Id) object;
    return this.signatories.equals(other.signatories) && this.label.equals(other.label) && this.version.equals(other.version);
  }

  @Override
  public int hashCode() {
    return Objects.hash(this.signatories, this.label, this.version);
  }

  @Override
  public String toString() {
    return String.format("com.daml.generated.da.finance.types.Id(%s, %s, %s)", this.signatories, this.label, this.version);
  }
}
