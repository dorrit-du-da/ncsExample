package com.daml.generated.da.finance.types;

import com.daml.ledger.javaapi.data.DamlRecord;
import com.daml.ledger.javaapi.data.Party;
import com.daml.ledger.javaapi.data.Value;
import java.lang.IllegalArgumentException;
import java.lang.Object;
import java.lang.Override;
import java.lang.String;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

public class Account {
  public static final String _packageId = "636e6e778aedec0710919591e9cb2a9404d6daab0581e4ddc515eeae03256f45";

  public final Id id;

  public final String provider;

  public final String owner;

  public Account(Id id, String provider, String owner) {
    this.id = id;
    this.provider = provider;
    this.owner = owner;
  }

  public static Account fromValue(Value value$) throws IllegalArgumentException {
    Value recordValue$ = value$;
    DamlRecord record$ = recordValue$.asRecord().orElseThrow(() -> new IllegalArgumentException("Contracts must be constructed from Records"));
    List<DamlRecord.Field> fields$ = record$.getFields();
    int numberOfFields = fields$.size();
    if (numberOfFields != 3) {
      throw new IllegalArgumentException("Expected 3 arguments, got " + numberOfFields);
    }
    Id id = Id.fromValue(fields$.get(0).getValue());
    String provider = fields$.get(1).getValue().asParty().orElseThrow(() -> new IllegalArgumentException("Expected provider to be of type com.daml.ledger.javaapi.data.Party")).getValue();
    String owner = fields$.get(2).getValue().asParty().orElseThrow(() -> new IllegalArgumentException("Expected owner to be of type com.daml.ledger.javaapi.data.Party")).getValue();
    return new com.daml.generated.da.finance.types.Account(id, provider, owner);
  }

  public DamlRecord toValue() {
    ArrayList<DamlRecord.Field> fields = new ArrayList<DamlRecord.Field>(3);
    fields.add(new DamlRecord.Field("id", this.id.toValue()));
    fields.add(new DamlRecord.Field("provider", new Party(this.provider)));
    fields.add(new DamlRecord.Field("owner", new Party(this.owner)));
    return new DamlRecord(fields);
  }

  @Override
  public boolean equals(Object object) {
    if (this == object) {
      return true;
    }
    if (object == null) {
      return false;
    }
    if (!(object instanceof Account)) {
      return false;
    }
    Account other = (Account) object;
    return this.id.equals(other.id) && this.provider.equals(other.provider) && this.owner.equals(other.owner);
  }

  @Override
  public int hashCode() {
    return Objects.hash(this.id, this.provider, this.owner);
  }

  @Override
  public String toString() {
    return String.format("com.daml.generated.da.finance.types.Account(%s, %s, %s)", this.id, this.provider, this.owner);
  }
}
