package com.daml.generated.marketplace.clearing.market.service;

import com.daml.generated.da.finance.types.Id;
import com.daml.generated.da.set.types.Set;
import com.daml.ledger.javaapi.data.DamlRecord;
import com.daml.ledger.javaapi.data.Numeric;
import com.daml.ledger.javaapi.data.Party;
import com.daml.ledger.javaapi.data.Text;
import com.daml.ledger.javaapi.data.Timestamp;
import com.daml.ledger.javaapi.data.Value;
import java.lang.IllegalArgumentException;
import java.lang.Object;
import java.lang.Override;
import java.lang.String;
import java.math.BigDecimal;
import java.time.Instant;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

public class CreateFairValue {
  public static final String _packageId = "636e6e778aedec0710919591e9cb2a9404d6daab0581e4ddc515eeae03256f45";

  public final String listingId;

  public final String calculationId;

  public final BigDecimal price;

  public final Id currency;

  public final Instant timestamp;

  public final Instant upTo;

  public final Set<String> observers;

  public CreateFairValue(String listingId, String calculationId, BigDecimal price, Id currency,
      Instant timestamp, Instant upTo, Set<String> observers) {
    this.listingId = listingId;
    this.calculationId = calculationId;
    this.price = price;
    this.currency = currency;
    this.timestamp = timestamp;
    this.upTo = upTo;
    this.observers = observers;
  }

  public static CreateFairValue fromValue(Value value$) throws IllegalArgumentException {
    Value recordValue$ = value$;
    DamlRecord record$ = recordValue$.asRecord().orElseThrow(() -> new IllegalArgumentException("Contracts must be constructed from Records"));
    List<DamlRecord.Field> fields$ = record$.getFields();
    int numberOfFields = fields$.size();
    if (numberOfFields != 7) {
      throw new IllegalArgumentException("Expected 7 arguments, got " + numberOfFields);
    }
    String listingId = fields$.get(0).getValue().asText().orElseThrow(() -> new IllegalArgumentException("Expected listingId to be of type com.daml.ledger.javaapi.data.Text")).getValue();
    String calculationId = fields$.get(1).getValue().asText().orElseThrow(() -> new IllegalArgumentException("Expected calculationId to be of type com.daml.ledger.javaapi.data.Text")).getValue();
    BigDecimal price = fields$.get(2).getValue().asNumeric().orElseThrow(() -> new IllegalArgumentException("Expected price to be of type com.daml.ledger.javaapi.data.Numeric")).getValue();
    Id currency = Id.fromValue(fields$.get(3).getValue());
    Instant timestamp = fields$.get(4).getValue().asTimestamp().orElseThrow(() -> new IllegalArgumentException("Expected timestamp to be of type com.daml.ledger.javaapi.data.Timestamp")).getValue();
    Instant upTo = fields$.get(5).getValue().asTimestamp().orElseThrow(() -> new IllegalArgumentException("Expected upTo to be of type com.daml.ledger.javaapi.data.Timestamp")).getValue();
    Set<String> observers = Set.<java.lang.String>fromValue(fields$.get(6).getValue(), v$0 -> v$0.asParty().orElseThrow(() -> new IllegalArgumentException("Expected observers to be of type com.daml.ledger.javaapi.data.Party")).getValue());
    return new com.daml.generated.marketplace.clearing.market.service.CreateFairValue(listingId, calculationId, price, currency, timestamp, upTo, observers);
  }

  public DamlRecord toValue() {
    ArrayList<DamlRecord.Field> fields = new ArrayList<DamlRecord.Field>(7);
    fields.add(new DamlRecord.Field("listingId", new Text(this.listingId)));
    fields.add(new DamlRecord.Field("calculationId", new Text(this.calculationId)));
    fields.add(new DamlRecord.Field("price", new Numeric(this.price)));
    fields.add(new DamlRecord.Field("currency", this.currency.toValue()));
    fields.add(new DamlRecord.Field("timestamp", Timestamp.fromInstant(this.timestamp)));
    fields.add(new DamlRecord.Field("upTo", Timestamp.fromInstant(this.upTo)));
    fields.add(new DamlRecord.Field("observers", this.observers.toValue(v$0 -> new Party(v$0))));
    return new DamlRecord(fields);
  }

  @Override
  public boolean equals(Object object) {
    if (this == object) {
      return true;
    }
    if (object == null) {
      return false;
    }
    if (!(object instanceof CreateFairValue)) {
      return false;
    }
    CreateFairValue other = (CreateFairValue) object;
    return this.listingId.equals(other.listingId) && this.calculationId.equals(other.calculationId) && this.price.equals(other.price) && this.currency.equals(other.currency) && this.timestamp.equals(other.timestamp) && this.upTo.equals(other.upTo) && this.observers.equals(other.observers);
  }

  @Override
  public int hashCode() {
    return Objects.hash(this.listingId, this.calculationId, this.price, this.currency, this.timestamp, this.upTo, this.observers);
  }

  @Override
  public String toString() {
    return String.format("com.daml.generated.marketplace.clearing.market.service.CreateFairValue(%s, %s, %s, %s, %s, %s, %s)", this.listingId, this.calculationId, this.price, this.currency, this.timestamp, this.upTo, this.observers);
  }
}
