package com.daml.generated.contingentclaims.observation.observation;

import com.daml.generated.contingentclaims.observation.Observation;
import com.daml.generated.da.types.Tuple2;
import com.daml.ledger.javaapi.data.Value;
import com.daml.ledger.javaapi.data.Variant;
import java.lang.IllegalArgumentException;
import java.lang.Object;
import java.lang.Override;
import java.lang.String;
import java.util.Objects;
import java.util.function.Function;

public class Add<t, x> extends Observation<t, x> {
  public static final String _packageId = "636e6e778aedec0710919591e9cb2a9404d6daab0581e4ddc515eeae03256f45";

  public final Tuple2<Observation<t, x>, Observation<t, x>> tuple2Value;

  public Add(Tuple2<Observation<t, x>, Observation<t, x>> tuple2Value) {
    this.tuple2Value = tuple2Value;
  }

  public Variant toValue(Function<t, Value> toValuet, Function<x, Value> toValuex) {
    return new Variant("Add", this.tuple2Value.toValue(v$0 -> v$0.toValue(v$1 -> toValuet.apply(v$1),v$2 -> toValuex.apply(v$2)),v$3 -> v$3.toValue(v$4 -> toValuet.apply(v$4),v$5 -> toValuex.apply(v$5))));
  }

  public static <t, x> Add<t, x> fromValue(Value value$, Function<Value, t> fromValuet,
      Function<Value, x> fromValuex) throws IllegalArgumentException {
    Variant variant$ = value$.asVariant().orElseThrow(() -> new IllegalArgumentException("Expected: Variant. Actual: " + value$.getClass().getName()));
    if (!"Add".equals(variant$.getConstructor())) throw new IllegalArgumentException("Invalid constructor. Expected: Add. Actual: " + variant$.getConstructor());
    Value variantValue$ = variant$.getValue();
    Tuple2<Observation<t, x>, Observation<t, x>> body = Tuple2.<com.daml.generated.contingentclaims.observation.Observation<t, x>, com.daml.generated.contingentclaims.observation.Observation<t, x>>fromValue(variantValue$, v$0 -> Observation.<t, x>fromValue(v$0, v$1 -> fromValuet.apply(v$1), v$2 -> fromValuex.apply(v$2)), v$3 -> Observation.<t, x>fromValue(v$3, v$4 -> fromValuet.apply(v$4), v$5 -> fromValuex.apply(v$5)));
    return new Add<t, x>(body);
  }

  @Override
  public boolean equals(Object object) {
    if (this == object) {
      return true;
    }
    if (object == null) {
      return false;
    }
    if (!(object instanceof Add<?, ?>)) {
      return false;
    }
    Add<?, ?> other = (Add<?, ?>) object;
    return this.tuple2Value.equals(other.tuple2Value);
  }

  @Override
  public int hashCode() {
    return Objects.hash(this.tuple2Value);
  }

  @Override
  public String toString() {
    return String.format("Add(%s)", this.tuple2Value);
  }
}
