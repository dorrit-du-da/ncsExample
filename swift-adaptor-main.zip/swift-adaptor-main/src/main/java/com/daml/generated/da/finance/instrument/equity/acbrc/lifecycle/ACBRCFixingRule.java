package com.daml.generated.da.finance.instrument.equity.acbrc.lifecycle;

import com.daml.generated.da.finance.instrument.equity.acbrc.ACBRC;
import com.daml.generated.da.finance.refdata.fixing.Fixing;
import com.daml.generated.da.internal.template.Archive;
import com.daml.generated.da.set.types.Set;
import com.daml.ledger.javaapi.data.CreateAndExerciseCommand;
import com.daml.ledger.javaapi.data.CreateCommand;
import com.daml.ledger.javaapi.data.CreatedEvent;
import com.daml.ledger.javaapi.data.DamlRecord;
import com.daml.ledger.javaapi.data.ExerciseByKeyCommand;
import com.daml.ledger.javaapi.data.ExerciseCommand;
import com.daml.ledger.javaapi.data.Identifier;
import com.daml.ledger.javaapi.data.Party;
import com.daml.ledger.javaapi.data.Template;
import com.daml.ledger.javaapi.data.Value;
import java.lang.Deprecated;
import java.lang.IllegalArgumentException;
import java.lang.Object;
import java.lang.Override;
import java.lang.String;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Objects;
import java.util.Optional;

public final class ACBRCFixingRule extends Template {
  public static final Identifier TEMPLATE_ID = new Identifier("636e6e778aedec0710919591e9cb2a9404d6daab0581e4ddc515eeae03256f45", "DA.Finance.Instrument.Equity.ACBRC.Lifecycle", "ACBRCFixingRule");

  public final Set<String> signatories;

  public ACBRCFixingRule(Set<String> signatories) {
    this.signatories = signatories;
  }

  public CreateCommand create() {
    return new CreateCommand(ACBRCFixingRule.TEMPLATE_ID, this.toValue());
  }

  public static ExerciseByKeyCommand exerciseByKeyArchive(Set<String> key, Archive arg) {
    return new ExerciseByKeyCommand(ACBRCFixingRule.TEMPLATE_ID, key.toValue(v$0 -> new Party(v$0)), "Archive", arg.toValue());
  }

  public static ExerciseByKeyCommand exerciseByKeyACBRCFixing_Lifecycle(Set<String> key,
      ACBRCFixing_Lifecycle arg) {
    return new ExerciseByKeyCommand(ACBRCFixingRule.TEMPLATE_ID, key.toValue(v$0 -> new Party(v$0)), "ACBRCFixing_Lifecycle", arg.toValue());
  }

  public static ExerciseByKeyCommand exerciseByKeyACBRCFixing_Lifecycle(Set<String> key,
      ACBRC.ContractId acbrcCid, Fixing.ContractId fixingCid) {
    return ACBRCFixingRule.exerciseByKeyACBRCFixing_Lifecycle(key, new ACBRCFixing_Lifecycle(acbrcCid, fixingCid));
  }

  public CreateAndExerciseCommand createAndExerciseArchive(Archive arg) {
    Value argValue = arg.toValue();
    return new CreateAndExerciseCommand(ACBRCFixingRule.TEMPLATE_ID, this.toValue(), "Archive", argValue);
  }

  public CreateAndExerciseCommand createAndExerciseACBRCFixing_Lifecycle(
      ACBRCFixing_Lifecycle arg) {
    Value argValue = arg.toValue();
    return new CreateAndExerciseCommand(ACBRCFixingRule.TEMPLATE_ID, this.toValue(), "ACBRCFixing_Lifecycle", argValue);
  }

  public CreateAndExerciseCommand createAndExerciseACBRCFixing_Lifecycle(ACBRC.ContractId acbrcCid,
      Fixing.ContractId fixingCid) {
    return createAndExerciseACBRCFixing_Lifecycle(new ACBRCFixing_Lifecycle(acbrcCid, fixingCid));
  }

  public static CreateCommand create(Set<String> signatories) {
    return new ACBRCFixingRule(signatories).create();
  }

  public static ACBRCFixingRule fromValue(Value value$) throws IllegalArgumentException {
    Value recordValue$ = value$;
    DamlRecord record$ = recordValue$.asRecord().orElseThrow(() -> new IllegalArgumentException("Contracts must be constructed from Records"));
    List<DamlRecord.Field> fields$ = record$.getFields();
    int numberOfFields = fields$.size();
    if (numberOfFields != 1) {
      throw new IllegalArgumentException("Expected 1 arguments, got " + numberOfFields);
    }
    Set<String> signatories = Set.<java.lang.String>fromValue(fields$.get(0).getValue(), v$0 -> v$0.asParty().orElseThrow(() -> new IllegalArgumentException("Expected signatories to be of type com.daml.ledger.javaapi.data.Party")).getValue());
    return new com.daml.generated.da.finance.instrument.equity.acbrc.lifecycle.ACBRCFixingRule(signatories);
  }

  public DamlRecord toValue() {
    ArrayList<DamlRecord.Field> fields = new ArrayList<DamlRecord.Field>(1);
    fields.add(new DamlRecord.Field("signatories", this.signatories.toValue(v$0 -> new Party(v$0))));
    return new DamlRecord(fields);
  }

  @Override
  public boolean equals(Object object) {
    if (this == object) {
      return true;
    }
    if (object == null) {
      return false;
    }
    if (!(object instanceof ACBRCFixingRule)) {
      return false;
    }
    ACBRCFixingRule other = (ACBRCFixingRule) object;
    return this.signatories.equals(other.signatories);
  }

  @Override
  public int hashCode() {
    return Objects.hash(this.signatories);
  }

  @Override
  public String toString() {
    return String.format("com.daml.generated.da.finance.instrument.equity.acbrc.lifecycle.ACBRCFixingRule(%s)", this.signatories);
  }

  public static final class ContractId extends com.daml.ledger.javaapi.data.codegen.ContractId<ACBRCFixingRule> {
    public ContractId(String contractId) {
      super(contractId);
    }

    public ExerciseCommand exerciseArchive(Archive arg) {
      Value argValue = arg.toValue();
      return new ExerciseCommand(ACBRCFixingRule.TEMPLATE_ID, this.contractId, "Archive", argValue);
    }

    public ExerciseCommand exerciseACBRCFixing_Lifecycle(ACBRCFixing_Lifecycle arg) {
      Value argValue = arg.toValue();
      return new ExerciseCommand(ACBRCFixingRule.TEMPLATE_ID, this.contractId, "ACBRCFixing_Lifecycle", argValue);
    }

    public ExerciseCommand exerciseACBRCFixing_Lifecycle(ACBRC.ContractId acbrcCid,
        Fixing.ContractId fixingCid) {
      return exerciseACBRCFixing_Lifecycle(new ACBRCFixing_Lifecycle(acbrcCid, fixingCid));
    }
  }

  public static class Contract implements com.daml.ledger.javaapi.data.Contract {
    public final ContractId id;

    public final ACBRCFixingRule data;

    public final Optional<String> agreementText;

    public final Optional<Set<String>> key;

    public final java.util.Set<String> signatories;

    public final java.util.Set<String> observers;

    public Contract(ContractId id, ACBRCFixingRule data, Optional<String> agreementText,
        Optional<Set<String>> key, java.util.Set<String> signatories,
        java.util.Set<String> observers) {
      this.id = id;
      this.data = data;
      this.agreementText = agreementText;
      this.key = key;
      this.signatories = signatories;
      this.observers = observers;
    }

    public static Contract fromIdAndRecord(String contractId, DamlRecord record$,
        Optional<String> agreementText, Optional<Set<String>> key,
        java.util.Set<String> signatories, java.util.Set<String> observers) {
      ContractId id = new ContractId(contractId);
      ACBRCFixingRule data = ACBRCFixingRule.fromValue(record$);
      return new Contract(id, data, agreementText, key, signatories, observers);
    }

    @Deprecated
    public static Contract fromIdAndRecord(String contractId, DamlRecord record$) {
      ContractId id = new ContractId(contractId);
      ACBRCFixingRule data = ACBRCFixingRule.fromValue(record$);
      return new Contract(id, data, Optional.empty(), Optional.empty(), Collections.emptySet(), Collections.emptySet());
    }

    public static Contract fromCreatedEvent(CreatedEvent event) {
      return fromIdAndRecord(event.getContractId(), event.getArguments(), event.getAgreementText(), event.getContractKey().map(e -> Set.<java.lang.String>fromValue(e, v$0 -> v$0.asParty().orElseThrow(() -> new IllegalArgumentException("Expected e to be of type com.daml.ledger.javaapi.data.Party")).getValue())), event.getSignatories(), event.getObservers());
    }

    @Override
    public boolean equals(Object object) {
      if (this == object) {
        return true;
      }
      if (object == null) {
        return false;
      }
      if (!(object instanceof Contract)) {
        return false;
      }
      Contract other = (Contract) object;
      return this.id.equals(other.id) && this.data.equals(other.data) && this.agreementText.equals(other.agreementText) && this.key.equals(other.key) && this.signatories.equals(other.signatories) && this.observers.equals(other.observers);
    }

    @Override
    public int hashCode() {
      return Objects.hash(this.id, this.data, this.agreementText, this.key, this.signatories, this.observers);
    }

    @Override
    public String toString() {
      return String.format("com.daml.generated.da.finance.instrument.equity.acbrc.lifecycle.ACBRCFixingRule.Contract(%s, %s, %s, %s, %s, %s)", this.id, this.data, this.agreementText, this.key, this.signatories, this.observers);
    }
  }
}
