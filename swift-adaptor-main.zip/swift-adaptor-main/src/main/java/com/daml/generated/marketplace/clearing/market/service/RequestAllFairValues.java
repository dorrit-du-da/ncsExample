package com.daml.generated.marketplace.clearing.market.service;

import com.daml.generated.da.finance.types.Id;
import com.daml.ledger.javaapi.data.DamlRecord;
import com.daml.ledger.javaapi.data.Party;
import com.daml.ledger.javaapi.data.Text;
import com.daml.ledger.javaapi.data.Timestamp;
import com.daml.ledger.javaapi.data.Value;
import java.lang.IllegalArgumentException;
import java.lang.Object;
import java.lang.Override;
import java.lang.String;
import java.time.Instant;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

public class RequestAllFairValues {
  public static final String _packageId = "636e6e778aedec0710919591e9cb2a9404d6daab0581e4ddc515eeae03256f45";

  public final String party;

  public final String calculationId;

  public final Instant upTo;

  public final Id currency;

  public RequestAllFairValues(String party, String calculationId, Instant upTo, Id currency) {
    this.party = party;
    this.calculationId = calculationId;
    this.upTo = upTo;
    this.currency = currency;
  }

  public static RequestAllFairValues fromValue(Value value$) throws IllegalArgumentException {
    Value recordValue$ = value$;
    DamlRecord record$ = recordValue$.asRecord().orElseThrow(() -> new IllegalArgumentException("Contracts must be constructed from Records"));
    List<DamlRecord.Field> fields$ = record$.getFields();
    int numberOfFields = fields$.size();
    if (numberOfFields != 4) {
      throw new IllegalArgumentException("Expected 4 arguments, got " + numberOfFields);
    }
    String party = fields$.get(0).getValue().asParty().orElseThrow(() -> new IllegalArgumentException("Expected party to be of type com.daml.ledger.javaapi.data.Party")).getValue();
    String calculationId = fields$.get(1).getValue().asText().orElseThrow(() -> new IllegalArgumentException("Expected calculationId to be of type com.daml.ledger.javaapi.data.Text")).getValue();
    Instant upTo = fields$.get(2).getValue().asTimestamp().orElseThrow(() -> new IllegalArgumentException("Expected upTo to be of type com.daml.ledger.javaapi.data.Timestamp")).getValue();
    Id currency = Id.fromValue(fields$.get(3).getValue());
    return new com.daml.generated.marketplace.clearing.market.service.RequestAllFairValues(party, calculationId, upTo, currency);
  }

  public DamlRecord toValue() {
    ArrayList<DamlRecord.Field> fields = new ArrayList<DamlRecord.Field>(4);
    fields.add(new DamlRecord.Field("party", new Party(this.party)));
    fields.add(new DamlRecord.Field("calculationId", new Text(this.calculationId)));
    fields.add(new DamlRecord.Field("upTo", Timestamp.fromInstant(this.upTo)));
    fields.add(new DamlRecord.Field("currency", this.currency.toValue()));
    return new DamlRecord(fields);
  }

  @Override
  public boolean equals(Object object) {
    if (this == object) {
      return true;
    }
    if (object == null) {
      return false;
    }
    if (!(object instanceof RequestAllFairValues)) {
      return false;
    }
    RequestAllFairValues other = (RequestAllFairValues) object;
    return this.party.equals(other.party) && this.calculationId.equals(other.calculationId) && this.upTo.equals(other.upTo) && this.currency.equals(other.currency);
  }

  @Override
  public int hashCode() {
    return Objects.hash(this.party, this.calculationId, this.upTo, this.currency);
  }

  @Override
  public String toString() {
    return String.format("com.daml.generated.marketplace.clearing.market.service.RequestAllFairValues(%s, %s, %s, %s)", this.party, this.calculationId, this.upTo, this.currency);
  }
}
