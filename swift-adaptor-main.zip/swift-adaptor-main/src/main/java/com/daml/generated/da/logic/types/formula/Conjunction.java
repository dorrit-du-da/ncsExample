package com.daml.generated.da.logic.types.formula;

import com.daml.generated.da.logic.types.Formula;
import com.daml.ledger.javaapi.data.DamlCollectors;
import com.daml.ledger.javaapi.data.Value;
import com.daml.ledger.javaapi.data.Variant;
import java.lang.IllegalArgumentException;
import java.lang.Object;
import java.lang.Override;
import java.lang.String;
import java.util.List;
import java.util.Objects;
import java.util.function.Function;

public class Conjunction<a> extends Formula<a> {
  public static final String _packageId = "c1f1f00558799eec139fb4f4c76f95fb52fa1837a5dd29600baa1c8ed1bdccfd";

  public final List<Formula<a>> listValue;

  public Conjunction(List<Formula<a>> listValue) {
    this.listValue = listValue;
  }

  public Variant toValue(Function<a, Value> toValuea) {
    return new Variant("Conjunction", this.listValue.stream().collect(DamlCollectors.toDamlList(v$0 -> v$0.toValue(v$1 -> toValuea.apply(v$1)))));
  }

  public static <a> Conjunction<a> fromValue(Value value$, Function<Value, a> fromValuea) throws
      IllegalArgumentException {
    Variant variant$ = value$.asVariant().orElseThrow(() -> new IllegalArgumentException("Expected: Variant. Actual: " + value$.getClass().getName()));
    if (!"Conjunction".equals(variant$.getConstructor())) throw new IllegalArgumentException("Invalid constructor. Expected: Conjunction. Actual: " + variant$.getConstructor());
    Value variantValue$ = variant$.getValue();
    List<Formula<a>> body = variantValue$.asList()
            .map(v$0 -> v$0.toList(v$1 ->
                Formula.<a>fromValue(v$1, v$2 -> fromValuea.apply(v$2))
            ))
            .orElseThrow(() -> new IllegalArgumentException("Expected body to be of type com.daml.ledger.javaapi.data.DamlList"))
        ;
    return new Conjunction<a>(body);
  }

  @Override
  public boolean equals(Object object) {
    if (this == object) {
      return true;
    }
    if (object == null) {
      return false;
    }
    if (!(object instanceof Conjunction<?>)) {
      return false;
    }
    Conjunction<?> other = (Conjunction<?>) object;
    return this.listValue.equals(other.listValue);
  }

  @Override
  public int hashCode() {
    return Objects.hash(this.listValue);
  }

  @Override
  public String toString() {
    return String.format("Conjunction(%s)", this.listValue);
  }
}
