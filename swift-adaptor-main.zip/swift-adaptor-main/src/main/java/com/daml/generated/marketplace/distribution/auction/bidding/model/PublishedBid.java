package com.daml.generated.marketplace.distribution.auction.bidding.model;

import com.daml.ledger.javaapi.data.DamlRecord;
import com.daml.ledger.javaapi.data.Numeric;
import com.daml.ledger.javaapi.data.Party;
import com.daml.ledger.javaapi.data.Text;
import com.daml.ledger.javaapi.data.Value;
import java.lang.IllegalArgumentException;
import java.lang.Object;
import java.lang.Override;
import java.lang.String;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

public class PublishedBid {
  public static final String _packageId = "636e6e778aedec0710919591e9cb2a9404d6daab0581e4ddc515eeae03256f45";

  public final String investor;

  public final String auctionId;

  public final BigDecimal quantity;

  public PublishedBid(String investor, String auctionId, BigDecimal quantity) {
    this.investor = investor;
    this.auctionId = auctionId;
    this.quantity = quantity;
  }

  public static PublishedBid fromValue(Value value$) throws IllegalArgumentException {
    Value recordValue$ = value$;
    DamlRecord record$ = recordValue$.asRecord().orElseThrow(() -> new IllegalArgumentException("Contracts must be constructed from Records"));
    List<DamlRecord.Field> fields$ = record$.getFields();
    int numberOfFields = fields$.size();
    if (numberOfFields != 3) {
      throw new IllegalArgumentException("Expected 3 arguments, got " + numberOfFields);
    }
    String investor = fields$.get(0).getValue().asParty().orElseThrow(() -> new IllegalArgumentException("Expected investor to be of type com.daml.ledger.javaapi.data.Party")).getValue();
    String auctionId = fields$.get(1).getValue().asText().orElseThrow(() -> new IllegalArgumentException("Expected auctionId to be of type com.daml.ledger.javaapi.data.Text")).getValue();
    BigDecimal quantity = fields$.get(2).getValue().asNumeric().orElseThrow(() -> new IllegalArgumentException("Expected quantity to be of type com.daml.ledger.javaapi.data.Numeric")).getValue();
    return new com.daml.generated.marketplace.distribution.auction.bidding.model.PublishedBid(investor, auctionId, quantity);
  }

  public DamlRecord toValue() {
    ArrayList<DamlRecord.Field> fields = new ArrayList<DamlRecord.Field>(3);
    fields.add(new DamlRecord.Field("investor", new Party(this.investor)));
    fields.add(new DamlRecord.Field("auctionId", new Text(this.auctionId)));
    fields.add(new DamlRecord.Field("quantity", new Numeric(this.quantity)));
    return new DamlRecord(fields);
  }

  @Override
  public boolean equals(Object object) {
    if (this == object) {
      return true;
    }
    if (object == null) {
      return false;
    }
    if (!(object instanceof PublishedBid)) {
      return false;
    }
    PublishedBid other = (PublishedBid) object;
    return this.investor.equals(other.investor) && this.auctionId.equals(other.auctionId) && this.quantity.equals(other.quantity);
  }

  @Override
  public int hashCode() {
    return Objects.hash(this.investor, this.auctionId, this.quantity);
  }

  @Override
  public String toString() {
    return String.format("com.daml.generated.marketplace.distribution.auction.bidding.model.PublishedBid(%s, %s, %s)", this.investor, this.auctionId, this.quantity);
  }
}
