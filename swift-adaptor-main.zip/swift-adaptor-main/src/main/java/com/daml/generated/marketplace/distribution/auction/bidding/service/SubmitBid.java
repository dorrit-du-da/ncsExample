package com.daml.generated.marketplace.distribution.auction.bidding.service;

import com.daml.generated.da.finance.asset.AssetDeposit;
import com.daml.generated.da.finance.types.Account;
import com.daml.generated.marketplace.distribution.auction.bidding.model.Auction;
import com.daml.ledger.javaapi.data.Bool;
import com.daml.ledger.javaapi.data.DamlRecord;
import com.daml.ledger.javaapi.data.Numeric;
import com.daml.ledger.javaapi.data.Value;
import java.lang.Boolean;
import java.lang.IllegalArgumentException;
import java.lang.Object;
import java.lang.Override;
import java.lang.String;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

public class SubmitBid {
  public static final String _packageId = "636e6e778aedec0710919591e9cb2a9404d6daab0581e4ddc515eeae03256f45";

  public final Auction.ContractId auctionCid;

  public final BigDecimal price;

  public final BigDecimal quantity;

  public final AssetDeposit.ContractId depositCid;

  public final Account receivableAccount;

  public final Boolean allowPublishing;

  public SubmitBid(Auction.ContractId auctionCid, BigDecimal price, BigDecimal quantity,
      AssetDeposit.ContractId depositCid, Account receivableAccount, Boolean allowPublishing) {
    this.auctionCid = auctionCid;
    this.price = price;
    this.quantity = quantity;
    this.depositCid = depositCid;
    this.receivableAccount = receivableAccount;
    this.allowPublishing = allowPublishing;
  }

  public static SubmitBid fromValue(Value value$) throws IllegalArgumentException {
    Value recordValue$ = value$;
    DamlRecord record$ = recordValue$.asRecord().orElseThrow(() -> new IllegalArgumentException("Contracts must be constructed from Records"));
    List<DamlRecord.Field> fields$ = record$.getFields();
    int numberOfFields = fields$.size();
    if (numberOfFields != 6) {
      throw new IllegalArgumentException("Expected 6 arguments, got " + numberOfFields);
    }
    Auction.ContractId auctionCid = new Auction.ContractId(fields$.get(0).getValue().asContractId().orElseThrow(() -> new IllegalArgumentException("Expected auctionCid to be of type com.daml.ledger.javaapi.data.ContractId")).getValue());
    BigDecimal price = fields$.get(1).getValue().asNumeric().orElseThrow(() -> new IllegalArgumentException("Expected price to be of type com.daml.ledger.javaapi.data.Numeric")).getValue();
    BigDecimal quantity = fields$.get(2).getValue().asNumeric().orElseThrow(() -> new IllegalArgumentException("Expected quantity to be of type com.daml.ledger.javaapi.data.Numeric")).getValue();
    AssetDeposit.ContractId depositCid = new AssetDeposit.ContractId(fields$.get(3).getValue().asContractId().orElseThrow(() -> new IllegalArgumentException("Expected depositCid to be of type com.daml.ledger.javaapi.data.ContractId")).getValue());
    Account receivableAccount = Account.fromValue(fields$.get(4).getValue());
    Boolean allowPublishing = fields$.get(5).getValue().asBool().orElseThrow(() -> new IllegalArgumentException("Expected allowPublishing to be of type com.daml.ledger.javaapi.data.Bool")).getValue();
    return new com.daml.generated.marketplace.distribution.auction.bidding.service.SubmitBid(auctionCid, price, quantity, depositCid, receivableAccount, allowPublishing);
  }

  public DamlRecord toValue() {
    ArrayList<DamlRecord.Field> fields = new ArrayList<DamlRecord.Field>(6);
    fields.add(new DamlRecord.Field("auctionCid", this.auctionCid.toValue()));
    fields.add(new DamlRecord.Field("price", new Numeric(this.price)));
    fields.add(new DamlRecord.Field("quantity", new Numeric(this.quantity)));
    fields.add(new DamlRecord.Field("depositCid", this.depositCid.toValue()));
    fields.add(new DamlRecord.Field("receivableAccount", this.receivableAccount.toValue()));
    fields.add(new DamlRecord.Field("allowPublishing", new Bool(this.allowPublishing)));
    return new DamlRecord(fields);
  }

  @Override
  public boolean equals(Object object) {
    if (this == object) {
      return true;
    }
    if (object == null) {
      return false;
    }
    if (!(object instanceof SubmitBid)) {
      return false;
    }
    SubmitBid other = (SubmitBid) object;
    return this.auctionCid.equals(other.auctionCid) && this.price.equals(other.price) && this.quantity.equals(other.quantity) && this.depositCid.equals(other.depositCid) && this.receivableAccount.equals(other.receivableAccount) && this.allowPublishing.equals(other.allowPublishing);
  }

  @Override
  public int hashCode() {
    return Objects.hash(this.auctionCid, this.price, this.quantity, this.depositCid, this.receivableAccount, this.allowPublishing);
  }

  @Override
  public String toString() {
    return String.format("com.daml.generated.marketplace.distribution.auction.bidding.service.SubmitBid(%s, %s, %s, %s, %s, %s)", this.auctionCid, this.price, this.quantity, this.depositCid, this.receivableAccount, this.allowPublishing);
  }
}
