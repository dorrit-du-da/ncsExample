package com.daml.generated.contingentclaims.claim.serializable.claim;

import com.daml.generated.contingentclaims.claim.serializable.Claim;
import com.daml.ledger.javaapi.data.DamlCollectors;
import com.daml.ledger.javaapi.data.DamlRecord;
import com.daml.ledger.javaapi.data.Value;
import com.daml.ledger.javaapi.data.Variant;
import java.lang.IllegalArgumentException;
import java.lang.Object;
import java.lang.Override;
import java.lang.String;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.function.Function;

public class And<t, x, a> extends Claim<t, x, a> {
  public static final String _packageId = "636e6e778aedec0710919591e9cb2a9404d6daab0581e4ddc515eeae03256f45";

  public final List<Claim<t, x, a>> claims;

  public And(List<Claim<t, x, a>> claims) {
    this.claims = claims;
  }

  public Variant toValue(Function<t, Value> toValuet, Function<x, Value> toValuex,
      Function<a, Value> toValuea) {
    ArrayList<DamlRecord.Field> fields = new ArrayList<DamlRecord.Field>(1);
    fields.add(new DamlRecord.Field("claims", this.claims.stream().collect(DamlCollectors.toDamlList(v$0 -> v$0.toValue(v$1 -> toValuet.apply(v$1),v$2 -> toValuex.apply(v$2),v$3 -> toValuea.apply(v$3))))));
    return new Variant("And", new DamlRecord(fields));
  }

  public static <t, x, a> And<t, x, a> fromValue(Value value$, Function<Value, t> fromValuet,
      Function<Value, x> fromValuex, Function<Value, a> fromValuea) throws
      IllegalArgumentException {
    Variant variant$ = value$.asVariant().orElseThrow(() -> new IllegalArgumentException("Expected: Variant. Actual: " + value$.getClass().getName()));
    if (!"And".equals(variant$.getConstructor())) throw new IllegalArgumentException("Invalid constructor. Expected: And. Actual: " + variant$.getConstructor());
    Value recordValue$ = variant$.getValue();
    DamlRecord record$ = recordValue$.asRecord().orElseThrow(() -> new IllegalArgumentException("Contracts must be constructed from Records"));
    List<DamlRecord.Field> fields$ = record$.getFields();
    int numberOfFields = fields$.size();
    if (numberOfFields != 1) {
      throw new IllegalArgumentException("Expected 1 arguments, got " + numberOfFields);
    }
    List<Claim<t, x, a>> claims = fields$.get(0).getValue().asList()
            .map(v$0 -> v$0.toList(v$1 ->
                Claim.<t, x, a>fromValue(v$1, v$2 -> fromValuet.apply(v$2), v$3 -> fromValuex.apply(v$3), v$4 -> fromValuea.apply(v$4))
            ))
            .orElseThrow(() -> new IllegalArgumentException("Expected claims to be of type com.daml.ledger.javaapi.data.DamlList"))
        ;
    return new And<t, x, a>(claims);
  }

  @Override
  public boolean equals(Object object) {
    if (this == object) {
      return true;
    }
    if (object == null) {
      return false;
    }
    if (!(object instanceof And<?, ?, ?>)) {
      return false;
    }
    And<?, ?, ?> other = (And<?, ?, ?>) object;
    return this.claims.equals(other.claims);
  }

  @Override
  public int hashCode() {
    return Objects.hash(this.claims);
  }

  @Override
  public String toString() {
    return String.format("And(%s)", this.claims);
  }
}
