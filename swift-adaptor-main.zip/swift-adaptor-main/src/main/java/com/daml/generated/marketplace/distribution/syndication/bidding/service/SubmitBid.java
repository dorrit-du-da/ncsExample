package com.daml.generated.marketplace.distribution.syndication.bidding.service;

import com.daml.generated.marketplace.distribution.syndication.bidding.model.BidRequest;
import com.daml.ledger.javaapi.data.DamlRecord;
import com.daml.ledger.javaapi.data.Numeric;
import com.daml.ledger.javaapi.data.Value;
import java.lang.IllegalArgumentException;
import java.lang.Object;
import java.lang.Override;
import java.lang.String;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

public class SubmitBid {
  public static final String _packageId = "636e6e778aedec0710919591e9cb2a9404d6daab0581e4ddc515eeae03256f45";

  public final BidRequest.ContractId bidRequestCid;

  public final BigDecimal price;

  public final BigDecimal quantity;

  public SubmitBid(BidRequest.ContractId bidRequestCid, BigDecimal price, BigDecimal quantity) {
    this.bidRequestCid = bidRequestCid;
    this.price = price;
    this.quantity = quantity;
  }

  public static SubmitBid fromValue(Value value$) throws IllegalArgumentException {
    Value recordValue$ = value$;
    DamlRecord record$ = recordValue$.asRecord().orElseThrow(() -> new IllegalArgumentException("Contracts must be constructed from Records"));
    List<DamlRecord.Field> fields$ = record$.getFields();
    int numberOfFields = fields$.size();
    if (numberOfFields != 3) {
      throw new IllegalArgumentException("Expected 3 arguments, got " + numberOfFields);
    }
    BidRequest.ContractId bidRequestCid = new BidRequest.ContractId(fields$.get(0).getValue().asContractId().orElseThrow(() -> new IllegalArgumentException("Expected bidRequestCid to be of type com.daml.ledger.javaapi.data.ContractId")).getValue());
    BigDecimal price = fields$.get(1).getValue().asNumeric().orElseThrow(() -> new IllegalArgumentException("Expected price to be of type com.daml.ledger.javaapi.data.Numeric")).getValue();
    BigDecimal quantity = fields$.get(2).getValue().asNumeric().orElseThrow(() -> new IllegalArgumentException("Expected quantity to be of type com.daml.ledger.javaapi.data.Numeric")).getValue();
    return new com.daml.generated.marketplace.distribution.syndication.bidding.service.SubmitBid(bidRequestCid, price, quantity);
  }

  public DamlRecord toValue() {
    ArrayList<DamlRecord.Field> fields = new ArrayList<DamlRecord.Field>(3);
    fields.add(new DamlRecord.Field("bidRequestCid", this.bidRequestCid.toValue()));
    fields.add(new DamlRecord.Field("price", new Numeric(this.price)));
    fields.add(new DamlRecord.Field("quantity", new Numeric(this.quantity)));
    return new DamlRecord(fields);
  }

  @Override
  public boolean equals(Object object) {
    if (this == object) {
      return true;
    }
    if (object == null) {
      return false;
    }
    if (!(object instanceof SubmitBid)) {
      return false;
    }
    SubmitBid other = (SubmitBid) object;
    return this.bidRequestCid.equals(other.bidRequestCid) && this.price.equals(other.price) && this.quantity.equals(other.quantity);
  }

  @Override
  public int hashCode() {
    return Objects.hash(this.bidRequestCid, this.price, this.quantity);
  }

  @Override
  public String toString() {
    return String.format("com.daml.generated.marketplace.distribution.syndication.bidding.service.SubmitBid(%s, %s, %s)", this.bidRequestCid, this.price, this.quantity);
  }
}
