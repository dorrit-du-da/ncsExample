package com.daml.generated.marketplace.custody.model;

import com.daml.ledger.javaapi.data.DamlRecord;
import com.daml.ledger.javaapi.data.Party;
import com.daml.ledger.javaapi.data.Value;
import java.lang.IllegalArgumentException;
import java.lang.Object;
import java.lang.Override;
import java.lang.String;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

public class SetSecuritiesAccount {
  public static final String _packageId = "636e6e778aedec0710919591e9cb2a9404d6daab0581e4ddc515eeae03256f45";

  public final String beneficiary;

  public final AccountInfo.ContractId accountInfoCid;

  public SetSecuritiesAccount(String beneficiary, AccountInfo.ContractId accountInfoCid) {
    this.beneficiary = beneficiary;
    this.accountInfoCid = accountInfoCid;
  }

  public static SetSecuritiesAccount fromValue(Value value$) throws IllegalArgumentException {
    Value recordValue$ = value$;
    DamlRecord record$ = recordValue$.asRecord().orElseThrow(() -> new IllegalArgumentException("Contracts must be constructed from Records"));
    List<DamlRecord.Field> fields$ = record$.getFields();
    int numberOfFields = fields$.size();
    if (numberOfFields != 2) {
      throw new IllegalArgumentException("Expected 2 arguments, got " + numberOfFields);
    }
    String beneficiary = fields$.get(0).getValue().asParty().orElseThrow(() -> new IllegalArgumentException("Expected beneficiary to be of type com.daml.ledger.javaapi.data.Party")).getValue();
    AccountInfo.ContractId accountInfoCid = new AccountInfo.ContractId(fields$.get(1).getValue().asContractId().orElseThrow(() -> new IllegalArgumentException("Expected accountInfoCid to be of type com.daml.ledger.javaapi.data.ContractId")).getValue());
    return new com.daml.generated.marketplace.custody.model.SetSecuritiesAccount(beneficiary, accountInfoCid);
  }

  public DamlRecord toValue() {
    ArrayList<DamlRecord.Field> fields = new ArrayList<DamlRecord.Field>(2);
    fields.add(new DamlRecord.Field("beneficiary", new Party(this.beneficiary)));
    fields.add(new DamlRecord.Field("accountInfoCid", this.accountInfoCid.toValue()));
    return new DamlRecord(fields);
  }

  @Override
  public boolean equals(Object object) {
    if (this == object) {
      return true;
    }
    if (object == null) {
      return false;
    }
    if (!(object instanceof SetSecuritiesAccount)) {
      return false;
    }
    SetSecuritiesAccount other = (SetSecuritiesAccount) object;
    return this.beneficiary.equals(other.beneficiary) && this.accountInfoCid.equals(other.accountInfoCid);
  }

  @Override
  public int hashCode() {
    return Objects.hash(this.beneficiary, this.accountInfoCid);
  }

  @Override
  public String toString() {
    return String.format("com.daml.generated.marketplace.custody.model.SetSecuritiesAccount(%s, %s)", this.beneficiary, this.accountInfoCid);
  }
}
