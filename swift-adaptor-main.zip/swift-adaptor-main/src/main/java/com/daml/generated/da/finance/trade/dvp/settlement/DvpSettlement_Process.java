package com.daml.generated.da.finance.trade.dvp.settlement;

import com.daml.generated.da.finance.trade.dvp.Dvp;
import com.daml.generated.da.finance.trade.settlementinstruction.SettlementInstruction;
import com.daml.ledger.javaapi.data.DamlCollectors;
import com.daml.ledger.javaapi.data.DamlRecord;
import com.daml.ledger.javaapi.data.Party;
import com.daml.ledger.javaapi.data.Value;
import java.lang.IllegalArgumentException;
import java.lang.Object;
import java.lang.Override;
import java.lang.String;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

public class DvpSettlement_Process {
  public static final String _packageId = "636e6e778aedec0710919591e9cb2a9404d6daab0581e4ddc515eeae03256f45";

  public final Dvp.ContractId dvpCid;

  public final List<SettlementInstruction.ContractId> paymentInstructionCids;

  public final List<SettlementInstruction.ContractId> deliveryInstructionCids;

  public final String ctrl;

  public DvpSettlement_Process(Dvp.ContractId dvpCid,
      List<SettlementInstruction.ContractId> paymentInstructionCids,
      List<SettlementInstruction.ContractId> deliveryInstructionCids, String ctrl) {
    this.dvpCid = dvpCid;
    this.paymentInstructionCids = paymentInstructionCids;
    this.deliveryInstructionCids = deliveryInstructionCids;
    this.ctrl = ctrl;
  }

  public static DvpSettlement_Process fromValue(Value value$) throws IllegalArgumentException {
    Value recordValue$ = value$;
    DamlRecord record$ = recordValue$.asRecord().orElseThrow(() -> new IllegalArgumentException("Contracts must be constructed from Records"));
    List<DamlRecord.Field> fields$ = record$.getFields();
    int numberOfFields = fields$.size();
    if (numberOfFields != 4) {
      throw new IllegalArgumentException("Expected 4 arguments, got " + numberOfFields);
    }
    Dvp.ContractId dvpCid = new Dvp.ContractId(fields$.get(0).getValue().asContractId().orElseThrow(() -> new IllegalArgumentException("Expected dvpCid to be of type com.daml.ledger.javaapi.data.ContractId")).getValue());
    List<SettlementInstruction.ContractId> paymentInstructionCids = fields$.get(1).getValue().asList()
            .map(v$0 -> v$0.toList(v$1 ->
                new SettlementInstruction.ContractId(v$1.asContractId().orElseThrow(() -> new IllegalArgumentException("Expected v$1 to be of type com.daml.ledger.javaapi.data.ContractId")).getValue())
            ))
            .orElseThrow(() -> new IllegalArgumentException("Expected paymentInstructionCids to be of type com.daml.ledger.javaapi.data.DamlList"))
        ;
    List<SettlementInstruction.ContractId> deliveryInstructionCids = fields$.get(2).getValue().asList()
            .map(v$0 -> v$0.toList(v$1 ->
                new SettlementInstruction.ContractId(v$1.asContractId().orElseThrow(() -> new IllegalArgumentException("Expected v$1 to be of type com.daml.ledger.javaapi.data.ContractId")).getValue())
            ))
            .orElseThrow(() -> new IllegalArgumentException("Expected deliveryInstructionCids to be of type com.daml.ledger.javaapi.data.DamlList"))
        ;
    String ctrl = fields$.get(3).getValue().asParty().orElseThrow(() -> new IllegalArgumentException("Expected ctrl to be of type com.daml.ledger.javaapi.data.Party")).getValue();
    return new com.daml.generated.da.finance.trade.dvp.settlement.DvpSettlement_Process(dvpCid, paymentInstructionCids, deliveryInstructionCids, ctrl);
  }

  public DamlRecord toValue() {
    ArrayList<DamlRecord.Field> fields = new ArrayList<DamlRecord.Field>(4);
    fields.add(new DamlRecord.Field("dvpCid", this.dvpCid.toValue()));
    fields.add(new DamlRecord.Field("paymentInstructionCids", this.paymentInstructionCids.stream().collect(DamlCollectors.toDamlList(v$0 -> v$0.toValue()))));
    fields.add(new DamlRecord.Field("deliveryInstructionCids", this.deliveryInstructionCids.stream().collect(DamlCollectors.toDamlList(v$0 -> v$0.toValue()))));
    fields.add(new DamlRecord.Field("ctrl", new Party(this.ctrl)));
    return new DamlRecord(fields);
  }

  @Override
  public boolean equals(Object object) {
    if (this == object) {
      return true;
    }
    if (object == null) {
      return false;
    }
    if (!(object instanceof DvpSettlement_Process)) {
      return false;
    }
    DvpSettlement_Process other = (DvpSettlement_Process) object;
    return this.dvpCid.equals(other.dvpCid) && this.paymentInstructionCids.equals(other.paymentInstructionCids) && this.deliveryInstructionCids.equals(other.deliveryInstructionCids) && this.ctrl.equals(other.ctrl);
  }

  @Override
  public int hashCode() {
    return Objects.hash(this.dvpCid, this.paymentInstructionCids, this.deliveryInstructionCids, this.ctrl);
  }

  @Override
  public String toString() {
    return String.format("com.daml.generated.da.finance.trade.dvp.settlement.DvpSettlement_Process(%s, %s, %s, %s)", this.dvpCid, this.paymentInstructionCids, this.deliveryInstructionCids, this.ctrl);
  }
}
