package com.daml.generated.marketplace.custody.role;

import com.daml.ledger.javaapi.data.DamlRecord;
import com.daml.ledger.javaapi.data.Party;
import com.daml.ledger.javaapi.data.Value;
import java.lang.IllegalArgumentException;
import java.lang.Object;
import java.lang.Override;
import java.lang.String;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

public class OfferCustodyService {
  public static final String _packageId = "636e6e778aedec0710919591e9cb2a9404d6daab0581e4ddc515eeae03256f45";

  public final String customer;

  public OfferCustodyService(String customer) {
    this.customer = customer;
  }

  public static OfferCustodyService fromValue(Value value$) throws IllegalArgumentException {
    Value recordValue$ = value$;
    DamlRecord record$ = recordValue$.asRecord().orElseThrow(() -> new IllegalArgumentException("Contracts must be constructed from Records"));
    List<DamlRecord.Field> fields$ = record$.getFields();
    int numberOfFields = fields$.size();
    if (numberOfFields != 1) {
      throw new IllegalArgumentException("Expected 1 arguments, got " + numberOfFields);
    }
    String customer = fields$.get(0).getValue().asParty().orElseThrow(() -> new IllegalArgumentException("Expected customer to be of type com.daml.ledger.javaapi.data.Party")).getValue();
    return new com.daml.generated.marketplace.custody.role.OfferCustodyService(customer);
  }

  public DamlRecord toValue() {
    ArrayList<DamlRecord.Field> fields = new ArrayList<DamlRecord.Field>(1);
    fields.add(new DamlRecord.Field("customer", new Party(this.customer)));
    return new DamlRecord(fields);
  }

  @Override
  public boolean equals(Object object) {
    if (this == object) {
      return true;
    }
    if (object == null) {
      return false;
    }
    if (!(object instanceof OfferCustodyService)) {
      return false;
    }
    OfferCustodyService other = (OfferCustodyService) object;
    return this.customer.equals(other.customer);
  }

  @Override
  public int hashCode() {
    return Objects.hash(this.customer);
  }

  @Override
  public String toString() {
    return String.format("com.daml.generated.marketplace.custody.role.OfferCustodyService(%s)", this.customer);
  }
}
