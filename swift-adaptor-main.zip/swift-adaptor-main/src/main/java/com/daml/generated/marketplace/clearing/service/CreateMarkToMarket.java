package com.daml.generated.marketplace.clearing.service;

import com.daml.generated.da.finance.types.Id;
import com.daml.ledger.javaapi.data.DamlRecord;
import com.daml.ledger.javaapi.data.Numeric;
import com.daml.ledger.javaapi.data.Text;
import com.daml.ledger.javaapi.data.Value;
import java.lang.IllegalArgumentException;
import java.lang.Object;
import java.lang.Override;
import java.lang.String;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

public class CreateMarkToMarket {
  public static final String _packageId = "636e6e778aedec0710919591e9cb2a9404d6daab0581e4ddc515eeae03256f45";

  public final BigDecimal mtmAmount;

  public final Id currency;

  public final String calculationId;

  public CreateMarkToMarket(BigDecimal mtmAmount, Id currency, String calculationId) {
    this.mtmAmount = mtmAmount;
    this.currency = currency;
    this.calculationId = calculationId;
  }

  public static CreateMarkToMarket fromValue(Value value$) throws IllegalArgumentException {
    Value recordValue$ = value$;
    DamlRecord record$ = recordValue$.asRecord().orElseThrow(() -> new IllegalArgumentException("Contracts must be constructed from Records"));
    List<DamlRecord.Field> fields$ = record$.getFields();
    int numberOfFields = fields$.size();
    if (numberOfFields != 3) {
      throw new IllegalArgumentException("Expected 3 arguments, got " + numberOfFields);
    }
    BigDecimal mtmAmount = fields$.get(0).getValue().asNumeric().orElseThrow(() -> new IllegalArgumentException("Expected mtmAmount to be of type com.daml.ledger.javaapi.data.Numeric")).getValue();
    Id currency = Id.fromValue(fields$.get(1).getValue());
    String calculationId = fields$.get(2).getValue().asText().orElseThrow(() -> new IllegalArgumentException("Expected calculationId to be of type com.daml.ledger.javaapi.data.Text")).getValue();
    return new com.daml.generated.marketplace.clearing.service.CreateMarkToMarket(mtmAmount, currency, calculationId);
  }

  public DamlRecord toValue() {
    ArrayList<DamlRecord.Field> fields = new ArrayList<DamlRecord.Field>(3);
    fields.add(new DamlRecord.Field("mtmAmount", new Numeric(this.mtmAmount)));
    fields.add(new DamlRecord.Field("currency", this.currency.toValue()));
    fields.add(new DamlRecord.Field("calculationId", new Text(this.calculationId)));
    return new DamlRecord(fields);
  }

  @Override
  public boolean equals(Object object) {
    if (this == object) {
      return true;
    }
    if (object == null) {
      return false;
    }
    if (!(object instanceof CreateMarkToMarket)) {
      return false;
    }
    CreateMarkToMarket other = (CreateMarkToMarket) object;
    return this.mtmAmount.equals(other.mtmAmount) && this.currency.equals(other.currency) && this.calculationId.equals(other.calculationId);
  }

  @Override
  public int hashCode() {
    return Objects.hash(this.mtmAmount, this.currency, this.calculationId);
  }

  @Override
  public String toString() {
    return String.format("com.daml.generated.marketplace.clearing.service.CreateMarkToMarket(%s, %s, %s)", this.mtmAmount, this.currency, this.calculationId);
  }
}
