package com.daml.generated.da.finance.trade.types;

import com.daml.ledger.javaapi.data.DamlEnum;
import com.daml.ledger.javaapi.data.Value;
import java.lang.IllegalArgumentException;
import java.lang.String;
import java.util.HashMap;
import java.util.Map;

public enum SettlementStatus {
  SETTLEMENTSTATUS_PENDING,

  SETTLEMENTSTATUS_INSTRUCTED,

  SETTLEMENTSTATUS_SETTLED;

  private static final DamlEnum[] __values$ = {new DamlEnum("SettlementStatus_Pending"), new DamlEnum("SettlementStatus_Instructed"), new DamlEnum("SettlementStatus_Settled")};

  private static final Map<String, SettlementStatus> __enums$ = SettlementStatus.__buildEnumsMap$();

  private static final Map<String, SettlementStatus> __buildEnumsMap$() {
    Map<String, SettlementStatus> m = new HashMap<String, SettlementStatus>();
    m.put("SettlementStatus_Pending", SETTLEMENTSTATUS_PENDING);
    m.put("SettlementStatus_Instructed", SETTLEMENTSTATUS_INSTRUCTED);
    m.put("SettlementStatus_Settled", SETTLEMENTSTATUS_SETTLED);
    return m;
  }

  public static final SettlementStatus fromValue(Value value$) {
    String constructor$ = value$.asEnum().orElseThrow(() -> new IllegalArgumentException("Expected DamlEnum to build an instance of the Enum SettlementStatus")).getConstructor();
    if (!SettlementStatus.__enums$.containsKey(constructor$)) throw new IllegalArgumentException("Expected a DamlEnum with SettlementStatus constructor, found " + constructor$);
    return (SettlementStatus) SettlementStatus.__enums$.get(constructor$);
  }

  public final DamlEnum toValue() {
    return SettlementStatus.__values$[ordinal()];
  }
}
