package com.daml.generated.da.finance.types;

import com.daml.ledger.javaapi.data.DamlRecord;
import com.daml.ledger.javaapi.data.Party;
import com.daml.ledger.javaapi.data.Value;
import java.lang.IllegalArgumentException;
import java.lang.Object;
import java.lang.Override;
import java.lang.String;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

public class MasterAgreement {
  public static final String _packageId = "636e6e778aedec0710919591e9cb2a9404d6daab0581e4ddc515eeae03256f45";

  public final Id id;

  public final String party1;

  public final String party2;

  public MasterAgreement(Id id, String party1, String party2) {
    this.id = id;
    this.party1 = party1;
    this.party2 = party2;
  }

  public static MasterAgreement fromValue(Value value$) throws IllegalArgumentException {
    Value recordValue$ = value$;
    DamlRecord record$ = recordValue$.asRecord().orElseThrow(() -> new IllegalArgumentException("Contracts must be constructed from Records"));
    List<DamlRecord.Field> fields$ = record$.getFields();
    int numberOfFields = fields$.size();
    if (numberOfFields != 3) {
      throw new IllegalArgumentException("Expected 3 arguments, got " + numberOfFields);
    }
    Id id = Id.fromValue(fields$.get(0).getValue());
    String party1 = fields$.get(1).getValue().asParty().orElseThrow(() -> new IllegalArgumentException("Expected party1 to be of type com.daml.ledger.javaapi.data.Party")).getValue();
    String party2 = fields$.get(2).getValue().asParty().orElseThrow(() -> new IllegalArgumentException("Expected party2 to be of type com.daml.ledger.javaapi.data.Party")).getValue();
    return new com.daml.generated.da.finance.types.MasterAgreement(id, party1, party2);
  }

  public DamlRecord toValue() {
    ArrayList<DamlRecord.Field> fields = new ArrayList<DamlRecord.Field>(3);
    fields.add(new DamlRecord.Field("id", this.id.toValue()));
    fields.add(new DamlRecord.Field("party1", new Party(this.party1)));
    fields.add(new DamlRecord.Field("party2", new Party(this.party2)));
    return new DamlRecord(fields);
  }

  @Override
  public boolean equals(Object object) {
    if (this == object) {
      return true;
    }
    if (object == null) {
      return false;
    }
    if (!(object instanceof MasterAgreement)) {
      return false;
    }
    MasterAgreement other = (MasterAgreement) object;
    return this.id.equals(other.id) && this.party1.equals(other.party1) && this.party2.equals(other.party2);
  }

  @Override
  public int hashCode() {
    return Objects.hash(this.id, this.party1, this.party2);
  }

  @Override
  public String toString() {
    return String.format("com.daml.generated.da.finance.types.MasterAgreement(%s, %s, %s)", this.id, this.party1, this.party2);
  }
}
