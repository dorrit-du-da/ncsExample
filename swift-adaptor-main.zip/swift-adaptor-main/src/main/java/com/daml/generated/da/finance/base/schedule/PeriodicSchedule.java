package com.daml.generated.da.finance.base.schedule;

import com.daml.generated.da.finance.base.holidaycalendar.BusinessDayAdjustment;
import com.daml.ledger.javaapi.data.DamlOptional;
import com.daml.ledger.javaapi.data.DamlRecord;
import com.daml.ledger.javaapi.data.Date;
import com.daml.ledger.javaapi.data.Value;
import java.lang.IllegalArgumentException;
import java.lang.Object;
import java.lang.Override;
import java.lang.String;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.Optional;

public class PeriodicSchedule {
  public static final String _packageId = "636e6e778aedec0710919591e9cb2a9404d6daab0581e4ddc515eeae03256f45";

  public final LocalDate effectiveDate;

  public final LocalDate terminationDate;

  public final Optional<LocalDate> firstRegularPeriodStartDate;

  public final Optional<LocalDate> lastRegularPeriodEndDate;

  public final Frequency frequency;

  public final BusinessDayAdjustment businessDayAdjustment;

  public final Optional<BusinessDayAdjustment> effectiveDateBusinessDayAdjustment;

  public final Optional<BusinessDayAdjustment> terminationDateBusinessDayAdjustment;

  public final Optional<StubPeriodTypeEnum> stubPeriodType;

  public PeriodicSchedule(LocalDate effectiveDate, LocalDate terminationDate,
      Optional<LocalDate> firstRegularPeriodStartDate, Optional<LocalDate> lastRegularPeriodEndDate,
      Frequency frequency, BusinessDayAdjustment businessDayAdjustment,
      Optional<BusinessDayAdjustment> effectiveDateBusinessDayAdjustment,
      Optional<BusinessDayAdjustment> terminationDateBusinessDayAdjustment,
      Optional<StubPeriodTypeEnum> stubPeriodType) {
    this.effectiveDate = effectiveDate;
    this.terminationDate = terminationDate;
    this.firstRegularPeriodStartDate = firstRegularPeriodStartDate;
    this.lastRegularPeriodEndDate = lastRegularPeriodEndDate;
    this.frequency = frequency;
    this.businessDayAdjustment = businessDayAdjustment;
    this.effectiveDateBusinessDayAdjustment = effectiveDateBusinessDayAdjustment;
    this.terminationDateBusinessDayAdjustment = terminationDateBusinessDayAdjustment;
    this.stubPeriodType = stubPeriodType;
  }

  public static PeriodicSchedule fromValue(Value value$) throws IllegalArgumentException {
    Value recordValue$ = value$;
    DamlRecord record$ = recordValue$.asRecord().orElseThrow(() -> new IllegalArgumentException("Contracts must be constructed from Records"));
    List<DamlRecord.Field> fields$ = record$.getFields();
    int numberOfFields = fields$.size();
    if (numberOfFields != 9) {
      throw new IllegalArgumentException("Expected 9 arguments, got " + numberOfFields);
    }
    LocalDate effectiveDate = fields$.get(0).getValue().asDate().orElseThrow(() -> new IllegalArgumentException("Expected effectiveDate to be of type com.daml.ledger.javaapi.data.Date")).getValue();
    LocalDate terminationDate = fields$.get(1).getValue().asDate().orElseThrow(() -> new IllegalArgumentException("Expected terminationDate to be of type com.daml.ledger.javaapi.data.Date")).getValue();
    Optional<LocalDate> firstRegularPeriodStartDate = fields$.get(2).getValue().asOptional()
            .map(v$0 -> v$0.toOptional(v$1 ->
                v$1.asDate().orElseThrow(() -> new IllegalArgumentException("Expected v$1 to be of type com.daml.ledger.javaapi.data.Date")).getValue()
            ))
            .orElseThrow(() -> new IllegalArgumentException("Expected firstRegularPeriodStartDate to be of type com.daml.ledger.javaapi.data.DamlOptional"))
                  ;
    Optional<LocalDate> lastRegularPeriodEndDate = fields$.get(3).getValue().asOptional()
            .map(v$0 -> v$0.toOptional(v$1 ->
                v$1.asDate().orElseThrow(() -> new IllegalArgumentException("Expected v$1 to be of type com.daml.ledger.javaapi.data.Date")).getValue()
            ))
            .orElseThrow(() -> new IllegalArgumentException("Expected lastRegularPeriodEndDate to be of type com.daml.ledger.javaapi.data.DamlOptional"))
                  ;
    Frequency frequency = Frequency.fromValue(fields$.get(4).getValue());
    BusinessDayAdjustment businessDayAdjustment = BusinessDayAdjustment.fromValue(fields$.get(5).getValue());
    Optional<BusinessDayAdjustment> effectiveDateBusinessDayAdjustment = fields$.get(6).getValue().asOptional()
            .map(v$0 -> v$0.toOptional(v$1 ->
                BusinessDayAdjustment.fromValue(v$1)
            ))
            .orElseThrow(() -> new IllegalArgumentException("Expected effectiveDateBusinessDayAdjustment to be of type com.daml.ledger.javaapi.data.DamlOptional"))
                  ;
    Optional<BusinessDayAdjustment> terminationDateBusinessDayAdjustment = fields$.get(7).getValue().asOptional()
            .map(v$0 -> v$0.toOptional(v$1 ->
                BusinessDayAdjustment.fromValue(v$1)
            ))
            .orElseThrow(() -> new IllegalArgumentException("Expected terminationDateBusinessDayAdjustment to be of type com.daml.ledger.javaapi.data.DamlOptional"))
                  ;
    Optional<StubPeriodTypeEnum> stubPeriodType = fields$.get(8).getValue().asOptional()
            .map(v$0 -> v$0.toOptional(v$1 ->
                StubPeriodTypeEnum.fromValue(v$1)
            ))
            .orElseThrow(() -> new IllegalArgumentException("Expected stubPeriodType to be of type com.daml.ledger.javaapi.data.DamlOptional"))
                  ;
    return new com.daml.generated.da.finance.base.schedule.PeriodicSchedule(effectiveDate, terminationDate, firstRegularPeriodStartDate, lastRegularPeriodEndDate, frequency, businessDayAdjustment, effectiveDateBusinessDayAdjustment, terminationDateBusinessDayAdjustment, stubPeriodType);
  }

  public DamlRecord toValue() {
    ArrayList<DamlRecord.Field> fields = new ArrayList<DamlRecord.Field>(9);
    fields.add(new DamlRecord.Field("effectiveDate", new Date((int) this.effectiveDate.toEpochDay())));
    fields.add(new DamlRecord.Field("terminationDate", new Date((int) this.terminationDate.toEpochDay())));
    fields.add(new DamlRecord.Field("firstRegularPeriodStartDate", DamlOptional.of(this.firstRegularPeriodStartDate.map(v$0 -> new Date((int) v$0.toEpochDay())))));
    fields.add(new DamlRecord.Field("lastRegularPeriodEndDate", DamlOptional.of(this.lastRegularPeriodEndDate.map(v$0 -> new Date((int) v$0.toEpochDay())))));
    fields.add(new DamlRecord.Field("frequency", this.frequency.toValue()));
    fields.add(new DamlRecord.Field("businessDayAdjustment", this.businessDayAdjustment.toValue()));
    fields.add(new DamlRecord.Field("effectiveDateBusinessDayAdjustment", DamlOptional.of(this.effectiveDateBusinessDayAdjustment.map(v$0 -> v$0.toValue()))));
    fields.add(new DamlRecord.Field("terminationDateBusinessDayAdjustment", DamlOptional.of(this.terminationDateBusinessDayAdjustment.map(v$0 -> v$0.toValue()))));
    fields.add(new DamlRecord.Field("stubPeriodType", DamlOptional.of(this.stubPeriodType.map(v$0 -> v$0.toValue()))));
    return new DamlRecord(fields);
  }

  @Override
  public boolean equals(Object object) {
    if (this == object) {
      return true;
    }
    if (object == null) {
      return false;
    }
    if (!(object instanceof PeriodicSchedule)) {
      return false;
    }
    PeriodicSchedule other = (PeriodicSchedule) object;
    return this.effectiveDate.equals(other.effectiveDate) && this.terminationDate.equals(other.terminationDate) && this.firstRegularPeriodStartDate.equals(other.firstRegularPeriodStartDate) && this.lastRegularPeriodEndDate.equals(other.lastRegularPeriodEndDate) && this.frequency.equals(other.frequency) && this.businessDayAdjustment.equals(other.businessDayAdjustment) && this.effectiveDateBusinessDayAdjustment.equals(other.effectiveDateBusinessDayAdjustment) && this.terminationDateBusinessDayAdjustment.equals(other.terminationDateBusinessDayAdjustment) && this.stubPeriodType.equals(other.stubPeriodType);
  }

  @Override
  public int hashCode() {
    return Objects.hash(this.effectiveDate, this.terminationDate, this.firstRegularPeriodStartDate, this.lastRegularPeriodEndDate, this.frequency, this.businessDayAdjustment, this.effectiveDateBusinessDayAdjustment, this.terminationDateBusinessDayAdjustment, this.stubPeriodType);
  }

  @Override
  public String toString() {
    return String.format("com.daml.generated.da.finance.base.schedule.PeriodicSchedule(%s, %s, %s, %s, %s, %s, %s, %s, %s)", this.effectiveDate, this.terminationDate, this.firstRegularPeriodStartDate, this.lastRegularPeriodEndDate, this.frequency, this.businessDayAdjustment, this.effectiveDateBusinessDayAdjustment, this.terminationDateBusinessDayAdjustment, this.stubPeriodType);
  }
}
