package com.daml.generated.marketplace.distribution.auction.bidding.model;

import com.daml.ledger.javaapi.data.Value;
import com.daml.ledger.javaapi.data.Variant;
import java.lang.String;

public abstract class Status {
  public static final String _packageId = "636e6e778aedec0710919591e9cb2a9404d6daab0581e4ddc515eeae03256f45";

  public Status() {
  }

  public abstract Value toValue();

  public static Status fromValue(Value value$) {
    Variant variant$ = value$.asVariant().orElseThrow(() -> new IllegalArgumentException("Expected Variant to build an instance of the Variant com.daml.generated.marketplace.distribution.auction.bidding.model.Status"));
    if ("Pending".equals(variant$.getConstructor())) {
      return com.daml.generated.marketplace.distribution.auction.bidding.model.status.Pending.fromValue(variant$);
    }
    if ("FullAllocation".equals(variant$.getConstructor())) {
      return com.daml.generated.marketplace.distribution.auction.bidding.model.status.FullAllocation.fromValue(variant$);
    }
    if ("PartialAllocation".equals(variant$.getConstructor())) {
      return com.daml.generated.marketplace.distribution.auction.bidding.model.status.PartialAllocation.fromValue(variant$);
    }
    if ("NoAllocation".equals(variant$.getConstructor())) {
      return com.daml.generated.marketplace.distribution.auction.bidding.model.status.NoAllocation.fromValue(variant$);
    }
    if ("Invalid".equals(variant$.getConstructor())) {
      return com.daml.generated.marketplace.distribution.auction.bidding.model.status.Invalid.fromValue(variant$);
    }
    throw new IllegalArgumentException("Found unknown constructor variant$.getConstructor() for variant com.daml.generated.marketplace.distribution.auction.bidding.model.Status, expected one of [Pending, FullAllocation, PartialAllocation, NoAllocation, Invalid]");
  }
}
