package com.daml.generated.contingentclaims.observation.observationf;

import com.daml.generated.contingentclaims.observation.ObservationF;
import com.daml.ledger.javaapi.data.Value;
import com.daml.ledger.javaapi.data.Variant;
import java.lang.IllegalArgumentException;
import java.lang.Object;
import java.lang.Override;
import java.lang.String;
import java.util.Objects;
import java.util.function.Function;

public class NegF<t, x, b> extends ObservationF<t, x, b> {
  public static final String _packageId = "636e6e778aedec0710919591e9cb2a9404d6daab0581e4ddc515eeae03256f45";

  public final b bValue;

  public NegF(b bValue) {
    this.bValue = bValue;
  }

  public Variant toValue(Function<b, Value> toValueb) {
    return new Variant("NegF", toValueb.apply(this.bValue));
  }

  public static <t, x, b> NegF<t, x, b> fromValue(Value value$, Function<Value, b> fromValueb)
      throws IllegalArgumentException {
    Variant variant$ = value$.asVariant().orElseThrow(() -> new IllegalArgumentException("Expected: Variant. Actual: " + value$.getClass().getName()));
    if (!"NegF".equals(variant$.getConstructor())) throw new IllegalArgumentException("Invalid constructor. Expected: NegF. Actual: " + variant$.getConstructor());
    Value variantValue$ = variant$.getValue();
    b body = fromValueb.apply(variantValue$);
    return new NegF<t, x, b>(body);
  }

  public Variant toValue(Function<t, Value> toValuet, Function<x, Value> toValuex,
      Function<b, Value> toValueb) {
    return new Variant("NegF", toValueb.apply(this.bValue));
  }

  public static <t, x, b> NegF<t, x, b> fromValue(Value value$, Function<Value, t> fromValuet,
      Function<Value, x> fromValuex, Function<Value, b> fromValueb) throws
      IllegalArgumentException {
    Variant variant$ = value$.asVariant().orElseThrow(() -> new IllegalArgumentException("Expected: Variant. Actual: " + value$.getClass().getName()));
    if (!"NegF".equals(variant$.getConstructor())) throw new IllegalArgumentException("Invalid constructor. Expected: NegF. Actual: " + variant$.getConstructor());
    Value variantValue$ = variant$.getValue();
    b body = fromValueb.apply(variantValue$);
    return new NegF<t, x, b>(body);
  }

  @Override
  public boolean equals(Object object) {
    if (this == object) {
      return true;
    }
    if (object == null) {
      return false;
    }
    if (!(object instanceof NegF<?, ?, ?>)) {
      return false;
    }
    NegF<?, ?, ?> other = (NegF<?, ?, ?>) object;
    return this.bValue.equals(other.bValue);
  }

  @Override
  public int hashCode() {
    return Objects.hash(this.bValue);
  }

  @Override
  public String toString() {
    return String.format("NegF(%s)", this.bValue);
  }
}
