package com.daml.generated.contingentclaims.observation.observation;

import com.daml.generated.contingentclaims.observation.Observation;
import com.daml.ledger.javaapi.data.Value;
import com.daml.ledger.javaapi.data.Variant;
import java.lang.IllegalArgumentException;
import java.lang.Object;
import java.lang.Override;
import java.lang.String;
import java.util.Objects;
import java.util.function.Function;

public class Neg<t, x> extends Observation<t, x> {
  public static final String _packageId = "636e6e778aedec0710919591e9cb2a9404d6daab0581e4ddc515eeae03256f45";

  public final Observation<t, x> observationValue;

  public Neg(Observation<t, x> observationValue) {
    this.observationValue = observationValue;
  }

  public Variant toValue(Function<t, Value> toValuet, Function<x, Value> toValuex) {
    return new Variant("Neg", this.observationValue.toValue(v$0 -> toValuet.apply(v$0),v$1 -> toValuex.apply(v$1)));
  }

  public static <t, x> Neg<t, x> fromValue(Value value$, Function<Value, t> fromValuet,
      Function<Value, x> fromValuex) throws IllegalArgumentException {
    Variant variant$ = value$.asVariant().orElseThrow(() -> new IllegalArgumentException("Expected: Variant. Actual: " + value$.getClass().getName()));
    if (!"Neg".equals(variant$.getConstructor())) throw new IllegalArgumentException("Invalid constructor. Expected: Neg. Actual: " + variant$.getConstructor());
    Value variantValue$ = variant$.getValue();
    Observation<t, x> body = Observation.<t, x>fromValue(variantValue$, v$0 -> fromValuet.apply(v$0), v$1 -> fromValuex.apply(v$1));
    return new Neg<t, x>(body);
  }

  @Override
  public boolean equals(Object object) {
    if (this == object) {
      return true;
    }
    if (object == null) {
      return false;
    }
    if (!(object instanceof Neg<?, ?>)) {
      return false;
    }
    Neg<?, ?> other = (Neg<?, ?>) object;
    return this.observationValue.equals(other.observationValue);
  }

  @Override
  public int hashCode() {
    return Objects.hash(this.observationValue);
  }

  @Override
  public String toString() {
    return String.format("Neg(%s)", this.observationValue);
  }
}
