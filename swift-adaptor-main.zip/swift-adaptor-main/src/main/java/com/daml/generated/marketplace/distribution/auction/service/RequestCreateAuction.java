package com.daml.generated.marketplace.distribution.auction.service;

import com.daml.generated.da.finance.asset.AssetDeposit;
import com.daml.generated.da.finance.types.Account;
import com.daml.generated.da.finance.types.Asset;
import com.daml.generated.da.finance.types.Id;
import com.daml.ledger.javaapi.data.DamlRecord;
import com.daml.ledger.javaapi.data.Numeric;
import com.daml.ledger.javaapi.data.Text;
import com.daml.ledger.javaapi.data.Value;
import java.lang.IllegalArgumentException;
import java.lang.Object;
import java.lang.Override;
import java.lang.String;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

public class RequestCreateAuction {
  public static final String _packageId = "636e6e778aedec0710919591e9cb2a9404d6daab0581e4ddc515eeae03256f45";

  public final String auctionId;

  public final Asset asset;

  public final Id quotedAssetId;

  public final BigDecimal floorPrice;

  public final AssetDeposit.ContractId depositCid;

  public final Account receivableAccount;

  public RequestCreateAuction(String auctionId, Asset asset, Id quotedAssetId,
      BigDecimal floorPrice, AssetDeposit.ContractId depositCid, Account receivableAccount) {
    this.auctionId = auctionId;
    this.asset = asset;
    this.quotedAssetId = quotedAssetId;
    this.floorPrice = floorPrice;
    this.depositCid = depositCid;
    this.receivableAccount = receivableAccount;
  }

  public static RequestCreateAuction fromValue(Value value$) throws IllegalArgumentException {
    Value recordValue$ = value$;
    DamlRecord record$ = recordValue$.asRecord().orElseThrow(() -> new IllegalArgumentException("Contracts must be constructed from Records"));
    List<DamlRecord.Field> fields$ = record$.getFields();
    int numberOfFields = fields$.size();
    if (numberOfFields != 6) {
      throw new IllegalArgumentException("Expected 6 arguments, got " + numberOfFields);
    }
    String auctionId = fields$.get(0).getValue().asText().orElseThrow(() -> new IllegalArgumentException("Expected auctionId to be of type com.daml.ledger.javaapi.data.Text")).getValue();
    Asset asset = Asset.fromValue(fields$.get(1).getValue());
    Id quotedAssetId = Id.fromValue(fields$.get(2).getValue());
    BigDecimal floorPrice = fields$.get(3).getValue().asNumeric().orElseThrow(() -> new IllegalArgumentException("Expected floorPrice to be of type com.daml.ledger.javaapi.data.Numeric")).getValue();
    AssetDeposit.ContractId depositCid = new AssetDeposit.ContractId(fields$.get(4).getValue().asContractId().orElseThrow(() -> new IllegalArgumentException("Expected depositCid to be of type com.daml.ledger.javaapi.data.ContractId")).getValue());
    Account receivableAccount = Account.fromValue(fields$.get(5).getValue());
    return new com.daml.generated.marketplace.distribution.auction.service.RequestCreateAuction(auctionId, asset, quotedAssetId, floorPrice, depositCid, receivableAccount);
  }

  public DamlRecord toValue() {
    ArrayList<DamlRecord.Field> fields = new ArrayList<DamlRecord.Field>(6);
    fields.add(new DamlRecord.Field("auctionId", new Text(this.auctionId)));
    fields.add(new DamlRecord.Field("asset", this.asset.toValue()));
    fields.add(new DamlRecord.Field("quotedAssetId", this.quotedAssetId.toValue()));
    fields.add(new DamlRecord.Field("floorPrice", new Numeric(this.floorPrice)));
    fields.add(new DamlRecord.Field("depositCid", this.depositCid.toValue()));
    fields.add(new DamlRecord.Field("receivableAccount", this.receivableAccount.toValue()));
    return new DamlRecord(fields);
  }

  @Override
  public boolean equals(Object object) {
    if (this == object) {
      return true;
    }
    if (object == null) {
      return false;
    }
    if (!(object instanceof RequestCreateAuction)) {
      return false;
    }
    RequestCreateAuction other = (RequestCreateAuction) object;
    return this.auctionId.equals(other.auctionId) && this.asset.equals(other.asset) && this.quotedAssetId.equals(other.quotedAssetId) && this.floorPrice.equals(other.floorPrice) && this.depositCid.equals(other.depositCid) && this.receivableAccount.equals(other.receivableAccount);
  }

  @Override
  public int hashCode() {
    return Objects.hash(this.auctionId, this.asset, this.quotedAssetId, this.floorPrice, this.depositCid, this.receivableAccount);
  }

  @Override
  public String toString() {
    return String.format("com.daml.generated.marketplace.distribution.auction.service.RequestCreateAuction(%s, %s, %s, %s, %s, %s)", this.auctionId, this.asset, this.quotedAssetId, this.floorPrice, this.depositCid, this.receivableAccount);
  }
}
