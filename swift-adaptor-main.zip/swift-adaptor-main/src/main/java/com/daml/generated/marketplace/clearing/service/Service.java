package com.daml.generated.marketplace.clearing.service;

import com.daml.generated.da.finance.asset.AssetDeposit;
import com.daml.generated.da.finance.types.Account;
import com.daml.generated.da.finance.types.Id;
import com.daml.generated.da.internal.template.Archive;
import com.daml.generated.da.types.Tuple3;
import com.daml.generated.marketplace.clearing.model.MarginCalculation;
import com.daml.generated.marketplace.clearing.model.MarkToMarketCalculation;
import com.daml.ledger.javaapi.data.CreateAndExerciseCommand;
import com.daml.ledger.javaapi.data.CreateCommand;
import com.daml.ledger.javaapi.data.CreatedEvent;
import com.daml.ledger.javaapi.data.DamlRecord;
import com.daml.ledger.javaapi.data.ExerciseByKeyCommand;
import com.daml.ledger.javaapi.data.ExerciseCommand;
import com.daml.ledger.javaapi.data.Identifier;
import com.daml.ledger.javaapi.data.Party;
import com.daml.ledger.javaapi.data.Template;
import com.daml.ledger.javaapi.data.Value;
import java.lang.Deprecated;
import java.lang.IllegalArgumentException;
import java.lang.Object;
import java.lang.Override;
import java.lang.String;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.Set;

public final class Service extends Template {
  public static final Identifier TEMPLATE_ID = new Identifier("636e6e778aedec0710919591e9cb2a9404d6daab0581e4ddc515eeae03256f45", "Marketplace.Clearing.Service", "Service");

  public final String operator;

  public final String provider;

  public final String customer;

  public final Account clearingAccount;

  public final Account ccpAccount;

  public Service(String operator, String provider, String customer, Account clearingAccount,
      Account ccpAccount) {
    this.operator = operator;
    this.provider = provider;
    this.customer = customer;
    this.clearingAccount = clearingAccount;
    this.ccpAccount = ccpAccount;
  }

  public CreateCommand create() {
    return new CreateCommand(Service.TEMPLATE_ID, this.toValue());
  }

  public static ExerciseByKeyCommand exerciseByKeyApproveTrade(Tuple3<String, String, String> key,
      ApproveTrade arg) {
    return new ExerciseByKeyCommand(Service.TEMPLATE_ID, key.toValue(v$0 -> new Party(v$0),v$1 -> new Party(v$1),v$2 -> new Party(v$2)), "ApproveTrade", arg.toValue());
  }

  public static ExerciseByKeyCommand exerciseByKeyApproveTrade(Tuple3<String, String, String> key) {
    return Service.exerciseByKeyApproveTrade(key, new ApproveTrade());
  }

  public static ExerciseByKeyCommand exerciseByKeyPerformMarkToMarket(
      Tuple3<String, String, String> key, PerformMarkToMarket arg) {
    return new ExerciseByKeyCommand(Service.TEMPLATE_ID, key.toValue(v$0 -> new Party(v$0),v$1 -> new Party(v$1),v$2 -> new Party(v$2)), "PerformMarkToMarket", arg.toValue());
  }

  public static ExerciseByKeyCommand exerciseByKeyPerformMarkToMarket(
      Tuple3<String, String, String> key, List<AssetDeposit.ContractId> providerDepositCids,
      List<AssetDeposit.ContractId> customerDepositCids,
      MarkToMarketCalculation.ContractId calculationCid) {
    return Service.exerciseByKeyPerformMarkToMarket(key, new PerformMarkToMarket(providerDepositCids, customerDepositCids, calculationCid));
  }

  public static ExerciseByKeyCommand exerciseByKeyTransferToMargin(
      Tuple3<String, String, String> key, TransferToMargin arg) {
    return new ExerciseByKeyCommand(Service.TEMPLATE_ID, key.toValue(v$0 -> new Party(v$0),v$1 -> new Party(v$1),v$2 -> new Party(v$2)), "TransferToMargin", arg.toValue());
  }

  public static ExerciseByKeyCommand exerciseByKeyTransferToMargin(
      Tuple3<String, String, String> key, List<AssetDeposit.ContractId> depositCids,
      BigDecimal amount) {
    return Service.exerciseByKeyTransferToMargin(key, new TransferToMargin(depositCids, amount));
  }

  public static ExerciseByKeyCommand exerciseByKeyTransferToProvider(
      Tuple3<String, String, String> key, TransferToProvider arg) {
    return new ExerciseByKeyCommand(Service.TEMPLATE_ID, key.toValue(v$0 -> new Party(v$0),v$1 -> new Party(v$1),v$2 -> new Party(v$2)), "TransferToProvider", arg.toValue());
  }

  public static ExerciseByKeyCommand exerciseByKeyTransferToProvider(
      Tuple3<String, String, String> key, BigDecimal amount,
      List<AssetDeposit.ContractId> depositCids) {
    return Service.exerciseByKeyTransferToProvider(key, new TransferToProvider(amount, depositCids));
  }

  public static ExerciseByKeyCommand exerciseByKeyTransferFromProvider(
      Tuple3<String, String, String> key, TransferFromProvider arg) {
    return new ExerciseByKeyCommand(Service.TEMPLATE_ID, key.toValue(v$0 -> new Party(v$0),v$1 -> new Party(v$1),v$2 -> new Party(v$2)), "TransferFromProvider", arg.toValue());
  }

  public static ExerciseByKeyCommand exerciseByKeyTransferFromProvider(
      Tuple3<String, String, String> key, List<AssetDeposit.ContractId> depositCids,
      BigDecimal amount) {
    return Service.exerciseByKeyTransferFromProvider(key, new TransferFromProvider(depositCids, amount));
  }

  public static ExerciseByKeyCommand exerciseByKeyTerminate(Tuple3<String, String, String> key,
      Terminate arg) {
    return new ExerciseByKeyCommand(Service.TEMPLATE_ID, key.toValue(v$0 -> new Party(v$0),v$1 -> new Party(v$1),v$2 -> new Party(v$2)), "Terminate", arg.toValue());
  }

  public static ExerciseByKeyCommand exerciseByKeyTerminate(Tuple3<String, String, String> key,
      String ctrl) {
    return Service.exerciseByKeyTerminate(key, new Terminate(ctrl));
  }

  public static ExerciseByKeyCommand exerciseByKeyCreateMarkToMarket(
      Tuple3<String, String, String> key, CreateMarkToMarket arg) {
    return new ExerciseByKeyCommand(Service.TEMPLATE_ID, key.toValue(v$0 -> new Party(v$0),v$1 -> new Party(v$1),v$2 -> new Party(v$2)), "CreateMarkToMarket", arg.toValue());
  }

  public static ExerciseByKeyCommand exerciseByKeyCreateMarkToMarket(
      Tuple3<String, String, String> key, BigDecimal mtmAmount, Id currency, String calculationId) {
    return Service.exerciseByKeyCreateMarkToMarket(key, new CreateMarkToMarket(mtmAmount, currency, calculationId));
  }

  public static ExerciseByKeyCommand exerciseByKeyTransferFromMargin(
      Tuple3<String, String, String> key, TransferFromMargin arg) {
    return new ExerciseByKeyCommand(Service.TEMPLATE_ID, key.toValue(v$0 -> new Party(v$0),v$1 -> new Party(v$1),v$2 -> new Party(v$2)), "TransferFromMargin", arg.toValue());
  }

  public static ExerciseByKeyCommand exerciseByKeyTransferFromMargin(
      Tuple3<String, String, String> key, List<AssetDeposit.ContractId> marginDepositCids,
      BigDecimal amount) {
    return Service.exerciseByKeyTransferFromMargin(key, new TransferFromMargin(marginDepositCids, amount));
  }

  public static ExerciseByKeyCommand exerciseByKeyArchive(Tuple3<String, String, String> key,
      Archive arg) {
    return new ExerciseByKeyCommand(Service.TEMPLATE_ID, key.toValue(v$0 -> new Party(v$0),v$1 -> new Party(v$1),v$2 -> new Party(v$2)), "Archive", arg.toValue());
  }

  public static ExerciseByKeyCommand exerciseByKeyPerformMarginFill(
      Tuple3<String, String, String> key, PerformMarginFill arg) {
    return new ExerciseByKeyCommand(Service.TEMPLATE_ID, key.toValue(v$0 -> new Party(v$0),v$1 -> new Party(v$1),v$2 -> new Party(v$2)), "PerformMarginFill", arg.toValue());
  }

  public static ExerciseByKeyCommand exerciseByKeyPerformMarginFill(
      Tuple3<String, String, String> key, List<AssetDeposit.ContractId> depositCids,
      List<AssetDeposit.ContractId> marginDepositCids,
      MarginCalculation.ContractId calculationCid) {
    return Service.exerciseByKeyPerformMarginFill(key, new PerformMarginFill(depositCids, marginDepositCids, calculationCid));
  }

  public static ExerciseByKeyCommand exerciseByKeyCreateMarginCalculation(
      Tuple3<String, String, String> key, CreateMarginCalculation arg) {
    return new ExerciseByKeyCommand(Service.TEMPLATE_ID, key.toValue(v$0 -> new Party(v$0),v$1 -> new Party(v$1),v$2 -> new Party(v$2)), "CreateMarginCalculation", arg.toValue());
  }

  public static ExerciseByKeyCommand exerciseByKeyCreateMarginCalculation(
      Tuple3<String, String, String> key, BigDecimal targetAmount, Id currency,
      String calculationId) {
    return Service.exerciseByKeyCreateMarginCalculation(key, new CreateMarginCalculation(targetAmount, currency, calculationId));
  }

  public CreateAndExerciseCommand createAndExerciseApproveTrade(ApproveTrade arg) {
    Value argValue = arg.toValue();
    return new CreateAndExerciseCommand(Service.TEMPLATE_ID, this.toValue(), "ApproveTrade", argValue);
  }

  public CreateAndExerciseCommand createAndExerciseApproveTrade() {
    return createAndExerciseApproveTrade(new ApproveTrade());
  }

  public CreateAndExerciseCommand createAndExercisePerformMarkToMarket(PerformMarkToMarket arg) {
    Value argValue = arg.toValue();
    return new CreateAndExerciseCommand(Service.TEMPLATE_ID, this.toValue(), "PerformMarkToMarket", argValue);
  }

  public CreateAndExerciseCommand createAndExercisePerformMarkToMarket(
      List<AssetDeposit.ContractId> providerDepositCids,
      List<AssetDeposit.ContractId> customerDepositCids,
      MarkToMarketCalculation.ContractId calculationCid) {
    return createAndExercisePerformMarkToMarket(new PerformMarkToMarket(providerDepositCids, customerDepositCids, calculationCid));
  }

  public CreateAndExerciseCommand createAndExerciseTransferToMargin(TransferToMargin arg) {
    Value argValue = arg.toValue();
    return new CreateAndExerciseCommand(Service.TEMPLATE_ID, this.toValue(), "TransferToMargin", argValue);
  }

  public CreateAndExerciseCommand createAndExerciseTransferToMargin(
      List<AssetDeposit.ContractId> depositCids, BigDecimal amount) {
    return createAndExerciseTransferToMargin(new TransferToMargin(depositCids, amount));
  }

  public CreateAndExerciseCommand createAndExerciseTransferToProvider(TransferToProvider arg) {
    Value argValue = arg.toValue();
    return new CreateAndExerciseCommand(Service.TEMPLATE_ID, this.toValue(), "TransferToProvider", argValue);
  }

  public CreateAndExerciseCommand createAndExerciseTransferToProvider(BigDecimal amount,
      List<AssetDeposit.ContractId> depositCids) {
    return createAndExerciseTransferToProvider(new TransferToProvider(amount, depositCids));
  }

  public CreateAndExerciseCommand createAndExerciseTransferFromProvider(TransferFromProvider arg) {
    Value argValue = arg.toValue();
    return new CreateAndExerciseCommand(Service.TEMPLATE_ID, this.toValue(), "TransferFromProvider", argValue);
  }

  public CreateAndExerciseCommand createAndExerciseTransferFromProvider(
      List<AssetDeposit.ContractId> depositCids, BigDecimal amount) {
    return createAndExerciseTransferFromProvider(new TransferFromProvider(depositCids, amount));
  }

  public CreateAndExerciseCommand createAndExerciseTerminate(Terminate arg) {
    Value argValue = arg.toValue();
    return new CreateAndExerciseCommand(Service.TEMPLATE_ID, this.toValue(), "Terminate", argValue);
  }

  public CreateAndExerciseCommand createAndExerciseTerminate(String ctrl) {
    return createAndExerciseTerminate(new Terminate(ctrl));
  }

  public CreateAndExerciseCommand createAndExerciseCreateMarkToMarket(CreateMarkToMarket arg) {
    Value argValue = arg.toValue();
    return new CreateAndExerciseCommand(Service.TEMPLATE_ID, this.toValue(), "CreateMarkToMarket", argValue);
  }

  public CreateAndExerciseCommand createAndExerciseCreateMarkToMarket(BigDecimal mtmAmount,
      Id currency, String calculationId) {
    return createAndExerciseCreateMarkToMarket(new CreateMarkToMarket(mtmAmount, currency, calculationId));
  }

  public CreateAndExerciseCommand createAndExerciseTransferFromMargin(TransferFromMargin arg) {
    Value argValue = arg.toValue();
    return new CreateAndExerciseCommand(Service.TEMPLATE_ID, this.toValue(), "TransferFromMargin", argValue);
  }

  public CreateAndExerciseCommand createAndExerciseTransferFromMargin(
      List<AssetDeposit.ContractId> marginDepositCids, BigDecimal amount) {
    return createAndExerciseTransferFromMargin(new TransferFromMargin(marginDepositCids, amount));
  }

  public CreateAndExerciseCommand createAndExerciseArchive(Archive arg) {
    Value argValue = arg.toValue();
    return new CreateAndExerciseCommand(Service.TEMPLATE_ID, this.toValue(), "Archive", argValue);
  }

  public CreateAndExerciseCommand createAndExercisePerformMarginFill(PerformMarginFill arg) {
    Value argValue = arg.toValue();
    return new CreateAndExerciseCommand(Service.TEMPLATE_ID, this.toValue(), "PerformMarginFill", argValue);
  }

  public CreateAndExerciseCommand createAndExercisePerformMarginFill(
      List<AssetDeposit.ContractId> depositCids, List<AssetDeposit.ContractId> marginDepositCids,
      MarginCalculation.ContractId calculationCid) {
    return createAndExercisePerformMarginFill(new PerformMarginFill(depositCids, marginDepositCids, calculationCid));
  }

  public CreateAndExerciseCommand createAndExerciseCreateMarginCalculation(
      CreateMarginCalculation arg) {
    Value argValue = arg.toValue();
    return new CreateAndExerciseCommand(Service.TEMPLATE_ID, this.toValue(), "CreateMarginCalculation", argValue);
  }

  public CreateAndExerciseCommand createAndExerciseCreateMarginCalculation(BigDecimal targetAmount,
      Id currency, String calculationId) {
    return createAndExerciseCreateMarginCalculation(new CreateMarginCalculation(targetAmount, currency, calculationId));
  }

  public static CreateCommand create(String operator, String provider, String customer,
      Account clearingAccount, Account ccpAccount) {
    return new Service(operator, provider, customer, clearingAccount, ccpAccount).create();
  }

  public static Service fromValue(Value value$) throws IllegalArgumentException {
    Value recordValue$ = value$;
    DamlRecord record$ = recordValue$.asRecord().orElseThrow(() -> new IllegalArgumentException("Contracts must be constructed from Records"));
    List<DamlRecord.Field> fields$ = record$.getFields();
    int numberOfFields = fields$.size();
    if (numberOfFields != 5) {
      throw new IllegalArgumentException("Expected 5 arguments, got " + numberOfFields);
    }
    String operator = fields$.get(0).getValue().asParty().orElseThrow(() -> new IllegalArgumentException("Expected operator to be of type com.daml.ledger.javaapi.data.Party")).getValue();
    String provider = fields$.get(1).getValue().asParty().orElseThrow(() -> new IllegalArgumentException("Expected provider to be of type com.daml.ledger.javaapi.data.Party")).getValue();
    String customer = fields$.get(2).getValue().asParty().orElseThrow(() -> new IllegalArgumentException("Expected customer to be of type com.daml.ledger.javaapi.data.Party")).getValue();
    Account clearingAccount = Account.fromValue(fields$.get(3).getValue());
    Account ccpAccount = Account.fromValue(fields$.get(4).getValue());
    return new com.daml.generated.marketplace.clearing.service.Service(operator, provider, customer, clearingAccount, ccpAccount);
  }

  public DamlRecord toValue() {
    ArrayList<DamlRecord.Field> fields = new ArrayList<DamlRecord.Field>(5);
    fields.add(new DamlRecord.Field("operator", new Party(this.operator)));
    fields.add(new DamlRecord.Field("provider", new Party(this.provider)));
    fields.add(new DamlRecord.Field("customer", new Party(this.customer)));
    fields.add(new DamlRecord.Field("clearingAccount", this.clearingAccount.toValue()));
    fields.add(new DamlRecord.Field("ccpAccount", this.ccpAccount.toValue()));
    return new DamlRecord(fields);
  }

  @Override
  public boolean equals(Object object) {
    if (this == object) {
      return true;
    }
    if (object == null) {
      return false;
    }
    if (!(object instanceof Service)) {
      return false;
    }
    Service other = (Service) object;
    return this.operator.equals(other.operator) && this.provider.equals(other.provider) && this.customer.equals(other.customer) && this.clearingAccount.equals(other.clearingAccount) && this.ccpAccount.equals(other.ccpAccount);
  }

  @Override
  public int hashCode() {
    return Objects.hash(this.operator, this.provider, this.customer, this.clearingAccount, this.ccpAccount);
  }

  @Override
  public String toString() {
    return String.format("com.daml.generated.marketplace.clearing.service.Service(%s, %s, %s, %s, %s)", this.operator, this.provider, this.customer, this.clearingAccount, this.ccpAccount);
  }

  public static final class ContractId extends com.daml.ledger.javaapi.data.codegen.ContractId<Service> {
    public ContractId(String contractId) {
      super(contractId);
    }

    public ExerciseCommand exerciseApproveTrade(ApproveTrade arg) {
      Value argValue = arg.toValue();
      return new ExerciseCommand(Service.TEMPLATE_ID, this.contractId, "ApproveTrade", argValue);
    }

    public ExerciseCommand exerciseApproveTrade() {
      return exerciseApproveTrade(new ApproveTrade());
    }

    public ExerciseCommand exercisePerformMarkToMarket(PerformMarkToMarket arg) {
      Value argValue = arg.toValue();
      return new ExerciseCommand(Service.TEMPLATE_ID, this.contractId, "PerformMarkToMarket", argValue);
    }

    public ExerciseCommand exercisePerformMarkToMarket(
        List<AssetDeposit.ContractId> providerDepositCids,
        List<AssetDeposit.ContractId> customerDepositCids,
        MarkToMarketCalculation.ContractId calculationCid) {
      return exercisePerformMarkToMarket(new PerformMarkToMarket(providerDepositCids, customerDepositCids, calculationCid));
    }

    public ExerciseCommand exerciseTransferToMargin(TransferToMargin arg) {
      Value argValue = arg.toValue();
      return new ExerciseCommand(Service.TEMPLATE_ID, this.contractId, "TransferToMargin", argValue);
    }

    public ExerciseCommand exerciseTransferToMargin(List<AssetDeposit.ContractId> depositCids,
        BigDecimal amount) {
      return exerciseTransferToMargin(new TransferToMargin(depositCids, amount));
    }

    public ExerciseCommand exerciseTransferToProvider(TransferToProvider arg) {
      Value argValue = arg.toValue();
      return new ExerciseCommand(Service.TEMPLATE_ID, this.contractId, "TransferToProvider", argValue);
    }

    public ExerciseCommand exerciseTransferToProvider(BigDecimal amount,
        List<AssetDeposit.ContractId> depositCids) {
      return exerciseTransferToProvider(new TransferToProvider(amount, depositCids));
    }

    public ExerciseCommand exerciseTransferFromProvider(TransferFromProvider arg) {
      Value argValue = arg.toValue();
      return new ExerciseCommand(Service.TEMPLATE_ID, this.contractId, "TransferFromProvider", argValue);
    }

    public ExerciseCommand exerciseTransferFromProvider(List<AssetDeposit.ContractId> depositCids,
        BigDecimal amount) {
      return exerciseTransferFromProvider(new TransferFromProvider(depositCids, amount));
    }

    public ExerciseCommand exerciseTerminate(Terminate arg) {
      Value argValue = arg.toValue();
      return new ExerciseCommand(Service.TEMPLATE_ID, this.contractId, "Terminate", argValue);
    }

    public ExerciseCommand exerciseTerminate(String ctrl) {
      return exerciseTerminate(new Terminate(ctrl));
    }

    public ExerciseCommand exerciseCreateMarkToMarket(CreateMarkToMarket arg) {
      Value argValue = arg.toValue();
      return new ExerciseCommand(Service.TEMPLATE_ID, this.contractId, "CreateMarkToMarket", argValue);
    }

    public ExerciseCommand exerciseCreateMarkToMarket(BigDecimal mtmAmount, Id currency,
        String calculationId) {
      return exerciseCreateMarkToMarket(new CreateMarkToMarket(mtmAmount, currency, calculationId));
    }

    public ExerciseCommand exerciseTransferFromMargin(TransferFromMargin arg) {
      Value argValue = arg.toValue();
      return new ExerciseCommand(Service.TEMPLATE_ID, this.contractId, "TransferFromMargin", argValue);
    }

    public ExerciseCommand exerciseTransferFromMargin(
        List<AssetDeposit.ContractId> marginDepositCids, BigDecimal amount) {
      return exerciseTransferFromMargin(new TransferFromMargin(marginDepositCids, amount));
    }

    public ExerciseCommand exerciseArchive(Archive arg) {
      Value argValue = arg.toValue();
      return new ExerciseCommand(Service.TEMPLATE_ID, this.contractId, "Archive", argValue);
    }

    public ExerciseCommand exercisePerformMarginFill(PerformMarginFill arg) {
      Value argValue = arg.toValue();
      return new ExerciseCommand(Service.TEMPLATE_ID, this.contractId, "PerformMarginFill", argValue);
    }

    public ExerciseCommand exercisePerformMarginFill(List<AssetDeposit.ContractId> depositCids,
        List<AssetDeposit.ContractId> marginDepositCids,
        MarginCalculation.ContractId calculationCid) {
      return exercisePerformMarginFill(new PerformMarginFill(depositCids, marginDepositCids, calculationCid));
    }

    public ExerciseCommand exerciseCreateMarginCalculation(CreateMarginCalculation arg) {
      Value argValue = arg.toValue();
      return new ExerciseCommand(Service.TEMPLATE_ID, this.contractId, "CreateMarginCalculation", argValue);
    }

    public ExerciseCommand exerciseCreateMarginCalculation(BigDecimal targetAmount, Id currency,
        String calculationId) {
      return exerciseCreateMarginCalculation(new CreateMarginCalculation(targetAmount, currency, calculationId));
    }
  }

  public static class Contract implements com.daml.ledger.javaapi.data.Contract {
    public final ContractId id;

    public final Service data;

    public final Optional<String> agreementText;

    public final Optional<Tuple3<String, String, String>> key;

    public final Set<String> signatories;

    public final Set<String> observers;

    public Contract(ContractId id, Service data, Optional<String> agreementText,
        Optional<Tuple3<String, String, String>> key, Set<String> signatories,
        Set<String> observers) {
      this.id = id;
      this.data = data;
      this.agreementText = agreementText;
      this.key = key;
      this.signatories = signatories;
      this.observers = observers;
    }

    public static Contract fromIdAndRecord(String contractId, DamlRecord record$,
        Optional<String> agreementText, Optional<Tuple3<String, String, String>> key,
        Set<String> signatories, Set<String> observers) {
      ContractId id = new ContractId(contractId);
      Service data = Service.fromValue(record$);
      return new Contract(id, data, agreementText, key, signatories, observers);
    }

    @Deprecated
    public static Contract fromIdAndRecord(String contractId, DamlRecord record$) {
      ContractId id = new ContractId(contractId);
      Service data = Service.fromValue(record$);
      return new Contract(id, data, Optional.empty(), Optional.empty(), Collections.emptySet(), Collections.emptySet());
    }

    public static Contract fromCreatedEvent(CreatedEvent event) {
      return fromIdAndRecord(event.getContractId(), event.getArguments(), event.getAgreementText(), event.getContractKey().map(e -> Tuple3.<java.lang.String, java.lang.String, java.lang.String>fromValue(e, v$0 -> v$0.asParty().orElseThrow(() -> new IllegalArgumentException("Expected e to be of type com.daml.ledger.javaapi.data.Party")).getValue(), v$1 -> v$1.asParty().orElseThrow(() -> new IllegalArgumentException("Expected e to be of type com.daml.ledger.javaapi.data.Party")).getValue(), v$2 -> v$2.asParty().orElseThrow(() -> new IllegalArgumentException("Expected e to be of type com.daml.ledger.javaapi.data.Party")).getValue())), event.getSignatories(), event.getObservers());
    }

    @Override
    public boolean equals(Object object) {
      if (this == object) {
        return true;
      }
      if (object == null) {
        return false;
      }
      if (!(object instanceof Contract)) {
        return false;
      }
      Contract other = (Contract) object;
      return this.id.equals(other.id) && this.data.equals(other.data) && this.agreementText.equals(other.agreementText) && this.key.equals(other.key) && this.signatories.equals(other.signatories) && this.observers.equals(other.observers);
    }

    @Override
    public int hashCode() {
      return Objects.hash(this.id, this.data, this.agreementText, this.key, this.signatories, this.observers);
    }

    @Override
    public String toString() {
      return String.format("com.daml.generated.marketplace.clearing.service.Service.Contract(%s, %s, %s, %s, %s, %s)", this.id, this.data, this.agreementText, this.key, this.signatories, this.observers);
    }
  }
}
