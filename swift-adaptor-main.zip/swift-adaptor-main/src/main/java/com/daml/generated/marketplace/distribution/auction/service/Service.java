package com.daml.generated.marketplace.distribution.auction.service;

import com.daml.generated.da.finance.asset.AssetDeposit;
import com.daml.generated.da.finance.types.Account;
import com.daml.generated.da.finance.types.Asset;
import com.daml.generated.da.finance.types.Id;
import com.daml.generated.da.internal.template.Archive;
import com.daml.generated.marketplace.distribution.auction.bidding.model.Bid;
import com.daml.generated.marketplace.distribution.auction.model.Auction;
import com.daml.ledger.javaapi.data.CreateAndExerciseCommand;
import com.daml.ledger.javaapi.data.CreateCommand;
import com.daml.ledger.javaapi.data.CreatedEvent;
import com.daml.ledger.javaapi.data.DamlRecord;
import com.daml.ledger.javaapi.data.ExerciseCommand;
import com.daml.ledger.javaapi.data.Identifier;
import com.daml.ledger.javaapi.data.Party;
import com.daml.ledger.javaapi.data.Template;
import com.daml.ledger.javaapi.data.Value;
import java.lang.Deprecated;
import java.lang.IllegalArgumentException;
import java.lang.Object;
import java.lang.Override;
import java.lang.String;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.Set;

public final class Service extends Template {
  public static final Identifier TEMPLATE_ID = new Identifier("636e6e778aedec0710919591e9cb2a9404d6daab0581e4ddc515eeae03256f45", "Marketplace.Distribution.Auction.Service", "Service");

  public final String operator;

  public final String provider;

  public final String customer;

  public Service(String operator, String provider, String customer) {
    this.operator = operator;
    this.provider = provider;
    this.customer = customer;
  }

  public CreateCommand create() {
    return new CreateCommand(Service.TEMPLATE_ID, this.toValue());
  }

  public CreateAndExerciseCommand createAndExerciseCreateAuction(CreateAuction arg) {
    Value argValue = arg.toValue();
    return new CreateAndExerciseCommand(Service.TEMPLATE_ID, this.toValue(), "CreateAuction", argValue);
  }

  public CreateAndExerciseCommand createAndExerciseCreateAuction(
      CreateAuctionRequest.ContractId createAuctionRequestCid) {
    return createAndExerciseCreateAuction(new CreateAuction(createAuctionRequestCid));
  }

  public CreateAndExerciseCommand createAndExerciseRequestCreateAuction(RequestCreateAuction arg) {
    Value argValue = arg.toValue();
    return new CreateAndExerciseCommand(Service.TEMPLATE_ID, this.toValue(), "RequestCreateAuction", argValue);
  }

  public CreateAndExerciseCommand createAndExerciseRequestCreateAuction(String auctionId,
      Asset asset, Id quotedAssetId, BigDecimal floorPrice, AssetDeposit.ContractId depositCid,
      Account receivableAccount) {
    return createAndExerciseRequestCreateAuction(new RequestCreateAuction(auctionId, asset, quotedAssetId, floorPrice, depositCid, receivableAccount));
  }

  public CreateAndExerciseCommand createAndExerciseRejectAuction(RejectAuction arg) {
    Value argValue = arg.toValue();
    return new CreateAndExerciseCommand(Service.TEMPLATE_ID, this.toValue(), "RejectAuction", argValue);
  }

  public CreateAndExerciseCommand createAndExerciseRejectAuction(
      CreateAuctionRequest.ContractId createAuctionRequestCid) {
    return createAndExerciseRejectAuction(new RejectAuction(createAuctionRequestCid));
  }

  public CreateAndExerciseCommand createAndExerciseCancelAuctionRequest(CancelAuctionRequest arg) {
    Value argValue = arg.toValue();
    return new CreateAndExerciseCommand(Service.TEMPLATE_ID, this.toValue(), "CancelAuctionRequest", argValue);
  }

  public CreateAndExerciseCommand createAndExerciseCancelAuctionRequest(
      CreateAuctionRequest.ContractId createAuctionRequestCid) {
    return createAndExerciseCancelAuctionRequest(new CancelAuctionRequest(createAuctionRequestCid));
  }

  public CreateAndExerciseCommand createAndExerciseArchive(Archive arg) {
    Value argValue = arg.toValue();
    return new CreateAndExerciseCommand(Service.TEMPLATE_ID, this.toValue(), "Archive", argValue);
  }

  public CreateAndExerciseCommand createAndExerciseProcessAuction(ProcessAuction arg) {
    Value argValue = arg.toValue();
    return new CreateAndExerciseCommand(Service.TEMPLATE_ID, this.toValue(), "ProcessAuction", argValue);
  }

  public CreateAndExerciseCommand createAndExerciseProcessAuction(Auction.ContractId auctionCid,
      List<Bid.ContractId> bidCids) {
    return createAndExerciseProcessAuction(new ProcessAuction(auctionCid, bidCids));
  }

  public static CreateCommand create(String operator, String provider, String customer) {
    return new Service(operator, provider, customer).create();
  }

  public static Service fromValue(Value value$) throws IllegalArgumentException {
    Value recordValue$ = value$;
    DamlRecord record$ = recordValue$.asRecord().orElseThrow(() -> new IllegalArgumentException("Contracts must be constructed from Records"));
    List<DamlRecord.Field> fields$ = record$.getFields();
    int numberOfFields = fields$.size();
    if (numberOfFields != 3) {
      throw new IllegalArgumentException("Expected 3 arguments, got " + numberOfFields);
    }
    String operator = fields$.get(0).getValue().asParty().orElseThrow(() -> new IllegalArgumentException("Expected operator to be of type com.daml.ledger.javaapi.data.Party")).getValue();
    String provider = fields$.get(1).getValue().asParty().orElseThrow(() -> new IllegalArgumentException("Expected provider to be of type com.daml.ledger.javaapi.data.Party")).getValue();
    String customer = fields$.get(2).getValue().asParty().orElseThrow(() -> new IllegalArgumentException("Expected customer to be of type com.daml.ledger.javaapi.data.Party")).getValue();
    return new com.daml.generated.marketplace.distribution.auction.service.Service(operator, provider, customer);
  }

  public DamlRecord toValue() {
    ArrayList<DamlRecord.Field> fields = new ArrayList<DamlRecord.Field>(3);
    fields.add(new DamlRecord.Field("operator", new Party(this.operator)));
    fields.add(new DamlRecord.Field("provider", new Party(this.provider)));
    fields.add(new DamlRecord.Field("customer", new Party(this.customer)));
    return new DamlRecord(fields);
  }

  @Override
  public boolean equals(Object object) {
    if (this == object) {
      return true;
    }
    if (object == null) {
      return false;
    }
    if (!(object instanceof Service)) {
      return false;
    }
    Service other = (Service) object;
    return this.operator.equals(other.operator) && this.provider.equals(other.provider) && this.customer.equals(other.customer);
  }

  @Override
  public int hashCode() {
    return Objects.hash(this.operator, this.provider, this.customer);
  }

  @Override
  public String toString() {
    return String.format("com.daml.generated.marketplace.distribution.auction.service.Service(%s, %s, %s)", this.operator, this.provider, this.customer);
  }

  public static final class ContractId extends com.daml.ledger.javaapi.data.codegen.ContractId<Service> {
    public ContractId(String contractId) {
      super(contractId);
    }

    public ExerciseCommand exerciseCreateAuction(CreateAuction arg) {
      Value argValue = arg.toValue();
      return new ExerciseCommand(Service.TEMPLATE_ID, this.contractId, "CreateAuction", argValue);
    }

    public ExerciseCommand exerciseCreateAuction(
        CreateAuctionRequest.ContractId createAuctionRequestCid) {
      return exerciseCreateAuction(new CreateAuction(createAuctionRequestCid));
    }

    public ExerciseCommand exerciseRequestCreateAuction(RequestCreateAuction arg) {
      Value argValue = arg.toValue();
      return new ExerciseCommand(Service.TEMPLATE_ID, this.contractId, "RequestCreateAuction", argValue);
    }

    public ExerciseCommand exerciseRequestCreateAuction(String auctionId, Asset asset,
        Id quotedAssetId, BigDecimal floorPrice, AssetDeposit.ContractId depositCid,
        Account receivableAccount) {
      return exerciseRequestCreateAuction(new RequestCreateAuction(auctionId, asset, quotedAssetId, floorPrice, depositCid, receivableAccount));
    }

    public ExerciseCommand exerciseRejectAuction(RejectAuction arg) {
      Value argValue = arg.toValue();
      return new ExerciseCommand(Service.TEMPLATE_ID, this.contractId, "RejectAuction", argValue);
    }

    public ExerciseCommand exerciseRejectAuction(
        CreateAuctionRequest.ContractId createAuctionRequestCid) {
      return exerciseRejectAuction(new RejectAuction(createAuctionRequestCid));
    }

    public ExerciseCommand exerciseCancelAuctionRequest(CancelAuctionRequest arg) {
      Value argValue = arg.toValue();
      return new ExerciseCommand(Service.TEMPLATE_ID, this.contractId, "CancelAuctionRequest", argValue);
    }

    public ExerciseCommand exerciseCancelAuctionRequest(
        CreateAuctionRequest.ContractId createAuctionRequestCid) {
      return exerciseCancelAuctionRequest(new CancelAuctionRequest(createAuctionRequestCid));
    }

    public ExerciseCommand exerciseArchive(Archive arg) {
      Value argValue = arg.toValue();
      return new ExerciseCommand(Service.TEMPLATE_ID, this.contractId, "Archive", argValue);
    }

    public ExerciseCommand exerciseProcessAuction(ProcessAuction arg) {
      Value argValue = arg.toValue();
      return new ExerciseCommand(Service.TEMPLATE_ID, this.contractId, "ProcessAuction", argValue);
    }

    public ExerciseCommand exerciseProcessAuction(Auction.ContractId auctionCid,
        List<Bid.ContractId> bidCids) {
      return exerciseProcessAuction(new ProcessAuction(auctionCid, bidCids));
    }
  }

  public static class Contract implements com.daml.ledger.javaapi.data.Contract {
    public final ContractId id;

    public final Service data;

    public final Optional<String> agreementText;

    public final Set<String> signatories;

    public final Set<String> observers;

    public Contract(ContractId id, Service data, Optional<String> agreementText,
        Set<String> signatories, Set<String> observers) {
      this.id = id;
      this.data = data;
      this.agreementText = agreementText;
      this.signatories = signatories;
      this.observers = observers;
    }

    public static Contract fromIdAndRecord(String contractId, DamlRecord record$,
        Optional<String> agreementText, Set<String> signatories, Set<String> observers) {
      ContractId id = new ContractId(contractId);
      Service data = Service.fromValue(record$);
      return new Contract(id, data, agreementText, signatories, observers);
    }

    @Deprecated
    public static Contract fromIdAndRecord(String contractId, DamlRecord record$) {
      ContractId id = new ContractId(contractId);
      Service data = Service.fromValue(record$);
      return new Contract(id, data, Optional.empty(), Collections.emptySet(), Collections.emptySet());
    }

    public static Contract fromCreatedEvent(CreatedEvent event) {
      return fromIdAndRecord(event.getContractId(), event.getArguments(), event.getAgreementText(), event.getSignatories(), event.getObservers());
    }

    @Override
    public boolean equals(Object object) {
      if (this == object) {
        return true;
      }
      if (object == null) {
        return false;
      }
      if (!(object instanceof Contract)) {
        return false;
      }
      Contract other = (Contract) object;
      return this.id.equals(other.id) && this.data.equals(other.data) && this.agreementText.equals(other.agreementText) && this.signatories.equals(other.signatories) && this.observers.equals(other.observers);
    }

    @Override
    public int hashCode() {
      return Objects.hash(this.id, this.data, this.agreementText, this.signatories, this.observers);
    }

    @Override
    public String toString() {
      return String.format("com.daml.generated.marketplace.distribution.auction.service.Service.Contract(%s, %s, %s, %s, %s)", this.id, this.data, this.agreementText, this.signatories, this.observers);
    }
  }
}
