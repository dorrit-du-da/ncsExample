package com.daml.generated.contingentclaims.observation;

import com.daml.ledger.javaapi.data.Value;
import com.daml.ledger.javaapi.data.Variant;
import java.lang.String;
import java.util.function.Function;

public abstract class ObservationF<t, x, b> {
  public static final String _packageId = "636e6e778aedec0710919591e9cb2a9404d6daab0581e4ddc515eeae03256f45";

  public ObservationF() {
  }

  public abstract Value toValue(Function<t, Value> toValuet, Function<x, Value> toValuex,
      Function<b, Value> toValueb);

  public static <t, x, b> ObservationF<t, x, b> fromValue(Value value$,
      Function<Value, t> fromValuet, Function<Value, x> fromValuex, Function<Value, b> fromValueb) {
    Variant variant$ = value$.asVariant().orElseThrow(() -> new IllegalArgumentException("Expected Variant to build an instance of the Variant com.daml.generated.contingentclaims.observation.ObservationF"));
    if ("ConstF".equals(variant$.getConstructor())) {
      return com.daml.generated.contingentclaims.observation.observationf.ConstF.fromValue(variant$, fromValuet, fromValuex, fromValueb);
    }
    if ("ObserveF".equals(variant$.getConstructor())) {
      return com.daml.generated.contingentclaims.observation.observationf.ObserveF.fromValue(variant$, fromValuet, fromValuex, fromValueb);
    }
    if ("AddF".equals(variant$.getConstructor())) {
      return com.daml.generated.contingentclaims.observation.observationf.AddF.fromValue(variant$, fromValuet, fromValuex, fromValueb);
    }
    if ("NegF".equals(variant$.getConstructor())) {
      return com.daml.generated.contingentclaims.observation.observationf.NegF.fromValue(variant$, fromValuet, fromValuex, fromValueb);
    }
    if ("MulF".equals(variant$.getConstructor())) {
      return com.daml.generated.contingentclaims.observation.observationf.MulF.fromValue(variant$, fromValuet, fromValuex, fromValueb);
    }
    if ("DivF".equals(variant$.getConstructor())) {
      return com.daml.generated.contingentclaims.observation.observationf.DivF.fromValue(variant$, fromValuet, fromValuex, fromValueb);
    }
    throw new IllegalArgumentException("Found unknown constructor variant$.getConstructor() for variant com.daml.generated.contingentclaims.observation.ObservationF, expected one of [ConstF, ObserveF, AddF, NegF, MulF, DivF]");
  }
}
