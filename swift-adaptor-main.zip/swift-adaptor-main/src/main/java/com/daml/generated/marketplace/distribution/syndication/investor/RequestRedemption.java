package com.daml.generated.marketplace.distribution.syndication.investor;

import com.daml.generated.da.finance.types.Asset;
import com.daml.ledger.javaapi.data.DamlRecord;
import com.daml.ledger.javaapi.data.Party;
import com.daml.ledger.javaapi.data.Value;
import java.lang.IllegalArgumentException;
import java.lang.Object;
import java.lang.Override;
import java.lang.String;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

public class RequestRedemption {
  public static final String _packageId = "636e6e778aedec0710919591e9cb2a9404d6daab0581e4ddc515eeae03256f45";

  public final String issuer;

  public final String bondRegistrar;

  public final String cashProvider;

  public final String payingAgent;

  public final Asset asset;

  public RequestRedemption(String issuer, String bondRegistrar, String cashProvider,
      String payingAgent, Asset asset) {
    this.issuer = issuer;
    this.bondRegistrar = bondRegistrar;
    this.cashProvider = cashProvider;
    this.payingAgent = payingAgent;
    this.asset = asset;
  }

  public static RequestRedemption fromValue(Value value$) throws IllegalArgumentException {
    Value recordValue$ = value$;
    DamlRecord record$ = recordValue$.asRecord().orElseThrow(() -> new IllegalArgumentException("Contracts must be constructed from Records"));
    List<DamlRecord.Field> fields$ = record$.getFields();
    int numberOfFields = fields$.size();
    if (numberOfFields != 5) {
      throw new IllegalArgumentException("Expected 5 arguments, got " + numberOfFields);
    }
    String issuer = fields$.get(0).getValue().asParty().orElseThrow(() -> new IllegalArgumentException("Expected issuer to be of type com.daml.ledger.javaapi.data.Party")).getValue();
    String bondRegistrar = fields$.get(1).getValue().asParty().orElseThrow(() -> new IllegalArgumentException("Expected bondRegistrar to be of type com.daml.ledger.javaapi.data.Party")).getValue();
    String cashProvider = fields$.get(2).getValue().asParty().orElseThrow(() -> new IllegalArgumentException("Expected cashProvider to be of type com.daml.ledger.javaapi.data.Party")).getValue();
    String payingAgent = fields$.get(3).getValue().asParty().orElseThrow(() -> new IllegalArgumentException("Expected payingAgent to be of type com.daml.ledger.javaapi.data.Party")).getValue();
    Asset asset = Asset.fromValue(fields$.get(4).getValue());
    return new com.daml.generated.marketplace.distribution.syndication.investor.RequestRedemption(issuer, bondRegistrar, cashProvider, payingAgent, asset);
  }

  public DamlRecord toValue() {
    ArrayList<DamlRecord.Field> fields = new ArrayList<DamlRecord.Field>(5);
    fields.add(new DamlRecord.Field("issuer", new Party(this.issuer)));
    fields.add(new DamlRecord.Field("bondRegistrar", new Party(this.bondRegistrar)));
    fields.add(new DamlRecord.Field("cashProvider", new Party(this.cashProvider)));
    fields.add(new DamlRecord.Field("payingAgent", new Party(this.payingAgent)));
    fields.add(new DamlRecord.Field("asset", this.asset.toValue()));
    return new DamlRecord(fields);
  }

  @Override
  public boolean equals(Object object) {
    if (this == object) {
      return true;
    }
    if (object == null) {
      return false;
    }
    if (!(object instanceof RequestRedemption)) {
      return false;
    }
    RequestRedemption other = (RequestRedemption) object;
    return this.issuer.equals(other.issuer) && this.bondRegistrar.equals(other.bondRegistrar) && this.cashProvider.equals(other.cashProvider) && this.payingAgent.equals(other.payingAgent) && this.asset.equals(other.asset);
  }

  @Override
  public int hashCode() {
    return Objects.hash(this.issuer, this.bondRegistrar, this.cashProvider, this.payingAgent, this.asset);
  }

  @Override
  public String toString() {
    return String.format("com.daml.generated.marketplace.distribution.syndication.investor.RequestRedemption(%s, %s, %s, %s, %s)", this.issuer, this.bondRegistrar, this.cashProvider, this.payingAgent, this.asset);
  }
}
