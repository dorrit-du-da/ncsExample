package com.daml.generated.da.finance.instrument.equity.stocksplit;

import com.daml.generated.da.finance.types.Id;
import com.daml.generated.da.internal.template.Archive;
import com.daml.generated.da.set.types.Set;
import com.daml.ledger.javaapi.data.CreateAndExerciseCommand;
import com.daml.ledger.javaapi.data.CreateCommand;
import com.daml.ledger.javaapi.data.CreatedEvent;
import com.daml.ledger.javaapi.data.DamlRecord;
import com.daml.ledger.javaapi.data.Date;
import com.daml.ledger.javaapi.data.ExerciseByKeyCommand;
import com.daml.ledger.javaapi.data.ExerciseCommand;
import com.daml.ledger.javaapi.data.Identifier;
import com.daml.ledger.javaapi.data.Numeric;
import com.daml.ledger.javaapi.data.Party;
import com.daml.ledger.javaapi.data.Template;
import com.daml.ledger.javaapi.data.Value;
import java.lang.Deprecated;
import java.lang.IllegalArgumentException;
import java.lang.Object;
import java.lang.Override;
import java.lang.String;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Objects;
import java.util.Optional;

public final class EquityStockSplit extends Template {
  public static final Identifier TEMPLATE_ID = new Identifier("636e6e778aedec0710919591e9cb2a9404d6daab0581e4ddc515eeae03256f45", "DA.Finance.Instrument.Equity.StockSplit", "EquityStockSplit");

  public final Id id;

  public final LocalDate exDate;

  public final BigDecimal rFactor;

  public final Set<String> observers;

  public EquityStockSplit(Id id, LocalDate exDate, BigDecimal rFactor, Set<String> observers) {
    this.id = id;
    this.exDate = exDate;
    this.rFactor = rFactor;
    this.observers = observers;
  }

  public CreateCommand create() {
    return new CreateCommand(EquityStockSplit.TEMPLATE_ID, this.toValue());
  }

  public static ExerciseByKeyCommand exerciseByKeyArchive(Id key, Archive arg) {
    return new ExerciseByKeyCommand(EquityStockSplit.TEMPLATE_ID, key.toValue(), "Archive", arg.toValue());
  }

  public static ExerciseByKeyCommand exerciseByKeyEquityStockSplit_SetObservers(Id key,
      EquityStockSplit_SetObservers arg) {
    return new ExerciseByKeyCommand(EquityStockSplit.TEMPLATE_ID, key.toValue(), "EquityStockSplit_SetObservers", arg.toValue());
  }

  public static ExerciseByKeyCommand exerciseByKeyEquityStockSplit_SetObservers(Id key,
      Set<String> newObservers) {
    return EquityStockSplit.exerciseByKeyEquityStockSplit_SetObservers(key, new EquityStockSplit_SetObservers(newObservers));
  }

  public CreateAndExerciseCommand createAndExerciseArchive(Archive arg) {
    Value argValue = arg.toValue();
    return new CreateAndExerciseCommand(EquityStockSplit.TEMPLATE_ID, this.toValue(), "Archive", argValue);
  }

  public CreateAndExerciseCommand createAndExerciseEquityStockSplit_SetObservers(
      EquityStockSplit_SetObservers arg) {
    Value argValue = arg.toValue();
    return new CreateAndExerciseCommand(EquityStockSplit.TEMPLATE_ID, this.toValue(), "EquityStockSplit_SetObservers", argValue);
  }

  public CreateAndExerciseCommand createAndExerciseEquityStockSplit_SetObservers(
      Set<String> newObservers) {
    return createAndExerciseEquityStockSplit_SetObservers(new EquityStockSplit_SetObservers(newObservers));
  }

  public static CreateCommand create(Id id, LocalDate exDate, BigDecimal rFactor,
      Set<String> observers) {
    return new EquityStockSplit(id, exDate, rFactor, observers).create();
  }

  public static EquityStockSplit fromValue(Value value$) throws IllegalArgumentException {
    Value recordValue$ = value$;
    DamlRecord record$ = recordValue$.asRecord().orElseThrow(() -> new IllegalArgumentException("Contracts must be constructed from Records"));
    List<DamlRecord.Field> fields$ = record$.getFields();
    int numberOfFields = fields$.size();
    if (numberOfFields != 4) {
      throw new IllegalArgumentException("Expected 4 arguments, got " + numberOfFields);
    }
    Id id = Id.fromValue(fields$.get(0).getValue());
    LocalDate exDate = fields$.get(1).getValue().asDate().orElseThrow(() -> new IllegalArgumentException("Expected exDate to be of type com.daml.ledger.javaapi.data.Date")).getValue();
    BigDecimal rFactor = fields$.get(2).getValue().asNumeric().orElseThrow(() -> new IllegalArgumentException("Expected rFactor to be of type com.daml.ledger.javaapi.data.Numeric")).getValue();
    Set<String> observers = Set.<java.lang.String>fromValue(fields$.get(3).getValue(), v$0 -> v$0.asParty().orElseThrow(() -> new IllegalArgumentException("Expected observers to be of type com.daml.ledger.javaapi.data.Party")).getValue());
    return new com.daml.generated.da.finance.instrument.equity.stocksplit.EquityStockSplit(id, exDate, rFactor, observers);
  }

  public DamlRecord toValue() {
    ArrayList<DamlRecord.Field> fields = new ArrayList<DamlRecord.Field>(4);
    fields.add(new DamlRecord.Field("id", this.id.toValue()));
    fields.add(new DamlRecord.Field("exDate", new Date((int) this.exDate.toEpochDay())));
    fields.add(new DamlRecord.Field("rFactor", new Numeric(this.rFactor)));
    fields.add(new DamlRecord.Field("observers", this.observers.toValue(v$0 -> new Party(v$0))));
    return new DamlRecord(fields);
  }

  @Override
  public boolean equals(Object object) {
    if (this == object) {
      return true;
    }
    if (object == null) {
      return false;
    }
    if (!(object instanceof EquityStockSplit)) {
      return false;
    }
    EquityStockSplit other = (EquityStockSplit) object;
    return this.id.equals(other.id) && this.exDate.equals(other.exDate) && this.rFactor.equals(other.rFactor) && this.observers.equals(other.observers);
  }

  @Override
  public int hashCode() {
    return Objects.hash(this.id, this.exDate, this.rFactor, this.observers);
  }

  @Override
  public String toString() {
    return String.format("com.daml.generated.da.finance.instrument.equity.stocksplit.EquityStockSplit(%s, %s, %s, %s)", this.id, this.exDate, this.rFactor, this.observers);
  }

  public static final class ContractId extends com.daml.ledger.javaapi.data.codegen.ContractId<EquityStockSplit> {
    public ContractId(String contractId) {
      super(contractId);
    }

    public ExerciseCommand exerciseArchive(Archive arg) {
      Value argValue = arg.toValue();
      return new ExerciseCommand(EquityStockSplit.TEMPLATE_ID, this.contractId, "Archive", argValue);
    }

    public ExerciseCommand exerciseEquityStockSplit_SetObservers(
        EquityStockSplit_SetObservers arg) {
      Value argValue = arg.toValue();
      return new ExerciseCommand(EquityStockSplit.TEMPLATE_ID, this.contractId, "EquityStockSplit_SetObservers", argValue);
    }

    public ExerciseCommand exerciseEquityStockSplit_SetObservers(Set<String> newObservers) {
      return exerciseEquityStockSplit_SetObservers(new EquityStockSplit_SetObservers(newObservers));
    }
  }

  public static class Contract implements com.daml.ledger.javaapi.data.Contract {
    public final ContractId id;

    public final EquityStockSplit data;

    public final Optional<String> agreementText;

    public final Optional<Id> key;

    public final java.util.Set<String> signatories;

    public final java.util.Set<String> observers;

    public Contract(ContractId id, EquityStockSplit data, Optional<String> agreementText,
        Optional<Id> key, java.util.Set<String> signatories, java.util.Set<String> observers) {
      this.id = id;
      this.data = data;
      this.agreementText = agreementText;
      this.key = key;
      this.signatories = signatories;
      this.observers = observers;
    }

    public static Contract fromIdAndRecord(String contractId, DamlRecord record$,
        Optional<String> agreementText, Optional<Id> key, java.util.Set<String> signatories,
        java.util.Set<String> observers) {
      ContractId id = new ContractId(contractId);
      EquityStockSplit data = EquityStockSplit.fromValue(record$);
      return new Contract(id, data, agreementText, key, signatories, observers);
    }

    @Deprecated
    public static Contract fromIdAndRecord(String contractId, DamlRecord record$) {
      ContractId id = new ContractId(contractId);
      EquityStockSplit data = EquityStockSplit.fromValue(record$);
      return new Contract(id, data, Optional.empty(), Optional.empty(), Collections.emptySet(), Collections.emptySet());
    }

    public static Contract fromCreatedEvent(CreatedEvent event) {
      return fromIdAndRecord(event.getContractId(), event.getArguments(), event.getAgreementText(), event.getContractKey().map(e -> Id.fromValue(e)), event.getSignatories(), event.getObservers());
    }

    @Override
    public boolean equals(Object object) {
      if (this == object) {
        return true;
      }
      if (object == null) {
        return false;
      }
      if (!(object instanceof Contract)) {
        return false;
      }
      Contract other = (Contract) object;
      return this.id.equals(other.id) && this.data.equals(other.data) && this.agreementText.equals(other.agreementText) && this.key.equals(other.key) && this.signatories.equals(other.signatories) && this.observers.equals(other.observers);
    }

    @Override
    public int hashCode() {
      return Objects.hash(this.id, this.data, this.agreementText, this.key, this.signatories, this.observers);
    }

    @Override
    public String toString() {
      return String.format("com.daml.generated.da.finance.instrument.equity.stocksplit.EquityStockSplit.Contract(%s, %s, %s, %s, %s, %s)", this.id, this.data, this.agreementText, this.key, this.signatories, this.observers);
    }
  }
}
