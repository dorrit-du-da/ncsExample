package com.daml.generated.da.finance.instrument.equity.option.lifecycle;

import com.daml.generated.da.finance.instrument.equity.option.EquityOption;
import com.daml.ledger.javaapi.data.DamlOptional;
import com.daml.ledger.javaapi.data.DamlRecord;
import com.daml.ledger.javaapi.data.Date;
import com.daml.ledger.javaapi.data.Numeric;
import com.daml.ledger.javaapi.data.Text;
import com.daml.ledger.javaapi.data.Value;
import java.lang.IllegalArgumentException;
import java.lang.Object;
import java.lang.Override;
import java.lang.String;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.Optional;

public class EquityOptionExercise_Lifecycle {
  public static final String _packageId = "636e6e778aedec0710919591e9cb2a9404d6daab0581e4ddc515eeae03256f45";

  public final EquityOption.ContractId optionCid;

  public final Optional<BigDecimal> underlyingPrice;

  public final String entitlementIdLabel;

  public final LocalDate settlementDate;

  public EquityOptionExercise_Lifecycle(EquityOption.ContractId optionCid,
      Optional<BigDecimal> underlyingPrice, String entitlementIdLabel, LocalDate settlementDate) {
    this.optionCid = optionCid;
    this.underlyingPrice = underlyingPrice;
    this.entitlementIdLabel = entitlementIdLabel;
    this.settlementDate = settlementDate;
  }

  public static EquityOptionExercise_Lifecycle fromValue(Value value$) throws
      IllegalArgumentException {
    Value recordValue$ = value$;
    DamlRecord record$ = recordValue$.asRecord().orElseThrow(() -> new IllegalArgumentException("Contracts must be constructed from Records"));
    List<DamlRecord.Field> fields$ = record$.getFields();
    int numberOfFields = fields$.size();
    if (numberOfFields != 4) {
      throw new IllegalArgumentException("Expected 4 arguments, got " + numberOfFields);
    }
    EquityOption.ContractId optionCid = new EquityOption.ContractId(fields$.get(0).getValue().asContractId().orElseThrow(() -> new IllegalArgumentException("Expected optionCid to be of type com.daml.ledger.javaapi.data.ContractId")).getValue());
    Optional<BigDecimal> underlyingPrice = fields$.get(1).getValue().asOptional()
            .map(v$0 -> v$0.toOptional(v$1 ->
                v$1.asNumeric().orElseThrow(() -> new IllegalArgumentException("Expected v$1 to be of type com.daml.ledger.javaapi.data.Numeric")).getValue()
            ))
            .orElseThrow(() -> new IllegalArgumentException("Expected underlyingPrice to be of type com.daml.ledger.javaapi.data.DamlOptional"))
                  ;
    String entitlementIdLabel = fields$.get(2).getValue().asText().orElseThrow(() -> new IllegalArgumentException("Expected entitlementIdLabel to be of type com.daml.ledger.javaapi.data.Text")).getValue();
    LocalDate settlementDate = fields$.get(3).getValue().asDate().orElseThrow(() -> new IllegalArgumentException("Expected settlementDate to be of type com.daml.ledger.javaapi.data.Date")).getValue();
    return new com.daml.generated.da.finance.instrument.equity.option.lifecycle.EquityOptionExercise_Lifecycle(optionCid, underlyingPrice, entitlementIdLabel, settlementDate);
  }

  public DamlRecord toValue() {
    ArrayList<DamlRecord.Field> fields = new ArrayList<DamlRecord.Field>(4);
    fields.add(new DamlRecord.Field("optionCid", this.optionCid.toValue()));
    fields.add(new DamlRecord.Field("underlyingPrice", DamlOptional.of(this.underlyingPrice.map(v$0 -> new Numeric(v$0)))));
    fields.add(new DamlRecord.Field("entitlementIdLabel", new Text(this.entitlementIdLabel)));
    fields.add(new DamlRecord.Field("settlementDate", new Date((int) this.settlementDate.toEpochDay())));
    return new DamlRecord(fields);
  }

  @Override
  public boolean equals(Object object) {
    if (this == object) {
      return true;
    }
    if (object == null) {
      return false;
    }
    if (!(object instanceof EquityOptionExercise_Lifecycle)) {
      return false;
    }
    EquityOptionExercise_Lifecycle other = (EquityOptionExercise_Lifecycle) object;
    return this.optionCid.equals(other.optionCid) && this.underlyingPrice.equals(other.underlyingPrice) && this.entitlementIdLabel.equals(other.entitlementIdLabel) && this.settlementDate.equals(other.settlementDate);
  }

  @Override
  public int hashCode() {
    return Objects.hash(this.optionCid, this.underlyingPrice, this.entitlementIdLabel, this.settlementDate);
  }

  @Override
  public String toString() {
    return String.format("com.daml.generated.da.finance.instrument.equity.option.lifecycle.EquityOptionExercise_Lifecycle(%s, %s, %s, %s)", this.optionCid, this.underlyingPrice, this.entitlementIdLabel, this.settlementDate);
  }
}
