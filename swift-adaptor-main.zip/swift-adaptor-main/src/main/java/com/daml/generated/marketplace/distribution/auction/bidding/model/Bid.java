package com.daml.generated.marketplace.distribution.auction.bidding.model;

import com.daml.generated.da.finance.asset.AssetDeposit;
import com.daml.generated.da.finance.types.Account;
import com.daml.generated.da.finance.types.Id;
import com.daml.generated.da.internal.template.Archive;
import com.daml.generated.da.types.Tuple2;
import com.daml.ledger.javaapi.data.Bool;
import com.daml.ledger.javaapi.data.CreateAndExerciseCommand;
import com.daml.ledger.javaapi.data.CreateCommand;
import com.daml.ledger.javaapi.data.CreatedEvent;
import com.daml.ledger.javaapi.data.DamlRecord;
import com.daml.ledger.javaapi.data.ExerciseByKeyCommand;
import com.daml.ledger.javaapi.data.ExerciseCommand;
import com.daml.ledger.javaapi.data.Identifier;
import com.daml.ledger.javaapi.data.Party;
import com.daml.ledger.javaapi.data.Template;
import com.daml.ledger.javaapi.data.Text;
import com.daml.ledger.javaapi.data.Value;
import java.lang.Boolean;
import java.lang.Deprecated;
import java.lang.IllegalArgumentException;
import java.lang.Object;
import java.lang.Override;
import java.lang.String;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.Set;

public final class Bid extends Template {
  public static final Identifier TEMPLATE_ID = new Identifier("636e6e778aedec0710919591e9cb2a9404d6daab0581e4ddc515eeae03256f45", "Marketplace.Distribution.Auction.Bidding.Model", "Bid");

  public final String operator;

  public final String provider;

  public final String customer;

  public final String issuer;

  public final String auctionId;

  public final Id assetId;

  public final Details details;

  public final Id quotedAssetId;

  public final AssetDeposit.ContractId depositCid;

  public final Account receivableAccount;

  public final Boolean allowPublishing;

  public final Status status;

  public Bid(String operator, String provider, String customer, String issuer, String auctionId,
      Id assetId, Details details, Id quotedAssetId, AssetDeposit.ContractId depositCid,
      Account receivableAccount, Boolean allowPublishing, Status status) {
    this.operator = operator;
    this.provider = provider;
    this.customer = customer;
    this.issuer = issuer;
    this.auctionId = auctionId;
    this.assetId = assetId;
    this.details = details;
    this.quotedAssetId = quotedAssetId;
    this.depositCid = depositCid;
    this.receivableAccount = receivableAccount;
    this.allowPublishing = allowPublishing;
    this.status = status;
  }

  public CreateCommand create() {
    return new CreateCommand(Bid.TEMPLATE_ID, this.toValue());
  }

  public static ExerciseByKeyCommand exerciseByKeyArchive(Tuple2<String, String> key, Archive arg) {
    return new ExerciseByKeyCommand(Bid.TEMPLATE_ID, key.toValue(v$0 -> new Party(v$0),v$1 -> new Text(v$1)), "Archive", arg.toValue());
  }

  public static ExerciseByKeyCommand exerciseByKeyUpdateStatus(Tuple2<String, String> key,
      UpdateStatus arg) {
    return new ExerciseByKeyCommand(Bid.TEMPLATE_ID, key.toValue(v$0 -> new Party(v$0),v$1 -> new Text(v$1)), "UpdateStatus", arg.toValue());
  }

  public static ExerciseByKeyCommand exerciseByKeyUpdateStatus(Tuple2<String, String> key,
      Status newStatus) {
    return Bid.exerciseByKeyUpdateStatus(key, new UpdateStatus(newStatus));
  }

  public CreateAndExerciseCommand createAndExerciseArchive(Archive arg) {
    Value argValue = arg.toValue();
    return new CreateAndExerciseCommand(Bid.TEMPLATE_ID, this.toValue(), "Archive", argValue);
  }

  public CreateAndExerciseCommand createAndExerciseUpdateStatus(UpdateStatus arg) {
    Value argValue = arg.toValue();
    return new CreateAndExerciseCommand(Bid.TEMPLATE_ID, this.toValue(), "UpdateStatus", argValue);
  }

  public CreateAndExerciseCommand createAndExerciseUpdateStatus(Status newStatus) {
    return createAndExerciseUpdateStatus(new UpdateStatus(newStatus));
  }

  public static CreateCommand create(String operator, String provider, String customer,
      String issuer, String auctionId, Id assetId, Details details, Id quotedAssetId,
      AssetDeposit.ContractId depositCid, Account receivableAccount, Boolean allowPublishing,
      Status status) {
    return new Bid(operator, provider, customer, issuer, auctionId, assetId, details, quotedAssetId, depositCid, receivableAccount, allowPublishing, status).create();
  }

  public static Bid fromValue(Value value$) throws IllegalArgumentException {
    Value recordValue$ = value$;
    DamlRecord record$ = recordValue$.asRecord().orElseThrow(() -> new IllegalArgumentException("Contracts must be constructed from Records"));
    List<DamlRecord.Field> fields$ = record$.getFields();
    int numberOfFields = fields$.size();
    if (numberOfFields != 12) {
      throw new IllegalArgumentException("Expected 12 arguments, got " + numberOfFields);
    }
    String operator = fields$.get(0).getValue().asParty().orElseThrow(() -> new IllegalArgumentException("Expected operator to be of type com.daml.ledger.javaapi.data.Party")).getValue();
    String provider = fields$.get(1).getValue().asParty().orElseThrow(() -> new IllegalArgumentException("Expected provider to be of type com.daml.ledger.javaapi.data.Party")).getValue();
    String customer = fields$.get(2).getValue().asParty().orElseThrow(() -> new IllegalArgumentException("Expected customer to be of type com.daml.ledger.javaapi.data.Party")).getValue();
    String issuer = fields$.get(3).getValue().asParty().orElseThrow(() -> new IllegalArgumentException("Expected issuer to be of type com.daml.ledger.javaapi.data.Party")).getValue();
    String auctionId = fields$.get(4).getValue().asText().orElseThrow(() -> new IllegalArgumentException("Expected auctionId to be of type com.daml.ledger.javaapi.data.Text")).getValue();
    Id assetId = Id.fromValue(fields$.get(5).getValue());
    Details details = Details.fromValue(fields$.get(6).getValue());
    Id quotedAssetId = Id.fromValue(fields$.get(7).getValue());
    AssetDeposit.ContractId depositCid = new AssetDeposit.ContractId(fields$.get(8).getValue().asContractId().orElseThrow(() -> new IllegalArgumentException("Expected depositCid to be of type com.daml.ledger.javaapi.data.ContractId")).getValue());
    Account receivableAccount = Account.fromValue(fields$.get(9).getValue());
    Boolean allowPublishing = fields$.get(10).getValue().asBool().orElseThrow(() -> new IllegalArgumentException("Expected allowPublishing to be of type com.daml.ledger.javaapi.data.Bool")).getValue();
    Status status = Status.fromValue(fields$.get(11).getValue());
    return new com.daml.generated.marketplace.distribution.auction.bidding.model.Bid(operator, provider, customer, issuer, auctionId, assetId, details, quotedAssetId, depositCid, receivableAccount, allowPublishing, status);
  }

  public DamlRecord toValue() {
    ArrayList<DamlRecord.Field> fields = new ArrayList<DamlRecord.Field>(12);
    fields.add(new DamlRecord.Field("operator", new Party(this.operator)));
    fields.add(new DamlRecord.Field("provider", new Party(this.provider)));
    fields.add(new DamlRecord.Field("customer", new Party(this.customer)));
    fields.add(new DamlRecord.Field("issuer", new Party(this.issuer)));
    fields.add(new DamlRecord.Field("auctionId", new Text(this.auctionId)));
    fields.add(new DamlRecord.Field("assetId", this.assetId.toValue()));
    fields.add(new DamlRecord.Field("details", this.details.toValue()));
    fields.add(new DamlRecord.Field("quotedAssetId", this.quotedAssetId.toValue()));
    fields.add(new DamlRecord.Field("depositCid", this.depositCid.toValue()));
    fields.add(new DamlRecord.Field("receivableAccount", this.receivableAccount.toValue()));
    fields.add(new DamlRecord.Field("allowPublishing", new Bool(this.allowPublishing)));
    fields.add(new DamlRecord.Field("status", this.status.toValue()));
    return new DamlRecord(fields);
  }

  @Override
  public boolean equals(Object object) {
    if (this == object) {
      return true;
    }
    if (object == null) {
      return false;
    }
    if (!(object instanceof Bid)) {
      return false;
    }
    Bid other = (Bid) object;
    return this.operator.equals(other.operator) && this.provider.equals(other.provider) && this.customer.equals(other.customer) && this.issuer.equals(other.issuer) && this.auctionId.equals(other.auctionId) && this.assetId.equals(other.assetId) && this.details.equals(other.details) && this.quotedAssetId.equals(other.quotedAssetId) && this.depositCid.equals(other.depositCid) && this.receivableAccount.equals(other.receivableAccount) && this.allowPublishing.equals(other.allowPublishing) && this.status.equals(other.status);
  }

  @Override
  public int hashCode() {
    return Objects.hash(this.operator, this.provider, this.customer, this.issuer, this.auctionId, this.assetId, this.details, this.quotedAssetId, this.depositCid, this.receivableAccount, this.allowPublishing, this.status);
  }

  @Override
  public String toString() {
    return String.format("com.daml.generated.marketplace.distribution.auction.bidding.model.Bid(%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)", this.operator, this.provider, this.customer, this.issuer, this.auctionId, this.assetId, this.details, this.quotedAssetId, this.depositCid, this.receivableAccount, this.allowPublishing, this.status);
  }

  public static final class ContractId extends com.daml.ledger.javaapi.data.codegen.ContractId<Bid> {
    public ContractId(String contractId) {
      super(contractId);
    }

    public ExerciseCommand exerciseArchive(Archive arg) {
      Value argValue = arg.toValue();
      return new ExerciseCommand(Bid.TEMPLATE_ID, this.contractId, "Archive", argValue);
    }

    public ExerciseCommand exerciseUpdateStatus(UpdateStatus arg) {
      Value argValue = arg.toValue();
      return new ExerciseCommand(Bid.TEMPLATE_ID, this.contractId, "UpdateStatus", argValue);
    }

    public ExerciseCommand exerciseUpdateStatus(Status newStatus) {
      return exerciseUpdateStatus(new UpdateStatus(newStatus));
    }
  }

  public static class Contract implements com.daml.ledger.javaapi.data.Contract {
    public final ContractId id;

    public final Bid data;

    public final Optional<String> agreementText;

    public final Optional<Tuple2<String, String>> key;

    public final Set<String> signatories;

    public final Set<String> observers;

    public Contract(ContractId id, Bid data, Optional<String> agreementText,
        Optional<Tuple2<String, String>> key, Set<String> signatories, Set<String> observers) {
      this.id = id;
      this.data = data;
      this.agreementText = agreementText;
      this.key = key;
      this.signatories = signatories;
      this.observers = observers;
    }

    public static Contract fromIdAndRecord(String contractId, DamlRecord record$,
        Optional<String> agreementText, Optional<Tuple2<String, String>> key,
        Set<String> signatories, Set<String> observers) {
      ContractId id = new ContractId(contractId);
      Bid data = Bid.fromValue(record$);
      return new Contract(id, data, agreementText, key, signatories, observers);
    }

    @Deprecated
    public static Contract fromIdAndRecord(String contractId, DamlRecord record$) {
      ContractId id = new ContractId(contractId);
      Bid data = Bid.fromValue(record$);
      return new Contract(id, data, Optional.empty(), Optional.empty(), Collections.emptySet(), Collections.emptySet());
    }

    public static Contract fromCreatedEvent(CreatedEvent event) {
      return fromIdAndRecord(event.getContractId(), event.getArguments(), event.getAgreementText(), event.getContractKey().map(e -> Tuple2.<java.lang.String, java.lang.String>fromValue(e, v$0 -> v$0.asParty().orElseThrow(() -> new IllegalArgumentException("Expected e to be of type com.daml.ledger.javaapi.data.Party")).getValue(), v$1 -> v$1.asText().orElseThrow(() -> new IllegalArgumentException("Expected e to be of type com.daml.ledger.javaapi.data.Text")).getValue())), event.getSignatories(), event.getObservers());
    }

    @Override
    public boolean equals(Object object) {
      if (this == object) {
        return true;
      }
      if (object == null) {
        return false;
      }
      if (!(object instanceof Contract)) {
        return false;
      }
      Contract other = (Contract) object;
      return this.id.equals(other.id) && this.data.equals(other.data) && this.agreementText.equals(other.agreementText) && this.key.equals(other.key) && this.signatories.equals(other.signatories) && this.observers.equals(other.observers);
    }

    @Override
    public int hashCode() {
      return Objects.hash(this.id, this.data, this.agreementText, this.key, this.signatories, this.observers);
    }

    @Override
    public String toString() {
      return String.format("com.daml.generated.marketplace.distribution.auction.bidding.model.Bid.Contract(%s, %s, %s, %s, %s, %s)", this.id, this.data, this.agreementText, this.key, this.signatories, this.observers);
    }
  }
}
