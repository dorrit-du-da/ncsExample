package com.daml.generated.da.finance.asset;

import com.daml.generated.da.set.types.Set;
import com.daml.ledger.javaapi.data.DamlRecord;
import com.daml.ledger.javaapi.data.Party;
import com.daml.ledger.javaapi.data.Value;
import java.lang.IllegalArgumentException;
import java.lang.Object;
import java.lang.Override;
import java.lang.String;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

public class AssetDeposit_SetObservers {
  public static final String _packageId = "636e6e778aedec0710919591e9cb2a9404d6daab0581e4ddc515eeae03256f45";

  public final Set<String> newObservers;

  public AssetDeposit_SetObservers(Set<String> newObservers) {
    this.newObservers = newObservers;
  }

  public static AssetDeposit_SetObservers fromValue(Value value$) throws IllegalArgumentException {
    Value recordValue$ = value$;
    DamlRecord record$ = recordValue$.asRecord().orElseThrow(() -> new IllegalArgumentException("Contracts must be constructed from Records"));
    List<DamlRecord.Field> fields$ = record$.getFields();
    int numberOfFields = fields$.size();
    if (numberOfFields != 1) {
      throw new IllegalArgumentException("Expected 1 arguments, got " + numberOfFields);
    }
    Set<String> newObservers = Set.<java.lang.String>fromValue(fields$.get(0).getValue(), v$0 -> v$0.asParty().orElseThrow(() -> new IllegalArgumentException("Expected newObservers to be of type com.daml.ledger.javaapi.data.Party")).getValue());
    return new com.daml.generated.da.finance.asset.AssetDeposit_SetObservers(newObservers);
  }

  public DamlRecord toValue() {
    ArrayList<DamlRecord.Field> fields = new ArrayList<DamlRecord.Field>(1);
    fields.add(new DamlRecord.Field("newObservers", this.newObservers.toValue(v$0 -> new Party(v$0))));
    return new DamlRecord(fields);
  }

  @Override
  public boolean equals(Object object) {
    if (this == object) {
      return true;
    }
    if (object == null) {
      return false;
    }
    if (!(object instanceof AssetDeposit_SetObservers)) {
      return false;
    }
    AssetDeposit_SetObservers other = (AssetDeposit_SetObservers) object;
    return this.newObservers.equals(other.newObservers);
  }

  @Override
  public int hashCode() {
    return Objects.hash(this.newObservers);
  }

  @Override
  public String toString() {
    return String.format("com.daml.generated.da.finance.asset.AssetDeposit_SetObservers(%s)", this.newObservers);
  }
}
