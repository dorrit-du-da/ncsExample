package com.daml.generated.contingentclaims.claim.serializable.claimf;

import com.daml.generated.contingentclaims.claim.serializable.ClaimF;
import com.daml.ledger.javaapi.data.DamlCollectors;
import com.daml.ledger.javaapi.data.DamlRecord;
import com.daml.ledger.javaapi.data.Value;
import com.daml.ledger.javaapi.data.Variant;
import java.lang.IllegalArgumentException;
import java.lang.Object;
import java.lang.Override;
import java.lang.String;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.function.Function;

public class AndF<t, x, a, b> extends ClaimF<t, x, a, b> {
  public static final String _packageId = "636e6e778aedec0710919591e9cb2a9404d6daab0581e4ddc515eeae03256f45";

  public final List<b> claims;

  public AndF(List<b> claims) {
    this.claims = claims;
  }

  public Variant toValue(Function<b, Value> toValueb) {
    ArrayList<DamlRecord.Field> fields = new ArrayList<DamlRecord.Field>(1);
    fields.add(new DamlRecord.Field("claims", this.claims.stream().collect(DamlCollectors.toDamlList(v$0 -> toValueb.apply(v$0)))));
    return new Variant("AndF", new DamlRecord(fields));
  }

  public static <t, x, a, b> AndF<t, x, a, b> fromValue(Value value$, Function<Value, b> fromValueb)
      throws IllegalArgumentException {
    Variant variant$ = value$.asVariant().orElseThrow(() -> new IllegalArgumentException("Expected: Variant. Actual: " + value$.getClass().getName()));
    if (!"AndF".equals(variant$.getConstructor())) throw new IllegalArgumentException("Invalid constructor. Expected: AndF. Actual: " + variant$.getConstructor());
    Value recordValue$ = variant$.getValue();
    DamlRecord record$ = recordValue$.asRecord().orElseThrow(() -> new IllegalArgumentException("Contracts must be constructed from Records"));
    List<DamlRecord.Field> fields$ = record$.getFields();
    int numberOfFields = fields$.size();
    if (numberOfFields != 1) {
      throw new IllegalArgumentException("Expected 1 arguments, got " + numberOfFields);
    }
    List<b> claims = fields$.get(0).getValue().asList()
            .map(v$0 -> v$0.toList(v$1 ->
                fromValueb.apply(v$1)
            ))
            .orElseThrow(() -> new IllegalArgumentException("Expected claims to be of type com.daml.ledger.javaapi.data.DamlList"))
        ;
    return new AndF<t, x, a, b>(claims);
  }

  public Variant toValue(Function<t, Value> toValuet, Function<x, Value> toValuex,
      Function<a, Value> toValuea, Function<b, Value> toValueb) {
    ArrayList<DamlRecord.Field> fields = new ArrayList<DamlRecord.Field>(1);
    fields.add(new DamlRecord.Field("claims", this.claims.stream().collect(DamlCollectors.toDamlList(v$0 -> toValueb.apply(v$0)))));
    return new Variant("AndF", new DamlRecord(fields));
  }

  public static <t, x, a, b> AndF<t, x, a, b> fromValue(Value value$, Function<Value, t> fromValuet,
      Function<Value, x> fromValuex, Function<Value, a> fromValuea, Function<Value, b> fromValueb)
      throws IllegalArgumentException {
    Variant variant$ = value$.asVariant().orElseThrow(() -> new IllegalArgumentException("Expected: Variant. Actual: " + value$.getClass().getName()));
    if (!"AndF".equals(variant$.getConstructor())) throw new IllegalArgumentException("Invalid constructor. Expected: AndF. Actual: " + variant$.getConstructor());
    Value recordValue$ = variant$.getValue();
    DamlRecord record$ = recordValue$.asRecord().orElseThrow(() -> new IllegalArgumentException("Contracts must be constructed from Records"));
    List<DamlRecord.Field> fields$ = record$.getFields();
    int numberOfFields = fields$.size();
    if (numberOfFields != 1) {
      throw new IllegalArgumentException("Expected 1 arguments, got " + numberOfFields);
    }
    List<b> claims = fields$.get(0).getValue().asList()
            .map(v$0 -> v$0.toList(v$1 ->
                fromValueb.apply(v$1)
            ))
            .orElseThrow(() -> new IllegalArgumentException("Expected claims to be of type com.daml.ledger.javaapi.data.DamlList"))
        ;
    return new AndF<t, x, a, b>(claims);
  }

  @Override
  public boolean equals(Object object) {
    if (this == object) {
      return true;
    }
    if (object == null) {
      return false;
    }
    if (!(object instanceof AndF<?, ?, ?, ?>)) {
      return false;
    }
    AndF<?, ?, ?, ?> other = (AndF<?, ?, ?, ?>) object;
    return this.claims.equals(other.claims);
  }

  @Override
  public int hashCode() {
    return Objects.hash(this.claims);
  }

  @Override
  public String toString() {
    return String.format("AndF(%s)", this.claims);
  }
}
