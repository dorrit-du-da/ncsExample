package com.daml.generated.marketplace.distribution.syndication.structuring.model;

import com.daml.generated.da.finance.types.Id;
import com.daml.generated.da.internal.template.Archive;
import com.daml.generated.da.types.Tuple3;
import com.daml.generated.marketplace.settlement.hierarchical.SettlementMode;
import com.daml.ledger.javaapi.data.CreateAndExerciseCommand;
import com.daml.ledger.javaapi.data.CreateCommand;
import com.daml.ledger.javaapi.data.CreatedEvent;
import com.daml.ledger.javaapi.data.DamlCollectors;
import com.daml.ledger.javaapi.data.DamlRecord;
import com.daml.ledger.javaapi.data.ExerciseByKeyCommand;
import com.daml.ledger.javaapi.data.ExerciseCommand;
import com.daml.ledger.javaapi.data.Identifier;
import com.daml.ledger.javaapi.data.Party;
import com.daml.ledger.javaapi.data.Template;
import com.daml.ledger.javaapi.data.Text;
import com.daml.ledger.javaapi.data.Value;
import java.lang.Deprecated;
import java.lang.IllegalArgumentException;
import java.lang.Object;
import java.lang.Override;
import java.lang.String;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.Set;

public final class Deal extends Template {
  public static final Identifier TEMPLATE_ID = new Identifier("636e6e778aedec0710919591e9cb2a9404d6daab0581e4ddc515eeae03256f45", "Marketplace.Distribution.Syndication.Structuring.Model", "Deal");

  public final String operator;

  public final String dealProvider;

  public final String issuer;

  public final String dealId;

  public final List<String> trancheIds;

  public Deal(String operator, String dealProvider, String issuer, String dealId,
      List<String> trancheIds) {
    this.operator = operator;
    this.dealProvider = dealProvider;
    this.issuer = issuer;
    this.dealId = dealId;
    this.trancheIds = trancheIds;
  }

  public CreateCommand create() {
    return new CreateCommand(Deal.TEMPLATE_ID, this.toValue());
  }

  public static ExerciseByKeyCommand exerciseByKeyArchive(Tuple3<String, String, String> key,
      Archive arg) {
    return new ExerciseByKeyCommand(Deal.TEMPLATE_ID, key.toValue(v$0 -> new Party(v$0),v$1 -> new Party(v$1),v$2 -> new Text(v$2)), "Archive", arg.toValue());
  }

  public static ExerciseByKeyCommand exerciseByKeyCreateTranche(Tuple3<String, String, String> key,
      CreateTranche arg) {
    return new ExerciseByKeyCommand(Deal.TEMPLATE_ID, key.toValue(v$0 -> new Party(v$0),v$1 -> new Party(v$1),v$2 -> new Text(v$2)), "CreateTranche", arg.toValue());
  }

  public static ExerciseByKeyCommand exerciseByKeyCreateTranche(Tuple3<String, String, String> key,
      String trancheId, Id deliveryId, Id paymentId, BigDecimal size, String settlementBank,
      String bndBank, String cashProvider, String bondRegistrar, String payingAgent,
      SettlementMode issuerSettlementMode, SettlementMode bndSettlementMode) {
    return Deal.exerciseByKeyCreateTranche(key, new CreateTranche(trancheId, deliveryId, paymentId, size, settlementBank, bndBank, cashProvider, bondRegistrar, payingAgent, issuerSettlementMode, bndSettlementMode));
  }

  public CreateAndExerciseCommand createAndExerciseArchive(Archive arg) {
    Value argValue = arg.toValue();
    return new CreateAndExerciseCommand(Deal.TEMPLATE_ID, this.toValue(), "Archive", argValue);
  }

  public CreateAndExerciseCommand createAndExerciseCreateTranche(CreateTranche arg) {
    Value argValue = arg.toValue();
    return new CreateAndExerciseCommand(Deal.TEMPLATE_ID, this.toValue(), "CreateTranche", argValue);
  }

  public CreateAndExerciseCommand createAndExerciseCreateTranche(String trancheId, Id deliveryId,
      Id paymentId, BigDecimal size, String settlementBank, String bndBank, String cashProvider,
      String bondRegistrar, String payingAgent, SettlementMode issuerSettlementMode,
      SettlementMode bndSettlementMode) {
    return createAndExerciseCreateTranche(new CreateTranche(trancheId, deliveryId, paymentId, size, settlementBank, bndBank, cashProvider, bondRegistrar, payingAgent, issuerSettlementMode, bndSettlementMode));
  }

  public static CreateCommand create(String operator, String dealProvider, String issuer,
      String dealId, List<String> trancheIds) {
    return new Deal(operator, dealProvider, issuer, dealId, trancheIds).create();
  }

  public static Deal fromValue(Value value$) throws IllegalArgumentException {
    Value recordValue$ = value$;
    DamlRecord record$ = recordValue$.asRecord().orElseThrow(() -> new IllegalArgumentException("Contracts must be constructed from Records"));
    List<DamlRecord.Field> fields$ = record$.getFields();
    int numberOfFields = fields$.size();
    if (numberOfFields != 5) {
      throw new IllegalArgumentException("Expected 5 arguments, got " + numberOfFields);
    }
    String operator = fields$.get(0).getValue().asParty().orElseThrow(() -> new IllegalArgumentException("Expected operator to be of type com.daml.ledger.javaapi.data.Party")).getValue();
    String dealProvider = fields$.get(1).getValue().asParty().orElseThrow(() -> new IllegalArgumentException("Expected dealProvider to be of type com.daml.ledger.javaapi.data.Party")).getValue();
    String issuer = fields$.get(2).getValue().asParty().orElseThrow(() -> new IllegalArgumentException("Expected issuer to be of type com.daml.ledger.javaapi.data.Party")).getValue();
    String dealId = fields$.get(3).getValue().asText().orElseThrow(() -> new IllegalArgumentException("Expected dealId to be of type com.daml.ledger.javaapi.data.Text")).getValue();
    List<String> trancheIds = fields$.get(4).getValue().asList()
            .map(v$0 -> v$0.toList(v$1 ->
                v$1.asText().orElseThrow(() -> new IllegalArgumentException("Expected v$1 to be of type com.daml.ledger.javaapi.data.Text")).getValue()
            ))
            .orElseThrow(() -> new IllegalArgumentException("Expected trancheIds to be of type com.daml.ledger.javaapi.data.DamlList"))
        ;
    return new com.daml.generated.marketplace.distribution.syndication.structuring.model.Deal(operator, dealProvider, issuer, dealId, trancheIds);
  }

  public DamlRecord toValue() {
    ArrayList<DamlRecord.Field> fields = new ArrayList<DamlRecord.Field>(5);
    fields.add(new DamlRecord.Field("operator", new Party(this.operator)));
    fields.add(new DamlRecord.Field("dealProvider", new Party(this.dealProvider)));
    fields.add(new DamlRecord.Field("issuer", new Party(this.issuer)));
    fields.add(new DamlRecord.Field("dealId", new Text(this.dealId)));
    fields.add(new DamlRecord.Field("trancheIds", this.trancheIds.stream().collect(DamlCollectors.toDamlList(v$0 -> new Text(v$0)))));
    return new DamlRecord(fields);
  }

  @Override
  public boolean equals(Object object) {
    if (this == object) {
      return true;
    }
    if (object == null) {
      return false;
    }
    if (!(object instanceof Deal)) {
      return false;
    }
    Deal other = (Deal) object;
    return this.operator.equals(other.operator) && this.dealProvider.equals(other.dealProvider) && this.issuer.equals(other.issuer) && this.dealId.equals(other.dealId) && this.trancheIds.equals(other.trancheIds);
  }

  @Override
  public int hashCode() {
    return Objects.hash(this.operator, this.dealProvider, this.issuer, this.dealId, this.trancheIds);
  }

  @Override
  public String toString() {
    return String.format("com.daml.generated.marketplace.distribution.syndication.structuring.model.Deal(%s, %s, %s, %s, %s)", this.operator, this.dealProvider, this.issuer, this.dealId, this.trancheIds);
  }

  public static final class ContractId extends com.daml.ledger.javaapi.data.codegen.ContractId<Deal> {
    public ContractId(String contractId) {
      super(contractId);
    }

    public ExerciseCommand exerciseArchive(Archive arg) {
      Value argValue = arg.toValue();
      return new ExerciseCommand(Deal.TEMPLATE_ID, this.contractId, "Archive", argValue);
    }

    public ExerciseCommand exerciseCreateTranche(CreateTranche arg) {
      Value argValue = arg.toValue();
      return new ExerciseCommand(Deal.TEMPLATE_ID, this.contractId, "CreateTranche", argValue);
    }

    public ExerciseCommand exerciseCreateTranche(String trancheId, Id deliveryId, Id paymentId,
        BigDecimal size, String settlementBank, String bndBank, String cashProvider,
        String bondRegistrar, String payingAgent, SettlementMode issuerSettlementMode,
        SettlementMode bndSettlementMode) {
      return exerciseCreateTranche(new CreateTranche(trancheId, deliveryId, paymentId, size, settlementBank, bndBank, cashProvider, bondRegistrar, payingAgent, issuerSettlementMode, bndSettlementMode));
    }
  }

  public static class Contract implements com.daml.ledger.javaapi.data.Contract {
    public final ContractId id;

    public final Deal data;

    public final Optional<String> agreementText;

    public final Optional<Tuple3<String, String, String>> key;

    public final Set<String> signatories;

    public final Set<String> observers;

    public Contract(ContractId id, Deal data, Optional<String> agreementText,
        Optional<Tuple3<String, String, String>> key, Set<String> signatories,
        Set<String> observers) {
      this.id = id;
      this.data = data;
      this.agreementText = agreementText;
      this.key = key;
      this.signatories = signatories;
      this.observers = observers;
    }

    public static Contract fromIdAndRecord(String contractId, DamlRecord record$,
        Optional<String> agreementText, Optional<Tuple3<String, String, String>> key,
        Set<String> signatories, Set<String> observers) {
      ContractId id = new ContractId(contractId);
      Deal data = Deal.fromValue(record$);
      return new Contract(id, data, agreementText, key, signatories, observers);
    }

    @Deprecated
    public static Contract fromIdAndRecord(String contractId, DamlRecord record$) {
      ContractId id = new ContractId(contractId);
      Deal data = Deal.fromValue(record$);
      return new Contract(id, data, Optional.empty(), Optional.empty(), Collections.emptySet(), Collections.emptySet());
    }

    public static Contract fromCreatedEvent(CreatedEvent event) {
      return fromIdAndRecord(event.getContractId(), event.getArguments(), event.getAgreementText(), event.getContractKey().map(e -> Tuple3.<java.lang.String, java.lang.String, java.lang.String>fromValue(e, v$0 -> v$0.asParty().orElseThrow(() -> new IllegalArgumentException("Expected e to be of type com.daml.ledger.javaapi.data.Party")).getValue(), v$1 -> v$1.asParty().orElseThrow(() -> new IllegalArgumentException("Expected e to be of type com.daml.ledger.javaapi.data.Party")).getValue(), v$2 -> v$2.asText().orElseThrow(() -> new IllegalArgumentException("Expected e to be of type com.daml.ledger.javaapi.data.Text")).getValue())), event.getSignatories(), event.getObservers());
    }

    @Override
    public boolean equals(Object object) {
      if (this == object) {
        return true;
      }
      if (object == null) {
        return false;
      }
      if (!(object instanceof Contract)) {
        return false;
      }
      Contract other = (Contract) object;
      return this.id.equals(other.id) && this.data.equals(other.data) && this.agreementText.equals(other.agreementText) && this.key.equals(other.key) && this.signatories.equals(other.signatories) && this.observers.equals(other.observers);
    }

    @Override
    public int hashCode() {
      return Objects.hash(this.id, this.data, this.agreementText, this.key, this.signatories, this.observers);
    }

    @Override
    public String toString() {
      return String.format("com.daml.generated.marketplace.distribution.syndication.structuring.model.Deal.Contract(%s, %s, %s, %s, %s, %s)", this.id, this.data, this.agreementText, this.key, this.signatories, this.observers);
    }
  }
}
