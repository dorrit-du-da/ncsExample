package com.daml.generated.marketplace.clearing.market.model;

import com.daml.generated.da.finance.types.Id;
import com.daml.generated.da.internal.template.Archive;
import com.daml.generated.da.set.types.Set;
import com.daml.ledger.javaapi.data.CreateAndExerciseCommand;
import com.daml.ledger.javaapi.data.CreateCommand;
import com.daml.ledger.javaapi.data.CreatedEvent;
import com.daml.ledger.javaapi.data.DamlRecord;
import com.daml.ledger.javaapi.data.ExerciseCommand;
import com.daml.ledger.javaapi.data.Identifier;
import com.daml.ledger.javaapi.data.Numeric;
import com.daml.ledger.javaapi.data.Party;
import com.daml.ledger.javaapi.data.Template;
import com.daml.ledger.javaapi.data.Text;
import com.daml.ledger.javaapi.data.Timestamp;
import com.daml.ledger.javaapi.data.Value;
import java.lang.Deprecated;
import java.lang.IllegalArgumentException;
import java.lang.Object;
import java.lang.Override;
import java.lang.String;
import java.math.BigDecimal;
import java.time.Instant;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Objects;
import java.util.Optional;

public final class FairValue extends Template {
  public static final Identifier TEMPLATE_ID = new Identifier("636e6e778aedec0710919591e9cb2a9404d6daab0581e4ddc515eeae03256f45", "Marketplace.Clearing.Market.Model", "FairValue");

  public final String operator;

  public final String provider;

  public final String customer;

  public final String listingId;

  public final String calculationId;

  public final BigDecimal price;

  public final Id currency;

  public final Instant timestamp;

  public final Instant upTo;

  public final Set<String> observers;

  public FairValue(String operator, String provider, String customer, String listingId,
      String calculationId, BigDecimal price, Id currency, Instant timestamp, Instant upTo,
      Set<String> observers) {
    this.operator = operator;
    this.provider = provider;
    this.customer = customer;
    this.listingId = listingId;
    this.calculationId = calculationId;
    this.price = price;
    this.currency = currency;
    this.timestamp = timestamp;
    this.upTo = upTo;
    this.observers = observers;
  }

  public CreateCommand create() {
    return new CreateCommand(FairValue.TEMPLATE_ID, this.toValue());
  }

  public CreateAndExerciseCommand createAndExerciseArchive(Archive arg) {
    Value argValue = arg.toValue();
    return new CreateAndExerciseCommand(FairValue.TEMPLATE_ID, this.toValue(), "Archive", argValue);
  }

  public static CreateCommand create(String operator, String provider, String customer,
      String listingId, String calculationId, BigDecimal price, Id currency, Instant timestamp,
      Instant upTo, Set<String> observers) {
    return new FairValue(operator, provider, customer, listingId, calculationId, price, currency, timestamp, upTo, observers).create();
  }

  public static FairValue fromValue(Value value$) throws IllegalArgumentException {
    Value recordValue$ = value$;
    DamlRecord record$ = recordValue$.asRecord().orElseThrow(() -> new IllegalArgumentException("Contracts must be constructed from Records"));
    List<DamlRecord.Field> fields$ = record$.getFields();
    int numberOfFields = fields$.size();
    if (numberOfFields != 10) {
      throw new IllegalArgumentException("Expected 10 arguments, got " + numberOfFields);
    }
    String operator = fields$.get(0).getValue().asParty().orElseThrow(() -> new IllegalArgumentException("Expected operator to be of type com.daml.ledger.javaapi.data.Party")).getValue();
    String provider = fields$.get(1).getValue().asParty().orElseThrow(() -> new IllegalArgumentException("Expected provider to be of type com.daml.ledger.javaapi.data.Party")).getValue();
    String customer = fields$.get(2).getValue().asParty().orElseThrow(() -> new IllegalArgumentException("Expected customer to be of type com.daml.ledger.javaapi.data.Party")).getValue();
    String listingId = fields$.get(3).getValue().asText().orElseThrow(() -> new IllegalArgumentException("Expected listingId to be of type com.daml.ledger.javaapi.data.Text")).getValue();
    String calculationId = fields$.get(4).getValue().asText().orElseThrow(() -> new IllegalArgumentException("Expected calculationId to be of type com.daml.ledger.javaapi.data.Text")).getValue();
    BigDecimal price = fields$.get(5).getValue().asNumeric().orElseThrow(() -> new IllegalArgumentException("Expected price to be of type com.daml.ledger.javaapi.data.Numeric")).getValue();
    Id currency = Id.fromValue(fields$.get(6).getValue());
    Instant timestamp = fields$.get(7).getValue().asTimestamp().orElseThrow(() -> new IllegalArgumentException("Expected timestamp to be of type com.daml.ledger.javaapi.data.Timestamp")).getValue();
    Instant upTo = fields$.get(8).getValue().asTimestamp().orElseThrow(() -> new IllegalArgumentException("Expected upTo to be of type com.daml.ledger.javaapi.data.Timestamp")).getValue();
    Set<String> observers = Set.<java.lang.String>fromValue(fields$.get(9).getValue(), v$0 -> v$0.asParty().orElseThrow(() -> new IllegalArgumentException("Expected observers to be of type com.daml.ledger.javaapi.data.Party")).getValue());
    return new com.daml.generated.marketplace.clearing.market.model.FairValue(operator, provider, customer, listingId, calculationId, price, currency, timestamp, upTo, observers);
  }

  public DamlRecord toValue() {
    ArrayList<DamlRecord.Field> fields = new ArrayList<DamlRecord.Field>(10);
    fields.add(new DamlRecord.Field("operator", new Party(this.operator)));
    fields.add(new DamlRecord.Field("provider", new Party(this.provider)));
    fields.add(new DamlRecord.Field("customer", new Party(this.customer)));
    fields.add(new DamlRecord.Field("listingId", new Text(this.listingId)));
    fields.add(new DamlRecord.Field("calculationId", new Text(this.calculationId)));
    fields.add(new DamlRecord.Field("price", new Numeric(this.price)));
    fields.add(new DamlRecord.Field("currency", this.currency.toValue()));
    fields.add(new DamlRecord.Field("timestamp", Timestamp.fromInstant(this.timestamp)));
    fields.add(new DamlRecord.Field("upTo", Timestamp.fromInstant(this.upTo)));
    fields.add(new DamlRecord.Field("observers", this.observers.toValue(v$0 -> new Party(v$0))));
    return new DamlRecord(fields);
  }

  @Override
  public boolean equals(Object object) {
    if (this == object) {
      return true;
    }
    if (object == null) {
      return false;
    }
    if (!(object instanceof FairValue)) {
      return false;
    }
    FairValue other = (FairValue) object;
    return this.operator.equals(other.operator) && this.provider.equals(other.provider) && this.customer.equals(other.customer) && this.listingId.equals(other.listingId) && this.calculationId.equals(other.calculationId) && this.price.equals(other.price) && this.currency.equals(other.currency) && this.timestamp.equals(other.timestamp) && this.upTo.equals(other.upTo) && this.observers.equals(other.observers);
  }

  @Override
  public int hashCode() {
    return Objects.hash(this.operator, this.provider, this.customer, this.listingId, this.calculationId, this.price, this.currency, this.timestamp, this.upTo, this.observers);
  }

  @Override
  public String toString() {
    return String.format("com.daml.generated.marketplace.clearing.market.model.FairValue(%s, %s, %s, %s, %s, %s, %s, %s, %s, %s)", this.operator, this.provider, this.customer, this.listingId, this.calculationId, this.price, this.currency, this.timestamp, this.upTo, this.observers);
  }

  public static final class ContractId extends com.daml.ledger.javaapi.data.codegen.ContractId<FairValue> {
    public ContractId(String contractId) {
      super(contractId);
    }

    public ExerciseCommand exerciseArchive(Archive arg) {
      Value argValue = arg.toValue();
      return new ExerciseCommand(FairValue.TEMPLATE_ID, this.contractId, "Archive", argValue);
    }
  }

  public static class Contract implements com.daml.ledger.javaapi.data.Contract {
    public final ContractId id;

    public final FairValue data;

    public final Optional<String> agreementText;

    public final java.util.Set<String> signatories;

    public final java.util.Set<String> observers;

    public Contract(ContractId id, FairValue data, Optional<String> agreementText,
        java.util.Set<String> signatories, java.util.Set<String> observers) {
      this.id = id;
      this.data = data;
      this.agreementText = agreementText;
      this.signatories = signatories;
      this.observers = observers;
    }

    public static Contract fromIdAndRecord(String contractId, DamlRecord record$,
        Optional<String> agreementText, java.util.Set<String> signatories,
        java.util.Set<String> observers) {
      ContractId id = new ContractId(contractId);
      FairValue data = FairValue.fromValue(record$);
      return new Contract(id, data, agreementText, signatories, observers);
    }

    @Deprecated
    public static Contract fromIdAndRecord(String contractId, DamlRecord record$) {
      ContractId id = new ContractId(contractId);
      FairValue data = FairValue.fromValue(record$);
      return new Contract(id, data, Optional.empty(), Collections.emptySet(), Collections.emptySet());
    }

    public static Contract fromCreatedEvent(CreatedEvent event) {
      return fromIdAndRecord(event.getContractId(), event.getArguments(), event.getAgreementText(), event.getSignatories(), event.getObservers());
    }

    @Override
    public boolean equals(Object object) {
      if (this == object) {
        return true;
      }
      if (object == null) {
        return false;
      }
      if (!(object instanceof Contract)) {
        return false;
      }
      Contract other = (Contract) object;
      return this.id.equals(other.id) && this.data.equals(other.data) && this.agreementText.equals(other.agreementText) && this.signatories.equals(other.signatories) && this.observers.equals(other.observers);
    }

    @Override
    public int hashCode() {
      return Objects.hash(this.id, this.data, this.agreementText, this.signatories, this.observers);
    }

    @Override
    public String toString() {
      return String.format("com.daml.generated.marketplace.clearing.market.model.FairValue.Contract(%s, %s, %s, %s, %s)", this.id, this.data, this.agreementText, this.signatories, this.observers);
    }
  }
}
