package com.daml.generated.da.finance.base.schedule;

import com.daml.ledger.javaapi.data.DamlEnum;
import com.daml.ledger.javaapi.data.Value;
import java.lang.IllegalArgumentException;
import java.lang.String;
import java.util.HashMap;
import java.util.Map;

public enum StubPeriodTypeEnum {
  LONG_FINAL,

  LONG_INITIAL,

  SHORT_FINAL,

  SHORT_INITIAL;

  private static final DamlEnum[] __values$ = {new DamlEnum("LONG_FINAL"), new DamlEnum("LONG_INITIAL"), new DamlEnum("SHORT_FINAL"), new DamlEnum("SHORT_INITIAL")};

  private static final Map<String, StubPeriodTypeEnum> __enums$ = StubPeriodTypeEnum.__buildEnumsMap$();

  private static final Map<String, StubPeriodTypeEnum> __buildEnumsMap$() {
    Map<String, StubPeriodTypeEnum> m = new HashMap<String, StubPeriodTypeEnum>();
    m.put("LONG_FINAL", LONG_FINAL);
    m.put("LONG_INITIAL", LONG_INITIAL);
    m.put("SHORT_FINAL", SHORT_FINAL);
    m.put("SHORT_INITIAL", SHORT_INITIAL);
    return m;
  }

  public static final StubPeriodTypeEnum fromValue(Value value$) {
    String constructor$ = value$.asEnum().orElseThrow(() -> new IllegalArgumentException("Expected DamlEnum to build an instance of the Enum StubPeriodTypeEnum")).getConstructor();
    if (!StubPeriodTypeEnum.__enums$.containsKey(constructor$)) throw new IllegalArgumentException("Expected a DamlEnum with StubPeriodTypeEnum constructor, found " + constructor$);
    return (StubPeriodTypeEnum) StubPeriodTypeEnum.__enums$.get(constructor$);
  }

  public final DamlEnum toValue() {
    return StubPeriodTypeEnum.__values$[ordinal()];
  }
}
