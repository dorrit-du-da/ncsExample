package com.daml.generated.marketplace.distribution.syndication.structuring.service;

import com.daml.generated.da.types.Tuple2;
import com.daml.generated.marketplace.distribution.syndication.bidding.model.Bid;
import com.daml.generated.marketplace.distribution.syndication.bookbuilding.model.BuildRequest;
import com.daml.ledger.javaapi.data.DamlCollectors;
import com.daml.ledger.javaapi.data.DamlRecord;
import com.daml.ledger.javaapi.data.Numeric;
import com.daml.ledger.javaapi.data.Party;
import com.daml.ledger.javaapi.data.Value;
import java.lang.IllegalArgumentException;
import java.lang.Object;
import java.lang.Override;
import java.lang.String;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

public class CloseBook {
  public static final String _packageId = "636e6e778aedec0710919591e9cb2a9404d6daab0581e4ddc515eeae03256f45";

  public final List<BuildRequest.ContractId> buildRequestCids;

  public final List<Bid.ContractId> bidCids;

  public final List<Tuple2<String, BigDecimal>> allocations;

  public final BigDecimal offeredPrice;

  public CloseBook(List<BuildRequest.ContractId> buildRequestCids, List<Bid.ContractId> bidCids,
      List<Tuple2<String, BigDecimal>> allocations, BigDecimal offeredPrice) {
    this.buildRequestCids = buildRequestCids;
    this.bidCids = bidCids;
    this.allocations = allocations;
    this.offeredPrice = offeredPrice;
  }

  public static CloseBook fromValue(Value value$) throws IllegalArgumentException {
    Value recordValue$ = value$;
    DamlRecord record$ = recordValue$.asRecord().orElseThrow(() -> new IllegalArgumentException("Contracts must be constructed from Records"));
    List<DamlRecord.Field> fields$ = record$.getFields();
    int numberOfFields = fields$.size();
    if (numberOfFields != 4) {
      throw new IllegalArgumentException("Expected 4 arguments, got " + numberOfFields);
    }
    List<BuildRequest.ContractId> buildRequestCids = fields$.get(0).getValue().asList()
            .map(v$0 -> v$0.toList(v$1 ->
                new BuildRequest.ContractId(v$1.asContractId().orElseThrow(() -> new IllegalArgumentException("Expected v$1 to be of type com.daml.ledger.javaapi.data.ContractId")).getValue())
            ))
            .orElseThrow(() -> new IllegalArgumentException("Expected buildRequestCids to be of type com.daml.ledger.javaapi.data.DamlList"))
        ;
    List<Bid.ContractId> bidCids = fields$.get(1).getValue().asList()
            .map(v$0 -> v$0.toList(v$1 ->
                new Bid.ContractId(v$1.asContractId().orElseThrow(() -> new IllegalArgumentException("Expected v$1 to be of type com.daml.ledger.javaapi.data.ContractId")).getValue())
            ))
            .orElseThrow(() -> new IllegalArgumentException("Expected bidCids to be of type com.daml.ledger.javaapi.data.DamlList"))
        ;
    List<Tuple2<String, BigDecimal>> allocations = fields$.get(2).getValue().asList()
            .map(v$0 -> v$0.toList(v$1 ->
                Tuple2.<java.lang.String, java.math.BigDecimal>fromValue(v$1, v$2 -> v$2.asParty().orElseThrow(() -> new IllegalArgumentException("Expected v$1 to be of type com.daml.ledger.javaapi.data.Party")).getValue(), v$3 -> v$3.asNumeric().orElseThrow(() -> new IllegalArgumentException("Expected v$1 to be of type com.daml.ledger.javaapi.data.Numeric")).getValue())
            ))
            .orElseThrow(() -> new IllegalArgumentException("Expected allocations to be of type com.daml.ledger.javaapi.data.DamlList"))
        ;
    BigDecimal offeredPrice = fields$.get(3).getValue().asNumeric().orElseThrow(() -> new IllegalArgumentException("Expected offeredPrice to be of type com.daml.ledger.javaapi.data.Numeric")).getValue();
    return new com.daml.generated.marketplace.distribution.syndication.structuring.service.CloseBook(buildRequestCids, bidCids, allocations, offeredPrice);
  }

  public DamlRecord toValue() {
    ArrayList<DamlRecord.Field> fields = new ArrayList<DamlRecord.Field>(4);
    fields.add(new DamlRecord.Field("buildRequestCids", this.buildRequestCids.stream().collect(DamlCollectors.toDamlList(v$0 -> v$0.toValue()))));
    fields.add(new DamlRecord.Field("bidCids", this.bidCids.stream().collect(DamlCollectors.toDamlList(v$0 -> v$0.toValue()))));
    fields.add(new DamlRecord.Field("allocations", this.allocations.stream().collect(DamlCollectors.toDamlList(v$0 -> v$0.toValue(v$1 -> new Party(v$1),v$2 -> new Numeric(v$2))))));
    fields.add(new DamlRecord.Field("offeredPrice", new Numeric(this.offeredPrice)));
    return new DamlRecord(fields);
  }

  @Override
  public boolean equals(Object object) {
    if (this == object) {
      return true;
    }
    if (object == null) {
      return false;
    }
    if (!(object instanceof CloseBook)) {
      return false;
    }
    CloseBook other = (CloseBook) object;
    return this.buildRequestCids.equals(other.buildRequestCids) && this.bidCids.equals(other.bidCids) && this.allocations.equals(other.allocations) && this.offeredPrice.equals(other.offeredPrice);
  }

  @Override
  public int hashCode() {
    return Objects.hash(this.buildRequestCids, this.bidCids, this.allocations, this.offeredPrice);
  }

  @Override
  public String toString() {
    return String.format("com.daml.generated.marketplace.distribution.syndication.structuring.service.CloseBook(%s, %s, %s, %s)", this.buildRequestCids, this.bidCids, this.allocations, this.offeredPrice);
  }
}
