package com.daml.generated.contingentclaims.claim.serializable.claimf;

import com.daml.generated.contingentclaims.claim.serializable.ClaimF;
import com.daml.ledger.javaapi.data.Value;
import com.daml.ledger.javaapi.data.Variant;
import java.lang.IllegalArgumentException;
import java.lang.Object;
import java.lang.Override;
import java.lang.String;
import java.util.Objects;
import java.util.function.Function;

public class OneF<t, x, a, b> extends ClaimF<t, x, a, b> {
  public static final String _packageId = "636e6e778aedec0710919591e9cb2a9404d6daab0581e4ddc515eeae03256f45";

  public final a aValue;

  public OneF(a aValue) {
    this.aValue = aValue;
  }

  public Variant toValue(Function<a, Value> toValuea) {
    return new Variant("OneF", toValuea.apply(this.aValue));
  }

  public static <t, x, a, b> OneF<t, x, a, b> fromValue(Value value$, Function<Value, a> fromValuea)
      throws IllegalArgumentException {
    Variant variant$ = value$.asVariant().orElseThrow(() -> new IllegalArgumentException("Expected: Variant. Actual: " + value$.getClass().getName()));
    if (!"OneF".equals(variant$.getConstructor())) throw new IllegalArgumentException("Invalid constructor. Expected: OneF. Actual: " + variant$.getConstructor());
    Value variantValue$ = variant$.getValue();
    a body = fromValuea.apply(variantValue$);
    return new OneF<t, x, a, b>(body);
  }

  public Variant toValue(Function<t, Value> toValuet, Function<x, Value> toValuex,
      Function<a, Value> toValuea, Function<b, Value> toValueb) {
    return new Variant("OneF", toValuea.apply(this.aValue));
  }

  public static <t, x, a, b> OneF<t, x, a, b> fromValue(Value value$, Function<Value, t> fromValuet,
      Function<Value, x> fromValuex, Function<Value, a> fromValuea, Function<Value, b> fromValueb)
      throws IllegalArgumentException {
    Variant variant$ = value$.asVariant().orElseThrow(() -> new IllegalArgumentException("Expected: Variant. Actual: " + value$.getClass().getName()));
    if (!"OneF".equals(variant$.getConstructor())) throw new IllegalArgumentException("Invalid constructor. Expected: OneF. Actual: " + variant$.getConstructor());
    Value variantValue$ = variant$.getValue();
    a body = fromValuea.apply(variantValue$);
    return new OneF<t, x, a, b>(body);
  }

  @Override
  public boolean equals(Object object) {
    if (this == object) {
      return true;
    }
    if (object == null) {
      return false;
    }
    if (!(object instanceof OneF<?, ?, ?, ?>)) {
      return false;
    }
    OneF<?, ?, ?, ?> other = (OneF<?, ?, ?, ?>) object;
    return this.aValue.equals(other.aValue);
  }

  @Override
  public int hashCode() {
    return Objects.hash(this.aValue);
  }

  @Override
  public String toString() {
    return String.format("OneF(%s)", this.aValue);
  }
}
