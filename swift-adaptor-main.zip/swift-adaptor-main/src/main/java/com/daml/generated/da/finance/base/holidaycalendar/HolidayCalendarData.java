package com.daml.generated.da.finance.base.holidaycalendar;

import com.daml.generated.da.date.types.DayOfWeek;
import com.daml.ledger.javaapi.data.DamlCollectors;
import com.daml.ledger.javaapi.data.DamlRecord;
import com.daml.ledger.javaapi.data.Date;
import com.daml.ledger.javaapi.data.Text;
import com.daml.ledger.javaapi.data.Value;
import java.lang.IllegalArgumentException;
import java.lang.Object;
import java.lang.Override;
import java.lang.String;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

public class HolidayCalendarData {
  public static final String _packageId = "636e6e778aedec0710919591e9cb2a9404d6daab0581e4ddc515eeae03256f45";

  public final String id;

  public final List<DayOfWeek> weekend;

  public final List<LocalDate> holidays;

  public HolidayCalendarData(String id, List<DayOfWeek> weekend, List<LocalDate> holidays) {
    this.id = id;
    this.weekend = weekend;
    this.holidays = holidays;
  }

  public static HolidayCalendarData fromValue(Value value$) throws IllegalArgumentException {
    Value recordValue$ = value$;
    DamlRecord record$ = recordValue$.asRecord().orElseThrow(() -> new IllegalArgumentException("Contracts must be constructed from Records"));
    List<DamlRecord.Field> fields$ = record$.getFields();
    int numberOfFields = fields$.size();
    if (numberOfFields != 3) {
      throw new IllegalArgumentException("Expected 3 arguments, got " + numberOfFields);
    }
    String id = fields$.get(0).getValue().asText().orElseThrow(() -> new IllegalArgumentException("Expected id to be of type com.daml.ledger.javaapi.data.Text")).getValue();
    List<DayOfWeek> weekend = fields$.get(1).getValue().asList()
            .map(v$0 -> v$0.toList(v$1 ->
                DayOfWeek.fromValue(v$1)
            ))
            .orElseThrow(() -> new IllegalArgumentException("Expected weekend to be of type com.daml.ledger.javaapi.data.DamlList"))
        ;
    List<LocalDate> holidays = fields$.get(2).getValue().asList()
            .map(v$0 -> v$0.toList(v$1 ->
                v$1.asDate().orElseThrow(() -> new IllegalArgumentException("Expected v$1 to be of type com.daml.ledger.javaapi.data.Date")).getValue()
            ))
            .orElseThrow(() -> new IllegalArgumentException("Expected holidays to be of type com.daml.ledger.javaapi.data.DamlList"))
        ;
    return new com.daml.generated.da.finance.base.holidaycalendar.HolidayCalendarData(id, weekend, holidays);
  }

  public DamlRecord toValue() {
    ArrayList<DamlRecord.Field> fields = new ArrayList<DamlRecord.Field>(3);
    fields.add(new DamlRecord.Field("id", new Text(this.id)));
    fields.add(new DamlRecord.Field("weekend", this.weekend.stream().collect(DamlCollectors.toDamlList(v$0 -> v$0.toValue()))));
    fields.add(new DamlRecord.Field("holidays", this.holidays.stream().collect(DamlCollectors.toDamlList(v$0 -> new Date((int) v$0.toEpochDay())))));
    return new DamlRecord(fields);
  }

  @Override
  public boolean equals(Object object) {
    if (this == object) {
      return true;
    }
    if (object == null) {
      return false;
    }
    if (!(object instanceof HolidayCalendarData)) {
      return false;
    }
    HolidayCalendarData other = (HolidayCalendarData) object;
    return this.id.equals(other.id) && this.weekend.equals(other.weekend) && this.holidays.equals(other.holidays);
  }

  @Override
  public int hashCode() {
    return Objects.hash(this.id, this.weekend, this.holidays);
  }

  @Override
  public String toString() {
    return String.format("com.daml.generated.da.finance.base.holidaycalendar.HolidayCalendarData(%s, %s, %s)", this.id, this.weekend, this.holidays);
  }
}
