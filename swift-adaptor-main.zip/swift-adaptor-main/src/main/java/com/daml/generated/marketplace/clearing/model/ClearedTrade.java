package com.daml.generated.marketplace.clearing.model;

import com.daml.generated.da.internal.template.Archive;
import com.daml.generated.marketplace.trading.model.Execution;
import com.daml.generated.marketplace.trading.model.Order;
import com.daml.ledger.javaapi.data.CreateAndExerciseCommand;
import com.daml.ledger.javaapi.data.CreateCommand;
import com.daml.ledger.javaapi.data.CreatedEvent;
import com.daml.ledger.javaapi.data.DamlRecord;
import com.daml.ledger.javaapi.data.ExerciseCommand;
import com.daml.ledger.javaapi.data.Identifier;
import com.daml.ledger.javaapi.data.Party;
import com.daml.ledger.javaapi.data.Template;
import com.daml.ledger.javaapi.data.Value;
import java.lang.Deprecated;
import java.lang.IllegalArgumentException;
import java.lang.Object;
import java.lang.Override;
import java.lang.String;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.Set;

public final class ClearedTrade extends Template {
  public static final Identifier TEMPLATE_ID = new Identifier("636e6e778aedec0710919591e9cb2a9404d6daab0581e4ddc515eeae03256f45", "Marketplace.Clearing.Model", "ClearedTrade");

  public final String operator;

  public final String provider;

  public final String clearinghouse;

  public final Order makerOrder;

  public final Order takerOrder;

  public final Execution execution;

  public ClearedTrade(String operator, String provider, String clearinghouse, Order makerOrder,
      Order takerOrder, Execution execution) {
    this.operator = operator;
    this.provider = provider;
    this.clearinghouse = clearinghouse;
    this.makerOrder = makerOrder;
    this.takerOrder = takerOrder;
    this.execution = execution;
  }

  public CreateCommand create() {
    return new CreateCommand(ClearedTrade.TEMPLATE_ID, this.toValue());
  }

  public CreateAndExerciseCommand createAndExerciseArchive(Archive arg) {
    Value argValue = arg.toValue();
    return new CreateAndExerciseCommand(ClearedTrade.TEMPLATE_ID, this.toValue(), "Archive", argValue);
  }

  public CreateAndExerciseCommand createAndExerciseClearedTrade_Novate(ClearedTrade_Novate arg) {
    Value argValue = arg.toValue();
    return new CreateAndExerciseCommand(ClearedTrade.TEMPLATE_ID, this.toValue(), "ClearedTrade_Novate", argValue);
  }

  public CreateAndExerciseCommand createAndExerciseClearedTrade_Novate() {
    return createAndExerciseClearedTrade_Novate(new ClearedTrade_Novate());
  }

  public static CreateCommand create(String operator, String provider, String clearinghouse,
      Order makerOrder, Order takerOrder, Execution execution) {
    return new ClearedTrade(operator, provider, clearinghouse, makerOrder, takerOrder, execution).create();
  }

  public static ClearedTrade fromValue(Value value$) throws IllegalArgumentException {
    Value recordValue$ = value$;
    DamlRecord record$ = recordValue$.asRecord().orElseThrow(() -> new IllegalArgumentException("Contracts must be constructed from Records"));
    List<DamlRecord.Field> fields$ = record$.getFields();
    int numberOfFields = fields$.size();
    if (numberOfFields != 6) {
      throw new IllegalArgumentException("Expected 6 arguments, got " + numberOfFields);
    }
    String operator = fields$.get(0).getValue().asParty().orElseThrow(() -> new IllegalArgumentException("Expected operator to be of type com.daml.ledger.javaapi.data.Party")).getValue();
    String provider = fields$.get(1).getValue().asParty().orElseThrow(() -> new IllegalArgumentException("Expected provider to be of type com.daml.ledger.javaapi.data.Party")).getValue();
    String clearinghouse = fields$.get(2).getValue().asParty().orElseThrow(() -> new IllegalArgumentException("Expected clearinghouse to be of type com.daml.ledger.javaapi.data.Party")).getValue();
    Order makerOrder = Order.fromValue(fields$.get(3).getValue());
    Order takerOrder = Order.fromValue(fields$.get(4).getValue());
    Execution execution = Execution.fromValue(fields$.get(5).getValue());
    return new com.daml.generated.marketplace.clearing.model.ClearedTrade(operator, provider, clearinghouse, makerOrder, takerOrder, execution);
  }

  public DamlRecord toValue() {
    ArrayList<DamlRecord.Field> fields = new ArrayList<DamlRecord.Field>(6);
    fields.add(new DamlRecord.Field("operator", new Party(this.operator)));
    fields.add(new DamlRecord.Field("provider", new Party(this.provider)));
    fields.add(new DamlRecord.Field("clearinghouse", new Party(this.clearinghouse)));
    fields.add(new DamlRecord.Field("makerOrder", this.makerOrder.toValue()));
    fields.add(new DamlRecord.Field("takerOrder", this.takerOrder.toValue()));
    fields.add(new DamlRecord.Field("execution", this.execution.toValue()));
    return new DamlRecord(fields);
  }

  @Override
  public boolean equals(Object object) {
    if (this == object) {
      return true;
    }
    if (object == null) {
      return false;
    }
    if (!(object instanceof ClearedTrade)) {
      return false;
    }
    ClearedTrade other = (ClearedTrade) object;
    return this.operator.equals(other.operator) && this.provider.equals(other.provider) && this.clearinghouse.equals(other.clearinghouse) && this.makerOrder.equals(other.makerOrder) && this.takerOrder.equals(other.takerOrder) && this.execution.equals(other.execution);
  }

  @Override
  public int hashCode() {
    return Objects.hash(this.operator, this.provider, this.clearinghouse, this.makerOrder, this.takerOrder, this.execution);
  }

  @Override
  public String toString() {
    return String.format("com.daml.generated.marketplace.clearing.model.ClearedTrade(%s, %s, %s, %s, %s, %s)", this.operator, this.provider, this.clearinghouse, this.makerOrder, this.takerOrder, this.execution);
  }

  public static final class ContractId extends com.daml.ledger.javaapi.data.codegen.ContractId<ClearedTrade> {
    public ContractId(String contractId) {
      super(contractId);
    }

    public ExerciseCommand exerciseArchive(Archive arg) {
      Value argValue = arg.toValue();
      return new ExerciseCommand(ClearedTrade.TEMPLATE_ID, this.contractId, "Archive", argValue);
    }

    public ExerciseCommand exerciseClearedTrade_Novate(ClearedTrade_Novate arg) {
      Value argValue = arg.toValue();
      return new ExerciseCommand(ClearedTrade.TEMPLATE_ID, this.contractId, "ClearedTrade_Novate", argValue);
    }

    public ExerciseCommand exerciseClearedTrade_Novate() {
      return exerciseClearedTrade_Novate(new ClearedTrade_Novate());
    }
  }

  public static class Contract implements com.daml.ledger.javaapi.data.Contract {
    public final ContractId id;

    public final ClearedTrade data;

    public final Optional<String> agreementText;

    public final Set<String> signatories;

    public final Set<String> observers;

    public Contract(ContractId id, ClearedTrade data, Optional<String> agreementText,
        Set<String> signatories, Set<String> observers) {
      this.id = id;
      this.data = data;
      this.agreementText = agreementText;
      this.signatories = signatories;
      this.observers = observers;
    }

    public static Contract fromIdAndRecord(String contractId, DamlRecord record$,
        Optional<String> agreementText, Set<String> signatories, Set<String> observers) {
      ContractId id = new ContractId(contractId);
      ClearedTrade data = ClearedTrade.fromValue(record$);
      return new Contract(id, data, agreementText, signatories, observers);
    }

    @Deprecated
    public static Contract fromIdAndRecord(String contractId, DamlRecord record$) {
      ContractId id = new ContractId(contractId);
      ClearedTrade data = ClearedTrade.fromValue(record$);
      return new Contract(id, data, Optional.empty(), Collections.emptySet(), Collections.emptySet());
    }

    public static Contract fromCreatedEvent(CreatedEvent event) {
      return fromIdAndRecord(event.getContractId(), event.getArguments(), event.getAgreementText(), event.getSignatories(), event.getObservers());
    }

    @Override
    public boolean equals(Object object) {
      if (this == object) {
        return true;
      }
      if (object == null) {
        return false;
      }
      if (!(object instanceof Contract)) {
        return false;
      }
      Contract other = (Contract) object;
      return this.id.equals(other.id) && this.data.equals(other.data) && this.agreementText.equals(other.agreementText) && this.signatories.equals(other.signatories) && this.observers.equals(other.observers);
    }

    @Override
    public int hashCode() {
      return Objects.hash(this.id, this.data, this.agreementText, this.signatories, this.observers);
    }

    @Override
    public String toString() {
      return String.format("com.daml.generated.marketplace.clearing.model.ClearedTrade.Contract(%s, %s, %s, %s, %s)", this.id, this.data, this.agreementText, this.signatories, this.observers);
    }
  }
}
