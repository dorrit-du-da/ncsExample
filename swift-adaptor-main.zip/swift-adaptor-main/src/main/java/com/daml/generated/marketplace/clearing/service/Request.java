package com.daml.generated.marketplace.clearing.service;

import com.daml.generated.da.finance.types.Account;
import com.daml.generated.da.internal.template.Archive;
import com.daml.ledger.javaapi.data.CreateAndExerciseCommand;
import com.daml.ledger.javaapi.data.CreateCommand;
import com.daml.ledger.javaapi.data.CreatedEvent;
import com.daml.ledger.javaapi.data.DamlRecord;
import com.daml.ledger.javaapi.data.ExerciseCommand;
import com.daml.ledger.javaapi.data.Identifier;
import com.daml.ledger.javaapi.data.Party;
import com.daml.ledger.javaapi.data.Template;
import com.daml.ledger.javaapi.data.Value;
import java.lang.Deprecated;
import java.lang.IllegalArgumentException;
import java.lang.Object;
import java.lang.Override;
import java.lang.String;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.Set;

public final class Request extends Template {
  public static final Identifier TEMPLATE_ID = new Identifier("636e6e778aedec0710919591e9cb2a9404d6daab0581e4ddc515eeae03256f45", "Marketplace.Clearing.Service", "Request");

  public final String customer;

  public final String provider;

  public final Account clearingAccount;

  public Request(String customer, String provider, Account clearingAccount) {
    this.customer = customer;
    this.provider = provider;
    this.clearingAccount = clearingAccount;
  }

  public CreateCommand create() {
    return new CreateCommand(Request.TEMPLATE_ID, this.toValue());
  }

  public CreateAndExerciseCommand createAndExerciseCancel(Cancel arg) {
    Value argValue = arg.toValue();
    return new CreateAndExerciseCommand(Request.TEMPLATE_ID, this.toValue(), "Cancel", argValue);
  }

  public CreateAndExerciseCommand createAndExerciseCancel() {
    return createAndExerciseCancel(new Cancel());
  }

  public CreateAndExerciseCommand createAndExerciseReject(Reject arg) {
    Value argValue = arg.toValue();
    return new CreateAndExerciseCommand(Request.TEMPLATE_ID, this.toValue(), "Reject", argValue);
  }

  public CreateAndExerciseCommand createAndExerciseReject() {
    return createAndExerciseReject(new Reject());
  }

  public CreateAndExerciseCommand createAndExerciseApprove(Approve arg) {
    Value argValue = arg.toValue();
    return new CreateAndExerciseCommand(Request.TEMPLATE_ID, this.toValue(), "Approve", argValue);
  }

  public CreateAndExerciseCommand createAndExerciseApprove(String operator, Account ccpAccount) {
    return createAndExerciseApprove(new Approve(operator, ccpAccount));
  }

  public CreateAndExerciseCommand createAndExerciseArchive(Archive arg) {
    Value argValue = arg.toValue();
    return new CreateAndExerciseCommand(Request.TEMPLATE_ID, this.toValue(), "Archive", argValue);
  }

  public static CreateCommand create(String customer, String provider, Account clearingAccount) {
    return new Request(customer, provider, clearingAccount).create();
  }

  public static Request fromValue(Value value$) throws IllegalArgumentException {
    Value recordValue$ = value$;
    DamlRecord record$ = recordValue$.asRecord().orElseThrow(() -> new IllegalArgumentException("Contracts must be constructed from Records"));
    List<DamlRecord.Field> fields$ = record$.getFields();
    int numberOfFields = fields$.size();
    if (numberOfFields != 3) {
      throw new IllegalArgumentException("Expected 3 arguments, got " + numberOfFields);
    }
    String customer = fields$.get(0).getValue().asParty().orElseThrow(() -> new IllegalArgumentException("Expected customer to be of type com.daml.ledger.javaapi.data.Party")).getValue();
    String provider = fields$.get(1).getValue().asParty().orElseThrow(() -> new IllegalArgumentException("Expected provider to be of type com.daml.ledger.javaapi.data.Party")).getValue();
    Account clearingAccount = Account.fromValue(fields$.get(2).getValue());
    return new com.daml.generated.marketplace.clearing.service.Request(customer, provider, clearingAccount);
  }

  public DamlRecord toValue() {
    ArrayList<DamlRecord.Field> fields = new ArrayList<DamlRecord.Field>(3);
    fields.add(new DamlRecord.Field("customer", new Party(this.customer)));
    fields.add(new DamlRecord.Field("provider", new Party(this.provider)));
    fields.add(new DamlRecord.Field("clearingAccount", this.clearingAccount.toValue()));
    return new DamlRecord(fields);
  }

  @Override
  public boolean equals(Object object) {
    if (this == object) {
      return true;
    }
    if (object == null) {
      return false;
    }
    if (!(object instanceof Request)) {
      return false;
    }
    Request other = (Request) object;
    return this.customer.equals(other.customer) && this.provider.equals(other.provider) && this.clearingAccount.equals(other.clearingAccount);
  }

  @Override
  public int hashCode() {
    return Objects.hash(this.customer, this.provider, this.clearingAccount);
  }

  @Override
  public String toString() {
    return String.format("com.daml.generated.marketplace.clearing.service.Request(%s, %s, %s)", this.customer, this.provider, this.clearingAccount);
  }

  public static final class ContractId extends com.daml.ledger.javaapi.data.codegen.ContractId<Request> {
    public ContractId(String contractId) {
      super(contractId);
    }

    public ExerciseCommand exerciseCancel(Cancel arg) {
      Value argValue = arg.toValue();
      return new ExerciseCommand(Request.TEMPLATE_ID, this.contractId, "Cancel", argValue);
    }

    public ExerciseCommand exerciseCancel() {
      return exerciseCancel(new Cancel());
    }

    public ExerciseCommand exerciseReject(Reject arg) {
      Value argValue = arg.toValue();
      return new ExerciseCommand(Request.TEMPLATE_ID, this.contractId, "Reject", argValue);
    }

    public ExerciseCommand exerciseReject() {
      return exerciseReject(new Reject());
    }

    public ExerciseCommand exerciseApprove(Approve arg) {
      Value argValue = arg.toValue();
      return new ExerciseCommand(Request.TEMPLATE_ID, this.contractId, "Approve", argValue);
    }

    public ExerciseCommand exerciseApprove(String operator, Account ccpAccount) {
      return exerciseApprove(new Approve(operator, ccpAccount));
    }

    public ExerciseCommand exerciseArchive(Archive arg) {
      Value argValue = arg.toValue();
      return new ExerciseCommand(Request.TEMPLATE_ID, this.contractId, "Archive", argValue);
    }
  }

  public static class Contract implements com.daml.ledger.javaapi.data.Contract {
    public final ContractId id;

    public final Request data;

    public final Optional<String> agreementText;

    public final Set<String> signatories;

    public final Set<String> observers;

    public Contract(ContractId id, Request data, Optional<String> agreementText,
        Set<String> signatories, Set<String> observers) {
      this.id = id;
      this.data = data;
      this.agreementText = agreementText;
      this.signatories = signatories;
      this.observers = observers;
    }

    public static Contract fromIdAndRecord(String contractId, DamlRecord record$,
        Optional<String> agreementText, Set<String> signatories, Set<String> observers) {
      ContractId id = new ContractId(contractId);
      Request data = Request.fromValue(record$);
      return new Contract(id, data, agreementText, signatories, observers);
    }

    @Deprecated
    public static Contract fromIdAndRecord(String contractId, DamlRecord record$) {
      ContractId id = new ContractId(contractId);
      Request data = Request.fromValue(record$);
      return new Contract(id, data, Optional.empty(), Collections.emptySet(), Collections.emptySet());
    }

    public static Contract fromCreatedEvent(CreatedEvent event) {
      return fromIdAndRecord(event.getContractId(), event.getArguments(), event.getAgreementText(), event.getSignatories(), event.getObservers());
    }

    @Override
    public boolean equals(Object object) {
      if (this == object) {
        return true;
      }
      if (object == null) {
        return false;
      }
      if (!(object instanceof Contract)) {
        return false;
      }
      Contract other = (Contract) object;
      return this.id.equals(other.id) && this.data.equals(other.data) && this.agreementText.equals(other.agreementText) && this.signatories.equals(other.signatories) && this.observers.equals(other.observers);
    }

    @Override
    public int hashCode() {
      return Objects.hash(this.id, this.data, this.agreementText, this.signatories, this.observers);
    }

    @Override
    public String toString() {
      return String.format("com.daml.generated.marketplace.clearing.service.Request.Contract(%s, %s, %s, %s, %s)", this.id, this.data, this.agreementText, this.signatories, this.observers);
    }
  }
}
