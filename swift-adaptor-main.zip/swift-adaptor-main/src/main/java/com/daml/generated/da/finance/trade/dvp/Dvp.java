package com.daml.generated.da.finance.trade.dvp;

import com.daml.generated.da.finance.trade.types.SettlementStatus;
import com.daml.generated.da.finance.types.Asset;
import com.daml.generated.da.finance.types.Id;
import com.daml.generated.da.finance.types.MasterAgreement;
import com.daml.generated.da.internal.template.Archive;
import com.daml.generated.da.set.types.Set;
import com.daml.generated.da.types.Tuple2;
import com.daml.ledger.javaapi.data.CreateAndExerciseCommand;
import com.daml.ledger.javaapi.data.CreateCommand;
import com.daml.ledger.javaapi.data.CreatedEvent;
import com.daml.ledger.javaapi.data.DamlCollectors;
import com.daml.ledger.javaapi.data.DamlOptional;
import com.daml.ledger.javaapi.data.DamlRecord;
import com.daml.ledger.javaapi.data.Date;
import com.daml.ledger.javaapi.data.ExerciseByKeyCommand;
import com.daml.ledger.javaapi.data.ExerciseCommand;
import com.daml.ledger.javaapi.data.Identifier;
import com.daml.ledger.javaapi.data.Party;
import com.daml.ledger.javaapi.data.Template;
import com.daml.ledger.javaapi.data.Value;
import java.lang.Deprecated;
import java.lang.IllegalArgumentException;
import java.lang.Object;
import java.lang.Override;
import java.lang.String;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Objects;
import java.util.Optional;

public final class Dvp extends Template {
  public static final Identifier TEMPLATE_ID = new Identifier("636e6e778aedec0710919591e9cb2a9404d6daab0581e4ddc515eeae03256f45", "DA.Finance.Trade.Dvp", "Dvp");

  public final MasterAgreement masterAgreement;

  public final Id tradeId;

  public final String buyer;

  public final SettlementStatus status;

  public final Optional<LocalDate> settlementDate;

  public final List<Asset> payments;

  public final List<Asset> deliveries;

  public final Set<String> observers;

  public Dvp(MasterAgreement masterAgreement, Id tradeId, String buyer, SettlementStatus status,
      Optional<LocalDate> settlementDate, List<Asset> payments, List<Asset> deliveries,
      Set<String> observers) {
    this.masterAgreement = masterAgreement;
    this.tradeId = tradeId;
    this.buyer = buyer;
    this.status = status;
    this.settlementDate = settlementDate;
    this.payments = payments;
    this.deliveries = deliveries;
    this.observers = observers;
  }

  public CreateCommand create() {
    return new CreateCommand(Dvp.TEMPLATE_ID, this.toValue());
  }

  public static ExerciseByKeyCommand exerciseByKeyArchive(Tuple2<Id, Id> key, Archive arg) {
    return new ExerciseByKeyCommand(Dvp.TEMPLATE_ID, key.toValue(v$0 -> v$0.toValue(),v$1 -> v$1.toValue()), "Archive", arg.toValue());
  }

  public CreateAndExerciseCommand createAndExerciseArchive(Archive arg) {
    Value argValue = arg.toValue();
    return new CreateAndExerciseCommand(Dvp.TEMPLATE_ID, this.toValue(), "Archive", argValue);
  }

  public static CreateCommand create(MasterAgreement masterAgreement, Id tradeId, String buyer,
      SettlementStatus status, Optional<LocalDate> settlementDate, List<Asset> payments,
      List<Asset> deliveries, Set<String> observers) {
    return new Dvp(masterAgreement, tradeId, buyer, status, settlementDate, payments, deliveries, observers).create();
  }

  public static Dvp fromValue(Value value$) throws IllegalArgumentException {
    Value recordValue$ = value$;
    DamlRecord record$ = recordValue$.asRecord().orElseThrow(() -> new IllegalArgumentException("Contracts must be constructed from Records"));
    List<DamlRecord.Field> fields$ = record$.getFields();
    int numberOfFields = fields$.size();
    if (numberOfFields != 8) {
      throw new IllegalArgumentException("Expected 8 arguments, got " + numberOfFields);
    }
    MasterAgreement masterAgreement = MasterAgreement.fromValue(fields$.get(0).getValue());
    Id tradeId = Id.fromValue(fields$.get(1).getValue());
    String buyer = fields$.get(2).getValue().asParty().orElseThrow(() -> new IllegalArgumentException("Expected buyer to be of type com.daml.ledger.javaapi.data.Party")).getValue();
    SettlementStatus status = SettlementStatus.fromValue(fields$.get(3).getValue());
    Optional<LocalDate> settlementDate = fields$.get(4).getValue().asOptional()
            .map(v$0 -> v$0.toOptional(v$1 ->
                v$1.asDate().orElseThrow(() -> new IllegalArgumentException("Expected v$1 to be of type com.daml.ledger.javaapi.data.Date")).getValue()
            ))
            .orElseThrow(() -> new IllegalArgumentException("Expected settlementDate to be of type com.daml.ledger.javaapi.data.DamlOptional"))
                  ;
    List<Asset> payments = fields$.get(5).getValue().asList()
            .map(v$0 -> v$0.toList(v$1 ->
                Asset.fromValue(v$1)
            ))
            .orElseThrow(() -> new IllegalArgumentException("Expected payments to be of type com.daml.ledger.javaapi.data.DamlList"))
        ;
    List<Asset> deliveries = fields$.get(6).getValue().asList()
            .map(v$0 -> v$0.toList(v$1 ->
                Asset.fromValue(v$1)
            ))
            .orElseThrow(() -> new IllegalArgumentException("Expected deliveries to be of type com.daml.ledger.javaapi.data.DamlList"))
        ;
    Set<String> observers = Set.<java.lang.String>fromValue(fields$.get(7).getValue(), v$0 -> v$0.asParty().orElseThrow(() -> new IllegalArgumentException("Expected observers to be of type com.daml.ledger.javaapi.data.Party")).getValue());
    return new com.daml.generated.da.finance.trade.dvp.Dvp(masterAgreement, tradeId, buyer, status, settlementDate, payments, deliveries, observers);
  }

  public DamlRecord toValue() {
    ArrayList<DamlRecord.Field> fields = new ArrayList<DamlRecord.Field>(8);
    fields.add(new DamlRecord.Field("masterAgreement", this.masterAgreement.toValue()));
    fields.add(new DamlRecord.Field("tradeId", this.tradeId.toValue()));
    fields.add(new DamlRecord.Field("buyer", new Party(this.buyer)));
    fields.add(new DamlRecord.Field("status", this.status.toValue()));
    fields.add(new DamlRecord.Field("settlementDate", DamlOptional.of(this.settlementDate.map(v$0 -> new Date((int) v$0.toEpochDay())))));
    fields.add(new DamlRecord.Field("payments", this.payments.stream().collect(DamlCollectors.toDamlList(v$0 -> v$0.toValue()))));
    fields.add(new DamlRecord.Field("deliveries", this.deliveries.stream().collect(DamlCollectors.toDamlList(v$0 -> v$0.toValue()))));
    fields.add(new DamlRecord.Field("observers", this.observers.toValue(v$0 -> new Party(v$0))));
    return new DamlRecord(fields);
  }

  @Override
  public boolean equals(Object object) {
    if (this == object) {
      return true;
    }
    if (object == null) {
      return false;
    }
    if (!(object instanceof Dvp)) {
      return false;
    }
    Dvp other = (Dvp) object;
    return this.masterAgreement.equals(other.masterAgreement) && this.tradeId.equals(other.tradeId) && this.buyer.equals(other.buyer) && this.status.equals(other.status) && this.settlementDate.equals(other.settlementDate) && this.payments.equals(other.payments) && this.deliveries.equals(other.deliveries) && this.observers.equals(other.observers);
  }

  @Override
  public int hashCode() {
    return Objects.hash(this.masterAgreement, this.tradeId, this.buyer, this.status, this.settlementDate, this.payments, this.deliveries, this.observers);
  }

  @Override
  public String toString() {
    return String.format("com.daml.generated.da.finance.trade.dvp.Dvp(%s, %s, %s, %s, %s, %s, %s, %s)", this.masterAgreement, this.tradeId, this.buyer, this.status, this.settlementDate, this.payments, this.deliveries, this.observers);
  }

  public static final class ContractId extends com.daml.ledger.javaapi.data.codegen.ContractId<Dvp> {
    public ContractId(String contractId) {
      super(contractId);
    }

    public ExerciseCommand exerciseArchive(Archive arg) {
      Value argValue = arg.toValue();
      return new ExerciseCommand(Dvp.TEMPLATE_ID, this.contractId, "Archive", argValue);
    }
  }

  public static class Contract implements com.daml.ledger.javaapi.data.Contract {
    public final ContractId id;

    public final Dvp data;

    public final Optional<String> agreementText;

    public final Optional<Tuple2<Id, Id>> key;

    public final java.util.Set<String> signatories;

    public final java.util.Set<String> observers;

    public Contract(ContractId id, Dvp data, Optional<String> agreementText,
        Optional<Tuple2<Id, Id>> key, java.util.Set<String> signatories,
        java.util.Set<String> observers) {
      this.id = id;
      this.data = data;
      this.agreementText = agreementText;
      this.key = key;
      this.signatories = signatories;
      this.observers = observers;
    }

    public static Contract fromIdAndRecord(String contractId, DamlRecord record$,
        Optional<String> agreementText, Optional<Tuple2<Id, Id>> key,
        java.util.Set<String> signatories, java.util.Set<String> observers) {
      ContractId id = new ContractId(contractId);
      Dvp data = Dvp.fromValue(record$);
      return new Contract(id, data, agreementText, key, signatories, observers);
    }

    @Deprecated
    public static Contract fromIdAndRecord(String contractId, DamlRecord record$) {
      ContractId id = new ContractId(contractId);
      Dvp data = Dvp.fromValue(record$);
      return new Contract(id, data, Optional.empty(), Optional.empty(), Collections.emptySet(), Collections.emptySet());
    }

    public static Contract fromCreatedEvent(CreatedEvent event) {
      return fromIdAndRecord(event.getContractId(), event.getArguments(), event.getAgreementText(), event.getContractKey().map(e -> Tuple2.<com.daml.generated.da.finance.types.Id, com.daml.generated.da.finance.types.Id>fromValue(e, v$0 -> Id.fromValue(v$0), v$1 -> Id.fromValue(v$1))), event.getSignatories(), event.getObservers());
    }

    @Override
    public boolean equals(Object object) {
      if (this == object) {
        return true;
      }
      if (object == null) {
        return false;
      }
      if (!(object instanceof Contract)) {
        return false;
      }
      Contract other = (Contract) object;
      return this.id.equals(other.id) && this.data.equals(other.data) && this.agreementText.equals(other.agreementText) && this.key.equals(other.key) && this.signatories.equals(other.signatories) && this.observers.equals(other.observers);
    }

    @Override
    public int hashCode() {
      return Objects.hash(this.id, this.data, this.agreementText, this.key, this.signatories, this.observers);
    }

    @Override
    public String toString() {
      return String.format("com.daml.generated.da.finance.trade.dvp.Dvp.Contract(%s, %s, %s, %s, %s, %s)", this.id, this.data, this.agreementText, this.key, this.signatories, this.observers);
    }
  }
}
