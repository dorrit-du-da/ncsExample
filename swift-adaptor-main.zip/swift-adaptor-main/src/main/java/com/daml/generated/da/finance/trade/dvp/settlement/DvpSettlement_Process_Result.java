package com.daml.generated.da.finance.trade.dvp.settlement;

import com.daml.generated.da.finance.asset.AssetDeposit;
import com.daml.generated.da.finance.trade.dvp.Dvp;
import com.daml.ledger.javaapi.data.DamlCollectors;
import com.daml.ledger.javaapi.data.DamlRecord;
import com.daml.ledger.javaapi.data.Value;
import java.lang.IllegalArgumentException;
import java.lang.Object;
import java.lang.Override;
import java.lang.String;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

public class DvpSettlement_Process_Result {
  public static final String _packageId = "636e6e778aedec0710919591e9cb2a9404d6daab0581e4ddc515eeae03256f45";

  public final Dvp.ContractId dvpCid;

  public final List<List<AssetDeposit.ContractId>> paymentDepositCids;

  public final List<List<AssetDeposit.ContractId>> deliveryDepositCids;

  public DvpSettlement_Process_Result(Dvp.ContractId dvpCid,
      List<List<AssetDeposit.ContractId>> paymentDepositCids,
      List<List<AssetDeposit.ContractId>> deliveryDepositCids) {
    this.dvpCid = dvpCid;
    this.paymentDepositCids = paymentDepositCids;
    this.deliveryDepositCids = deliveryDepositCids;
  }

  public static DvpSettlement_Process_Result fromValue(Value value$) throws
      IllegalArgumentException {
    Value recordValue$ = value$;
    DamlRecord record$ = recordValue$.asRecord().orElseThrow(() -> new IllegalArgumentException("Contracts must be constructed from Records"));
    List<DamlRecord.Field> fields$ = record$.getFields();
    int numberOfFields = fields$.size();
    if (numberOfFields != 3) {
      throw new IllegalArgumentException("Expected 3 arguments, got " + numberOfFields);
    }
    Dvp.ContractId dvpCid = new Dvp.ContractId(fields$.get(0).getValue().asContractId().orElseThrow(() -> new IllegalArgumentException("Expected dvpCid to be of type com.daml.ledger.javaapi.data.ContractId")).getValue());
    List<List<AssetDeposit.ContractId>> paymentDepositCids = fields$.get(1).getValue().asList()
            .map(v$0 -> v$0.toList(v$1 ->
                v$1.asList()
            .map(v$2 -> v$2.toList(v$3 ->
                new AssetDeposit.ContractId(v$3.asContractId().orElseThrow(() -> new IllegalArgumentException("Expected v$3 to be of type com.daml.ledger.javaapi.data.ContractId")).getValue())
            ))
            .orElseThrow(() -> new IllegalArgumentException("Expected v$1 to be of type com.daml.ledger.javaapi.data.DamlList"))
        
            ))
            .orElseThrow(() -> new IllegalArgumentException("Expected paymentDepositCids to be of type com.daml.ledger.javaapi.data.DamlList"))
        ;
    List<List<AssetDeposit.ContractId>> deliveryDepositCids = fields$.get(2).getValue().asList()
            .map(v$0 -> v$0.toList(v$1 ->
                v$1.asList()
            .map(v$2 -> v$2.toList(v$3 ->
                new AssetDeposit.ContractId(v$3.asContractId().orElseThrow(() -> new IllegalArgumentException("Expected v$3 to be of type com.daml.ledger.javaapi.data.ContractId")).getValue())
            ))
            .orElseThrow(() -> new IllegalArgumentException("Expected v$1 to be of type com.daml.ledger.javaapi.data.DamlList"))
        
            ))
            .orElseThrow(() -> new IllegalArgumentException("Expected deliveryDepositCids to be of type com.daml.ledger.javaapi.data.DamlList"))
        ;
    return new com.daml.generated.da.finance.trade.dvp.settlement.DvpSettlement_Process_Result(dvpCid, paymentDepositCids, deliveryDepositCids);
  }

  public DamlRecord toValue() {
    ArrayList<DamlRecord.Field> fields = new ArrayList<DamlRecord.Field>(3);
    fields.add(new DamlRecord.Field("dvpCid", this.dvpCid.toValue()));
    fields.add(new DamlRecord.Field("paymentDepositCids", this.paymentDepositCids.stream().collect(DamlCollectors.toDamlList(v$0 -> v$0.stream().collect(DamlCollectors.toDamlList(v$1 -> v$1.toValue()))))));
    fields.add(new DamlRecord.Field("deliveryDepositCids", this.deliveryDepositCids.stream().collect(DamlCollectors.toDamlList(v$0 -> v$0.stream().collect(DamlCollectors.toDamlList(v$1 -> v$1.toValue()))))));
    return new DamlRecord(fields);
  }

  @Override
  public boolean equals(Object object) {
    if (this == object) {
      return true;
    }
    if (object == null) {
      return false;
    }
    if (!(object instanceof DvpSettlement_Process_Result)) {
      return false;
    }
    DvpSettlement_Process_Result other = (DvpSettlement_Process_Result) object;
    return this.dvpCid.equals(other.dvpCid) && this.paymentDepositCids.equals(other.paymentDepositCids) && this.deliveryDepositCids.equals(other.deliveryDepositCids);
  }

  @Override
  public int hashCode() {
    return Objects.hash(this.dvpCid, this.paymentDepositCids, this.deliveryDepositCids);
  }

  @Override
  public String toString() {
    return String.format("com.daml.generated.da.finance.trade.dvp.settlement.DvpSettlement_Process_Result(%s, %s, %s)", this.dvpCid, this.paymentDepositCids, this.deliveryDepositCids);
  }
}
