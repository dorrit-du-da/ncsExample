package com.daml.generated.marketplace.clearing.service;

import com.daml.generated.da.finance.asset.AssetDeposit;
import com.daml.generated.marketplace.clearing.model.MarginCalculation;
import com.daml.ledger.javaapi.data.DamlCollectors;
import com.daml.ledger.javaapi.data.DamlRecord;
import com.daml.ledger.javaapi.data.Value;
import java.lang.IllegalArgumentException;
import java.lang.Object;
import java.lang.Override;
import java.lang.String;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

public class PerformMarginFill {
  public static final String _packageId = "636e6e778aedec0710919591e9cb2a9404d6daab0581e4ddc515eeae03256f45";

  public final List<AssetDeposit.ContractId> depositCids;

  public final List<AssetDeposit.ContractId> marginDepositCids;

  public final MarginCalculation.ContractId calculationCid;

  public PerformMarginFill(List<AssetDeposit.ContractId> depositCids,
      List<AssetDeposit.ContractId> marginDepositCids,
      MarginCalculation.ContractId calculationCid) {
    this.depositCids = depositCids;
    this.marginDepositCids = marginDepositCids;
    this.calculationCid = calculationCid;
  }

  public static PerformMarginFill fromValue(Value value$) throws IllegalArgumentException {
    Value recordValue$ = value$;
    DamlRecord record$ = recordValue$.asRecord().orElseThrow(() -> new IllegalArgumentException("Contracts must be constructed from Records"));
    List<DamlRecord.Field> fields$ = record$.getFields();
    int numberOfFields = fields$.size();
    if (numberOfFields != 3) {
      throw new IllegalArgumentException("Expected 3 arguments, got " + numberOfFields);
    }
    List<AssetDeposit.ContractId> depositCids = fields$.get(0).getValue().asList()
            .map(v$0 -> v$0.toList(v$1 ->
                new AssetDeposit.ContractId(v$1.asContractId().orElseThrow(() -> new IllegalArgumentException("Expected v$1 to be of type com.daml.ledger.javaapi.data.ContractId")).getValue())
            ))
            .orElseThrow(() -> new IllegalArgumentException("Expected depositCids to be of type com.daml.ledger.javaapi.data.DamlList"))
        ;
    List<AssetDeposit.ContractId> marginDepositCids = fields$.get(1).getValue().asList()
            .map(v$0 -> v$0.toList(v$1 ->
                new AssetDeposit.ContractId(v$1.asContractId().orElseThrow(() -> new IllegalArgumentException("Expected v$1 to be of type com.daml.ledger.javaapi.data.ContractId")).getValue())
            ))
            .orElseThrow(() -> new IllegalArgumentException("Expected marginDepositCids to be of type com.daml.ledger.javaapi.data.DamlList"))
        ;
    MarginCalculation.ContractId calculationCid = new MarginCalculation.ContractId(fields$.get(2).getValue().asContractId().orElseThrow(() -> new IllegalArgumentException("Expected calculationCid to be of type com.daml.ledger.javaapi.data.ContractId")).getValue());
    return new com.daml.generated.marketplace.clearing.service.PerformMarginFill(depositCids, marginDepositCids, calculationCid);
  }

  public DamlRecord toValue() {
    ArrayList<DamlRecord.Field> fields = new ArrayList<DamlRecord.Field>(3);
    fields.add(new DamlRecord.Field("depositCids", this.depositCids.stream().collect(DamlCollectors.toDamlList(v$0 -> v$0.toValue()))));
    fields.add(new DamlRecord.Field("marginDepositCids", this.marginDepositCids.stream().collect(DamlCollectors.toDamlList(v$0 -> v$0.toValue()))));
    fields.add(new DamlRecord.Field("calculationCid", this.calculationCid.toValue()));
    return new DamlRecord(fields);
  }

  @Override
  public boolean equals(Object object) {
    if (this == object) {
      return true;
    }
    if (object == null) {
      return false;
    }
    if (!(object instanceof PerformMarginFill)) {
      return false;
    }
    PerformMarginFill other = (PerformMarginFill) object;
    return this.depositCids.equals(other.depositCids) && this.marginDepositCids.equals(other.marginDepositCids) && this.calculationCid.equals(other.calculationCid);
  }

  @Override
  public int hashCode() {
    return Objects.hash(this.depositCids, this.marginDepositCids, this.calculationCid);
  }

  @Override
  public String toString() {
    return String.format("com.daml.generated.marketplace.clearing.service.PerformMarginFill(%s, %s, %s)", this.depositCids, this.marginDepositCids, this.calculationCid);
  }
}
