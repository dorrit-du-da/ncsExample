package com.daml.generated.marketplace.distribution.syndication.bookbuilding.model;

import com.daml.generated.da.finance.types.Id;
import com.daml.generated.da.internal.template.Archive;
import com.daml.generated.da.types.Tuple5;
import com.daml.ledger.javaapi.data.CreateAndExerciseCommand;
import com.daml.ledger.javaapi.data.CreateCommand;
import com.daml.ledger.javaapi.data.CreatedEvent;
import com.daml.ledger.javaapi.data.DamlRecord;
import com.daml.ledger.javaapi.data.ExerciseByKeyCommand;
import com.daml.ledger.javaapi.data.ExerciseCommand;
import com.daml.ledger.javaapi.data.Identifier;
import com.daml.ledger.javaapi.data.Numeric;
import com.daml.ledger.javaapi.data.Party;
import com.daml.ledger.javaapi.data.Template;
import com.daml.ledger.javaapi.data.Text;
import com.daml.ledger.javaapi.data.Value;
import java.lang.Deprecated;
import java.lang.IllegalArgumentException;
import java.lang.Object;
import java.lang.Override;
import java.lang.String;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.Set;

public final class BuildRequest extends Template {
  public static final Identifier TEMPLATE_ID = new Identifier("636e6e778aedec0710919591e9cb2a9404d6daab0581e4ddc515eeae03256f45", "Marketplace.Distribution.Syndication.BookBuilding.Model", "BuildRequest");

  public final String operator;

  public final String provider;

  public final String customer;

  public final String issuer;

  public final String dealId;

  public final String trancheId;

  public final Id deliveryId;

  public final Id paymentId;

  public final BigDecimal size;

  public BuildRequest(String operator, String provider, String customer, String issuer,
      String dealId, String trancheId, Id deliveryId, Id paymentId, BigDecimal size) {
    this.operator = operator;
    this.provider = provider;
    this.customer = customer;
    this.issuer = issuer;
    this.dealId = dealId;
    this.trancheId = trancheId;
    this.deliveryId = deliveryId;
    this.paymentId = paymentId;
    this.size = size;
  }

  public CreateCommand create() {
    return new CreateCommand(BuildRequest.TEMPLATE_ID, this.toValue());
  }

  public static ExerciseByKeyCommand exerciseByKeyArchive(
      Tuple5<String, String, String, String, String> key, Archive arg) {
    return new ExerciseByKeyCommand(BuildRequest.TEMPLATE_ID, key.toValue(v$0 -> new Party(v$0),v$1 -> new Party(v$1),v$2 -> new Party(v$2),v$3 -> new Text(v$3),v$4 -> new Text(v$4)), "Archive", arg.toValue());
  }

  public static ExerciseByKeyCommand exerciseByKeyDelete(
      Tuple5<String, String, String, String, String> key, Delete arg) {
    return new ExerciseByKeyCommand(BuildRequest.TEMPLATE_ID, key.toValue(v$0 -> new Party(v$0),v$1 -> new Party(v$1),v$2 -> new Party(v$2),v$3 -> new Text(v$3),v$4 -> new Text(v$4)), "Delete", arg.toValue());
  }

  public static ExerciseByKeyCommand exerciseByKeyDelete(
      Tuple5<String, String, String, String, String> key) {
    return BuildRequest.exerciseByKeyDelete(key, new Delete());
  }

  public CreateAndExerciseCommand createAndExerciseArchive(Archive arg) {
    Value argValue = arg.toValue();
    return new CreateAndExerciseCommand(BuildRequest.TEMPLATE_ID, this.toValue(), "Archive", argValue);
  }

  public CreateAndExerciseCommand createAndExerciseDelete(Delete arg) {
    Value argValue = arg.toValue();
    return new CreateAndExerciseCommand(BuildRequest.TEMPLATE_ID, this.toValue(), "Delete", argValue);
  }

  public CreateAndExerciseCommand createAndExerciseDelete() {
    return createAndExerciseDelete(new Delete());
  }

  public static CreateCommand create(String operator, String provider, String customer,
      String issuer, String dealId, String trancheId, Id deliveryId, Id paymentId,
      BigDecimal size) {
    return new BuildRequest(operator, provider, customer, issuer, dealId, trancheId, deliveryId, paymentId, size).create();
  }

  public static BuildRequest fromValue(Value value$) throws IllegalArgumentException {
    Value recordValue$ = value$;
    DamlRecord record$ = recordValue$.asRecord().orElseThrow(() -> new IllegalArgumentException("Contracts must be constructed from Records"));
    List<DamlRecord.Field> fields$ = record$.getFields();
    int numberOfFields = fields$.size();
    if (numberOfFields != 9) {
      throw new IllegalArgumentException("Expected 9 arguments, got " + numberOfFields);
    }
    String operator = fields$.get(0).getValue().asParty().orElseThrow(() -> new IllegalArgumentException("Expected operator to be of type com.daml.ledger.javaapi.data.Party")).getValue();
    String provider = fields$.get(1).getValue().asParty().orElseThrow(() -> new IllegalArgumentException("Expected provider to be of type com.daml.ledger.javaapi.data.Party")).getValue();
    String customer = fields$.get(2).getValue().asParty().orElseThrow(() -> new IllegalArgumentException("Expected customer to be of type com.daml.ledger.javaapi.data.Party")).getValue();
    String issuer = fields$.get(3).getValue().asParty().orElseThrow(() -> new IllegalArgumentException("Expected issuer to be of type com.daml.ledger.javaapi.data.Party")).getValue();
    String dealId = fields$.get(4).getValue().asText().orElseThrow(() -> new IllegalArgumentException("Expected dealId to be of type com.daml.ledger.javaapi.data.Text")).getValue();
    String trancheId = fields$.get(5).getValue().asText().orElseThrow(() -> new IllegalArgumentException("Expected trancheId to be of type com.daml.ledger.javaapi.data.Text")).getValue();
    Id deliveryId = Id.fromValue(fields$.get(6).getValue());
    Id paymentId = Id.fromValue(fields$.get(7).getValue());
    BigDecimal size = fields$.get(8).getValue().asNumeric().orElseThrow(() -> new IllegalArgumentException("Expected size to be of type com.daml.ledger.javaapi.data.Numeric")).getValue();
    return new com.daml.generated.marketplace.distribution.syndication.bookbuilding.model.BuildRequest(operator, provider, customer, issuer, dealId, trancheId, deliveryId, paymentId, size);
  }

  public DamlRecord toValue() {
    ArrayList<DamlRecord.Field> fields = new ArrayList<DamlRecord.Field>(9);
    fields.add(new DamlRecord.Field("operator", new Party(this.operator)));
    fields.add(new DamlRecord.Field("provider", new Party(this.provider)));
    fields.add(new DamlRecord.Field("customer", new Party(this.customer)));
    fields.add(new DamlRecord.Field("issuer", new Party(this.issuer)));
    fields.add(new DamlRecord.Field("dealId", new Text(this.dealId)));
    fields.add(new DamlRecord.Field("trancheId", new Text(this.trancheId)));
    fields.add(new DamlRecord.Field("deliveryId", this.deliveryId.toValue()));
    fields.add(new DamlRecord.Field("paymentId", this.paymentId.toValue()));
    fields.add(new DamlRecord.Field("size", new Numeric(this.size)));
    return new DamlRecord(fields);
  }

  @Override
  public boolean equals(Object object) {
    if (this == object) {
      return true;
    }
    if (object == null) {
      return false;
    }
    if (!(object instanceof BuildRequest)) {
      return false;
    }
    BuildRequest other = (BuildRequest) object;
    return this.operator.equals(other.operator) && this.provider.equals(other.provider) && this.customer.equals(other.customer) && this.issuer.equals(other.issuer) && this.dealId.equals(other.dealId) && this.trancheId.equals(other.trancheId) && this.deliveryId.equals(other.deliveryId) && this.paymentId.equals(other.paymentId) && this.size.equals(other.size);
  }

  @Override
  public int hashCode() {
    return Objects.hash(this.operator, this.provider, this.customer, this.issuer, this.dealId, this.trancheId, this.deliveryId, this.paymentId, this.size);
  }

  @Override
  public String toString() {
    return String.format("com.daml.generated.marketplace.distribution.syndication.bookbuilding.model.BuildRequest(%s, %s, %s, %s, %s, %s, %s, %s, %s)", this.operator, this.provider, this.customer, this.issuer, this.dealId, this.trancheId, this.deliveryId, this.paymentId, this.size);
  }

  public static final class ContractId extends com.daml.ledger.javaapi.data.codegen.ContractId<BuildRequest> {
    public ContractId(String contractId) {
      super(contractId);
    }

    public ExerciseCommand exerciseArchive(Archive arg) {
      Value argValue = arg.toValue();
      return new ExerciseCommand(BuildRequest.TEMPLATE_ID, this.contractId, "Archive", argValue);
    }

    public ExerciseCommand exerciseDelete(Delete arg) {
      Value argValue = arg.toValue();
      return new ExerciseCommand(BuildRequest.TEMPLATE_ID, this.contractId, "Delete", argValue);
    }

    public ExerciseCommand exerciseDelete() {
      return exerciseDelete(new Delete());
    }
  }

  public static class Contract implements com.daml.ledger.javaapi.data.Contract {
    public final ContractId id;

    public final BuildRequest data;

    public final Optional<String> agreementText;

    public final Optional<Tuple5<String, String, String, String, String>> key;

    public final Set<String> signatories;

    public final Set<String> observers;

    public Contract(ContractId id, BuildRequest data, Optional<String> agreementText,
        Optional<Tuple5<String, String, String, String, String>> key, Set<String> signatories,
        Set<String> observers) {
      this.id = id;
      this.data = data;
      this.agreementText = agreementText;
      this.key = key;
      this.signatories = signatories;
      this.observers = observers;
    }

    public static Contract fromIdAndRecord(String contractId, DamlRecord record$,
        Optional<String> agreementText,
        Optional<Tuple5<String, String, String, String, String>> key, Set<String> signatories,
        Set<String> observers) {
      ContractId id = new ContractId(contractId);
      BuildRequest data = BuildRequest.fromValue(record$);
      return new Contract(id, data, agreementText, key, signatories, observers);
    }

    @Deprecated
    public static Contract fromIdAndRecord(String contractId, DamlRecord record$) {
      ContractId id = new ContractId(contractId);
      BuildRequest data = BuildRequest.fromValue(record$);
      return new Contract(id, data, Optional.empty(), Optional.empty(), Collections.emptySet(), Collections.emptySet());
    }

    public static Contract fromCreatedEvent(CreatedEvent event) {
      return fromIdAndRecord(event.getContractId(), event.getArguments(), event.getAgreementText(), event.getContractKey().map(e -> Tuple5.<java.lang.String, java.lang.String, java.lang.String, java.lang.String, java.lang.String>fromValue(e, v$0 -> v$0.asParty().orElseThrow(() -> new IllegalArgumentException("Expected e to be of type com.daml.ledger.javaapi.data.Party")).getValue(), v$1 -> v$1.asParty().orElseThrow(() -> new IllegalArgumentException("Expected e to be of type com.daml.ledger.javaapi.data.Party")).getValue(), v$2 -> v$2.asParty().orElseThrow(() -> new IllegalArgumentException("Expected e to be of type com.daml.ledger.javaapi.data.Party")).getValue(), v$3 -> v$3.asText().orElseThrow(() -> new IllegalArgumentException("Expected e to be of type com.daml.ledger.javaapi.data.Text")).getValue(), v$4 -> v$4.asText().orElseThrow(() -> new IllegalArgumentException("Expected e to be of type com.daml.ledger.javaapi.data.Text")).getValue())), event.getSignatories(), event.getObservers());
    }

    @Override
    public boolean equals(Object object) {
      if (this == object) {
        return true;
      }
      if (object == null) {
        return false;
      }
      if (!(object instanceof Contract)) {
        return false;
      }
      Contract other = (Contract) object;
      return this.id.equals(other.id) && this.data.equals(other.data) && this.agreementText.equals(other.agreementText) && this.key.equals(other.key) && this.signatories.equals(other.signatories) && this.observers.equals(other.observers);
    }

    @Override
    public int hashCode() {
      return Objects.hash(this.id, this.data, this.agreementText, this.key, this.signatories, this.observers);
    }

    @Override
    public String toString() {
      return String.format("com.daml.generated.marketplace.distribution.syndication.bookbuilding.model.BuildRequest.Contract(%s, %s, %s, %s, %s, %s)", this.id, this.data, this.agreementText, this.key, this.signatories, this.observers);
    }
  }
}
