package com.daml.generated.da.finance.trade.dvp.lifecycle;

import com.daml.generated.da.finance.asset.lifecycle.LifecycleEffects;
import com.daml.generated.da.finance.trade.dvp.Dvp;
import com.daml.ledger.javaapi.data.DamlRecord;
import com.daml.ledger.javaapi.data.Party;
import com.daml.ledger.javaapi.data.Value;
import java.lang.IllegalArgumentException;
import java.lang.Object;
import java.lang.Override;
import java.lang.String;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

public class DvpLifecycle_Process {
  public static final String _packageId = "636e6e778aedec0710919591e9cb2a9404d6daab0581e4ddc515eeae03256f45";

  public final Dvp.ContractId dvpCid;

  public final LifecycleEffects.ContractId lifecycleEffectsCid;

  public final String ctrl;

  public DvpLifecycle_Process(Dvp.ContractId dvpCid,
      LifecycleEffects.ContractId lifecycleEffectsCid, String ctrl) {
    this.dvpCid = dvpCid;
    this.lifecycleEffectsCid = lifecycleEffectsCid;
    this.ctrl = ctrl;
  }

  public static DvpLifecycle_Process fromValue(Value value$) throws IllegalArgumentException {
    Value recordValue$ = value$;
    DamlRecord record$ = recordValue$.asRecord().orElseThrow(() -> new IllegalArgumentException("Contracts must be constructed from Records"));
    List<DamlRecord.Field> fields$ = record$.getFields();
    int numberOfFields = fields$.size();
    if (numberOfFields != 3) {
      throw new IllegalArgumentException("Expected 3 arguments, got " + numberOfFields);
    }
    Dvp.ContractId dvpCid = new Dvp.ContractId(fields$.get(0).getValue().asContractId().orElseThrow(() -> new IllegalArgumentException("Expected dvpCid to be of type com.daml.ledger.javaapi.data.ContractId")).getValue());
    LifecycleEffects.ContractId lifecycleEffectsCid = new LifecycleEffects.ContractId(fields$.get(1).getValue().asContractId().orElseThrow(() -> new IllegalArgumentException("Expected lifecycleEffectsCid to be of type com.daml.ledger.javaapi.data.ContractId")).getValue());
    String ctrl = fields$.get(2).getValue().asParty().orElseThrow(() -> new IllegalArgumentException("Expected ctrl to be of type com.daml.ledger.javaapi.data.Party")).getValue();
    return new com.daml.generated.da.finance.trade.dvp.lifecycle.DvpLifecycle_Process(dvpCid, lifecycleEffectsCid, ctrl);
  }

  public DamlRecord toValue() {
    ArrayList<DamlRecord.Field> fields = new ArrayList<DamlRecord.Field>(3);
    fields.add(new DamlRecord.Field("dvpCid", this.dvpCid.toValue()));
    fields.add(new DamlRecord.Field("lifecycleEffectsCid", this.lifecycleEffectsCid.toValue()));
    fields.add(new DamlRecord.Field("ctrl", new Party(this.ctrl)));
    return new DamlRecord(fields);
  }

  @Override
  public boolean equals(Object object) {
    if (this == object) {
      return true;
    }
    if (object == null) {
      return false;
    }
    if (!(object instanceof DvpLifecycle_Process)) {
      return false;
    }
    DvpLifecycle_Process other = (DvpLifecycle_Process) object;
    return this.dvpCid.equals(other.dvpCid) && this.lifecycleEffectsCid.equals(other.lifecycleEffectsCid) && this.ctrl.equals(other.ctrl);
  }

  @Override
  public int hashCode() {
    return Objects.hash(this.dvpCid, this.lifecycleEffectsCid, this.ctrl);
  }

  @Override
  public String toString() {
    return String.format("com.daml.generated.da.finance.trade.dvp.lifecycle.DvpLifecycle_Process(%s, %s, %s)", this.dvpCid, this.lifecycleEffectsCid, this.ctrl);
  }
}
