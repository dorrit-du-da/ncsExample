package com.daml.generated.marketplace.distribution.syndication.structurer;

import com.daml.generated.da.internal.template.Archive;
import com.daml.generated.da.types.Tuple2;
import com.daml.generated.marketplace.distribution.syndication.structuring.service.Request;
import com.daml.generated.marketplace.distribution.syndication.structuring.service.Service;
import com.daml.ledger.javaapi.data.CreateAndExerciseCommand;
import com.daml.ledger.javaapi.data.CreateCommand;
import com.daml.ledger.javaapi.data.CreatedEvent;
import com.daml.ledger.javaapi.data.DamlRecord;
import com.daml.ledger.javaapi.data.ExerciseByKeyCommand;
import com.daml.ledger.javaapi.data.ExerciseCommand;
import com.daml.ledger.javaapi.data.Identifier;
import com.daml.ledger.javaapi.data.Party;
import com.daml.ledger.javaapi.data.Template;
import com.daml.ledger.javaapi.data.Value;
import java.lang.Deprecated;
import java.lang.IllegalArgumentException;
import java.lang.Object;
import java.lang.Override;
import java.lang.String;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.Set;

public final class Role extends Template {
  public static final Identifier TEMPLATE_ID = new Identifier("636e6e778aedec0710919591e9cb2a9404d6daab0581e4ddc515eeae03256f45", "Marketplace.Distribution.Syndication.Structurer", "Role");

  public final String operator;

  public final String provider;

  public Role(String operator, String provider) {
    this.operator = operator;
    this.provider = provider;
  }

  public CreateCommand create() {
    return new CreateCommand(Role.TEMPLATE_ID, this.toValue());
  }

  public static ExerciseByKeyCommand exerciseByKeyTerminateStructuringService(
      Tuple2<String, String> key, TerminateStructuringService arg) {
    return new ExerciseByKeyCommand(Role.TEMPLATE_ID, key.toValue(v$0 -> new Party(v$0),v$1 -> new Party(v$1)), "TerminateStructuringService", arg.toValue());
  }

  public static ExerciseByKeyCommand exerciseByKeyTerminateStructuringService(
      Tuple2<String, String> key, Service.ContractId structuringServiceCid) {
    return Role.exerciseByKeyTerminateStructuringService(key, new TerminateStructuringService(structuringServiceCid));
  }

  public static ExerciseByKeyCommand exerciseByKeyTerminateRole(Tuple2<String, String> key,
      TerminateRole arg) {
    return new ExerciseByKeyCommand(Role.TEMPLATE_ID, key.toValue(v$0 -> new Party(v$0),v$1 -> new Party(v$1)), "TerminateRole", arg.toValue());
  }

  public static ExerciseByKeyCommand exerciseByKeyTerminateRole(Tuple2<String, String> key) {
    return Role.exerciseByKeyTerminateRole(key, new TerminateRole());
  }

  public static ExerciseByKeyCommand exerciseByKeyApproveStructuringRequest(
      Tuple2<String, String> key, ApproveStructuringRequest arg) {
    return new ExerciseByKeyCommand(Role.TEMPLATE_ID, key.toValue(v$0 -> new Party(v$0),v$1 -> new Party(v$1)), "ApproveStructuringRequest", arg.toValue());
  }

  public static ExerciseByKeyCommand exerciseByKeyApproveStructuringRequest(
      Tuple2<String, String> key, Request.ContractId structuringRequestCid) {
    return Role.exerciseByKeyApproveStructuringRequest(key, new ApproveStructuringRequest(structuringRequestCid));
  }

  public static ExerciseByKeyCommand exerciseByKeyOfferStructuringService(
      Tuple2<String, String> key, OfferStructuringService arg) {
    return new ExerciseByKeyCommand(Role.TEMPLATE_ID, key.toValue(v$0 -> new Party(v$0),v$1 -> new Party(v$1)), "OfferStructuringService", arg.toValue());
  }

  public static ExerciseByKeyCommand exerciseByKeyOfferStructuringService(
      Tuple2<String, String> key, String customer) {
    return Role.exerciseByKeyOfferStructuringService(key, new OfferStructuringService(customer));
  }

  public static ExerciseByKeyCommand exerciseByKeyArchive(Tuple2<String, String> key, Archive arg) {
    return new ExerciseByKeyCommand(Role.TEMPLATE_ID, key.toValue(v$0 -> new Party(v$0),v$1 -> new Party(v$1)), "Archive", arg.toValue());
  }

  public CreateAndExerciseCommand createAndExerciseTerminateStructuringService(
      TerminateStructuringService arg) {
    Value argValue = arg.toValue();
    return new CreateAndExerciseCommand(Role.TEMPLATE_ID, this.toValue(), "TerminateStructuringService", argValue);
  }

  public CreateAndExerciseCommand createAndExerciseTerminateStructuringService(
      Service.ContractId structuringServiceCid) {
    return createAndExerciseTerminateStructuringService(new TerminateStructuringService(structuringServiceCid));
  }

  public CreateAndExerciseCommand createAndExerciseTerminateRole(TerminateRole arg) {
    Value argValue = arg.toValue();
    return new CreateAndExerciseCommand(Role.TEMPLATE_ID, this.toValue(), "TerminateRole", argValue);
  }

  public CreateAndExerciseCommand createAndExerciseTerminateRole() {
    return createAndExerciseTerminateRole(new TerminateRole());
  }

  public CreateAndExerciseCommand createAndExerciseApproveStructuringRequest(
      ApproveStructuringRequest arg) {
    Value argValue = arg.toValue();
    return new CreateAndExerciseCommand(Role.TEMPLATE_ID, this.toValue(), "ApproveStructuringRequest", argValue);
  }

  public CreateAndExerciseCommand createAndExerciseApproveStructuringRequest(
      Request.ContractId structuringRequestCid) {
    return createAndExerciseApproveStructuringRequest(new ApproveStructuringRequest(structuringRequestCid));
  }

  public CreateAndExerciseCommand createAndExerciseOfferStructuringService(
      OfferStructuringService arg) {
    Value argValue = arg.toValue();
    return new CreateAndExerciseCommand(Role.TEMPLATE_ID, this.toValue(), "OfferStructuringService", argValue);
  }

  public CreateAndExerciseCommand createAndExerciseOfferStructuringService(String customer) {
    return createAndExerciseOfferStructuringService(new OfferStructuringService(customer));
  }

  public CreateAndExerciseCommand createAndExerciseArchive(Archive arg) {
    Value argValue = arg.toValue();
    return new CreateAndExerciseCommand(Role.TEMPLATE_ID, this.toValue(), "Archive", argValue);
  }

  public static CreateCommand create(String operator, String provider) {
    return new Role(operator, provider).create();
  }

  public static Role fromValue(Value value$) throws IllegalArgumentException {
    Value recordValue$ = value$;
    DamlRecord record$ = recordValue$.asRecord().orElseThrow(() -> new IllegalArgumentException("Contracts must be constructed from Records"));
    List<DamlRecord.Field> fields$ = record$.getFields();
    int numberOfFields = fields$.size();
    if (numberOfFields != 2) {
      throw new IllegalArgumentException("Expected 2 arguments, got " + numberOfFields);
    }
    String operator = fields$.get(0).getValue().asParty().orElseThrow(() -> new IllegalArgumentException("Expected operator to be of type com.daml.ledger.javaapi.data.Party")).getValue();
    String provider = fields$.get(1).getValue().asParty().orElseThrow(() -> new IllegalArgumentException("Expected provider to be of type com.daml.ledger.javaapi.data.Party")).getValue();
    return new com.daml.generated.marketplace.distribution.syndication.structurer.Role(operator, provider);
  }

  public DamlRecord toValue() {
    ArrayList<DamlRecord.Field> fields = new ArrayList<DamlRecord.Field>(2);
    fields.add(new DamlRecord.Field("operator", new Party(this.operator)));
    fields.add(new DamlRecord.Field("provider", new Party(this.provider)));
    return new DamlRecord(fields);
  }

  @Override
  public boolean equals(Object object) {
    if (this == object) {
      return true;
    }
    if (object == null) {
      return false;
    }
    if (!(object instanceof Role)) {
      return false;
    }
    Role other = (Role) object;
    return this.operator.equals(other.operator) && this.provider.equals(other.provider);
  }

  @Override
  public int hashCode() {
    return Objects.hash(this.operator, this.provider);
  }

  @Override
  public String toString() {
    return String.format("com.daml.generated.marketplace.distribution.syndication.structurer.Role(%s, %s)", this.operator, this.provider);
  }

  public static final class ContractId extends com.daml.ledger.javaapi.data.codegen.ContractId<Role> {
    public ContractId(String contractId) {
      super(contractId);
    }

    public ExerciseCommand exerciseTerminateStructuringService(TerminateStructuringService arg) {
      Value argValue = arg.toValue();
      return new ExerciseCommand(Role.TEMPLATE_ID, this.contractId, "TerminateStructuringService", argValue);
    }

    public ExerciseCommand exerciseTerminateStructuringService(
        Service.ContractId structuringServiceCid) {
      return exerciseTerminateStructuringService(new TerminateStructuringService(structuringServiceCid));
    }

    public ExerciseCommand exerciseTerminateRole(TerminateRole arg) {
      Value argValue = arg.toValue();
      return new ExerciseCommand(Role.TEMPLATE_ID, this.contractId, "TerminateRole", argValue);
    }

    public ExerciseCommand exerciseTerminateRole() {
      return exerciseTerminateRole(new TerminateRole());
    }

    public ExerciseCommand exerciseApproveStructuringRequest(ApproveStructuringRequest arg) {
      Value argValue = arg.toValue();
      return new ExerciseCommand(Role.TEMPLATE_ID, this.contractId, "ApproveStructuringRequest", argValue);
    }

    public ExerciseCommand exerciseApproveStructuringRequest(
        Request.ContractId structuringRequestCid) {
      return exerciseApproveStructuringRequest(new ApproveStructuringRequest(structuringRequestCid));
    }

    public ExerciseCommand exerciseOfferStructuringService(OfferStructuringService arg) {
      Value argValue = arg.toValue();
      return new ExerciseCommand(Role.TEMPLATE_ID, this.contractId, "OfferStructuringService", argValue);
    }

    public ExerciseCommand exerciseOfferStructuringService(String customer) {
      return exerciseOfferStructuringService(new OfferStructuringService(customer));
    }

    public ExerciseCommand exerciseArchive(Archive arg) {
      Value argValue = arg.toValue();
      return new ExerciseCommand(Role.TEMPLATE_ID, this.contractId, "Archive", argValue);
    }
  }

  public static class Contract implements com.daml.ledger.javaapi.data.Contract {
    public final ContractId id;

    public final Role data;

    public final Optional<String> agreementText;

    public final Optional<Tuple2<String, String>> key;

    public final Set<String> signatories;

    public final Set<String> observers;

    public Contract(ContractId id, Role data, Optional<String> agreementText,
        Optional<Tuple2<String, String>> key, Set<String> signatories, Set<String> observers) {
      this.id = id;
      this.data = data;
      this.agreementText = agreementText;
      this.key = key;
      this.signatories = signatories;
      this.observers = observers;
    }

    public static Contract fromIdAndRecord(String contractId, DamlRecord record$,
        Optional<String> agreementText, Optional<Tuple2<String, String>> key,
        Set<String> signatories, Set<String> observers) {
      ContractId id = new ContractId(contractId);
      Role data = Role.fromValue(record$);
      return new Contract(id, data, agreementText, key, signatories, observers);
    }

    @Deprecated
    public static Contract fromIdAndRecord(String contractId, DamlRecord record$) {
      ContractId id = new ContractId(contractId);
      Role data = Role.fromValue(record$);
      return new Contract(id, data, Optional.empty(), Optional.empty(), Collections.emptySet(), Collections.emptySet());
    }

    public static Contract fromCreatedEvent(CreatedEvent event) {
      return fromIdAndRecord(event.getContractId(), event.getArguments(), event.getAgreementText(), event.getContractKey().map(e -> Tuple2.<java.lang.String, java.lang.String>fromValue(e, v$0 -> v$0.asParty().orElseThrow(() -> new IllegalArgumentException("Expected e to be of type com.daml.ledger.javaapi.data.Party")).getValue(), v$1 -> v$1.asParty().orElseThrow(() -> new IllegalArgumentException("Expected e to be of type com.daml.ledger.javaapi.data.Party")).getValue())), event.getSignatories(), event.getObservers());
    }

    @Override
    public boolean equals(Object object) {
      if (this == object) {
        return true;
      }
      if (object == null) {
        return false;
      }
      if (!(object instanceof Contract)) {
        return false;
      }
      Contract other = (Contract) object;
      return this.id.equals(other.id) && this.data.equals(other.data) && this.agreementText.equals(other.agreementText) && this.key.equals(other.key) && this.signatories.equals(other.signatories) && this.observers.equals(other.observers);
    }

    @Override
    public int hashCode() {
      return Objects.hash(this.id, this.data, this.agreementText, this.key, this.signatories, this.observers);
    }

    @Override
    public String toString() {
      return String.format("com.daml.generated.marketplace.distribution.syndication.structurer.Role.Contract(%s, %s, %s, %s, %s, %s)", this.id, this.data, this.agreementText, this.key, this.signatories, this.observers);
    }
  }
}
