package com.daml.generated.marketplace.clearing.service;

import com.daml.generated.da.finance.asset.AssetDeposit;
import com.daml.generated.marketplace.clearing.model.MarkToMarketCalculation;
import com.daml.ledger.javaapi.data.DamlCollectors;
import com.daml.ledger.javaapi.data.DamlRecord;
import com.daml.ledger.javaapi.data.Value;
import java.lang.IllegalArgumentException;
import java.lang.Object;
import java.lang.Override;
import java.lang.String;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

public class PerformMarkToMarket {
  public static final String _packageId = "636e6e778aedec0710919591e9cb2a9404d6daab0581e4ddc515eeae03256f45";

  public final List<AssetDeposit.ContractId> providerDepositCids;

  public final List<AssetDeposit.ContractId> customerDepositCids;

  public final MarkToMarketCalculation.ContractId calculationCid;

  public PerformMarkToMarket(List<AssetDeposit.ContractId> providerDepositCids,
      List<AssetDeposit.ContractId> customerDepositCids,
      MarkToMarketCalculation.ContractId calculationCid) {
    this.providerDepositCids = providerDepositCids;
    this.customerDepositCids = customerDepositCids;
    this.calculationCid = calculationCid;
  }

  public static PerformMarkToMarket fromValue(Value value$) throws IllegalArgumentException {
    Value recordValue$ = value$;
    DamlRecord record$ = recordValue$.asRecord().orElseThrow(() -> new IllegalArgumentException("Contracts must be constructed from Records"));
    List<DamlRecord.Field> fields$ = record$.getFields();
    int numberOfFields = fields$.size();
    if (numberOfFields != 3) {
      throw new IllegalArgumentException("Expected 3 arguments, got " + numberOfFields);
    }
    List<AssetDeposit.ContractId> providerDepositCids = fields$.get(0).getValue().asList()
            .map(v$0 -> v$0.toList(v$1 ->
                new AssetDeposit.ContractId(v$1.asContractId().orElseThrow(() -> new IllegalArgumentException("Expected v$1 to be of type com.daml.ledger.javaapi.data.ContractId")).getValue())
            ))
            .orElseThrow(() -> new IllegalArgumentException("Expected providerDepositCids to be of type com.daml.ledger.javaapi.data.DamlList"))
        ;
    List<AssetDeposit.ContractId> customerDepositCids = fields$.get(1).getValue().asList()
            .map(v$0 -> v$0.toList(v$1 ->
                new AssetDeposit.ContractId(v$1.asContractId().orElseThrow(() -> new IllegalArgumentException("Expected v$1 to be of type com.daml.ledger.javaapi.data.ContractId")).getValue())
            ))
            .orElseThrow(() -> new IllegalArgumentException("Expected customerDepositCids to be of type com.daml.ledger.javaapi.data.DamlList"))
        ;
    MarkToMarketCalculation.ContractId calculationCid = new MarkToMarketCalculation.ContractId(fields$.get(2).getValue().asContractId().orElseThrow(() -> new IllegalArgumentException("Expected calculationCid to be of type com.daml.ledger.javaapi.data.ContractId")).getValue());
    return new com.daml.generated.marketplace.clearing.service.PerformMarkToMarket(providerDepositCids, customerDepositCids, calculationCid);
  }

  public DamlRecord toValue() {
    ArrayList<DamlRecord.Field> fields = new ArrayList<DamlRecord.Field>(3);
    fields.add(new DamlRecord.Field("providerDepositCids", this.providerDepositCids.stream().collect(DamlCollectors.toDamlList(v$0 -> v$0.toValue()))));
    fields.add(new DamlRecord.Field("customerDepositCids", this.customerDepositCids.stream().collect(DamlCollectors.toDamlList(v$0 -> v$0.toValue()))));
    fields.add(new DamlRecord.Field("calculationCid", this.calculationCid.toValue()));
    return new DamlRecord(fields);
  }

  @Override
  public boolean equals(Object object) {
    if (this == object) {
      return true;
    }
    if (object == null) {
      return false;
    }
    if (!(object instanceof PerformMarkToMarket)) {
      return false;
    }
    PerformMarkToMarket other = (PerformMarkToMarket) object;
    return this.providerDepositCids.equals(other.providerDepositCids) && this.customerDepositCids.equals(other.customerDepositCids) && this.calculationCid.equals(other.calculationCid);
  }

  @Override
  public int hashCode() {
    return Objects.hash(this.providerDepositCids, this.customerDepositCids, this.calculationCid);
  }

  @Override
  public String toString() {
    return String.format("com.daml.generated.marketplace.clearing.service.PerformMarkToMarket(%s, %s, %s)", this.providerDepositCids, this.customerDepositCids, this.calculationCid);
  }
}
