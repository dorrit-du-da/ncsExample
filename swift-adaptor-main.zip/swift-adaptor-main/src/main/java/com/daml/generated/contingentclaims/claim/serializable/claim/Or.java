package com.daml.generated.contingentclaims.claim.serializable.claim;

import com.daml.generated.contingentclaims.claim.serializable.Claim;
import com.daml.ledger.javaapi.data.DamlRecord;
import com.daml.ledger.javaapi.data.Value;
import com.daml.ledger.javaapi.data.Variant;
import java.lang.IllegalArgumentException;
import java.lang.Object;
import java.lang.Override;
import java.lang.String;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.function.Function;

public class Or<t, x, a> extends Claim<t, x, a> {
  public static final String _packageId = "636e6e778aedec0710919591e9cb2a9404d6daab0581e4ddc515eeae03256f45";

  public final Claim<t, x, a> lhs;

  public final Claim<t, x, a> rhs;

  public Or(Claim<t, x, a> lhs, Claim<t, x, a> rhs) {
    this.lhs = lhs;
    this.rhs = rhs;
  }

  public Variant toValue(Function<t, Value> toValuet, Function<x, Value> toValuex,
      Function<a, Value> toValuea) {
    ArrayList<DamlRecord.Field> fields = new ArrayList<DamlRecord.Field>(2);
    fields.add(new DamlRecord.Field("lhs", this.lhs.toValue(v$0 -> toValuet.apply(v$0),v$1 -> toValuex.apply(v$1),v$2 -> toValuea.apply(v$2))));
    fields.add(new DamlRecord.Field("rhs", this.rhs.toValue(v$0 -> toValuet.apply(v$0),v$1 -> toValuex.apply(v$1),v$2 -> toValuea.apply(v$2))));
    return new Variant("Or", new DamlRecord(fields));
  }

  public static <t, x, a> Or<t, x, a> fromValue(Value value$, Function<Value, t> fromValuet,
      Function<Value, x> fromValuex, Function<Value, a> fromValuea) throws
      IllegalArgumentException {
    Variant variant$ = value$.asVariant().orElseThrow(() -> new IllegalArgumentException("Expected: Variant. Actual: " + value$.getClass().getName()));
    if (!"Or".equals(variant$.getConstructor())) throw new IllegalArgumentException("Invalid constructor. Expected: Or. Actual: " + variant$.getConstructor());
    Value recordValue$ = variant$.getValue();
    DamlRecord record$ = recordValue$.asRecord().orElseThrow(() -> new IllegalArgumentException("Contracts must be constructed from Records"));
    List<DamlRecord.Field> fields$ = record$.getFields();
    int numberOfFields = fields$.size();
    if (numberOfFields != 2) {
      throw new IllegalArgumentException("Expected 2 arguments, got " + numberOfFields);
    }
    Claim<t, x, a> lhs = Claim.<t, x, a>fromValue(fields$.get(0).getValue(), v$0 -> fromValuet.apply(v$0), v$1 -> fromValuex.apply(v$1), v$2 -> fromValuea.apply(v$2));
    Claim<t, x, a> rhs = Claim.<t, x, a>fromValue(fields$.get(1).getValue(), v$0 -> fromValuet.apply(v$0), v$1 -> fromValuex.apply(v$1), v$2 -> fromValuea.apply(v$2));
    return new Or<t, x, a>(lhs, rhs);
  }

  @Override
  public boolean equals(Object object) {
    if (this == object) {
      return true;
    }
    if (object == null) {
      return false;
    }
    if (!(object instanceof Or<?, ?, ?>)) {
      return false;
    }
    Or<?, ?, ?> other = (Or<?, ?, ?>) object;
    return this.lhs.equals(other.lhs) && this.rhs.equals(other.rhs);
  }

  @Override
  public int hashCode() {
    return Objects.hash(this.lhs, this.rhs);
  }

  @Override
  public String toString() {
    return String.format("Or(%s, %s)", this.lhs, this.rhs);
  }
}
