package com.daml.generated.contingentclaims.claim.serializable.claimf;

import com.daml.generated.contingentclaims.claim.serializable.ClaimF;
import com.daml.generated.contingentclaims.claim.serializable.Inequality;
import com.daml.ledger.javaapi.data.DamlRecord;
import com.daml.ledger.javaapi.data.Value;
import com.daml.ledger.javaapi.data.Variant;
import java.lang.IllegalArgumentException;
import java.lang.Object;
import java.lang.Override;
import java.lang.String;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.function.Function;

public class WhenF<t, x, a, b> extends ClaimF<t, x, a, b> {
  public static final String _packageId = "636e6e778aedec0710919591e9cb2a9404d6daab0581e4ddc515eeae03256f45";

  public final Inequality<t, x> predicate;

  public final b claim;

  public WhenF(Inequality<t, x> predicate, b claim) {
    this.predicate = predicate;
    this.claim = claim;
  }

  public Variant toValue(Function<t, Value> toValuet, Function<x, Value> toValuex,
      Function<b, Value> toValueb) {
    ArrayList<DamlRecord.Field> fields = new ArrayList<DamlRecord.Field>(2);
    fields.add(new DamlRecord.Field("predicate", this.predicate.toValue(v$0 -> toValuet.apply(v$0),v$1 -> toValuex.apply(v$1))));
    fields.add(new DamlRecord.Field("claim", toValueb.apply(this.claim)));
    return new Variant("WhenF", new DamlRecord(fields));
  }

  public static <t, x, a, b> WhenF<t, x, a, b> fromValue(Value value$,
      Function<Value, t> fromValuet, Function<Value, x> fromValuex, Function<Value, b> fromValueb)
      throws IllegalArgumentException {
    Variant variant$ = value$.asVariant().orElseThrow(() -> new IllegalArgumentException("Expected: Variant. Actual: " + value$.getClass().getName()));
    if (!"WhenF".equals(variant$.getConstructor())) throw new IllegalArgumentException("Invalid constructor. Expected: WhenF. Actual: " + variant$.getConstructor());
    Value recordValue$ = variant$.getValue();
    DamlRecord record$ = recordValue$.asRecord().orElseThrow(() -> new IllegalArgumentException("Contracts must be constructed from Records"));
    List<DamlRecord.Field> fields$ = record$.getFields();
    int numberOfFields = fields$.size();
    if (numberOfFields != 2) {
      throw new IllegalArgumentException("Expected 2 arguments, got " + numberOfFields);
    }
    Inequality<t, x> predicate = Inequality.<t, x>fromValue(fields$.get(0).getValue(), v$0 -> fromValuet.apply(v$0), v$1 -> fromValuex.apply(v$1));
    b claim = fromValueb.apply(fields$.get(1).getValue());
    return new WhenF<t, x, a, b>(predicate, claim);
  }

  public Variant toValue(Function<t, Value> toValuet, Function<x, Value> toValuex,
      Function<a, Value> toValuea, Function<b, Value> toValueb) {
    ArrayList<DamlRecord.Field> fields = new ArrayList<DamlRecord.Field>(2);
    fields.add(new DamlRecord.Field("predicate", this.predicate.toValue(v$0 -> toValuet.apply(v$0),v$1 -> toValuex.apply(v$1))));
    fields.add(new DamlRecord.Field("claim", toValueb.apply(this.claim)));
    return new Variant("WhenF", new DamlRecord(fields));
  }

  public static <t, x, a, b> WhenF<t, x, a, b> fromValue(Value value$,
      Function<Value, t> fromValuet, Function<Value, x> fromValuex, Function<Value, a> fromValuea,
      Function<Value, b> fromValueb) throws IllegalArgumentException {
    Variant variant$ = value$.asVariant().orElseThrow(() -> new IllegalArgumentException("Expected: Variant. Actual: " + value$.getClass().getName()));
    if (!"WhenF".equals(variant$.getConstructor())) throw new IllegalArgumentException("Invalid constructor. Expected: WhenF. Actual: " + variant$.getConstructor());
    Value recordValue$ = variant$.getValue();
    DamlRecord record$ = recordValue$.asRecord().orElseThrow(() -> new IllegalArgumentException("Contracts must be constructed from Records"));
    List<DamlRecord.Field> fields$ = record$.getFields();
    int numberOfFields = fields$.size();
    if (numberOfFields != 2) {
      throw new IllegalArgumentException("Expected 2 arguments, got " + numberOfFields);
    }
    Inequality<t, x> predicate = Inequality.<t, x>fromValue(fields$.get(0).getValue(), v$0 -> fromValuet.apply(v$0), v$1 -> fromValuex.apply(v$1));
    b claim = fromValueb.apply(fields$.get(1).getValue());
    return new WhenF<t, x, a, b>(predicate, claim);
  }

  @Override
  public boolean equals(Object object) {
    if (this == object) {
      return true;
    }
    if (object == null) {
      return false;
    }
    if (!(object instanceof WhenF<?, ?, ?, ?>)) {
      return false;
    }
    WhenF<?, ?, ?, ?> other = (WhenF<?, ?, ?, ?>) object;
    return this.predicate.equals(other.predicate) && this.claim.equals(other.claim);
  }

  @Override
  public int hashCode() {
    return Objects.hash(this.predicate, this.claim);
  }

  @Override
  public String toString() {
    return String.format("WhenF(%s, %s)", this.predicate, this.claim);
  }
}
