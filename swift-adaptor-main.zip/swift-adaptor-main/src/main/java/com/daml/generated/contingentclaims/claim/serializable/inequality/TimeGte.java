package com.daml.generated.contingentclaims.claim.serializable.inequality;

import com.daml.generated.contingentclaims.claim.serializable.Inequality;
import com.daml.ledger.javaapi.data.Value;
import com.daml.ledger.javaapi.data.Variant;
import java.lang.IllegalArgumentException;
import java.lang.Object;
import java.lang.Override;
import java.lang.String;
import java.util.Objects;
import java.util.function.Function;

public class TimeGte<t, x> extends Inequality<t, x> {
  public static final String _packageId = "636e6e778aedec0710919591e9cb2a9404d6daab0581e4ddc515eeae03256f45";

  public final t tValue;

  public TimeGte(t tValue) {
    this.tValue = tValue;
  }

  public Variant toValue(Function<t, Value> toValuet) {
    return new Variant("TimeGte", toValuet.apply(this.tValue));
  }

  public static <t, x> TimeGte<t, x> fromValue(Value value$, Function<Value, t> fromValuet) throws
      IllegalArgumentException {
    Variant variant$ = value$.asVariant().orElseThrow(() -> new IllegalArgumentException("Expected: Variant. Actual: " + value$.getClass().getName()));
    if (!"TimeGte".equals(variant$.getConstructor())) throw new IllegalArgumentException("Invalid constructor. Expected: TimeGte. Actual: " + variant$.getConstructor());
    Value variantValue$ = variant$.getValue();
    t body = fromValuet.apply(variantValue$);
    return new TimeGte<t, x>(body);
  }

  public Variant toValue(Function<t, Value> toValuet, Function<x, Value> toValuex) {
    return new Variant("TimeGte", toValuet.apply(this.tValue));
  }

  public static <t, x> TimeGte<t, x> fromValue(Value value$, Function<Value, t> fromValuet,
      Function<Value, x> fromValuex) throws IllegalArgumentException {
    Variant variant$ = value$.asVariant().orElseThrow(() -> new IllegalArgumentException("Expected: Variant. Actual: " + value$.getClass().getName()));
    if (!"TimeGte".equals(variant$.getConstructor())) throw new IllegalArgumentException("Invalid constructor. Expected: TimeGte. Actual: " + variant$.getConstructor());
    Value variantValue$ = variant$.getValue();
    t body = fromValuet.apply(variantValue$);
    return new TimeGte<t, x>(body);
  }

  @Override
  public boolean equals(Object object) {
    if (this == object) {
      return true;
    }
    if (object == null) {
      return false;
    }
    if (!(object instanceof TimeGte<?, ?>)) {
      return false;
    }
    TimeGte<?, ?> other = (TimeGte<?, ?>) object;
    return this.tValue.equals(other.tValue);
  }

  @Override
  public int hashCode() {
    return Objects.hash(this.tValue);
  }

  @Override
  public String toString() {
    return String.format("TimeGte(%s)", this.tValue);
  }
}
