package com.daml.generated.contingentclaims.claim.serializable.claim;

import com.daml.generated.contingentclaims.claim.serializable.Claim;
import com.daml.generated.contingentclaims.claim.serializable.Inequality;
import com.daml.ledger.javaapi.data.DamlRecord;
import com.daml.ledger.javaapi.data.Value;
import com.daml.ledger.javaapi.data.Variant;
import java.lang.IllegalArgumentException;
import java.lang.Object;
import java.lang.Override;
import java.lang.String;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.function.Function;

public class Cond<t, x, a> extends Claim<t, x, a> {
  public static final String _packageId = "636e6e778aedec0710919591e9cb2a9404d6daab0581e4ddc515eeae03256f45";

  public final Inequality<t, x> predicate;

  public final Claim<t, x, a> success;

  public final Claim<t, x, a> failure;

  public Cond(Inequality<t, x> predicate, Claim<t, x, a> success, Claim<t, x, a> failure) {
    this.predicate = predicate;
    this.success = success;
    this.failure = failure;
  }

  public Variant toValue(Function<t, Value> toValuet, Function<x, Value> toValuex,
      Function<a, Value> toValuea) {
    ArrayList<DamlRecord.Field> fields = new ArrayList<DamlRecord.Field>(3);
    fields.add(new DamlRecord.Field("predicate", this.predicate.toValue(v$0 -> toValuet.apply(v$0),v$1 -> toValuex.apply(v$1))));
    fields.add(new DamlRecord.Field("success", this.success.toValue(v$0 -> toValuet.apply(v$0),v$1 -> toValuex.apply(v$1),v$2 -> toValuea.apply(v$2))));
    fields.add(new DamlRecord.Field("failure", this.failure.toValue(v$0 -> toValuet.apply(v$0),v$1 -> toValuex.apply(v$1),v$2 -> toValuea.apply(v$2))));
    return new Variant("Cond", new DamlRecord(fields));
  }

  public static <t, x, a> Cond<t, x, a> fromValue(Value value$, Function<Value, t> fromValuet,
      Function<Value, x> fromValuex, Function<Value, a> fromValuea) throws
      IllegalArgumentException {
    Variant variant$ = value$.asVariant().orElseThrow(() -> new IllegalArgumentException("Expected: Variant. Actual: " + value$.getClass().getName()));
    if (!"Cond".equals(variant$.getConstructor())) throw new IllegalArgumentException("Invalid constructor. Expected: Cond. Actual: " + variant$.getConstructor());
    Value recordValue$ = variant$.getValue();
    DamlRecord record$ = recordValue$.asRecord().orElseThrow(() -> new IllegalArgumentException("Contracts must be constructed from Records"));
    List<DamlRecord.Field> fields$ = record$.getFields();
    int numberOfFields = fields$.size();
    if (numberOfFields != 3) {
      throw new IllegalArgumentException("Expected 3 arguments, got " + numberOfFields);
    }
    Inequality<t, x> predicate = Inequality.<t, x>fromValue(fields$.get(0).getValue(), v$0 -> fromValuet.apply(v$0), v$1 -> fromValuex.apply(v$1));
    Claim<t, x, a> success = Claim.<t, x, a>fromValue(fields$.get(1).getValue(), v$0 -> fromValuet.apply(v$0), v$1 -> fromValuex.apply(v$1), v$2 -> fromValuea.apply(v$2));
    Claim<t, x, a> failure = Claim.<t, x, a>fromValue(fields$.get(2).getValue(), v$0 -> fromValuet.apply(v$0), v$1 -> fromValuex.apply(v$1), v$2 -> fromValuea.apply(v$2));
    return new Cond<t, x, a>(predicate, success, failure);
  }

  @Override
  public boolean equals(Object object) {
    if (this == object) {
      return true;
    }
    if (object == null) {
      return false;
    }
    if (!(object instanceof Cond<?, ?, ?>)) {
      return false;
    }
    Cond<?, ?, ?> other = (Cond<?, ?, ?>) object;
    return this.predicate.equals(other.predicate) && this.success.equals(other.success) && this.failure.equals(other.failure);
  }

  @Override
  public int hashCode() {
    return Objects.hash(this.predicate, this.success, this.failure);
  }

  @Override
  public String toString() {
    return String.format("Cond(%s, %s, %s)", this.predicate, this.success, this.failure);
  }
}
