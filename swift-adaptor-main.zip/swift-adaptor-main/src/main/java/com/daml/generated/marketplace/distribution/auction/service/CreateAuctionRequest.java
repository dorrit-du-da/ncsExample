package com.daml.generated.marketplace.distribution.auction.service;

import com.daml.generated.da.finance.asset.AssetDeposit;
import com.daml.generated.da.finance.types.Account;
import com.daml.generated.da.finance.types.Asset;
import com.daml.generated.da.finance.types.Id;
import com.daml.generated.da.internal.template.Archive;
import com.daml.ledger.javaapi.data.CreateAndExerciseCommand;
import com.daml.ledger.javaapi.data.CreateCommand;
import com.daml.ledger.javaapi.data.CreatedEvent;
import com.daml.ledger.javaapi.data.DamlRecord;
import com.daml.ledger.javaapi.data.ExerciseCommand;
import com.daml.ledger.javaapi.data.Identifier;
import com.daml.ledger.javaapi.data.Numeric;
import com.daml.ledger.javaapi.data.Party;
import com.daml.ledger.javaapi.data.Template;
import com.daml.ledger.javaapi.data.Text;
import com.daml.ledger.javaapi.data.Value;
import java.lang.Deprecated;
import java.lang.IllegalArgumentException;
import java.lang.Object;
import java.lang.Override;
import java.lang.String;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.Set;

public final class CreateAuctionRequest extends Template {
  public static final Identifier TEMPLATE_ID = new Identifier("636e6e778aedec0710919591e9cb2a9404d6daab0581e4ddc515eeae03256f45", "Marketplace.Distribution.Auction.Service", "CreateAuctionRequest");

  public final String operator;

  public final String provider;

  public final String customer;

  public final String auctionId;

  public final Asset asset;

  public final Id quotedAssetId;

  public final BigDecimal floorPrice;

  public final AssetDeposit.ContractId depositCid;

  public final Account receivableAccount;

  public CreateAuctionRequest(String operator, String provider, String customer, String auctionId,
      Asset asset, Id quotedAssetId, BigDecimal floorPrice, AssetDeposit.ContractId depositCid,
      Account receivableAccount) {
    this.operator = operator;
    this.provider = provider;
    this.customer = customer;
    this.auctionId = auctionId;
    this.asset = asset;
    this.quotedAssetId = quotedAssetId;
    this.floorPrice = floorPrice;
    this.depositCid = depositCid;
    this.receivableAccount = receivableAccount;
  }

  public CreateCommand create() {
    return new CreateCommand(CreateAuctionRequest.TEMPLATE_ID, this.toValue());
  }

  public CreateAndExerciseCommand createAndExerciseArchive(Archive arg) {
    Value argValue = arg.toValue();
    return new CreateAndExerciseCommand(CreateAuctionRequest.TEMPLATE_ID, this.toValue(), "Archive", argValue);
  }

  public static CreateCommand create(String operator, String provider, String customer,
      String auctionId, Asset asset, Id quotedAssetId, BigDecimal floorPrice,
      AssetDeposit.ContractId depositCid, Account receivableAccount) {
    return new CreateAuctionRequest(operator, provider, customer, auctionId, asset, quotedAssetId, floorPrice, depositCid, receivableAccount).create();
  }

  public static CreateAuctionRequest fromValue(Value value$) throws IllegalArgumentException {
    Value recordValue$ = value$;
    DamlRecord record$ = recordValue$.asRecord().orElseThrow(() -> new IllegalArgumentException("Contracts must be constructed from Records"));
    List<DamlRecord.Field> fields$ = record$.getFields();
    int numberOfFields = fields$.size();
    if (numberOfFields != 9) {
      throw new IllegalArgumentException("Expected 9 arguments, got " + numberOfFields);
    }
    String operator = fields$.get(0).getValue().asParty().orElseThrow(() -> new IllegalArgumentException("Expected operator to be of type com.daml.ledger.javaapi.data.Party")).getValue();
    String provider = fields$.get(1).getValue().asParty().orElseThrow(() -> new IllegalArgumentException("Expected provider to be of type com.daml.ledger.javaapi.data.Party")).getValue();
    String customer = fields$.get(2).getValue().asParty().orElseThrow(() -> new IllegalArgumentException("Expected customer to be of type com.daml.ledger.javaapi.data.Party")).getValue();
    String auctionId = fields$.get(3).getValue().asText().orElseThrow(() -> new IllegalArgumentException("Expected auctionId to be of type com.daml.ledger.javaapi.data.Text")).getValue();
    Asset asset = Asset.fromValue(fields$.get(4).getValue());
    Id quotedAssetId = Id.fromValue(fields$.get(5).getValue());
    BigDecimal floorPrice = fields$.get(6).getValue().asNumeric().orElseThrow(() -> new IllegalArgumentException("Expected floorPrice to be of type com.daml.ledger.javaapi.data.Numeric")).getValue();
    AssetDeposit.ContractId depositCid = new AssetDeposit.ContractId(fields$.get(7).getValue().asContractId().orElseThrow(() -> new IllegalArgumentException("Expected depositCid to be of type com.daml.ledger.javaapi.data.ContractId")).getValue());
    Account receivableAccount = Account.fromValue(fields$.get(8).getValue());
    return new com.daml.generated.marketplace.distribution.auction.service.CreateAuctionRequest(operator, provider, customer, auctionId, asset, quotedAssetId, floorPrice, depositCid, receivableAccount);
  }

  public DamlRecord toValue() {
    ArrayList<DamlRecord.Field> fields = new ArrayList<DamlRecord.Field>(9);
    fields.add(new DamlRecord.Field("operator", new Party(this.operator)));
    fields.add(new DamlRecord.Field("provider", new Party(this.provider)));
    fields.add(new DamlRecord.Field("customer", new Party(this.customer)));
    fields.add(new DamlRecord.Field("auctionId", new Text(this.auctionId)));
    fields.add(new DamlRecord.Field("asset", this.asset.toValue()));
    fields.add(new DamlRecord.Field("quotedAssetId", this.quotedAssetId.toValue()));
    fields.add(new DamlRecord.Field("floorPrice", new Numeric(this.floorPrice)));
    fields.add(new DamlRecord.Field("depositCid", this.depositCid.toValue()));
    fields.add(new DamlRecord.Field("receivableAccount", this.receivableAccount.toValue()));
    return new DamlRecord(fields);
  }

  @Override
  public boolean equals(Object object) {
    if (this == object) {
      return true;
    }
    if (object == null) {
      return false;
    }
    if (!(object instanceof CreateAuctionRequest)) {
      return false;
    }
    CreateAuctionRequest other = (CreateAuctionRequest) object;
    return this.operator.equals(other.operator) && this.provider.equals(other.provider) && this.customer.equals(other.customer) && this.auctionId.equals(other.auctionId) && this.asset.equals(other.asset) && this.quotedAssetId.equals(other.quotedAssetId) && this.floorPrice.equals(other.floorPrice) && this.depositCid.equals(other.depositCid) && this.receivableAccount.equals(other.receivableAccount);
  }

  @Override
  public int hashCode() {
    return Objects.hash(this.operator, this.provider, this.customer, this.auctionId, this.asset, this.quotedAssetId, this.floorPrice, this.depositCid, this.receivableAccount);
  }

  @Override
  public String toString() {
    return String.format("com.daml.generated.marketplace.distribution.auction.service.CreateAuctionRequest(%s, %s, %s, %s, %s, %s, %s, %s, %s)", this.operator, this.provider, this.customer, this.auctionId, this.asset, this.quotedAssetId, this.floorPrice, this.depositCid, this.receivableAccount);
  }

  public static final class ContractId extends com.daml.ledger.javaapi.data.codegen.ContractId<CreateAuctionRequest> {
    public ContractId(String contractId) {
      super(contractId);
    }

    public ExerciseCommand exerciseArchive(Archive arg) {
      Value argValue = arg.toValue();
      return new ExerciseCommand(CreateAuctionRequest.TEMPLATE_ID, this.contractId, "Archive", argValue);
    }
  }

  public static class Contract implements com.daml.ledger.javaapi.data.Contract {
    public final ContractId id;

    public final CreateAuctionRequest data;

    public final Optional<String> agreementText;

    public final Set<String> signatories;

    public final Set<String> observers;

    public Contract(ContractId id, CreateAuctionRequest data, Optional<String> agreementText,
        Set<String> signatories, Set<String> observers) {
      this.id = id;
      this.data = data;
      this.agreementText = agreementText;
      this.signatories = signatories;
      this.observers = observers;
    }

    public static Contract fromIdAndRecord(String contractId, DamlRecord record$,
        Optional<String> agreementText, Set<String> signatories, Set<String> observers) {
      ContractId id = new ContractId(contractId);
      CreateAuctionRequest data = CreateAuctionRequest.fromValue(record$);
      return new Contract(id, data, agreementText, signatories, observers);
    }

    @Deprecated
    public static Contract fromIdAndRecord(String contractId, DamlRecord record$) {
      ContractId id = new ContractId(contractId);
      CreateAuctionRequest data = CreateAuctionRequest.fromValue(record$);
      return new Contract(id, data, Optional.empty(), Collections.emptySet(), Collections.emptySet());
    }

    public static Contract fromCreatedEvent(CreatedEvent event) {
      return fromIdAndRecord(event.getContractId(), event.getArguments(), event.getAgreementText(), event.getSignatories(), event.getObservers());
    }

    @Override
    public boolean equals(Object object) {
      if (this == object) {
        return true;
      }
      if (object == null) {
        return false;
      }
      if (!(object instanceof Contract)) {
        return false;
      }
      Contract other = (Contract) object;
      return this.id.equals(other.id) && this.data.equals(other.data) && this.agreementText.equals(other.agreementText) && this.signatories.equals(other.signatories) && this.observers.equals(other.observers);
    }

    @Override
    public int hashCode() {
      return Objects.hash(this.id, this.data, this.agreementText, this.signatories, this.observers);
    }

    @Override
    public String toString() {
      return String.format("com.daml.generated.marketplace.distribution.auction.service.CreateAuctionRequest.Contract(%s, %s, %s, %s, %s)", this.id, this.data, this.agreementText, this.signatories, this.observers);
    }
  }
}
