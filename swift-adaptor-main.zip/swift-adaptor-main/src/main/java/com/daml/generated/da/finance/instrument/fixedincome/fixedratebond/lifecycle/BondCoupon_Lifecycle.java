package com.daml.generated.da.finance.instrument.fixedincome.fixedratebond.lifecycle;

import com.daml.generated.da.finance.instrument.fixedincome.fixedratebond.FixedRateBond;
import com.daml.ledger.javaapi.data.DamlRecord;
import com.daml.ledger.javaapi.data.Value;
import java.lang.IllegalArgumentException;
import java.lang.Object;
import java.lang.Override;
import java.lang.String;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

public class BondCoupon_Lifecycle {
  public static final String _packageId = "636e6e778aedec0710919591e9cb2a9404d6daab0581e4ddc515eeae03256f45";

  public final FixedRateBond.ContractId bondCid;

  public BondCoupon_Lifecycle(FixedRateBond.ContractId bondCid) {
    this.bondCid = bondCid;
  }

  public static BondCoupon_Lifecycle fromValue(Value value$) throws IllegalArgumentException {
    Value recordValue$ = value$;
    DamlRecord record$ = recordValue$.asRecord().orElseThrow(() -> new IllegalArgumentException("Contracts must be constructed from Records"));
    List<DamlRecord.Field> fields$ = record$.getFields();
    int numberOfFields = fields$.size();
    if (numberOfFields != 1) {
      throw new IllegalArgumentException("Expected 1 arguments, got " + numberOfFields);
    }
    FixedRateBond.ContractId bondCid = new FixedRateBond.ContractId(fields$.get(0).getValue().asContractId().orElseThrow(() -> new IllegalArgumentException("Expected bondCid to be of type com.daml.ledger.javaapi.data.ContractId")).getValue());
    return new com.daml.generated.da.finance.instrument.fixedincome.fixedratebond.lifecycle.BondCoupon_Lifecycle(bondCid);
  }

  public DamlRecord toValue() {
    ArrayList<DamlRecord.Field> fields = new ArrayList<DamlRecord.Field>(1);
    fields.add(new DamlRecord.Field("bondCid", this.bondCid.toValue()));
    return new DamlRecord(fields);
  }

  @Override
  public boolean equals(Object object) {
    if (this == object) {
      return true;
    }
    if (object == null) {
      return false;
    }
    if (!(object instanceof BondCoupon_Lifecycle)) {
      return false;
    }
    BondCoupon_Lifecycle other = (BondCoupon_Lifecycle) object;
    return this.bondCid.equals(other.bondCid);
  }

  @Override
  public int hashCode() {
    return Objects.hash(this.bondCid);
  }

  @Override
  public String toString() {
    return String.format("com.daml.generated.da.finance.instrument.fixedincome.fixedratebond.lifecycle.BondCoupon_Lifecycle(%s)", this.bondCid);
  }
}
