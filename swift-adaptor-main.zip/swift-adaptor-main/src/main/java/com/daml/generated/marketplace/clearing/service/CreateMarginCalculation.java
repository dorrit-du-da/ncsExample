package com.daml.generated.marketplace.clearing.service;

import com.daml.generated.da.finance.types.Id;
import com.daml.ledger.javaapi.data.DamlRecord;
import com.daml.ledger.javaapi.data.Numeric;
import com.daml.ledger.javaapi.data.Text;
import com.daml.ledger.javaapi.data.Value;
import java.lang.IllegalArgumentException;
import java.lang.Object;
import java.lang.Override;
import java.lang.String;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

public class CreateMarginCalculation {
  public static final String _packageId = "636e6e778aedec0710919591e9cb2a9404d6daab0581e4ddc515eeae03256f45";

  public final BigDecimal targetAmount;

  public final Id currency;

  public final String calculationId;

  public CreateMarginCalculation(BigDecimal targetAmount, Id currency, String calculationId) {
    this.targetAmount = targetAmount;
    this.currency = currency;
    this.calculationId = calculationId;
  }

  public static CreateMarginCalculation fromValue(Value value$) throws IllegalArgumentException {
    Value recordValue$ = value$;
    DamlRecord record$ = recordValue$.asRecord().orElseThrow(() -> new IllegalArgumentException("Contracts must be constructed from Records"));
    List<DamlRecord.Field> fields$ = record$.getFields();
    int numberOfFields = fields$.size();
    if (numberOfFields != 3) {
      throw new IllegalArgumentException("Expected 3 arguments, got " + numberOfFields);
    }
    BigDecimal targetAmount = fields$.get(0).getValue().asNumeric().orElseThrow(() -> new IllegalArgumentException("Expected targetAmount to be of type com.daml.ledger.javaapi.data.Numeric")).getValue();
    Id currency = Id.fromValue(fields$.get(1).getValue());
    String calculationId = fields$.get(2).getValue().asText().orElseThrow(() -> new IllegalArgumentException("Expected calculationId to be of type com.daml.ledger.javaapi.data.Text")).getValue();
    return new com.daml.generated.marketplace.clearing.service.CreateMarginCalculation(targetAmount, currency, calculationId);
  }

  public DamlRecord toValue() {
    ArrayList<DamlRecord.Field> fields = new ArrayList<DamlRecord.Field>(3);
    fields.add(new DamlRecord.Field("targetAmount", new Numeric(this.targetAmount)));
    fields.add(new DamlRecord.Field("currency", this.currency.toValue()));
    fields.add(new DamlRecord.Field("calculationId", new Text(this.calculationId)));
    return new DamlRecord(fields);
  }

  @Override
  public boolean equals(Object object) {
    if (this == object) {
      return true;
    }
    if (object == null) {
      return false;
    }
    if (!(object instanceof CreateMarginCalculation)) {
      return false;
    }
    CreateMarginCalculation other = (CreateMarginCalculation) object;
    return this.targetAmount.equals(other.targetAmount) && this.currency.equals(other.currency) && this.calculationId.equals(other.calculationId);
  }

  @Override
  public int hashCode() {
    return Objects.hash(this.targetAmount, this.currency, this.calculationId);
  }

  @Override
  public String toString() {
    return String.format("com.daml.generated.marketplace.clearing.service.CreateMarginCalculation(%s, %s, %s)", this.targetAmount, this.currency, this.calculationId);
  }
}
