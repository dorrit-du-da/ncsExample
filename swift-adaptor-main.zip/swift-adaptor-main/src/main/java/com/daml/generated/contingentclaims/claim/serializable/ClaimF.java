package com.daml.generated.contingentclaims.claim.serializable;

import com.daml.ledger.javaapi.data.Value;
import com.daml.ledger.javaapi.data.Variant;
import java.lang.String;
import java.util.function.Function;

public abstract class ClaimF<t, x, a, b> {
  public static final String _packageId = "636e6e778aedec0710919591e9cb2a9404d6daab0581e4ddc515eeae03256f45";

  public ClaimF() {
  }

  public abstract Value toValue(Function<t, Value> toValuet, Function<x, Value> toValuex,
      Function<a, Value> toValuea, Function<b, Value> toValueb);

  public static <t, x, a, b> ClaimF<t, x, a, b> fromValue(Value value$,
      Function<Value, t> fromValuet, Function<Value, x> fromValuex, Function<Value, a> fromValuea,
      Function<Value, b> fromValueb) {
    Variant variant$ = value$.asVariant().orElseThrow(() -> new IllegalArgumentException("Expected Variant to build an instance of the Variant com.daml.generated.contingentclaims.claim.serializable.ClaimF"));
    if ("ZeroF".equals(variant$.getConstructor())) {
      return com.daml.generated.contingentclaims.claim.serializable.claimf.ZeroF.fromValue(variant$, fromValuet, fromValuex, fromValuea, fromValueb);
    }
    if ("OneF".equals(variant$.getConstructor())) {
      return com.daml.generated.contingentclaims.claim.serializable.claimf.OneF.fromValue(variant$, fromValuet, fromValuex, fromValuea, fromValueb);
    }
    if ("GiveF".equals(variant$.getConstructor())) {
      return com.daml.generated.contingentclaims.claim.serializable.claimf.GiveF.fromValue(variant$, fromValuet, fromValuex, fromValuea, fromValueb);
    }
    if ("AndF".equals(variant$.getConstructor())) {
      return com.daml.generated.contingentclaims.claim.serializable.claimf.AndF.fromValue(variant$, fromValuet, fromValuex, fromValuea, fromValueb);
    }
    if ("OrF".equals(variant$.getConstructor())) {
      return com.daml.generated.contingentclaims.claim.serializable.claimf.OrF.fromValue(variant$, fromValuet, fromValuex, fromValuea, fromValueb);
    }
    if ("CondF".equals(variant$.getConstructor())) {
      return com.daml.generated.contingentclaims.claim.serializable.claimf.CondF.fromValue(variant$, fromValuet, fromValuex, fromValuea, fromValueb);
    }
    if ("ScaleF".equals(variant$.getConstructor())) {
      return com.daml.generated.contingentclaims.claim.serializable.claimf.ScaleF.fromValue(variant$, fromValuet, fromValuex, fromValuea, fromValueb);
    }
    if ("WhenF".equals(variant$.getConstructor())) {
      return com.daml.generated.contingentclaims.claim.serializable.claimf.WhenF.fromValue(variant$, fromValuet, fromValuex, fromValuea, fromValueb);
    }
    if ("AnytimeF".equals(variant$.getConstructor())) {
      return com.daml.generated.contingentclaims.claim.serializable.claimf.AnytimeF.fromValue(variant$, fromValuet, fromValuex, fromValuea, fromValueb);
    }
    if ("UntilF".equals(variant$.getConstructor())) {
      return com.daml.generated.contingentclaims.claim.serializable.claimf.UntilF.fromValue(variant$, fromValuet, fromValuex, fromValuea, fromValueb);
    }
    throw new IllegalArgumentException("Found unknown constructor variant$.getConstructor() for variant com.daml.generated.contingentclaims.claim.serializable.ClaimF, expected one of [ZeroF, OneF, GiveF, AndF, OrF, CondF, ScaleF, WhenF, AnytimeF, UntilF]");
  }
}
