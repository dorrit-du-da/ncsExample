package com.daml.generated.daml.control.recursion.listf;

import com.daml.generated.daml.control.recursion.ListF;
import com.daml.ledger.javaapi.data.DamlRecord;
import com.daml.ledger.javaapi.data.Value;
import com.daml.ledger.javaapi.data.Variant;
import java.lang.IllegalArgumentException;
import java.lang.Object;
import java.lang.Override;
import java.lang.String;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.function.Function;

public class Cons<a, x> extends ListF<a, x> {
  public static final String _packageId = "636e6e778aedec0710919591e9cb2a9404d6daab0581e4ddc515eeae03256f45";

  public final a value;

  public final x pattern;

  public Cons(a value, x pattern) {
    this.value = value;
    this.pattern = pattern;
  }

  public Variant toValue(Function<a, Value> toValuea, Function<x, Value> toValuex) {
    ArrayList<DamlRecord.Field> fields = new ArrayList<DamlRecord.Field>(2);
    fields.add(new DamlRecord.Field("value", toValuea.apply(this.value)));
    fields.add(new DamlRecord.Field("pattern", toValuex.apply(this.pattern)));
    return new Variant("Cons", new DamlRecord(fields));
  }

  public static <a, x> Cons<a, x> fromValue(Value value$, Function<Value, a> fromValuea,
      Function<Value, x> fromValuex) throws IllegalArgumentException {
    Variant variant$ = value$.asVariant().orElseThrow(() -> new IllegalArgumentException("Expected: Variant. Actual: " + value$.getClass().getName()));
    if (!"Cons".equals(variant$.getConstructor())) throw new IllegalArgumentException("Invalid constructor. Expected: Cons. Actual: " + variant$.getConstructor());
    Value recordValue$ = variant$.getValue();
    DamlRecord record$ = recordValue$.asRecord().orElseThrow(() -> new IllegalArgumentException("Contracts must be constructed from Records"));
    List<DamlRecord.Field> fields$ = record$.getFields();
    int numberOfFields = fields$.size();
    if (numberOfFields != 2) {
      throw new IllegalArgumentException("Expected 2 arguments, got " + numberOfFields);
    }
    a value = fromValuea.apply(fields$.get(0).getValue());
    x pattern = fromValuex.apply(fields$.get(1).getValue());
    return new Cons<a, x>(value, pattern);
  }

  @Override
  public boolean equals(Object object) {
    if (this == object) {
      return true;
    }
    if (object == null) {
      return false;
    }
    if (!(object instanceof Cons<?, ?>)) {
      return false;
    }
    Cons<?, ?> other = (Cons<?, ?>) object;
    return this.value.equals(other.value) && this.pattern.equals(other.pattern);
  }

  @Override
  public int hashCode() {
    return Objects.hash(this.value, this.pattern);
  }

  @Override
  public String toString() {
    return String.format("Cons(%s, %s)", this.value, this.pattern);
  }
}
