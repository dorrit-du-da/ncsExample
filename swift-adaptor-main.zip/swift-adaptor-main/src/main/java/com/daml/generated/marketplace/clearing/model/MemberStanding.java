package com.daml.generated.marketplace.clearing.model;

import com.daml.generated.da.internal.template.Archive;
import com.daml.generated.da.set.types.Set;
import com.daml.generated.da.types.Tuple2;
import com.daml.ledger.javaapi.data.Bool;
import com.daml.ledger.javaapi.data.CreateAndExerciseCommand;
import com.daml.ledger.javaapi.data.CreateCommand;
import com.daml.ledger.javaapi.data.CreatedEvent;
import com.daml.ledger.javaapi.data.DamlRecord;
import com.daml.ledger.javaapi.data.ExerciseByKeyCommand;
import com.daml.ledger.javaapi.data.ExerciseCommand;
import com.daml.ledger.javaapi.data.Identifier;
import com.daml.ledger.javaapi.data.Party;
import com.daml.ledger.javaapi.data.Template;
import com.daml.ledger.javaapi.data.Value;
import java.lang.Boolean;
import java.lang.Deprecated;
import java.lang.IllegalArgumentException;
import java.lang.Object;
import java.lang.Override;
import java.lang.String;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Objects;
import java.util.Optional;

public final class MemberStanding extends Template {
  public static final Identifier TEMPLATE_ID = new Identifier("636e6e778aedec0710919591e9cb2a9404d6daab0581e4ddc515eeae03256f45", "Marketplace.Clearing.Model", "MemberStanding");

  public final String operator;

  public final String provider;

  public final String customer;

  public final Boolean marginSatisfied;

  public final Boolean mtmSatisfied;

  public final Set<String> observers;

  public MemberStanding(String operator, String provider, String customer, Boolean marginSatisfied,
      Boolean mtmSatisfied, Set<String> observers) {
    this.operator = operator;
    this.provider = provider;
    this.customer = customer;
    this.marginSatisfied = marginSatisfied;
    this.mtmSatisfied = mtmSatisfied;
    this.observers = observers;
  }

  public CreateCommand create() {
    return new CreateCommand(MemberStanding.TEMPLATE_ID, this.toValue());
  }

  public static ExerciseByKeyCommand exerciseByKeyArchive(Tuple2<String, String> key, Archive arg) {
    return new ExerciseByKeyCommand(MemberStanding.TEMPLATE_ID, key.toValue(v$0 -> new Party(v$0),v$1 -> new Party(v$1)), "Archive", arg.toValue());
  }

  public static ExerciseByKeyCommand exerciseByKeyMemberStanding_UpdateMargin(
      Tuple2<String, String> key, MemberStanding_UpdateMargin arg) {
    return new ExerciseByKeyCommand(MemberStanding.TEMPLATE_ID, key.toValue(v$0 -> new Party(v$0),v$1 -> new Party(v$1)), "MemberStanding_UpdateMargin", arg.toValue());
  }

  public static ExerciseByKeyCommand exerciseByKeyMemberStanding_UpdateMargin(
      Tuple2<String, String> key, Boolean newMarginSatisfied) {
    return MemberStanding.exerciseByKeyMemberStanding_UpdateMargin(key, new MemberStanding_UpdateMargin(newMarginSatisfied));
  }

  public static ExerciseByKeyCommand exerciseByKeyMemberStanding_UpdateMTM(
      Tuple2<String, String> key, MemberStanding_UpdateMTM arg) {
    return new ExerciseByKeyCommand(MemberStanding.TEMPLATE_ID, key.toValue(v$0 -> new Party(v$0),v$1 -> new Party(v$1)), "MemberStanding_UpdateMTM", arg.toValue());
  }

  public static ExerciseByKeyCommand exerciseByKeyMemberStanding_UpdateMTM(
      Tuple2<String, String> key, Boolean newMtmSatisied) {
    return MemberStanding.exerciseByKeyMemberStanding_UpdateMTM(key, new MemberStanding_UpdateMTM(newMtmSatisied));
  }

  public static ExerciseByKeyCommand exerciseByKeyMemberStanding_AddObservers(
      Tuple2<String, String> key, MemberStanding_AddObservers arg) {
    return new ExerciseByKeyCommand(MemberStanding.TEMPLATE_ID, key.toValue(v$0 -> new Party(v$0),v$1 -> new Party(v$1)), "MemberStanding_AddObservers", arg.toValue());
  }

  public static ExerciseByKeyCommand exerciseByKeyMemberStanding_AddObservers(
      Tuple2<String, String> key, Set<String> newObservers) {
    return MemberStanding.exerciseByKeyMemberStanding_AddObservers(key, new MemberStanding_AddObservers(newObservers));
  }

  public CreateAndExerciseCommand createAndExerciseArchive(Archive arg) {
    Value argValue = arg.toValue();
    return new CreateAndExerciseCommand(MemberStanding.TEMPLATE_ID, this.toValue(), "Archive", argValue);
  }

  public CreateAndExerciseCommand createAndExerciseMemberStanding_UpdateMargin(
      MemberStanding_UpdateMargin arg) {
    Value argValue = arg.toValue();
    return new CreateAndExerciseCommand(MemberStanding.TEMPLATE_ID, this.toValue(), "MemberStanding_UpdateMargin", argValue);
  }

  public CreateAndExerciseCommand createAndExerciseMemberStanding_UpdateMargin(
      Boolean newMarginSatisfied) {
    return createAndExerciseMemberStanding_UpdateMargin(new MemberStanding_UpdateMargin(newMarginSatisfied));
  }

  public CreateAndExerciseCommand createAndExerciseMemberStanding_UpdateMTM(
      MemberStanding_UpdateMTM arg) {
    Value argValue = arg.toValue();
    return new CreateAndExerciseCommand(MemberStanding.TEMPLATE_ID, this.toValue(), "MemberStanding_UpdateMTM", argValue);
  }

  public CreateAndExerciseCommand createAndExerciseMemberStanding_UpdateMTM(
      Boolean newMtmSatisied) {
    return createAndExerciseMemberStanding_UpdateMTM(new MemberStanding_UpdateMTM(newMtmSatisied));
  }

  public CreateAndExerciseCommand createAndExerciseMemberStanding_AddObservers(
      MemberStanding_AddObservers arg) {
    Value argValue = arg.toValue();
    return new CreateAndExerciseCommand(MemberStanding.TEMPLATE_ID, this.toValue(), "MemberStanding_AddObservers", argValue);
  }

  public CreateAndExerciseCommand createAndExerciseMemberStanding_AddObservers(
      Set<String> newObservers) {
    return createAndExerciseMemberStanding_AddObservers(new MemberStanding_AddObservers(newObservers));
  }

  public static CreateCommand create(String operator, String provider, String customer,
      Boolean marginSatisfied, Boolean mtmSatisfied, Set<String> observers) {
    return new MemberStanding(operator, provider, customer, marginSatisfied, mtmSatisfied, observers).create();
  }

  public static MemberStanding fromValue(Value value$) throws IllegalArgumentException {
    Value recordValue$ = value$;
    DamlRecord record$ = recordValue$.asRecord().orElseThrow(() -> new IllegalArgumentException("Contracts must be constructed from Records"));
    List<DamlRecord.Field> fields$ = record$.getFields();
    int numberOfFields = fields$.size();
    if (numberOfFields != 6) {
      throw new IllegalArgumentException("Expected 6 arguments, got " + numberOfFields);
    }
    String operator = fields$.get(0).getValue().asParty().orElseThrow(() -> new IllegalArgumentException("Expected operator to be of type com.daml.ledger.javaapi.data.Party")).getValue();
    String provider = fields$.get(1).getValue().asParty().orElseThrow(() -> new IllegalArgumentException("Expected provider to be of type com.daml.ledger.javaapi.data.Party")).getValue();
    String customer = fields$.get(2).getValue().asParty().orElseThrow(() -> new IllegalArgumentException("Expected customer to be of type com.daml.ledger.javaapi.data.Party")).getValue();
    Boolean marginSatisfied = fields$.get(3).getValue().asBool().orElseThrow(() -> new IllegalArgumentException("Expected marginSatisfied to be of type com.daml.ledger.javaapi.data.Bool")).getValue();
    Boolean mtmSatisfied = fields$.get(4).getValue().asBool().orElseThrow(() -> new IllegalArgumentException("Expected mtmSatisfied to be of type com.daml.ledger.javaapi.data.Bool")).getValue();
    Set<String> observers = Set.<java.lang.String>fromValue(fields$.get(5).getValue(), v$0 -> v$0.asParty().orElseThrow(() -> new IllegalArgumentException("Expected observers to be of type com.daml.ledger.javaapi.data.Party")).getValue());
    return new com.daml.generated.marketplace.clearing.model.MemberStanding(operator, provider, customer, marginSatisfied, mtmSatisfied, observers);
  }

  public DamlRecord toValue() {
    ArrayList<DamlRecord.Field> fields = new ArrayList<DamlRecord.Field>(6);
    fields.add(new DamlRecord.Field("operator", new Party(this.operator)));
    fields.add(new DamlRecord.Field("provider", new Party(this.provider)));
    fields.add(new DamlRecord.Field("customer", new Party(this.customer)));
    fields.add(new DamlRecord.Field("marginSatisfied", new Bool(this.marginSatisfied)));
    fields.add(new DamlRecord.Field("mtmSatisfied", new Bool(this.mtmSatisfied)));
    fields.add(new DamlRecord.Field("observers", this.observers.toValue(v$0 -> new Party(v$0))));
    return new DamlRecord(fields);
  }

  @Override
  public boolean equals(Object object) {
    if (this == object) {
      return true;
    }
    if (object == null) {
      return false;
    }
    if (!(object instanceof MemberStanding)) {
      return false;
    }
    MemberStanding other = (MemberStanding) object;
    return this.operator.equals(other.operator) && this.provider.equals(other.provider) && this.customer.equals(other.customer) && this.marginSatisfied.equals(other.marginSatisfied) && this.mtmSatisfied.equals(other.mtmSatisfied) && this.observers.equals(other.observers);
  }

  @Override
  public int hashCode() {
    return Objects.hash(this.operator, this.provider, this.customer, this.marginSatisfied, this.mtmSatisfied, this.observers);
  }

  @Override
  public String toString() {
    return String.format("com.daml.generated.marketplace.clearing.model.MemberStanding(%s, %s, %s, %s, %s, %s)", this.operator, this.provider, this.customer, this.marginSatisfied, this.mtmSatisfied, this.observers);
  }

  public static final class ContractId extends com.daml.ledger.javaapi.data.codegen.ContractId<MemberStanding> {
    public ContractId(String contractId) {
      super(contractId);
    }

    public ExerciseCommand exerciseArchive(Archive arg) {
      Value argValue = arg.toValue();
      return new ExerciseCommand(MemberStanding.TEMPLATE_ID, this.contractId, "Archive", argValue);
    }

    public ExerciseCommand exerciseMemberStanding_UpdateMargin(MemberStanding_UpdateMargin arg) {
      Value argValue = arg.toValue();
      return new ExerciseCommand(MemberStanding.TEMPLATE_ID, this.contractId, "MemberStanding_UpdateMargin", argValue);
    }

    public ExerciseCommand exerciseMemberStanding_UpdateMargin(Boolean newMarginSatisfied) {
      return exerciseMemberStanding_UpdateMargin(new MemberStanding_UpdateMargin(newMarginSatisfied));
    }

    public ExerciseCommand exerciseMemberStanding_UpdateMTM(MemberStanding_UpdateMTM arg) {
      Value argValue = arg.toValue();
      return new ExerciseCommand(MemberStanding.TEMPLATE_ID, this.contractId, "MemberStanding_UpdateMTM", argValue);
    }

    public ExerciseCommand exerciseMemberStanding_UpdateMTM(Boolean newMtmSatisied) {
      return exerciseMemberStanding_UpdateMTM(new MemberStanding_UpdateMTM(newMtmSatisied));
    }

    public ExerciseCommand exerciseMemberStanding_AddObservers(MemberStanding_AddObservers arg) {
      Value argValue = arg.toValue();
      return new ExerciseCommand(MemberStanding.TEMPLATE_ID, this.contractId, "MemberStanding_AddObservers", argValue);
    }

    public ExerciseCommand exerciseMemberStanding_AddObservers(Set<String> newObservers) {
      return exerciseMemberStanding_AddObservers(new MemberStanding_AddObservers(newObservers));
    }
  }

  public static class Contract implements com.daml.ledger.javaapi.data.Contract {
    public final ContractId id;

    public final MemberStanding data;

    public final Optional<String> agreementText;

    public final Optional<Tuple2<String, String>> key;

    public final java.util.Set<String> signatories;

    public final java.util.Set<String> observers;

    public Contract(ContractId id, MemberStanding data, Optional<String> agreementText,
        Optional<Tuple2<String, String>> key, java.util.Set<String> signatories,
        java.util.Set<String> observers) {
      this.id = id;
      this.data = data;
      this.agreementText = agreementText;
      this.key = key;
      this.signatories = signatories;
      this.observers = observers;
    }

    public static Contract fromIdAndRecord(String contractId, DamlRecord record$,
        Optional<String> agreementText, Optional<Tuple2<String, String>> key,
        java.util.Set<String> signatories, java.util.Set<String> observers) {
      ContractId id = new ContractId(contractId);
      MemberStanding data = MemberStanding.fromValue(record$);
      return new Contract(id, data, agreementText, key, signatories, observers);
    }

    @Deprecated
    public static Contract fromIdAndRecord(String contractId, DamlRecord record$) {
      ContractId id = new ContractId(contractId);
      MemberStanding data = MemberStanding.fromValue(record$);
      return new Contract(id, data, Optional.empty(), Optional.empty(), Collections.emptySet(), Collections.emptySet());
    }

    public static Contract fromCreatedEvent(CreatedEvent event) {
      return fromIdAndRecord(event.getContractId(), event.getArguments(), event.getAgreementText(), event.getContractKey().map(e -> Tuple2.<java.lang.String, java.lang.String>fromValue(e, v$0 -> v$0.asParty().orElseThrow(() -> new IllegalArgumentException("Expected e to be of type com.daml.ledger.javaapi.data.Party")).getValue(), v$1 -> v$1.asParty().orElseThrow(() -> new IllegalArgumentException("Expected e to be of type com.daml.ledger.javaapi.data.Party")).getValue())), event.getSignatories(), event.getObservers());
    }

    @Override
    public boolean equals(Object object) {
      if (this == object) {
        return true;
      }
      if (object == null) {
        return false;
      }
      if (!(object instanceof Contract)) {
        return false;
      }
      Contract other = (Contract) object;
      return this.id.equals(other.id) && this.data.equals(other.data) && this.agreementText.equals(other.agreementText) && this.key.equals(other.key) && this.signatories.equals(other.signatories) && this.observers.equals(other.observers);
    }

    @Override
    public int hashCode() {
      return Objects.hash(this.id, this.data, this.agreementText, this.key, this.signatories, this.observers);
    }

    @Override
    public String toString() {
      return String.format("com.daml.generated.marketplace.clearing.model.MemberStanding.Contract(%s, %s, %s, %s, %s, %s)", this.id, this.data, this.agreementText, this.key, this.signatories, this.observers);
    }
  }
}
