package com.daml.generated.marketplace.custody.service;

import com.daml.generated.da.finance.asset.AssetDeposit;
import com.daml.generated.marketplace.custody.model.Channel;
import com.daml.ledger.javaapi.data.DamlRecord;
import com.daml.ledger.javaapi.data.Value;
import java.lang.IllegalArgumentException;
import java.lang.Object;
import java.lang.Override;
import java.lang.String;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

public class RequestWithdrawal {
  public static final String _packageId = "636e6e778aedec0710919591e9cb2a9404d6daab0581e4ddc515eeae03256f45";

  public final AssetDeposit.ContractId depositCid;

  public final Channel withdrawalChannel;

  public RequestWithdrawal(AssetDeposit.ContractId depositCid, Channel withdrawalChannel) {
    this.depositCid = depositCid;
    this.withdrawalChannel = withdrawalChannel;
  }

  public static RequestWithdrawal fromValue(Value value$) throws IllegalArgumentException {
    Value recordValue$ = value$;
    DamlRecord record$ = recordValue$.asRecord().orElseThrow(() -> new IllegalArgumentException("Contracts must be constructed from Records"));
    List<DamlRecord.Field> fields$ = record$.getFields();
    int numberOfFields = fields$.size();
    if (numberOfFields != 2) {
      throw new IllegalArgumentException("Expected 2 arguments, got " + numberOfFields);
    }
    AssetDeposit.ContractId depositCid = new AssetDeposit.ContractId(fields$.get(0).getValue().asContractId().orElseThrow(() -> new IllegalArgumentException("Expected depositCid to be of type com.daml.ledger.javaapi.data.ContractId")).getValue());
    Channel withdrawalChannel = Channel.fromValue(fields$.get(1).getValue());
    return new com.daml.generated.marketplace.custody.service.RequestWithdrawal(depositCid, withdrawalChannel);
  }

  public DamlRecord toValue() {
    ArrayList<DamlRecord.Field> fields = new ArrayList<DamlRecord.Field>(2);
    fields.add(new DamlRecord.Field("depositCid", this.depositCid.toValue()));
    fields.add(new DamlRecord.Field("withdrawalChannel", this.withdrawalChannel.toValue()));
    return new DamlRecord(fields);
  }

  @Override
  public boolean equals(Object object) {
    if (this == object) {
      return true;
    }
    if (object == null) {
      return false;
    }
    if (!(object instanceof RequestWithdrawal)) {
      return false;
    }
    RequestWithdrawal other = (RequestWithdrawal) object;
    return this.depositCid.equals(other.depositCid) && this.withdrawalChannel.equals(other.withdrawalChannel);
  }

  @Override
  public int hashCode() {
    return Objects.hash(this.depositCid, this.withdrawalChannel);
  }

  @Override
  public String toString() {
    return String.format("com.daml.generated.marketplace.custody.service.RequestWithdrawal(%s, %s)", this.depositCid, this.withdrawalChannel);
  }
}
