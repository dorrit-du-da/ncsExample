package com.daml.generated.marketplace.custody.model.channel;

import com.daml.generated.marketplace.custody.model.Channel;
import com.daml.ledger.javaapi.data.DamlRecord;
import com.daml.ledger.javaapi.data.Text;
import com.daml.ledger.javaapi.data.Value;
import com.daml.ledger.javaapi.data.Variant;
import java.lang.IllegalArgumentException;
import java.lang.Object;
import java.lang.Override;
import java.lang.String;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

public class SWIFT extends Channel {
  public static final String _packageId = "636e6e778aedec0710919591e9cb2a9404d6daab0581e4ddc515eeae03256f45";

  public final String remark;

  public SWIFT(String remark) {
    this.remark = remark;
  }

  public Variant toValue() {
    ArrayList<DamlRecord.Field> fields = new ArrayList<DamlRecord.Field>(1);
    fields.add(new DamlRecord.Field("remark", new Text(this.remark)));
    return new Variant("SWIFT", new DamlRecord(fields));
  }

  public static SWIFT fromValue(Value value$) throws IllegalArgumentException {
    Variant variant$ = value$.asVariant().orElseThrow(() -> new IllegalArgumentException("Expected: Variant. Actual: " + value$.getClass().getName()));
    if (!"SWIFT".equals(variant$.getConstructor())) throw new IllegalArgumentException("Invalid constructor. Expected: SWIFT. Actual: " + variant$.getConstructor());
    Value recordValue$ = variant$.getValue();
    DamlRecord record$ = recordValue$.asRecord().orElseThrow(() -> new IllegalArgumentException("Contracts must be constructed from Records"));
    List<DamlRecord.Field> fields$ = record$.getFields();
    int numberOfFields = fields$.size();
    if (numberOfFields != 1) {
      throw new IllegalArgumentException("Expected 1 arguments, got " + numberOfFields);
    }
    String remark = fields$.get(0).getValue().asText().orElseThrow(() -> new IllegalArgumentException("Expected remark to be of type com.daml.ledger.javaapi.data.Text")).getValue();
    return new SWIFT(remark);
  }

  @Override
  public boolean equals(Object object) {
    if (this == object) {
      return true;
    }
    if (object == null) {
      return false;
    }
    if (!(object instanceof SWIFT)) {
      return false;
    }
    SWIFT other = (SWIFT) object;
    return this.remark.equals(other.remark);
  }

  @Override
  public int hashCode() {
    return Objects.hash(this.remark);
  }

  @Override
  public String toString() {
    return String.format("SWIFT(%s)", this.remark);
  }
}
