package com.daml.generated.marketplace.distribution.syndication.bidding.model;

import com.daml.generated.da.finance.types.Asset;
import com.daml.generated.da.internal.template.Archive;
import com.daml.ledger.javaapi.data.CreateAndExerciseCommand;
import com.daml.ledger.javaapi.data.CreateCommand;
import com.daml.ledger.javaapi.data.CreatedEvent;
import com.daml.ledger.javaapi.data.DamlRecord;
import com.daml.ledger.javaapi.data.ExerciseCommand;
import com.daml.ledger.javaapi.data.Identifier;
import com.daml.ledger.javaapi.data.Party;
import com.daml.ledger.javaapi.data.Template;
import com.daml.ledger.javaapi.data.Text;
import com.daml.ledger.javaapi.data.Value;
import java.lang.Deprecated;
import java.lang.IllegalArgumentException;
import java.lang.Object;
import java.lang.Override;
import java.lang.String;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.Set;

public final class Bid extends Template {
  public static final Identifier TEMPLATE_ID = new Identifier("636e6e778aedec0710919591e9cb2a9404d6daab0581e4ddc515eeae03256f45", "Marketplace.Distribution.Syndication.Bidding.Model", "Bid");

  public final String operator;

  public final String provider;

  public final String investor;

  public final String issuer;

  public final String dealId;

  public final String trancheId;

  public final Asset asset;

  public final Asset price;

  public Bid(String operator, String provider, String investor, String issuer, String dealId,
      String trancheId, Asset asset, Asset price) {
    this.operator = operator;
    this.provider = provider;
    this.investor = investor;
    this.issuer = issuer;
    this.dealId = dealId;
    this.trancheId = trancheId;
    this.asset = asset;
    this.price = price;
  }

  public CreateCommand create() {
    return new CreateCommand(Bid.TEMPLATE_ID, this.toValue());
  }

  public CreateAndExerciseCommand createAndExerciseAllocate(Allocate arg) {
    Value argValue = arg.toValue();
    return new CreateAndExerciseCommand(Bid.TEMPLATE_ID, this.toValue(), "Allocate", argValue);
  }

  public CreateAndExerciseCommand createAndExerciseAllocate(BigDecimal offeredPrice,
      BigDecimal offeredQuantity) {
    return createAndExerciseAllocate(new Allocate(offeredPrice, offeredQuantity));
  }

  public CreateAndExerciseCommand createAndExerciseReject(Reject arg) {
    Value argValue = arg.toValue();
    return new CreateAndExerciseCommand(Bid.TEMPLATE_ID, this.toValue(), "Reject", argValue);
  }

  public CreateAndExerciseCommand createAndExerciseReject() {
    return createAndExerciseReject(new Reject());
  }

  public CreateAndExerciseCommand createAndExerciseArchive(Archive arg) {
    Value argValue = arg.toValue();
    return new CreateAndExerciseCommand(Bid.TEMPLATE_ID, this.toValue(), "Archive", argValue);
  }

  public static CreateCommand create(String operator, String provider, String investor,
      String issuer, String dealId, String trancheId, Asset asset, Asset price) {
    return new Bid(operator, provider, investor, issuer, dealId, trancheId, asset, price).create();
  }

  public static Bid fromValue(Value value$) throws IllegalArgumentException {
    Value recordValue$ = value$;
    DamlRecord record$ = recordValue$.asRecord().orElseThrow(() -> new IllegalArgumentException("Contracts must be constructed from Records"));
    List<DamlRecord.Field> fields$ = record$.getFields();
    int numberOfFields = fields$.size();
    if (numberOfFields != 8) {
      throw new IllegalArgumentException("Expected 8 arguments, got " + numberOfFields);
    }
    String operator = fields$.get(0).getValue().asParty().orElseThrow(() -> new IllegalArgumentException("Expected operator to be of type com.daml.ledger.javaapi.data.Party")).getValue();
    String provider = fields$.get(1).getValue().asParty().orElseThrow(() -> new IllegalArgumentException("Expected provider to be of type com.daml.ledger.javaapi.data.Party")).getValue();
    String investor = fields$.get(2).getValue().asParty().orElseThrow(() -> new IllegalArgumentException("Expected investor to be of type com.daml.ledger.javaapi.data.Party")).getValue();
    String issuer = fields$.get(3).getValue().asParty().orElseThrow(() -> new IllegalArgumentException("Expected issuer to be of type com.daml.ledger.javaapi.data.Party")).getValue();
    String dealId = fields$.get(4).getValue().asText().orElseThrow(() -> new IllegalArgumentException("Expected dealId to be of type com.daml.ledger.javaapi.data.Text")).getValue();
    String trancheId = fields$.get(5).getValue().asText().orElseThrow(() -> new IllegalArgumentException("Expected trancheId to be of type com.daml.ledger.javaapi.data.Text")).getValue();
    Asset asset = Asset.fromValue(fields$.get(6).getValue());
    Asset price = Asset.fromValue(fields$.get(7).getValue());
    return new com.daml.generated.marketplace.distribution.syndication.bidding.model.Bid(operator, provider, investor, issuer, dealId, trancheId, asset, price);
  }

  public DamlRecord toValue() {
    ArrayList<DamlRecord.Field> fields = new ArrayList<DamlRecord.Field>(8);
    fields.add(new DamlRecord.Field("operator", new Party(this.operator)));
    fields.add(new DamlRecord.Field("provider", new Party(this.provider)));
    fields.add(new DamlRecord.Field("investor", new Party(this.investor)));
    fields.add(new DamlRecord.Field("issuer", new Party(this.issuer)));
    fields.add(new DamlRecord.Field("dealId", new Text(this.dealId)));
    fields.add(new DamlRecord.Field("trancheId", new Text(this.trancheId)));
    fields.add(new DamlRecord.Field("asset", this.asset.toValue()));
    fields.add(new DamlRecord.Field("price", this.price.toValue()));
    return new DamlRecord(fields);
  }

  @Override
  public boolean equals(Object object) {
    if (this == object) {
      return true;
    }
    if (object == null) {
      return false;
    }
    if (!(object instanceof Bid)) {
      return false;
    }
    Bid other = (Bid) object;
    return this.operator.equals(other.operator) && this.provider.equals(other.provider) && this.investor.equals(other.investor) && this.issuer.equals(other.issuer) && this.dealId.equals(other.dealId) && this.trancheId.equals(other.trancheId) && this.asset.equals(other.asset) && this.price.equals(other.price);
  }

  @Override
  public int hashCode() {
    return Objects.hash(this.operator, this.provider, this.investor, this.issuer, this.dealId, this.trancheId, this.asset, this.price);
  }

  @Override
  public String toString() {
    return String.format("com.daml.generated.marketplace.distribution.syndication.bidding.model.Bid(%s, %s, %s, %s, %s, %s, %s, %s)", this.operator, this.provider, this.investor, this.issuer, this.dealId, this.trancheId, this.asset, this.price);
  }

  public static final class ContractId extends com.daml.ledger.javaapi.data.codegen.ContractId<Bid> {
    public ContractId(String contractId) {
      super(contractId);
    }

    public ExerciseCommand exerciseAllocate(Allocate arg) {
      Value argValue = arg.toValue();
      return new ExerciseCommand(Bid.TEMPLATE_ID, this.contractId, "Allocate", argValue);
    }

    public ExerciseCommand exerciseAllocate(BigDecimal offeredPrice, BigDecimal offeredQuantity) {
      return exerciseAllocate(new Allocate(offeredPrice, offeredQuantity));
    }

    public ExerciseCommand exerciseReject(Reject arg) {
      Value argValue = arg.toValue();
      return new ExerciseCommand(Bid.TEMPLATE_ID, this.contractId, "Reject", argValue);
    }

    public ExerciseCommand exerciseReject() {
      return exerciseReject(new Reject());
    }

    public ExerciseCommand exerciseArchive(Archive arg) {
      Value argValue = arg.toValue();
      return new ExerciseCommand(Bid.TEMPLATE_ID, this.contractId, "Archive", argValue);
    }
  }

  public static class Contract implements com.daml.ledger.javaapi.data.Contract {
    public final ContractId id;

    public final Bid data;

    public final Optional<String> agreementText;

    public final Set<String> signatories;

    public final Set<String> observers;

    public Contract(ContractId id, Bid data, Optional<String> agreementText,
        Set<String> signatories, Set<String> observers) {
      this.id = id;
      this.data = data;
      this.agreementText = agreementText;
      this.signatories = signatories;
      this.observers = observers;
    }

    public static Contract fromIdAndRecord(String contractId, DamlRecord record$,
        Optional<String> agreementText, Set<String> signatories, Set<String> observers) {
      ContractId id = new ContractId(contractId);
      Bid data = Bid.fromValue(record$);
      return new Contract(id, data, agreementText, signatories, observers);
    }

    @Deprecated
    public static Contract fromIdAndRecord(String contractId, DamlRecord record$) {
      ContractId id = new ContractId(contractId);
      Bid data = Bid.fromValue(record$);
      return new Contract(id, data, Optional.empty(), Collections.emptySet(), Collections.emptySet());
    }

    public static Contract fromCreatedEvent(CreatedEvent event) {
      return fromIdAndRecord(event.getContractId(), event.getArguments(), event.getAgreementText(), event.getSignatories(), event.getObservers());
    }

    @Override
    public boolean equals(Object object) {
      if (this == object) {
        return true;
      }
      if (object == null) {
        return false;
      }
      if (!(object instanceof Contract)) {
        return false;
      }
      Contract other = (Contract) object;
      return this.id.equals(other.id) && this.data.equals(other.data) && this.agreementText.equals(other.agreementText) && this.signatories.equals(other.signatories) && this.observers.equals(other.observers);
    }

    @Override
    public int hashCode() {
      return Objects.hash(this.id, this.data, this.agreementText, this.signatories, this.observers);
    }

    @Override
    public String toString() {
      return String.format("com.daml.generated.marketplace.distribution.syndication.bidding.model.Bid.Contract(%s, %s, %s, %s, %s)", this.id, this.data, this.agreementText, this.signatories, this.observers);
    }
  }
}
