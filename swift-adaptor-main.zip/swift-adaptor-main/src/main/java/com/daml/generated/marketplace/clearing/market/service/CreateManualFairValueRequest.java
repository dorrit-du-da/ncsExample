package com.daml.generated.marketplace.clearing.market.service;

import com.daml.generated.da.finance.types.Id;
import com.daml.generated.da.set.types.Set;
import com.daml.ledger.javaapi.data.DamlRecord;
import com.daml.ledger.javaapi.data.Party;
import com.daml.ledger.javaapi.data.Text;
import com.daml.ledger.javaapi.data.Timestamp;
import com.daml.ledger.javaapi.data.Value;
import java.lang.IllegalArgumentException;
import java.lang.Object;
import java.lang.Override;
import java.lang.String;
import java.time.Instant;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

public class CreateManualFairValueRequest {
  public static final String _packageId = "636e6e778aedec0710919591e9cb2a9404d6daab0581e4ddc515eeae03256f45";

  public final String listingId;

  public final String calculationId;

  public final Id currency;

  public final Instant upTo;

  public final Set<String> observers;

  public CreateManualFairValueRequest(String listingId, String calculationId, Id currency,
      Instant upTo, Set<String> observers) {
    this.listingId = listingId;
    this.calculationId = calculationId;
    this.currency = currency;
    this.upTo = upTo;
    this.observers = observers;
  }

  public static CreateManualFairValueRequest fromValue(Value value$) throws
      IllegalArgumentException {
    Value recordValue$ = value$;
    DamlRecord record$ = recordValue$.asRecord().orElseThrow(() -> new IllegalArgumentException("Contracts must be constructed from Records"));
    List<DamlRecord.Field> fields$ = record$.getFields();
    int numberOfFields = fields$.size();
    if (numberOfFields != 5) {
      throw new IllegalArgumentException("Expected 5 arguments, got " + numberOfFields);
    }
    String listingId = fields$.get(0).getValue().asText().orElseThrow(() -> new IllegalArgumentException("Expected listingId to be of type com.daml.ledger.javaapi.data.Text")).getValue();
    String calculationId = fields$.get(1).getValue().asText().orElseThrow(() -> new IllegalArgumentException("Expected calculationId to be of type com.daml.ledger.javaapi.data.Text")).getValue();
    Id currency = Id.fromValue(fields$.get(2).getValue());
    Instant upTo = fields$.get(3).getValue().asTimestamp().orElseThrow(() -> new IllegalArgumentException("Expected upTo to be of type com.daml.ledger.javaapi.data.Timestamp")).getValue();
    Set<String> observers = Set.<java.lang.String>fromValue(fields$.get(4).getValue(), v$0 -> v$0.asParty().orElseThrow(() -> new IllegalArgumentException("Expected observers to be of type com.daml.ledger.javaapi.data.Party")).getValue());
    return new com.daml.generated.marketplace.clearing.market.service.CreateManualFairValueRequest(listingId, calculationId, currency, upTo, observers);
  }

  public DamlRecord toValue() {
    ArrayList<DamlRecord.Field> fields = new ArrayList<DamlRecord.Field>(5);
    fields.add(new DamlRecord.Field("listingId", new Text(this.listingId)));
    fields.add(new DamlRecord.Field("calculationId", new Text(this.calculationId)));
    fields.add(new DamlRecord.Field("currency", this.currency.toValue()));
    fields.add(new DamlRecord.Field("upTo", Timestamp.fromInstant(this.upTo)));
    fields.add(new DamlRecord.Field("observers", this.observers.toValue(v$0 -> new Party(v$0))));
    return new DamlRecord(fields);
  }

  @Override
  public boolean equals(Object object) {
    if (this == object) {
      return true;
    }
    if (object == null) {
      return false;
    }
    if (!(object instanceof CreateManualFairValueRequest)) {
      return false;
    }
    CreateManualFairValueRequest other = (CreateManualFairValueRequest) object;
    return this.listingId.equals(other.listingId) && this.calculationId.equals(other.calculationId) && this.currency.equals(other.currency) && this.upTo.equals(other.upTo) && this.observers.equals(other.observers);
  }

  @Override
  public int hashCode() {
    return Objects.hash(this.listingId, this.calculationId, this.currency, this.upTo, this.observers);
  }

  @Override
  public String toString() {
    return String.format("com.daml.generated.marketplace.clearing.market.service.CreateManualFairValueRequest(%s, %s, %s, %s, %s)", this.listingId, this.calculationId, this.currency, this.upTo, this.observers);
  }
}
