package com.daml.generated.da.finance.trade.settlementinstruction;

import com.daml.generated.da.finance.asset.AssetDeposit;
import com.daml.ledger.javaapi.data.DamlRecord;
import com.daml.ledger.javaapi.data.Party;
import com.daml.ledger.javaapi.data.Value;
import java.lang.IllegalArgumentException;
import java.lang.Object;
import java.lang.Override;
import java.lang.String;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

public class SettlementInstruction_AllocateNext {
  public static final String _packageId = "636e6e778aedec0710919591e9cb2a9404d6daab0581e4ddc515eeae03256f45";

  public final AssetDeposit.ContractId depositCid;

  public final String ctrl;

  public SettlementInstruction_AllocateNext(AssetDeposit.ContractId depositCid, String ctrl) {
    this.depositCid = depositCid;
    this.ctrl = ctrl;
  }

  public static SettlementInstruction_AllocateNext fromValue(Value value$) throws
      IllegalArgumentException {
    Value recordValue$ = value$;
    DamlRecord record$ = recordValue$.asRecord().orElseThrow(() -> new IllegalArgumentException("Contracts must be constructed from Records"));
    List<DamlRecord.Field> fields$ = record$.getFields();
    int numberOfFields = fields$.size();
    if (numberOfFields != 2) {
      throw new IllegalArgumentException("Expected 2 arguments, got " + numberOfFields);
    }
    AssetDeposit.ContractId depositCid = new AssetDeposit.ContractId(fields$.get(0).getValue().asContractId().orElseThrow(() -> new IllegalArgumentException("Expected depositCid to be of type com.daml.ledger.javaapi.data.ContractId")).getValue());
    String ctrl = fields$.get(1).getValue().asParty().orElseThrow(() -> new IllegalArgumentException("Expected ctrl to be of type com.daml.ledger.javaapi.data.Party")).getValue();
    return new com.daml.generated.da.finance.trade.settlementinstruction.SettlementInstruction_AllocateNext(depositCid, ctrl);
  }

  public DamlRecord toValue() {
    ArrayList<DamlRecord.Field> fields = new ArrayList<DamlRecord.Field>(2);
    fields.add(new DamlRecord.Field("depositCid", this.depositCid.toValue()));
    fields.add(new DamlRecord.Field("ctrl", new Party(this.ctrl)));
    return new DamlRecord(fields);
  }

  @Override
  public boolean equals(Object object) {
    if (this == object) {
      return true;
    }
    if (object == null) {
      return false;
    }
    if (!(object instanceof SettlementInstruction_AllocateNext)) {
      return false;
    }
    SettlementInstruction_AllocateNext other = (SettlementInstruction_AllocateNext) object;
    return this.depositCid.equals(other.depositCid) && this.ctrl.equals(other.ctrl);
  }

  @Override
  public int hashCode() {
    return Objects.hash(this.depositCid, this.ctrl);
  }

  @Override
  public String toString() {
    return String.format("com.daml.generated.da.finance.trade.settlementinstruction.SettlementInstruction_AllocateNext(%s, %s)", this.depositCid, this.ctrl);
  }
}
