package com.daml.generated.contingentclaims.observation;

import com.daml.ledger.javaapi.data.Value;
import com.daml.ledger.javaapi.data.Variant;
import java.lang.String;
import java.util.function.Function;

public abstract class Observation<t, x> {
  public static final String _packageId = "636e6e778aedec0710919591e9cb2a9404d6daab0581e4ddc515eeae03256f45";

  public Observation() {
  }

  public abstract Value toValue(Function<t, Value> toValuet, Function<x, Value> toValuex);

  public static <t, x> Observation<t, x> fromValue(Value value$, Function<Value, t> fromValuet,
      Function<Value, x> fromValuex) {
    Variant variant$ = value$.asVariant().orElseThrow(() -> new IllegalArgumentException("Expected Variant to build an instance of the Variant com.daml.generated.contingentclaims.observation.Observation"));
    if ("Const".equals(variant$.getConstructor())) {
      return com.daml.generated.contingentclaims.observation.observation.Const.fromValue(variant$, fromValuet, fromValuex);
    }
    if ("Observe".equals(variant$.getConstructor())) {
      return com.daml.generated.contingentclaims.observation.observation.Observe.fromValue(variant$, fromValuet, fromValuex);
    }
    if ("Add".equals(variant$.getConstructor())) {
      return com.daml.generated.contingentclaims.observation.observation.Add.fromValue(variant$, fromValuet, fromValuex);
    }
    if ("Neg".equals(variant$.getConstructor())) {
      return com.daml.generated.contingentclaims.observation.observation.Neg.fromValue(variant$, fromValuet, fromValuex);
    }
    if ("Mul".equals(variant$.getConstructor())) {
      return com.daml.generated.contingentclaims.observation.observation.Mul.fromValue(variant$, fromValuet, fromValuex);
    }
    if ("Div".equals(variant$.getConstructor())) {
      return com.daml.generated.contingentclaims.observation.observation.Div.fromValue(variant$, fromValuet, fromValuex);
    }
    throw new IllegalArgumentException("Found unknown constructor variant$.getConstructor() for variant com.daml.generated.contingentclaims.observation.Observation, expected one of [Const, Observe, Add, Neg, Mul, Div]");
  }
}
