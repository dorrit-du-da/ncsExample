package com.daml.generated.marketplace.distribution.auction.bidding.service;

import com.daml.generated.marketplace.distribution.auction.bidding.model.Bid;
import com.daml.generated.marketplace.distribution.auction.bidding.model.Status;
import com.daml.ledger.javaapi.data.DamlRecord;
import com.daml.ledger.javaapi.data.Value;
import java.lang.IllegalArgumentException;
import java.lang.Object;
import java.lang.Override;
import java.lang.String;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

public class RejectAllocation {
  public static final String _packageId = "636e6e778aedec0710919591e9cb2a9404d6daab0581e4ddc515eeae03256f45";

  public final Bid.ContractId bidCid;

  public final Status newStatus;

  public RejectAllocation(Bid.ContractId bidCid, Status newStatus) {
    this.bidCid = bidCid;
    this.newStatus = newStatus;
  }

  public static RejectAllocation fromValue(Value value$) throws IllegalArgumentException {
    Value recordValue$ = value$;
    DamlRecord record$ = recordValue$.asRecord().orElseThrow(() -> new IllegalArgumentException("Contracts must be constructed from Records"));
    List<DamlRecord.Field> fields$ = record$.getFields();
    int numberOfFields = fields$.size();
    if (numberOfFields != 2) {
      throw new IllegalArgumentException("Expected 2 arguments, got " + numberOfFields);
    }
    Bid.ContractId bidCid = new Bid.ContractId(fields$.get(0).getValue().asContractId().orElseThrow(() -> new IllegalArgumentException("Expected bidCid to be of type com.daml.ledger.javaapi.data.ContractId")).getValue());
    Status newStatus = Status.fromValue(fields$.get(1).getValue());
    return new com.daml.generated.marketplace.distribution.auction.bidding.service.RejectAllocation(bidCid, newStatus);
  }

  public DamlRecord toValue() {
    ArrayList<DamlRecord.Field> fields = new ArrayList<DamlRecord.Field>(2);
    fields.add(new DamlRecord.Field("bidCid", this.bidCid.toValue()));
    fields.add(new DamlRecord.Field("newStatus", this.newStatus.toValue()));
    return new DamlRecord(fields);
  }

  @Override
  public boolean equals(Object object) {
    if (this == object) {
      return true;
    }
    if (object == null) {
      return false;
    }
    if (!(object instanceof RejectAllocation)) {
      return false;
    }
    RejectAllocation other = (RejectAllocation) object;
    return this.bidCid.equals(other.bidCid) && this.newStatus.equals(other.newStatus);
  }

  @Override
  public int hashCode() {
    return Objects.hash(this.bidCid, this.newStatus);
  }

  @Override
  public String toString() {
    return String.format("com.daml.generated.marketplace.distribution.auction.bidding.service.RejectAllocation(%s, %s)", this.bidCid, this.newStatus);
  }
}
