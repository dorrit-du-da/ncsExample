package com.daml.generated.daml.data.functor.identity;

import com.daml.ledger.javaapi.data.DamlRecord;
import com.daml.ledger.javaapi.data.Value;
import java.lang.IllegalArgumentException;
import java.lang.Object;
import java.lang.Override;
import java.lang.String;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.function.Function;

public class Identity<a> {
  public static final String _packageId = "636e6e778aedec0710919591e9cb2a9404d6daab0581e4ddc515eeae03256f45";

  public final a unpack;

  public Identity(a unpack) {
    this.unpack = unpack;
  }

  public static <a> Identity<a> fromValue(Value value$, Function<Value, a> fromValuea) throws
      IllegalArgumentException {
    Value recordValue$ = value$;
    DamlRecord record$ = recordValue$.asRecord().orElseThrow(() -> new IllegalArgumentException("Contracts must be constructed from Records"));
    List<DamlRecord.Field> fields$ = record$.getFields();
    int numberOfFields = fields$.size();
    if (numberOfFields != 1) {
      throw new IllegalArgumentException("Expected 1 arguments, got " + numberOfFields);
    }
    a unpack = fromValuea.apply(fields$.get(0).getValue());
    return new com.daml.generated.daml.data.functor.identity.Identity<a>(unpack);
  }

  public DamlRecord toValue(Function<a, Value> toValuea) {
    ArrayList<DamlRecord.Field> fields = new ArrayList<DamlRecord.Field>(1);
    fields.add(new DamlRecord.Field("unpack", toValuea.apply(this.unpack)));
    return new DamlRecord(fields);
  }

  @Override
  public boolean equals(Object object) {
    if (this == object) {
      return true;
    }
    if (object == null) {
      return false;
    }
    if (!(object instanceof Identity<?>)) {
      return false;
    }
    Identity<?> other = (Identity<?>) object;
    return this.unpack.equals(other.unpack);
  }

  @Override
  public int hashCode() {
    return Objects.hash(this.unpack);
  }

  @Override
  public String toString() {
    return String.format("com.daml.generated.daml.data.functor.identity.Identity(%s)", this.unpack);
  }
}
