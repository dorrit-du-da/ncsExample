package com.daml.generated.da.finance.trade.dvp.settlement;

import com.daml.generated.da.finance.trade.dvp.Dvp;
import com.daml.generated.da.finance.trade.settlementinstruction.SettlementInstruction;
import com.daml.generated.da.finance.types.Id;
import com.daml.generated.da.finance.types.MasterAgreement;
import com.daml.generated.da.internal.template.Archive;
import com.daml.ledger.javaapi.data.CreateAndExerciseCommand;
import com.daml.ledger.javaapi.data.CreateCommand;
import com.daml.ledger.javaapi.data.CreatedEvent;
import com.daml.ledger.javaapi.data.DamlRecord;
import com.daml.ledger.javaapi.data.ExerciseByKeyCommand;
import com.daml.ledger.javaapi.data.ExerciseCommand;
import com.daml.ledger.javaapi.data.Identifier;
import com.daml.ledger.javaapi.data.Template;
import com.daml.ledger.javaapi.data.Value;
import java.lang.Deprecated;
import java.lang.IllegalArgumentException;
import java.lang.Object;
import java.lang.Override;
import java.lang.String;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.Set;

public final class DvpSettlementRule extends Template {
  public static final Identifier TEMPLATE_ID = new Identifier("636e6e778aedec0710919591e9cb2a9404d6daab0581e4ddc515eeae03256f45", "DA.Finance.Trade.Dvp.Settlement", "DvpSettlementRule");

  public final MasterAgreement masterAgreement;

  public DvpSettlementRule(MasterAgreement masterAgreement) {
    this.masterAgreement = masterAgreement;
  }

  public CreateCommand create() {
    return new CreateCommand(DvpSettlementRule.TEMPLATE_ID, this.toValue());
  }

  public static ExerciseByKeyCommand exerciseByKeyDvpSettlement_Process(Id key,
      DvpSettlement_Process arg) {
    return new ExerciseByKeyCommand(DvpSettlementRule.TEMPLATE_ID, key.toValue(), "DvpSettlement_Process", arg.toValue());
  }

  public static ExerciseByKeyCommand exerciseByKeyDvpSettlement_Process(Id key,
      Dvp.ContractId dvpCid, List<SettlementInstruction.ContractId> paymentInstructionCids,
      List<SettlementInstruction.ContractId> deliveryInstructionCids, String ctrl) {
    return DvpSettlementRule.exerciseByKeyDvpSettlement_Process(key, new DvpSettlement_Process(dvpCid, paymentInstructionCids, deliveryInstructionCids, ctrl));
  }

  public static ExerciseByKeyCommand exerciseByKeyArchive(Id key, Archive arg) {
    return new ExerciseByKeyCommand(DvpSettlementRule.TEMPLATE_ID, key.toValue(), "Archive", arg.toValue());
  }

  public CreateAndExerciseCommand createAndExerciseDvpSettlement_Process(
      DvpSettlement_Process arg) {
    Value argValue = arg.toValue();
    return new CreateAndExerciseCommand(DvpSettlementRule.TEMPLATE_ID, this.toValue(), "DvpSettlement_Process", argValue);
  }

  public CreateAndExerciseCommand createAndExerciseDvpSettlement_Process(Dvp.ContractId dvpCid,
      List<SettlementInstruction.ContractId> paymentInstructionCids,
      List<SettlementInstruction.ContractId> deliveryInstructionCids, String ctrl) {
    return createAndExerciseDvpSettlement_Process(new DvpSettlement_Process(dvpCid, paymentInstructionCids, deliveryInstructionCids, ctrl));
  }

  public CreateAndExerciseCommand createAndExerciseArchive(Archive arg) {
    Value argValue = arg.toValue();
    return new CreateAndExerciseCommand(DvpSettlementRule.TEMPLATE_ID, this.toValue(), "Archive", argValue);
  }

  public static CreateCommand create(MasterAgreement masterAgreement) {
    return new DvpSettlementRule(masterAgreement).create();
  }

  public static DvpSettlementRule fromValue(Value value$) throws IllegalArgumentException {
    Value recordValue$ = value$;
    DamlRecord record$ = recordValue$.asRecord().orElseThrow(() -> new IllegalArgumentException("Contracts must be constructed from Records"));
    List<DamlRecord.Field> fields$ = record$.getFields();
    int numberOfFields = fields$.size();
    if (numberOfFields != 1) {
      throw new IllegalArgumentException("Expected 1 arguments, got " + numberOfFields);
    }
    MasterAgreement masterAgreement = MasterAgreement.fromValue(fields$.get(0).getValue());
    return new com.daml.generated.da.finance.trade.dvp.settlement.DvpSettlementRule(masterAgreement);
  }

  public DamlRecord toValue() {
    ArrayList<DamlRecord.Field> fields = new ArrayList<DamlRecord.Field>(1);
    fields.add(new DamlRecord.Field("masterAgreement", this.masterAgreement.toValue()));
    return new DamlRecord(fields);
  }

  @Override
  public boolean equals(Object object) {
    if (this == object) {
      return true;
    }
    if (object == null) {
      return false;
    }
    if (!(object instanceof DvpSettlementRule)) {
      return false;
    }
    DvpSettlementRule other = (DvpSettlementRule) object;
    return this.masterAgreement.equals(other.masterAgreement);
  }

  @Override
  public int hashCode() {
    return Objects.hash(this.masterAgreement);
  }

  @Override
  public String toString() {
    return String.format("com.daml.generated.da.finance.trade.dvp.settlement.DvpSettlementRule(%s)", this.masterAgreement);
  }

  public static final class ContractId extends com.daml.ledger.javaapi.data.codegen.ContractId<DvpSettlementRule> {
    public ContractId(String contractId) {
      super(contractId);
    }

    public ExerciseCommand exerciseDvpSettlement_Process(DvpSettlement_Process arg) {
      Value argValue = arg.toValue();
      return new ExerciseCommand(DvpSettlementRule.TEMPLATE_ID, this.contractId, "DvpSettlement_Process", argValue);
    }

    public ExerciseCommand exerciseDvpSettlement_Process(Dvp.ContractId dvpCid,
        List<SettlementInstruction.ContractId> paymentInstructionCids,
        List<SettlementInstruction.ContractId> deliveryInstructionCids, String ctrl) {
      return exerciseDvpSettlement_Process(new DvpSettlement_Process(dvpCid, paymentInstructionCids, deliveryInstructionCids, ctrl));
    }

    public ExerciseCommand exerciseArchive(Archive arg) {
      Value argValue = arg.toValue();
      return new ExerciseCommand(DvpSettlementRule.TEMPLATE_ID, this.contractId, "Archive", argValue);
    }
  }

  public static class Contract implements com.daml.ledger.javaapi.data.Contract {
    public final ContractId id;

    public final DvpSettlementRule data;

    public final Optional<String> agreementText;

    public final Optional<Id> key;

    public final Set<String> signatories;

    public final Set<String> observers;

    public Contract(ContractId id, DvpSettlementRule data, Optional<String> agreementText,
        Optional<Id> key, Set<String> signatories, Set<String> observers) {
      this.id = id;
      this.data = data;
      this.agreementText = agreementText;
      this.key = key;
      this.signatories = signatories;
      this.observers = observers;
    }

    public static Contract fromIdAndRecord(String contractId, DamlRecord record$,
        Optional<String> agreementText, Optional<Id> key, Set<String> signatories,
        Set<String> observers) {
      ContractId id = new ContractId(contractId);
      DvpSettlementRule data = DvpSettlementRule.fromValue(record$);
      return new Contract(id, data, agreementText, key, signatories, observers);
    }

    @Deprecated
    public static Contract fromIdAndRecord(String contractId, DamlRecord record$) {
      ContractId id = new ContractId(contractId);
      DvpSettlementRule data = DvpSettlementRule.fromValue(record$);
      return new Contract(id, data, Optional.empty(), Optional.empty(), Collections.emptySet(), Collections.emptySet());
    }

    public static Contract fromCreatedEvent(CreatedEvent event) {
      return fromIdAndRecord(event.getContractId(), event.getArguments(), event.getAgreementText(), event.getContractKey().map(e -> Id.fromValue(e)), event.getSignatories(), event.getObservers());
    }

    @Override
    public boolean equals(Object object) {
      if (this == object) {
        return true;
      }
      if (object == null) {
        return false;
      }
      if (!(object instanceof Contract)) {
        return false;
      }
      Contract other = (Contract) object;
      return this.id.equals(other.id) && this.data.equals(other.data) && this.agreementText.equals(other.agreementText) && this.key.equals(other.key) && this.signatories.equals(other.signatories) && this.observers.equals(other.observers);
    }

    @Override
    public int hashCode() {
      return Objects.hash(this.id, this.data, this.agreementText, this.key, this.signatories, this.observers);
    }

    @Override
    public String toString() {
      return String.format("com.daml.generated.da.finance.trade.dvp.settlement.DvpSettlementRule.Contract(%s, %s, %s, %s, %s, %s)", this.id, this.data, this.agreementText, this.key, this.signatories, this.observers);
    }
  }
}
