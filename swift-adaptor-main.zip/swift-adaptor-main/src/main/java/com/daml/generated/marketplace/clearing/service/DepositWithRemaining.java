package com.daml.generated.marketplace.clearing.service;

import com.daml.generated.da.finance.asset.AssetDeposit;
import com.daml.ledger.javaapi.data.DamlCollectors;
import com.daml.ledger.javaapi.data.DamlRecord;
import com.daml.ledger.javaapi.data.Value;
import java.lang.IllegalArgumentException;
import java.lang.Object;
import java.lang.Override;
import java.lang.String;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

public class DepositWithRemaining {
  public static final String _packageId = "636e6e778aedec0710919591e9cb2a9404d6daab0581e4ddc515eeae03256f45";

  public final AssetDeposit.ContractId deposit;

  public final List<AssetDeposit.ContractId> remaining;

  public DepositWithRemaining(AssetDeposit.ContractId deposit,
      List<AssetDeposit.ContractId> remaining) {
    this.deposit = deposit;
    this.remaining = remaining;
  }

  public static DepositWithRemaining fromValue(Value value$) throws IllegalArgumentException {
    Value recordValue$ = value$;
    DamlRecord record$ = recordValue$.asRecord().orElseThrow(() -> new IllegalArgumentException("Contracts must be constructed from Records"));
    List<DamlRecord.Field> fields$ = record$.getFields();
    int numberOfFields = fields$.size();
    if (numberOfFields != 2) {
      throw new IllegalArgumentException("Expected 2 arguments, got " + numberOfFields);
    }
    AssetDeposit.ContractId deposit = new AssetDeposit.ContractId(fields$.get(0).getValue().asContractId().orElseThrow(() -> new IllegalArgumentException("Expected deposit to be of type com.daml.ledger.javaapi.data.ContractId")).getValue());
    List<AssetDeposit.ContractId> remaining = fields$.get(1).getValue().asList()
            .map(v$0 -> v$0.toList(v$1 ->
                new AssetDeposit.ContractId(v$1.asContractId().orElseThrow(() -> new IllegalArgumentException("Expected v$1 to be of type com.daml.ledger.javaapi.data.ContractId")).getValue())
            ))
            .orElseThrow(() -> new IllegalArgumentException("Expected remaining to be of type com.daml.ledger.javaapi.data.DamlList"))
        ;
    return new com.daml.generated.marketplace.clearing.service.DepositWithRemaining(deposit, remaining);
  }

  public DamlRecord toValue() {
    ArrayList<DamlRecord.Field> fields = new ArrayList<DamlRecord.Field>(2);
    fields.add(new DamlRecord.Field("deposit", this.deposit.toValue()));
    fields.add(new DamlRecord.Field("remaining", this.remaining.stream().collect(DamlCollectors.toDamlList(v$0 -> v$0.toValue()))));
    return new DamlRecord(fields);
  }

  @Override
  public boolean equals(Object object) {
    if (this == object) {
      return true;
    }
    if (object == null) {
      return false;
    }
    if (!(object instanceof DepositWithRemaining)) {
      return false;
    }
    DepositWithRemaining other = (DepositWithRemaining) object;
    return this.deposit.equals(other.deposit) && this.remaining.equals(other.remaining);
  }

  @Override
  public int hashCode() {
    return Objects.hash(this.deposit, this.remaining);
  }

  @Override
  public String toString() {
    return String.format("com.daml.generated.marketplace.clearing.service.DepositWithRemaining(%s, %s)", this.deposit, this.remaining);
  }
}
