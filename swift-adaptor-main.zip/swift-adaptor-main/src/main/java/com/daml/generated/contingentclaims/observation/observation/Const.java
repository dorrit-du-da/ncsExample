package com.daml.generated.contingentclaims.observation.observation;

import com.daml.generated.contingentclaims.observation.Observation;
import com.daml.ledger.javaapi.data.DamlRecord;
import com.daml.ledger.javaapi.data.Value;
import com.daml.ledger.javaapi.data.Variant;
import java.lang.IllegalArgumentException;
import java.lang.Object;
import java.lang.Override;
import java.lang.String;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.function.Function;

public class Const<t, x> extends Observation<t, x> {
  public static final String _packageId = "636e6e778aedec0710919591e9cb2a9404d6daab0581e4ddc515eeae03256f45";

  public final x value;

  public Const(x value) {
    this.value = value;
  }

  public Variant toValue(Function<x, Value> toValuex) {
    ArrayList<DamlRecord.Field> fields = new ArrayList<DamlRecord.Field>(1);
    fields.add(new DamlRecord.Field("value", toValuex.apply(this.value)));
    return new Variant("Const", new DamlRecord(fields));
  }

  public static <t, x> Const<t, x> fromValue(Value value$, Function<Value, x> fromValuex) throws
      IllegalArgumentException {
    Variant variant$ = value$.asVariant().orElseThrow(() -> new IllegalArgumentException("Expected: Variant. Actual: " + value$.getClass().getName()));
    if (!"Const".equals(variant$.getConstructor())) throw new IllegalArgumentException("Invalid constructor. Expected: Const. Actual: " + variant$.getConstructor());
    Value recordValue$ = variant$.getValue();
    DamlRecord record$ = recordValue$.asRecord().orElseThrow(() -> new IllegalArgumentException("Contracts must be constructed from Records"));
    List<DamlRecord.Field> fields$ = record$.getFields();
    int numberOfFields = fields$.size();
    if (numberOfFields != 1) {
      throw new IllegalArgumentException("Expected 1 arguments, got " + numberOfFields);
    }
    x value = fromValuex.apply(fields$.get(0).getValue());
    return new Const<t, x>(value);
  }

  public Variant toValue(Function<t, Value> toValuet, Function<x, Value> toValuex) {
    ArrayList<DamlRecord.Field> fields = new ArrayList<DamlRecord.Field>(1);
    fields.add(new DamlRecord.Field("value", toValuex.apply(this.value)));
    return new Variant("Const", new DamlRecord(fields));
  }

  public static <t, x> Const<t, x> fromValue(Value value$, Function<Value, t> fromValuet,
      Function<Value, x> fromValuex) throws IllegalArgumentException {
    Variant variant$ = value$.asVariant().orElseThrow(() -> new IllegalArgumentException("Expected: Variant. Actual: " + value$.getClass().getName()));
    if (!"Const".equals(variant$.getConstructor())) throw new IllegalArgumentException("Invalid constructor. Expected: Const. Actual: " + variant$.getConstructor());
    Value recordValue$ = variant$.getValue();
    DamlRecord record$ = recordValue$.asRecord().orElseThrow(() -> new IllegalArgumentException("Contracts must be constructed from Records"));
    List<DamlRecord.Field> fields$ = record$.getFields();
    int numberOfFields = fields$.size();
    if (numberOfFields != 1) {
      throw new IllegalArgumentException("Expected 1 arguments, got " + numberOfFields);
    }
    x value = fromValuex.apply(fields$.get(0).getValue());
    return new Const<t, x>(value);
  }

  @Override
  public boolean equals(Object object) {
    if (this == object) {
      return true;
    }
    if (object == null) {
      return false;
    }
    if (!(object instanceof Const<?, ?>)) {
      return false;
    }
    Const<?, ?> other = (Const<?, ?>) object;
    return this.value.equals(other.value);
  }

  @Override
  public int hashCode() {
    return Objects.hash(this.value);
  }

  @Override
  public String toString() {
    return String.format("Const(%s)", this.value);
  }
}
