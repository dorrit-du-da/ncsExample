package com.daml.generated.contingentclaims.claim.serializable;

import com.daml.ledger.javaapi.data.Value;
import com.daml.ledger.javaapi.data.Variant;
import java.lang.String;
import java.util.function.Function;

public abstract class Inequality<t, x> {
  public static final String _packageId = "636e6e778aedec0710919591e9cb2a9404d6daab0581e4ddc515eeae03256f45";

  public Inequality() {
  }

  public abstract Value toValue(Function<t, Value> toValuet, Function<x, Value> toValuex);

  public static <t, x> Inequality<t, x> fromValue(Value value$, Function<Value, t> fromValuet,
      Function<Value, x> fromValuex) {
    Variant variant$ = value$.asVariant().orElseThrow(() -> new IllegalArgumentException("Expected Variant to build an instance of the Variant com.daml.generated.contingentclaims.claim.serializable.Inequality"));
    if ("TimeGte".equals(variant$.getConstructor())) {
      return com.daml.generated.contingentclaims.claim.serializable.inequality.TimeGte.fromValue(variant$, fromValuet, fromValuex);
    }
    if ("Lte".equals(variant$.getConstructor())) {
      return com.daml.generated.contingentclaims.claim.serializable.inequality.Lte.fromValue(variant$, fromValuet, fromValuex);
    }
    throw new IllegalArgumentException("Found unknown constructor variant$.getConstructor() for variant com.daml.generated.contingentclaims.claim.serializable.Inequality, expected one of [TimeGte, Lte]");
  }
}
