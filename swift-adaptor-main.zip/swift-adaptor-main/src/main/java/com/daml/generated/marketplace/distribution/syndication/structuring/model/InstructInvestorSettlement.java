package com.daml.generated.marketplace.distribution.syndication.structuring.model;

import com.daml.generated.marketplace.distribution.syndication.bidding.model.Confirmation;
import com.daml.ledger.javaapi.data.DamlCollectors;
import com.daml.ledger.javaapi.data.DamlRecord;
import com.daml.ledger.javaapi.data.Date;
import com.daml.ledger.javaapi.data.Numeric;
import com.daml.ledger.javaapi.data.Value;
import java.lang.IllegalArgumentException;
import java.lang.Object;
import java.lang.Override;
import java.lang.String;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

public class InstructInvestorSettlement {
  public static final String _packageId = "636e6e778aedec0710919591e9cb2a9404d6daab0581e4ddc515eeae03256f45";

  public final List<Confirmation.ContractId> confirmationCids;

  public final BigDecimal price;

  public final LocalDate dateOfTrade;

  public final LocalDate dateOfSettlement;

  public InstructInvestorSettlement(List<Confirmation.ContractId> confirmationCids,
      BigDecimal price, LocalDate dateOfTrade, LocalDate dateOfSettlement) {
    this.confirmationCids = confirmationCids;
    this.price = price;
    this.dateOfTrade = dateOfTrade;
    this.dateOfSettlement = dateOfSettlement;
  }

  public static InstructInvestorSettlement fromValue(Value value$) throws IllegalArgumentException {
    Value recordValue$ = value$;
    DamlRecord record$ = recordValue$.asRecord().orElseThrow(() -> new IllegalArgumentException("Contracts must be constructed from Records"));
    List<DamlRecord.Field> fields$ = record$.getFields();
    int numberOfFields = fields$.size();
    if (numberOfFields != 4) {
      throw new IllegalArgumentException("Expected 4 arguments, got " + numberOfFields);
    }
    List<Confirmation.ContractId> confirmationCids = fields$.get(0).getValue().asList()
            .map(v$0 -> v$0.toList(v$1 ->
                new Confirmation.ContractId(v$1.asContractId().orElseThrow(() -> new IllegalArgumentException("Expected v$1 to be of type com.daml.ledger.javaapi.data.ContractId")).getValue())
            ))
            .orElseThrow(() -> new IllegalArgumentException("Expected confirmationCids to be of type com.daml.ledger.javaapi.data.DamlList"))
        ;
    BigDecimal price = fields$.get(1).getValue().asNumeric().orElseThrow(() -> new IllegalArgumentException("Expected price to be of type com.daml.ledger.javaapi.data.Numeric")).getValue();
    LocalDate dateOfTrade = fields$.get(2).getValue().asDate().orElseThrow(() -> new IllegalArgumentException("Expected dateOfTrade to be of type com.daml.ledger.javaapi.data.Date")).getValue();
    LocalDate dateOfSettlement = fields$.get(3).getValue().asDate().orElseThrow(() -> new IllegalArgumentException("Expected dateOfSettlement to be of type com.daml.ledger.javaapi.data.Date")).getValue();
    return new com.daml.generated.marketplace.distribution.syndication.structuring.model.InstructInvestorSettlement(confirmationCids, price, dateOfTrade, dateOfSettlement);
  }

  public DamlRecord toValue() {
    ArrayList<DamlRecord.Field> fields = new ArrayList<DamlRecord.Field>(4);
    fields.add(new DamlRecord.Field("confirmationCids", this.confirmationCids.stream().collect(DamlCollectors.toDamlList(v$0 -> v$0.toValue()))));
    fields.add(new DamlRecord.Field("price", new Numeric(this.price)));
    fields.add(new DamlRecord.Field("dateOfTrade", new Date((int) this.dateOfTrade.toEpochDay())));
    fields.add(new DamlRecord.Field("dateOfSettlement", new Date((int) this.dateOfSettlement.toEpochDay())));
    return new DamlRecord(fields);
  }

  @Override
  public boolean equals(Object object) {
    if (this == object) {
      return true;
    }
    if (object == null) {
      return false;
    }
    if (!(object instanceof InstructInvestorSettlement)) {
      return false;
    }
    InstructInvestorSettlement other = (InstructInvestorSettlement) object;
    return this.confirmationCids.equals(other.confirmationCids) && this.price.equals(other.price) && this.dateOfTrade.equals(other.dateOfTrade) && this.dateOfSettlement.equals(other.dateOfSettlement);
  }

  @Override
  public int hashCode() {
    return Objects.hash(this.confirmationCids, this.price, this.dateOfTrade, this.dateOfSettlement);
  }

  @Override
  public String toString() {
    return String.format("com.daml.generated.marketplace.distribution.syndication.structuring.model.InstructInvestorSettlement(%s, %s, %s, %s)", this.confirmationCids, this.price, this.dateOfTrade, this.dateOfSettlement);
  }
}
