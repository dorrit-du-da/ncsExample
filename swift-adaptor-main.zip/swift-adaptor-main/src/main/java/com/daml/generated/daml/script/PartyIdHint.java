package com.daml.generated.daml.script;

import com.daml.ledger.javaapi.data.DamlRecord;
import com.daml.ledger.javaapi.data.Text;
import com.daml.ledger.javaapi.data.Value;
import java.lang.IllegalArgumentException;
import java.lang.Object;
import java.lang.Override;
import java.lang.String;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

public class PartyIdHint {
  public static final String _packageId = "46fdb8cc2ec70b5a473a46b22690d60cc8c79fc2d9d185685f1238d0fa1edb2a";

  public final String partyIdHint;

  public PartyIdHint(String partyIdHint) {
    this.partyIdHint = partyIdHint;
  }

  public static PartyIdHint fromValue(Value value$) throws IllegalArgumentException {
    Value recordValue$ = value$;
    DamlRecord record$ = recordValue$.asRecord().orElseThrow(() -> new IllegalArgumentException("Contracts must be constructed from Records"));
    List<DamlRecord.Field> fields$ = record$.getFields();
    int numberOfFields = fields$.size();
    if (numberOfFields != 1) {
      throw new IllegalArgumentException("Expected 1 arguments, got " + numberOfFields);
    }
    String partyIdHint = fields$.get(0).getValue().asText().orElseThrow(() -> new IllegalArgumentException("Expected partyIdHint to be of type com.daml.ledger.javaapi.data.Text")).getValue();
    return new com.daml.generated.daml.script.PartyIdHint(partyIdHint);
  }

  public DamlRecord toValue() {
    ArrayList<DamlRecord.Field> fields = new ArrayList<DamlRecord.Field>(1);
    fields.add(new DamlRecord.Field("partyIdHint", new Text(this.partyIdHint)));
    return new DamlRecord(fields);
  }

  @Override
  public boolean equals(Object object) {
    if (this == object) {
      return true;
    }
    if (object == null) {
      return false;
    }
    if (!(object instanceof PartyIdHint)) {
      return false;
    }
    PartyIdHint other = (PartyIdHint) object;
    return this.partyIdHint.equals(other.partyIdHint);
  }

  @Override
  public int hashCode() {
    return Objects.hash(this.partyIdHint);
  }

  @Override
  public String toString() {
    return String.format("com.daml.generated.daml.script.PartyIdHint(%s)", this.partyIdHint);
  }
}
