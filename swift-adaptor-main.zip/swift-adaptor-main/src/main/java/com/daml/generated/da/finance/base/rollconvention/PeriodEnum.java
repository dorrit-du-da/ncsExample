package com.daml.generated.da.finance.base.rollconvention;

import com.daml.ledger.javaapi.data.DamlEnum;
import com.daml.ledger.javaapi.data.Value;
import java.lang.IllegalArgumentException;
import java.lang.String;
import java.util.HashMap;
import java.util.Map;

public enum PeriodEnum {
  D,

  M,

  W,

  Y;

  private static final DamlEnum[] __values$ = {new DamlEnum("D"), new DamlEnum("M"), new DamlEnum("W"), new DamlEnum("Y")};

  private static final Map<String, PeriodEnum> __enums$ = PeriodEnum.__buildEnumsMap$();

  private static final Map<String, PeriodEnum> __buildEnumsMap$() {
    Map<String, PeriodEnum> m = new HashMap<String, PeriodEnum>();
    m.put("D", D);
    m.put("M", M);
    m.put("W", W);
    m.put("Y", Y);
    return m;
  }

  public static final PeriodEnum fromValue(Value value$) {
    String constructor$ = value$.asEnum().orElseThrow(() -> new IllegalArgumentException("Expected DamlEnum to build an instance of the Enum PeriodEnum")).getConstructor();
    if (!PeriodEnum.__enums$.containsKey(constructor$)) throw new IllegalArgumentException("Expected a DamlEnum with PeriodEnum constructor, found " + constructor$);
    return (PeriodEnum) PeriodEnum.__enums$.get(constructor$);
  }

  public final DamlEnum toValue() {
    return PeriodEnum.__values$[ordinal()];
  }
}
