package com.daml.generated.da.finance.trade.settlementinstruction;

import com.daml.generated.da.finance.asset.AssetDeposit;
import com.daml.generated.da.finance.types.Account;
import com.daml.ledger.javaapi.data.DamlOptional;
import com.daml.ledger.javaapi.data.DamlRecord;
import com.daml.ledger.javaapi.data.Value;
import java.lang.IllegalArgumentException;
import java.lang.Object;
import java.lang.Override;
import java.lang.String;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.Optional;

public class SettlementDetails {
  public static final String _packageId = "636e6e778aedec0710919591e9cb2a9404d6daab0581e4ddc515eeae03256f45";

  public final Account senderAccount;

  public final Account receiverAccount;

  public final Optional<AssetDeposit.ContractId> depositCid;

  public SettlementDetails(Account senderAccount, Account receiverAccount,
      Optional<AssetDeposit.ContractId> depositCid) {
    this.senderAccount = senderAccount;
    this.receiverAccount = receiverAccount;
    this.depositCid = depositCid;
  }

  public static SettlementDetails fromValue(Value value$) throws IllegalArgumentException {
    Value recordValue$ = value$;
    DamlRecord record$ = recordValue$.asRecord().orElseThrow(() -> new IllegalArgumentException("Contracts must be constructed from Records"));
    List<DamlRecord.Field> fields$ = record$.getFields();
    int numberOfFields = fields$.size();
    if (numberOfFields != 3) {
      throw new IllegalArgumentException("Expected 3 arguments, got " + numberOfFields);
    }
    Account senderAccount = Account.fromValue(fields$.get(0).getValue());
    Account receiverAccount = Account.fromValue(fields$.get(1).getValue());
    Optional<AssetDeposit.ContractId> depositCid = fields$.get(2).getValue().asOptional()
            .map(v$0 -> v$0.toOptional(v$1 ->
                new AssetDeposit.ContractId(v$1.asContractId().orElseThrow(() -> new IllegalArgumentException("Expected v$1 to be of type com.daml.ledger.javaapi.data.ContractId")).getValue())
            ))
            .orElseThrow(() -> new IllegalArgumentException("Expected depositCid to be of type com.daml.ledger.javaapi.data.DamlOptional"))
                  ;
    return new com.daml.generated.da.finance.trade.settlementinstruction.SettlementDetails(senderAccount, receiverAccount, depositCid);
  }

  public DamlRecord toValue() {
    ArrayList<DamlRecord.Field> fields = new ArrayList<DamlRecord.Field>(3);
    fields.add(new DamlRecord.Field("senderAccount", this.senderAccount.toValue()));
    fields.add(new DamlRecord.Field("receiverAccount", this.receiverAccount.toValue()));
    fields.add(new DamlRecord.Field("depositCid", DamlOptional.of(this.depositCid.map(v$0 -> v$0.toValue()))));
    return new DamlRecord(fields);
  }

  @Override
  public boolean equals(Object object) {
    if (this == object) {
      return true;
    }
    if (object == null) {
      return false;
    }
    if (!(object instanceof SettlementDetails)) {
      return false;
    }
    SettlementDetails other = (SettlementDetails) object;
    return this.senderAccount.equals(other.senderAccount) && this.receiverAccount.equals(other.receiverAccount) && this.depositCid.equals(other.depositCid);
  }

  @Override
  public int hashCode() {
    return Objects.hash(this.senderAccount, this.receiverAccount, this.depositCid);
  }

  @Override
  public String toString() {
    return String.format("com.daml.generated.da.finance.trade.settlementinstruction.SettlementDetails(%s, %s, %s)", this.senderAccount, this.receiverAccount, this.depositCid);
  }
}
