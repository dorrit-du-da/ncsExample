package com.daml.generated.contingentclaims.claim.serializable;

import com.daml.ledger.javaapi.data.Value;
import com.daml.ledger.javaapi.data.Variant;
import java.lang.String;
import java.util.function.Function;

public abstract class Claim<t, x, a> {
  public static final String _packageId = "636e6e778aedec0710919591e9cb2a9404d6daab0581e4ddc515eeae03256f45";

  public Claim() {
  }

  public abstract Value toValue(Function<t, Value> toValuet, Function<x, Value> toValuex,
      Function<a, Value> toValuea);

  public static <t, x, a> Claim<t, x, a> fromValue(Value value$, Function<Value, t> fromValuet,
      Function<Value, x> fromValuex, Function<Value, a> fromValuea) {
    Variant variant$ = value$.asVariant().orElseThrow(() -> new IllegalArgumentException("Expected Variant to build an instance of the Variant com.daml.generated.contingentclaims.claim.serializable.Claim"));
    if ("Zero".equals(variant$.getConstructor())) {
      return com.daml.generated.contingentclaims.claim.serializable.claim.Zero.fromValue(variant$, fromValuet, fromValuex, fromValuea);
    }
    if ("One".equals(variant$.getConstructor())) {
      return com.daml.generated.contingentclaims.claim.serializable.claim.One.fromValue(variant$, fromValuet, fromValuex, fromValuea);
    }
    if ("Give".equals(variant$.getConstructor())) {
      return com.daml.generated.contingentclaims.claim.serializable.claim.Give.fromValue(variant$, fromValuet, fromValuex, fromValuea);
    }
    if ("And".equals(variant$.getConstructor())) {
      return com.daml.generated.contingentclaims.claim.serializable.claim.And.fromValue(variant$, fromValuet, fromValuex, fromValuea);
    }
    if ("Or".equals(variant$.getConstructor())) {
      return com.daml.generated.contingentclaims.claim.serializable.claim.Or.fromValue(variant$, fromValuet, fromValuex, fromValuea);
    }
    if ("Cond".equals(variant$.getConstructor())) {
      return com.daml.generated.contingentclaims.claim.serializable.claim.Cond.fromValue(variant$, fromValuet, fromValuex, fromValuea);
    }
    if ("Scale".equals(variant$.getConstructor())) {
      return com.daml.generated.contingentclaims.claim.serializable.claim.Scale.fromValue(variant$, fromValuet, fromValuex, fromValuea);
    }
    if ("When".equals(variant$.getConstructor())) {
      return com.daml.generated.contingentclaims.claim.serializable.claim.When.fromValue(variant$, fromValuet, fromValuex, fromValuea);
    }
    if ("Anytime".equals(variant$.getConstructor())) {
      return com.daml.generated.contingentclaims.claim.serializable.claim.Anytime.fromValue(variant$, fromValuet, fromValuex, fromValuea);
    }
    if ("Until".equals(variant$.getConstructor())) {
      return com.daml.generated.contingentclaims.claim.serializable.claim.Until.fromValue(variant$, fromValuet, fromValuex, fromValuea);
    }
    throw new IllegalArgumentException("Found unknown constructor variant$.getConstructor() for variant com.daml.generated.contingentclaims.claim.serializable.Claim, expected one of [Zero, One, Give, And, Or, Cond, Scale, When, Anytime, Until]");
  }
}
