package com.daml.generated.contingentclaims.claim.serializable.claim;

import com.daml.generated.contingentclaims.claim.serializable.Claim;
import com.daml.generated.contingentclaims.observation.Observation;
import com.daml.ledger.javaapi.data.DamlRecord;
import com.daml.ledger.javaapi.data.Value;
import com.daml.ledger.javaapi.data.Variant;
import java.lang.IllegalArgumentException;
import java.lang.Object;
import java.lang.Override;
import java.lang.String;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.function.Function;

public class Scale<t, x, a> extends Claim<t, x, a> {
  public static final String _packageId = "636e6e778aedec0710919591e9cb2a9404d6daab0581e4ddc515eeae03256f45";

  public final Observation<t, x> k;

  public final Claim<t, x, a> claim;

  public Scale(Observation<t, x> k, Claim<t, x, a> claim) {
    this.k = k;
    this.claim = claim;
  }

  public Variant toValue(Function<t, Value> toValuet, Function<x, Value> toValuex,
      Function<a, Value> toValuea) {
    ArrayList<DamlRecord.Field> fields = new ArrayList<DamlRecord.Field>(2);
    fields.add(new DamlRecord.Field("k", this.k.toValue(v$0 -> toValuet.apply(v$0),v$1 -> toValuex.apply(v$1))));
    fields.add(new DamlRecord.Field("claim", this.claim.toValue(v$0 -> toValuet.apply(v$0),v$1 -> toValuex.apply(v$1),v$2 -> toValuea.apply(v$2))));
    return new Variant("Scale", new DamlRecord(fields));
  }

  public static <t, x, a> Scale<t, x, a> fromValue(Value value$, Function<Value, t> fromValuet,
      Function<Value, x> fromValuex, Function<Value, a> fromValuea) throws
      IllegalArgumentException {
    Variant variant$ = value$.asVariant().orElseThrow(() -> new IllegalArgumentException("Expected: Variant. Actual: " + value$.getClass().getName()));
    if (!"Scale".equals(variant$.getConstructor())) throw new IllegalArgumentException("Invalid constructor. Expected: Scale. Actual: " + variant$.getConstructor());
    Value recordValue$ = variant$.getValue();
    DamlRecord record$ = recordValue$.asRecord().orElseThrow(() -> new IllegalArgumentException("Contracts must be constructed from Records"));
    List<DamlRecord.Field> fields$ = record$.getFields();
    int numberOfFields = fields$.size();
    if (numberOfFields != 2) {
      throw new IllegalArgumentException("Expected 2 arguments, got " + numberOfFields);
    }
    Observation<t, x> k = Observation.<t, x>fromValue(fields$.get(0).getValue(), v$0 -> fromValuet.apply(v$0), v$1 -> fromValuex.apply(v$1));
    Claim<t, x, a> claim = Claim.<t, x, a>fromValue(fields$.get(1).getValue(), v$0 -> fromValuet.apply(v$0), v$1 -> fromValuex.apply(v$1), v$2 -> fromValuea.apply(v$2));
    return new Scale<t, x, a>(k, claim);
  }

  @Override
  public boolean equals(Object object) {
    if (this == object) {
      return true;
    }
    if (object == null) {
      return false;
    }
    if (!(object instanceof Scale<?, ?, ?>)) {
      return false;
    }
    Scale<?, ?, ?> other = (Scale<?, ?, ?>) object;
    return this.k.equals(other.k) && this.claim.equals(other.claim);
  }

  @Override
  public int hashCode() {
    return Objects.hash(this.k, this.claim);
  }

  @Override
  public String toString() {
    return String.format("Scale(%s, %s)", this.k, this.claim);
  }
}
