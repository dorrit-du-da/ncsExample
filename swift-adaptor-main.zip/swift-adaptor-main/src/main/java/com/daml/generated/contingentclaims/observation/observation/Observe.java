package com.daml.generated.contingentclaims.observation.observation;

import com.daml.generated.contingentclaims.observation.Observation;
import com.daml.ledger.javaapi.data.DamlRecord;
import com.daml.ledger.javaapi.data.Text;
import com.daml.ledger.javaapi.data.Value;
import com.daml.ledger.javaapi.data.Variant;
import java.lang.IllegalArgumentException;
import java.lang.Object;
import java.lang.Override;
import java.lang.String;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.function.Function;

public class Observe<t, x> extends Observation<t, x> {
  public static final String _packageId = "636e6e778aedec0710919591e9cb2a9404d6daab0581e4ddc515eeae03256f45";

  public final String key;

  public Observe(String key) {
    this.key = key;
  }

  public Variant toValue() {
    ArrayList<DamlRecord.Field> fields = new ArrayList<DamlRecord.Field>(1);
    fields.add(new DamlRecord.Field("key", new Text(this.key)));
    return new Variant("Observe", new DamlRecord(fields));
  }

  public static <t, x> Observe<t, x> fromValue(Value value$) throws IllegalArgumentException {
    Variant variant$ = value$.asVariant().orElseThrow(() -> new IllegalArgumentException("Expected: Variant. Actual: " + value$.getClass().getName()));
    if (!"Observe".equals(variant$.getConstructor())) throw new IllegalArgumentException("Invalid constructor. Expected: Observe. Actual: " + variant$.getConstructor());
    Value recordValue$ = variant$.getValue();
    DamlRecord record$ = recordValue$.asRecord().orElseThrow(() -> new IllegalArgumentException("Contracts must be constructed from Records"));
    List<DamlRecord.Field> fields$ = record$.getFields();
    int numberOfFields = fields$.size();
    if (numberOfFields != 1) {
      throw new IllegalArgumentException("Expected 1 arguments, got " + numberOfFields);
    }
    String key = fields$.get(0).getValue().asText().orElseThrow(() -> new IllegalArgumentException("Expected key to be of type com.daml.ledger.javaapi.data.Text")).getValue();
    return new Observe<t, x>(key);
  }

  public Variant toValue(Function<t, Value> toValuet, Function<x, Value> toValuex) {
    ArrayList<DamlRecord.Field> fields = new ArrayList<DamlRecord.Field>(1);
    fields.add(new DamlRecord.Field("key", new Text(this.key)));
    return new Variant("Observe", new DamlRecord(fields));
  }

  public static <t, x> Observe<t, x> fromValue(Value value$, Function<Value, t> fromValuet,
      Function<Value, x> fromValuex) throws IllegalArgumentException {
    Variant variant$ = value$.asVariant().orElseThrow(() -> new IllegalArgumentException("Expected: Variant. Actual: " + value$.getClass().getName()));
    if (!"Observe".equals(variant$.getConstructor())) throw new IllegalArgumentException("Invalid constructor. Expected: Observe. Actual: " + variant$.getConstructor());
    Value recordValue$ = variant$.getValue();
    DamlRecord record$ = recordValue$.asRecord().orElseThrow(() -> new IllegalArgumentException("Contracts must be constructed from Records"));
    List<DamlRecord.Field> fields$ = record$.getFields();
    int numberOfFields = fields$.size();
    if (numberOfFields != 1) {
      throw new IllegalArgumentException("Expected 1 arguments, got " + numberOfFields);
    }
    String key = fields$.get(0).getValue().asText().orElseThrow(() -> new IllegalArgumentException("Expected key to be of type com.daml.ledger.javaapi.data.Text")).getValue();
    return new Observe<t, x>(key);
  }

  @Override
  public boolean equals(Object object) {
    if (this == object) {
      return true;
    }
    if (object == null) {
      return false;
    }
    if (!(object instanceof Observe<?, ?>)) {
      return false;
    }
    Observe<?, ?> other = (Observe<?, ?>) object;
    return this.key.equals(other.key);
  }

  @Override
  public int hashCode() {
    return Objects.hash(this.key);
  }

  @Override
  public String toString() {
    return String.format("Observe(%s)", this.key);
  }
}
