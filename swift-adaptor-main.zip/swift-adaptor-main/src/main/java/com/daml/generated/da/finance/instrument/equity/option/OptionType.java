package com.daml.generated.da.finance.instrument.equity.option;

import com.daml.ledger.javaapi.data.DamlEnum;
import com.daml.ledger.javaapi.data.Value;
import java.lang.IllegalArgumentException;
import java.lang.String;
import java.util.HashMap;
import java.util.Map;

public enum OptionType {
  PUT,

  CALL;

  private static final DamlEnum[] __values$ = {new DamlEnum("PUT"), new DamlEnum("CALL")};

  private static final Map<String, OptionType> __enums$ = OptionType.__buildEnumsMap$();

  private static final Map<String, OptionType> __buildEnumsMap$() {
    Map<String, OptionType> m = new HashMap<String, OptionType>();
    m.put("PUT", PUT);
    m.put("CALL", CALL);
    return m;
  }

  public static final OptionType fromValue(Value value$) {
    String constructor$ = value$.asEnum().orElseThrow(() -> new IllegalArgumentException("Expected DamlEnum to build an instance of the Enum OptionType")).getConstructor();
    if (!OptionType.__enums$.containsKey(constructor$)) throw new IllegalArgumentException("Expected a DamlEnum with OptionType constructor, found " + constructor$);
    return (OptionType) OptionType.__enums$.get(constructor$);
  }

  public final DamlEnum toValue() {
    return OptionType.__values$[ordinal()];
  }
}
