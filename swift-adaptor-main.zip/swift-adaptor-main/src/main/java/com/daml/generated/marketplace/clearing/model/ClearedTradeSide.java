package com.daml.generated.marketplace.clearing.model;

import com.daml.generated.da.internal.template.Archive;
import com.daml.generated.marketplace.trading.model.Execution;
import com.daml.generated.marketplace.trading.model.Order;
import com.daml.ledger.javaapi.data.CreateAndExerciseCommand;
import com.daml.ledger.javaapi.data.CreateCommand;
import com.daml.ledger.javaapi.data.CreatedEvent;
import com.daml.ledger.javaapi.data.DamlRecord;
import com.daml.ledger.javaapi.data.ExerciseCommand;
import com.daml.ledger.javaapi.data.Identifier;
import com.daml.ledger.javaapi.data.Party;
import com.daml.ledger.javaapi.data.Template;
import com.daml.ledger.javaapi.data.Timestamp;
import com.daml.ledger.javaapi.data.Value;
import java.lang.Deprecated;
import java.lang.IllegalArgumentException;
import java.lang.Object;
import java.lang.Override;
import java.lang.String;
import java.time.Instant;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.Set;

public final class ClearedTradeSide extends Template {
  public static final Identifier TEMPLATE_ID = new Identifier("636e6e778aedec0710919591e9cb2a9404d6daab0581e4ddc515eeae03256f45", "Marketplace.Clearing.Model", "ClearedTradeSide");

  public final String clearinghouse;

  public final String exchange;

  public final String participant;

  public final Order order;

  public final Execution execution;

  public final Instant timeNovated;

  public ClearedTradeSide(String clearinghouse, String exchange, String participant, Order order,
      Execution execution, Instant timeNovated) {
    this.clearinghouse = clearinghouse;
    this.exchange = exchange;
    this.participant = participant;
    this.order = order;
    this.execution = execution;
    this.timeNovated = timeNovated;
  }

  public CreateCommand create() {
    return new CreateCommand(ClearedTradeSide.TEMPLATE_ID, this.toValue());
  }

  public CreateAndExerciseCommand createAndExerciseArchive(Archive arg) {
    Value argValue = arg.toValue();
    return new CreateAndExerciseCommand(ClearedTradeSide.TEMPLATE_ID, this.toValue(), "Archive", argValue);
  }

  public static CreateCommand create(String clearinghouse, String exchange, String participant,
      Order order, Execution execution, Instant timeNovated) {
    return new ClearedTradeSide(clearinghouse, exchange, participant, order, execution, timeNovated).create();
  }

  public static ClearedTradeSide fromValue(Value value$) throws IllegalArgumentException {
    Value recordValue$ = value$;
    DamlRecord record$ = recordValue$.asRecord().orElseThrow(() -> new IllegalArgumentException("Contracts must be constructed from Records"));
    List<DamlRecord.Field> fields$ = record$.getFields();
    int numberOfFields = fields$.size();
    if (numberOfFields != 6) {
      throw new IllegalArgumentException("Expected 6 arguments, got " + numberOfFields);
    }
    String clearinghouse = fields$.get(0).getValue().asParty().orElseThrow(() -> new IllegalArgumentException("Expected clearinghouse to be of type com.daml.ledger.javaapi.data.Party")).getValue();
    String exchange = fields$.get(1).getValue().asParty().orElseThrow(() -> new IllegalArgumentException("Expected exchange to be of type com.daml.ledger.javaapi.data.Party")).getValue();
    String participant = fields$.get(2).getValue().asParty().orElseThrow(() -> new IllegalArgumentException("Expected participant to be of type com.daml.ledger.javaapi.data.Party")).getValue();
    Order order = Order.fromValue(fields$.get(3).getValue());
    Execution execution = Execution.fromValue(fields$.get(4).getValue());
    Instant timeNovated = fields$.get(5).getValue().asTimestamp().orElseThrow(() -> new IllegalArgumentException("Expected timeNovated to be of type com.daml.ledger.javaapi.data.Timestamp")).getValue();
    return new com.daml.generated.marketplace.clearing.model.ClearedTradeSide(clearinghouse, exchange, participant, order, execution, timeNovated);
  }

  public DamlRecord toValue() {
    ArrayList<DamlRecord.Field> fields = new ArrayList<DamlRecord.Field>(6);
    fields.add(new DamlRecord.Field("clearinghouse", new Party(this.clearinghouse)));
    fields.add(new DamlRecord.Field("exchange", new Party(this.exchange)));
    fields.add(new DamlRecord.Field("participant", new Party(this.participant)));
    fields.add(new DamlRecord.Field("order", this.order.toValue()));
    fields.add(new DamlRecord.Field("execution", this.execution.toValue()));
    fields.add(new DamlRecord.Field("timeNovated", Timestamp.fromInstant(this.timeNovated)));
    return new DamlRecord(fields);
  }

  @Override
  public boolean equals(Object object) {
    if (this == object) {
      return true;
    }
    if (object == null) {
      return false;
    }
    if (!(object instanceof ClearedTradeSide)) {
      return false;
    }
    ClearedTradeSide other = (ClearedTradeSide) object;
    return this.clearinghouse.equals(other.clearinghouse) && this.exchange.equals(other.exchange) && this.participant.equals(other.participant) && this.order.equals(other.order) && this.execution.equals(other.execution) && this.timeNovated.equals(other.timeNovated);
  }

  @Override
  public int hashCode() {
    return Objects.hash(this.clearinghouse, this.exchange, this.participant, this.order, this.execution, this.timeNovated);
  }

  @Override
  public String toString() {
    return String.format("com.daml.generated.marketplace.clearing.model.ClearedTradeSide(%s, %s, %s, %s, %s, %s)", this.clearinghouse, this.exchange, this.participant, this.order, this.execution, this.timeNovated);
  }

  public static final class ContractId extends com.daml.ledger.javaapi.data.codegen.ContractId<ClearedTradeSide> {
    public ContractId(String contractId) {
      super(contractId);
    }

    public ExerciseCommand exerciseArchive(Archive arg) {
      Value argValue = arg.toValue();
      return new ExerciseCommand(ClearedTradeSide.TEMPLATE_ID, this.contractId, "Archive", argValue);
    }
  }

  public static class Contract implements com.daml.ledger.javaapi.data.Contract {
    public final ContractId id;

    public final ClearedTradeSide data;

    public final Optional<String> agreementText;

    public final Set<String> signatories;

    public final Set<String> observers;

    public Contract(ContractId id, ClearedTradeSide data, Optional<String> agreementText,
        Set<String> signatories, Set<String> observers) {
      this.id = id;
      this.data = data;
      this.agreementText = agreementText;
      this.signatories = signatories;
      this.observers = observers;
    }

    public static Contract fromIdAndRecord(String contractId, DamlRecord record$,
        Optional<String> agreementText, Set<String> signatories, Set<String> observers) {
      ContractId id = new ContractId(contractId);
      ClearedTradeSide data = ClearedTradeSide.fromValue(record$);
      return new Contract(id, data, agreementText, signatories, observers);
    }

    @Deprecated
    public static Contract fromIdAndRecord(String contractId, DamlRecord record$) {
      ContractId id = new ContractId(contractId);
      ClearedTradeSide data = ClearedTradeSide.fromValue(record$);
      return new Contract(id, data, Optional.empty(), Collections.emptySet(), Collections.emptySet());
    }

    public static Contract fromCreatedEvent(CreatedEvent event) {
      return fromIdAndRecord(event.getContractId(), event.getArguments(), event.getAgreementText(), event.getSignatories(), event.getObservers());
    }

    @Override
    public boolean equals(Object object) {
      if (this == object) {
        return true;
      }
      if (object == null) {
        return false;
      }
      if (!(object instanceof Contract)) {
        return false;
      }
      Contract other = (Contract) object;
      return this.id.equals(other.id) && this.data.equals(other.data) && this.agreementText.equals(other.agreementText) && this.signatories.equals(other.signatories) && this.observers.equals(other.observers);
    }

    @Override
    public int hashCode() {
      return Objects.hash(this.id, this.data, this.agreementText, this.signatories, this.observers);
    }

    @Override
    public String toString() {
      return String.format("com.daml.generated.marketplace.clearing.model.ClearedTradeSide.Contract(%s, %s, %s, %s, %s)", this.id, this.data, this.agreementText, this.signatories, this.observers);
    }
  }
}
