package com.daml.generated.daml.data.ior.ior;

import com.daml.generated.daml.data.ior.IOr;
import com.daml.ledger.javaapi.data.DamlRecord;
import com.daml.ledger.javaapi.data.Value;
import com.daml.ledger.javaapi.data.Variant;
import java.lang.IllegalArgumentException;
import java.lang.Object;
import java.lang.Override;
import java.lang.String;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.function.Function;

public class Both<a, b> extends IOr<a, b> {
  public static final String _packageId = "636e6e778aedec0710919591e9cb2a9404d6daab0581e4ddc515eeae03256f45";

  public final a left;

  public final b right;

  public Both(a left, b right) {
    this.left = left;
    this.right = right;
  }

  public Variant toValue(Function<a, Value> toValuea, Function<b, Value> toValueb) {
    ArrayList<DamlRecord.Field> fields = new ArrayList<DamlRecord.Field>(2);
    fields.add(new DamlRecord.Field("left", toValuea.apply(this.left)));
    fields.add(new DamlRecord.Field("right", toValueb.apply(this.right)));
    return new Variant("Both", new DamlRecord(fields));
  }

  public static <a, b> Both<a, b> fromValue(Value value$, Function<Value, a> fromValuea,
      Function<Value, b> fromValueb) throws IllegalArgumentException {
    Variant variant$ = value$.asVariant().orElseThrow(() -> new IllegalArgumentException("Expected: Variant. Actual: " + value$.getClass().getName()));
    if (!"Both".equals(variant$.getConstructor())) throw new IllegalArgumentException("Invalid constructor. Expected: Both. Actual: " + variant$.getConstructor());
    Value recordValue$ = variant$.getValue();
    DamlRecord record$ = recordValue$.asRecord().orElseThrow(() -> new IllegalArgumentException("Contracts must be constructed from Records"));
    List<DamlRecord.Field> fields$ = record$.getFields();
    int numberOfFields = fields$.size();
    if (numberOfFields != 2) {
      throw new IllegalArgumentException("Expected 2 arguments, got " + numberOfFields);
    }
    a left = fromValuea.apply(fields$.get(0).getValue());
    b right = fromValueb.apply(fields$.get(1).getValue());
    return new Both<a, b>(left, right);
  }

  @Override
  public boolean equals(Object object) {
    if (this == object) {
      return true;
    }
    if (object == null) {
      return false;
    }
    if (!(object instanceof Both<?, ?>)) {
      return false;
    }
    Both<?, ?> other = (Both<?, ?>) object;
    return this.left.equals(other.left) && this.right.equals(other.right);
  }

  @Override
  public int hashCode() {
    return Objects.hash(this.left, this.right);
  }

  @Override
  public String toString() {
    return String.format("Both(%s, %s)", this.left, this.right);
  }
}
