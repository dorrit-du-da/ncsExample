package com.daml.generated.marketplace.clearing.market.service;

import com.daml.generated.da.finance.types.Id;
import com.daml.generated.da.internal.template.Archive;
import com.daml.generated.da.set.types.Set;
import com.daml.generated.da.types.Tuple3;
import com.daml.ledger.javaapi.data.CreateAndExerciseCommand;
import com.daml.ledger.javaapi.data.CreateCommand;
import com.daml.ledger.javaapi.data.CreatedEvent;
import com.daml.ledger.javaapi.data.DamlRecord;
import com.daml.ledger.javaapi.data.ExerciseByKeyCommand;
import com.daml.ledger.javaapi.data.ExerciseCommand;
import com.daml.ledger.javaapi.data.Identifier;
import com.daml.ledger.javaapi.data.Party;
import com.daml.ledger.javaapi.data.Template;
import com.daml.ledger.javaapi.data.Value;
import java.lang.Deprecated;
import java.lang.IllegalArgumentException;
import java.lang.Object;
import java.lang.Override;
import java.lang.String;
import java.math.BigDecimal;
import java.time.Instant;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Objects;
import java.util.Optional;

public final class Service extends Template {
  public static final Identifier TEMPLATE_ID = new Identifier("636e6e778aedec0710919591e9cb2a9404d6daab0581e4ddc515eeae03256f45", "Marketplace.Clearing.Market.Service", "Service");

  public final String operator;

  public final String provider;

  public final String customer;

  public Service(String operator, String provider, String customer) {
    this.operator = operator;
    this.provider = provider;
    this.customer = customer;
  }

  public CreateCommand create() {
    return new CreateCommand(Service.TEMPLATE_ID, this.toValue());
  }

  public static ExerciseByKeyCommand exerciseByKeyCreateFairValue(
      Tuple3<String, String, String> key, CreateFairValue arg) {
    return new ExerciseByKeyCommand(Service.TEMPLATE_ID, key.toValue(v$0 -> new Party(v$0),v$1 -> new Party(v$1),v$2 -> new Party(v$2)), "CreateFairValue", arg.toValue());
  }

  public static ExerciseByKeyCommand exerciseByKeyCreateFairValue(
      Tuple3<String, String, String> key, String listingId, String calculationId, BigDecimal price,
      Id currency, Instant timestamp, Instant upTo, Set<String> observers) {
    return Service.exerciseByKeyCreateFairValue(key, new CreateFairValue(listingId, calculationId, price, currency, timestamp, upTo, observers));
  }

  public static ExerciseByKeyCommand exerciseByKeyApproveClearedListing(
      Tuple3<String, String, String> key, ApproveClearedListing arg) {
    return new ExerciseByKeyCommand(Service.TEMPLATE_ID, key.toValue(v$0 -> new Party(v$0),v$1 -> new Party(v$1),v$2 -> new Party(v$2)), "ApproveClearedListing", arg.toValue());
  }

  public static ExerciseByKeyCommand exerciseByKeyApproveClearedListing(
      Tuple3<String, String, String> key, String symbol, Set<String> observers) {
    return Service.exerciseByKeyApproveClearedListing(key, new ApproveClearedListing(symbol, observers));
  }

  public static ExerciseByKeyCommand exerciseByKeyRequestFairValues(
      Tuple3<String, String, String> key, RequestFairValues arg) {
    return new ExerciseByKeyCommand(Service.TEMPLATE_ID, key.toValue(v$0 -> new Party(v$0),v$1 -> new Party(v$1),v$2 -> new Party(v$2)), "RequestFairValues", arg.toValue());
  }

  public static ExerciseByKeyCommand exerciseByKeyRequestFairValues(
      Tuple3<String, String, String> key, String party, List<String> listingIds,
      String calculationId, Instant upTo, Id currency) {
    return Service.exerciseByKeyRequestFairValues(key, new RequestFairValues(party, listingIds, calculationId, upTo, currency));
  }

  public static ExerciseByKeyCommand exerciseByKeyCreateManualFairValueRequest(
      Tuple3<String, String, String> key, CreateManualFairValueRequest arg) {
    return new ExerciseByKeyCommand(Service.TEMPLATE_ID, key.toValue(v$0 -> new Party(v$0),v$1 -> new Party(v$1),v$2 -> new Party(v$2)), "CreateManualFairValueRequest", arg.toValue());
  }

  public static ExerciseByKeyCommand exerciseByKeyCreateManualFairValueRequest(
      Tuple3<String, String, String> key, String listingId, String calculationId, Id currency,
      Instant upTo, Set<String> observers) {
    return Service.exerciseByKeyCreateManualFairValueRequest(key, new CreateManualFairValueRequest(listingId, calculationId, currency, upTo, observers));
  }

  public static ExerciseByKeyCommand exerciseByKeyTerminate(Tuple3<String, String, String> key,
      Terminate arg) {
    return new ExerciseByKeyCommand(Service.TEMPLATE_ID, key.toValue(v$0 -> new Party(v$0),v$1 -> new Party(v$1),v$2 -> new Party(v$2)), "Terminate", arg.toValue());
  }

  public static ExerciseByKeyCommand exerciseByKeyTerminate(Tuple3<String, String, String> key,
      String ctrl) {
    return Service.exerciseByKeyTerminate(key, new Terminate(ctrl));
  }

  public static ExerciseByKeyCommand exerciseByKeyArchive(Tuple3<String, String, String> key,
      Archive arg) {
    return new ExerciseByKeyCommand(Service.TEMPLATE_ID, key.toValue(v$0 -> new Party(v$0),v$1 -> new Party(v$1),v$2 -> new Party(v$2)), "Archive", arg.toValue());
  }

  public static ExerciseByKeyCommand exerciseByKeyRequestAllFairValues(
      Tuple3<String, String, String> key, RequestAllFairValues arg) {
    return new ExerciseByKeyCommand(Service.TEMPLATE_ID, key.toValue(v$0 -> new Party(v$0),v$1 -> new Party(v$1),v$2 -> new Party(v$2)), "RequestAllFairValues", arg.toValue());
  }

  public static ExerciseByKeyCommand exerciseByKeyRequestAllFairValues(
      Tuple3<String, String, String> key, String party, String calculationId, Instant upTo,
      Id currency) {
    return Service.exerciseByKeyRequestAllFairValues(key, new RequestAllFairValues(party, calculationId, upTo, currency));
  }

  public CreateAndExerciseCommand createAndExerciseCreateFairValue(CreateFairValue arg) {
    Value argValue = arg.toValue();
    return new CreateAndExerciseCommand(Service.TEMPLATE_ID, this.toValue(), "CreateFairValue", argValue);
  }

  public CreateAndExerciseCommand createAndExerciseCreateFairValue(String listingId,
      String calculationId, BigDecimal price, Id currency, Instant timestamp, Instant upTo,
      Set<String> observers) {
    return createAndExerciseCreateFairValue(new CreateFairValue(listingId, calculationId, price, currency, timestamp, upTo, observers));
  }

  public CreateAndExerciseCommand createAndExerciseApproveClearedListing(
      ApproveClearedListing arg) {
    Value argValue = arg.toValue();
    return new CreateAndExerciseCommand(Service.TEMPLATE_ID, this.toValue(), "ApproveClearedListing", argValue);
  }

  public CreateAndExerciseCommand createAndExerciseApproveClearedListing(String symbol,
      Set<String> observers) {
    return createAndExerciseApproveClearedListing(new ApproveClearedListing(symbol, observers));
  }

  public CreateAndExerciseCommand createAndExerciseRequestFairValues(RequestFairValues arg) {
    Value argValue = arg.toValue();
    return new CreateAndExerciseCommand(Service.TEMPLATE_ID, this.toValue(), "RequestFairValues", argValue);
  }

  public CreateAndExerciseCommand createAndExerciseRequestFairValues(String party,
      List<String> listingIds, String calculationId, Instant upTo, Id currency) {
    return createAndExerciseRequestFairValues(new RequestFairValues(party, listingIds, calculationId, upTo, currency));
  }

  public CreateAndExerciseCommand createAndExerciseCreateManualFairValueRequest(
      CreateManualFairValueRequest arg) {
    Value argValue = arg.toValue();
    return new CreateAndExerciseCommand(Service.TEMPLATE_ID, this.toValue(), "CreateManualFairValueRequest", argValue);
  }

  public CreateAndExerciseCommand createAndExerciseCreateManualFairValueRequest(String listingId,
      String calculationId, Id currency, Instant upTo, Set<String> observers) {
    return createAndExerciseCreateManualFairValueRequest(new CreateManualFairValueRequest(listingId, calculationId, currency, upTo, observers));
  }

  public CreateAndExerciseCommand createAndExerciseTerminate(Terminate arg) {
    Value argValue = arg.toValue();
    return new CreateAndExerciseCommand(Service.TEMPLATE_ID, this.toValue(), "Terminate", argValue);
  }

  public CreateAndExerciseCommand createAndExerciseTerminate(String ctrl) {
    return createAndExerciseTerminate(new Terminate(ctrl));
  }

  public CreateAndExerciseCommand createAndExerciseArchive(Archive arg) {
    Value argValue = arg.toValue();
    return new CreateAndExerciseCommand(Service.TEMPLATE_ID, this.toValue(), "Archive", argValue);
  }

  public CreateAndExerciseCommand createAndExerciseRequestAllFairValues(RequestAllFairValues arg) {
    Value argValue = arg.toValue();
    return new CreateAndExerciseCommand(Service.TEMPLATE_ID, this.toValue(), "RequestAllFairValues", argValue);
  }

  public CreateAndExerciseCommand createAndExerciseRequestAllFairValues(String party,
      String calculationId, Instant upTo, Id currency) {
    return createAndExerciseRequestAllFairValues(new RequestAllFairValues(party, calculationId, upTo, currency));
  }

  public static CreateCommand create(String operator, String provider, String customer) {
    return new Service(operator, provider, customer).create();
  }

  public static Service fromValue(Value value$) throws IllegalArgumentException {
    Value recordValue$ = value$;
    DamlRecord record$ = recordValue$.asRecord().orElseThrow(() -> new IllegalArgumentException("Contracts must be constructed from Records"));
    List<DamlRecord.Field> fields$ = record$.getFields();
    int numberOfFields = fields$.size();
    if (numberOfFields != 3) {
      throw new IllegalArgumentException("Expected 3 arguments, got " + numberOfFields);
    }
    String operator = fields$.get(0).getValue().asParty().orElseThrow(() -> new IllegalArgumentException("Expected operator to be of type com.daml.ledger.javaapi.data.Party")).getValue();
    String provider = fields$.get(1).getValue().asParty().orElseThrow(() -> new IllegalArgumentException("Expected provider to be of type com.daml.ledger.javaapi.data.Party")).getValue();
    String customer = fields$.get(2).getValue().asParty().orElseThrow(() -> new IllegalArgumentException("Expected customer to be of type com.daml.ledger.javaapi.data.Party")).getValue();
    return new com.daml.generated.marketplace.clearing.market.service.Service(operator, provider, customer);
  }

  public DamlRecord toValue() {
    ArrayList<DamlRecord.Field> fields = new ArrayList<DamlRecord.Field>(3);
    fields.add(new DamlRecord.Field("operator", new Party(this.operator)));
    fields.add(new DamlRecord.Field("provider", new Party(this.provider)));
    fields.add(new DamlRecord.Field("customer", new Party(this.customer)));
    return new DamlRecord(fields);
  }

  @Override
  public boolean equals(Object object) {
    if (this == object) {
      return true;
    }
    if (object == null) {
      return false;
    }
    if (!(object instanceof Service)) {
      return false;
    }
    Service other = (Service) object;
    return this.operator.equals(other.operator) && this.provider.equals(other.provider) && this.customer.equals(other.customer);
  }

  @Override
  public int hashCode() {
    return Objects.hash(this.operator, this.provider, this.customer);
  }

  @Override
  public String toString() {
    return String.format("com.daml.generated.marketplace.clearing.market.service.Service(%s, %s, %s)", this.operator, this.provider, this.customer);
  }

  public static final class ContractId extends com.daml.ledger.javaapi.data.codegen.ContractId<Service> {
    public ContractId(String contractId) {
      super(contractId);
    }

    public ExerciseCommand exerciseCreateFairValue(CreateFairValue arg) {
      Value argValue = arg.toValue();
      return new ExerciseCommand(Service.TEMPLATE_ID, this.contractId, "CreateFairValue", argValue);
    }

    public ExerciseCommand exerciseCreateFairValue(String listingId, String calculationId,
        BigDecimal price, Id currency, Instant timestamp, Instant upTo, Set<String> observers) {
      return exerciseCreateFairValue(new CreateFairValue(listingId, calculationId, price, currency, timestamp, upTo, observers));
    }

    public ExerciseCommand exerciseApproveClearedListing(ApproveClearedListing arg) {
      Value argValue = arg.toValue();
      return new ExerciseCommand(Service.TEMPLATE_ID, this.contractId, "ApproveClearedListing", argValue);
    }

    public ExerciseCommand exerciseApproveClearedListing(String symbol, Set<String> observers) {
      return exerciseApproveClearedListing(new ApproveClearedListing(symbol, observers));
    }

    public ExerciseCommand exerciseRequestFairValues(RequestFairValues arg) {
      Value argValue = arg.toValue();
      return new ExerciseCommand(Service.TEMPLATE_ID, this.contractId, "RequestFairValues", argValue);
    }

    public ExerciseCommand exerciseRequestFairValues(String party, List<String> listingIds,
        String calculationId, Instant upTo, Id currency) {
      return exerciseRequestFairValues(new RequestFairValues(party, listingIds, calculationId, upTo, currency));
    }

    public ExerciseCommand exerciseCreateManualFairValueRequest(CreateManualFairValueRequest arg) {
      Value argValue = arg.toValue();
      return new ExerciseCommand(Service.TEMPLATE_ID, this.contractId, "CreateManualFairValueRequest", argValue);
    }

    public ExerciseCommand exerciseCreateManualFairValueRequest(String listingId,
        String calculationId, Id currency, Instant upTo, Set<String> observers) {
      return exerciseCreateManualFairValueRequest(new CreateManualFairValueRequest(listingId, calculationId, currency, upTo, observers));
    }

    public ExerciseCommand exerciseTerminate(Terminate arg) {
      Value argValue = arg.toValue();
      return new ExerciseCommand(Service.TEMPLATE_ID, this.contractId, "Terminate", argValue);
    }

    public ExerciseCommand exerciseTerminate(String ctrl) {
      return exerciseTerminate(new Terminate(ctrl));
    }

    public ExerciseCommand exerciseArchive(Archive arg) {
      Value argValue = arg.toValue();
      return new ExerciseCommand(Service.TEMPLATE_ID, this.contractId, "Archive", argValue);
    }

    public ExerciseCommand exerciseRequestAllFairValues(RequestAllFairValues arg) {
      Value argValue = arg.toValue();
      return new ExerciseCommand(Service.TEMPLATE_ID, this.contractId, "RequestAllFairValues", argValue);
    }

    public ExerciseCommand exerciseRequestAllFairValues(String party, String calculationId,
        Instant upTo, Id currency) {
      return exerciseRequestAllFairValues(new RequestAllFairValues(party, calculationId, upTo, currency));
    }
  }

  public static class Contract implements com.daml.ledger.javaapi.data.Contract {
    public final ContractId id;

    public final Service data;

    public final Optional<String> agreementText;

    public final Optional<Tuple3<String, String, String>> key;

    public final java.util.Set<String> signatories;

    public final java.util.Set<String> observers;

    public Contract(ContractId id, Service data, Optional<String> agreementText,
        Optional<Tuple3<String, String, String>> key, java.util.Set<String> signatories,
        java.util.Set<String> observers) {
      this.id = id;
      this.data = data;
      this.agreementText = agreementText;
      this.key = key;
      this.signatories = signatories;
      this.observers = observers;
    }

    public static Contract fromIdAndRecord(String contractId, DamlRecord record$,
        Optional<String> agreementText, Optional<Tuple3<String, String, String>> key,
        java.util.Set<String> signatories, java.util.Set<String> observers) {
      ContractId id = new ContractId(contractId);
      Service data = Service.fromValue(record$);
      return new Contract(id, data, agreementText, key, signatories, observers);
    }

    @Deprecated
    public static Contract fromIdAndRecord(String contractId, DamlRecord record$) {
      ContractId id = new ContractId(contractId);
      Service data = Service.fromValue(record$);
      return new Contract(id, data, Optional.empty(), Optional.empty(), Collections.emptySet(), Collections.emptySet());
    }

    public static Contract fromCreatedEvent(CreatedEvent event) {
      return fromIdAndRecord(event.getContractId(), event.getArguments(), event.getAgreementText(), event.getContractKey().map(e -> Tuple3.<java.lang.String, java.lang.String, java.lang.String>fromValue(e, v$0 -> v$0.asParty().orElseThrow(() -> new IllegalArgumentException("Expected e to be of type com.daml.ledger.javaapi.data.Party")).getValue(), v$1 -> v$1.asParty().orElseThrow(() -> new IllegalArgumentException("Expected e to be of type com.daml.ledger.javaapi.data.Party")).getValue(), v$2 -> v$2.asParty().orElseThrow(() -> new IllegalArgumentException("Expected e to be of type com.daml.ledger.javaapi.data.Party")).getValue())), event.getSignatories(), event.getObservers());
    }

    @Override
    public boolean equals(Object object) {
      if (this == object) {
        return true;
      }
      if (object == null) {
        return false;
      }
      if (!(object instanceof Contract)) {
        return false;
      }
      Contract other = (Contract) object;
      return this.id.equals(other.id) && this.data.equals(other.data) && this.agreementText.equals(other.agreementText) && this.key.equals(other.key) && this.signatories.equals(other.signatories) && this.observers.equals(other.observers);
    }

    @Override
    public int hashCode() {
      return Objects.hash(this.id, this.data, this.agreementText, this.key, this.signatories, this.observers);
    }

    @Override
    public String toString() {
      return String.format("com.daml.generated.marketplace.clearing.market.service.Service.Contract(%s, %s, %s, %s, %s, %s)", this.id, this.data, this.agreementText, this.key, this.signatories, this.observers);
    }
  }
}
