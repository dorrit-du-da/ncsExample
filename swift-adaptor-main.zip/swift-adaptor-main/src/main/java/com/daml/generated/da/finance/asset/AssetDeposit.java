package com.daml.generated.da.finance.asset;

import com.daml.generated.da.finance.types.Account;
import com.daml.generated.da.finance.types.Asset;
import com.daml.generated.da.internal.template.Archive;
import com.daml.generated.da.set.types.Set;
import com.daml.ledger.javaapi.data.CreateAndExerciseCommand;
import com.daml.ledger.javaapi.data.CreateCommand;
import com.daml.ledger.javaapi.data.CreatedEvent;
import com.daml.ledger.javaapi.data.DamlRecord;
import com.daml.ledger.javaapi.data.ExerciseCommand;
import com.daml.ledger.javaapi.data.Identifier;
import com.daml.ledger.javaapi.data.Party;
import com.daml.ledger.javaapi.data.Template;
import com.daml.ledger.javaapi.data.Value;
import java.lang.Deprecated;
import java.lang.IllegalArgumentException;
import java.lang.Long;
import java.lang.Object;
import java.lang.Override;
import java.lang.String;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Objects;
import java.util.Optional;

public final class AssetDeposit extends Template {
  public static final Identifier TEMPLATE_ID = new Identifier("636e6e778aedec0710919591e9cb2a9404d6daab0581e4ddc515eeae03256f45", "DA.Finance.Asset", "AssetDeposit");

  public final Account account;

  public final Asset asset;

  public final Set<String> lockers;

  public final Set<String> observers;

  public AssetDeposit(Account account, Asset asset, Set<String> lockers, Set<String> observers) {
    this.account = account;
    this.asset = asset;
    this.lockers = lockers;
    this.observers = observers;
  }

  public CreateCommand create() {
    return new CreateCommand(AssetDeposit.TEMPLATE_ID, this.toValue());
  }

  public CreateAndExerciseCommand createAndExerciseAssetDeposit_Upgrade(AssetDeposit_Upgrade arg) {
    Value argValue = arg.toValue();
    return new CreateAndExerciseCommand(AssetDeposit.TEMPLATE_ID, this.toValue(), "AssetDeposit_Upgrade", argValue);
  }

  public CreateAndExerciseCommand createAndExerciseAssetDeposit_Upgrade(Long newVersion) {
    return createAndExerciseAssetDeposit_Upgrade(new AssetDeposit_Upgrade(newVersion));
  }

  public CreateAndExerciseCommand createAndExerciseAssetDeposit_Split(AssetDeposit_Split arg) {
    Value argValue = arg.toValue();
    return new CreateAndExerciseCommand(AssetDeposit.TEMPLATE_ID, this.toValue(), "AssetDeposit_Split", argValue);
  }

  public CreateAndExerciseCommand createAndExerciseAssetDeposit_Split(List<BigDecimal> quantities) {
    return createAndExerciseAssetDeposit_Split(new AssetDeposit_Split(quantities));
  }

  public CreateAndExerciseCommand createAndExerciseAssetDeposit_Lock(AssetDeposit_Lock arg) {
    Value argValue = arg.toValue();
    return new CreateAndExerciseCommand(AssetDeposit.TEMPLATE_ID, this.toValue(), "AssetDeposit_Lock", argValue);
  }

  public CreateAndExerciseCommand createAndExerciseAssetDeposit_Lock(Set<String> newLockers) {
    return createAndExerciseAssetDeposit_Lock(new AssetDeposit_Lock(newLockers));
  }

  public CreateAndExerciseCommand createAndExerciseAssetDeposit_Merge(AssetDeposit_Merge arg) {
    Value argValue = arg.toValue();
    return new CreateAndExerciseCommand(AssetDeposit.TEMPLATE_ID, this.toValue(), "AssetDeposit_Merge", argValue);
  }

  public CreateAndExerciseCommand createAndExerciseAssetDeposit_Merge(
      List<ContractId> depositCids) {
    return createAndExerciseAssetDeposit_Merge(new AssetDeposit_Merge(depositCids));
  }

  public CreateAndExerciseCommand createAndExerciseArchive(Archive arg) {
    Value argValue = arg.toValue();
    return new CreateAndExerciseCommand(AssetDeposit.TEMPLATE_ID, this.toValue(), "Archive", argValue);
  }

  public CreateAndExerciseCommand createAndExerciseAssetDeposit_SetObservers(
      AssetDeposit_SetObservers arg) {
    Value argValue = arg.toValue();
    return new CreateAndExerciseCommand(AssetDeposit.TEMPLATE_ID, this.toValue(), "AssetDeposit_SetObservers", argValue);
  }

  public CreateAndExerciseCommand createAndExerciseAssetDeposit_SetObservers(
      Set<String> newObservers) {
    return createAndExerciseAssetDeposit_SetObservers(new AssetDeposit_SetObservers(newObservers));
  }

  public CreateAndExerciseCommand createAndExerciseAssetDeposit_Transfer(
      AssetDeposit_Transfer arg) {
    Value argValue = arg.toValue();
    return new CreateAndExerciseCommand(AssetDeposit.TEMPLATE_ID, this.toValue(), "AssetDeposit_Transfer", argValue);
  }

  public CreateAndExerciseCommand createAndExerciseAssetDeposit_Transfer(Account receiverAccount) {
    return createAndExerciseAssetDeposit_Transfer(new AssetDeposit_Transfer(receiverAccount));
  }

  public CreateAndExerciseCommand createAndExerciseAssetDeposit_Unlock(AssetDeposit_Unlock arg) {
    Value argValue = arg.toValue();
    return new CreateAndExerciseCommand(AssetDeposit.TEMPLATE_ID, this.toValue(), "AssetDeposit_Unlock", argValue);
  }

  public CreateAndExerciseCommand createAndExerciseAssetDeposit_Unlock() {
    return createAndExerciseAssetDeposit_Unlock(new AssetDeposit_Unlock());
  }

  public static CreateCommand create(Account account, Asset asset, Set<String> lockers,
      Set<String> observers) {
    return new AssetDeposit(account, asset, lockers, observers).create();
  }

  public static AssetDeposit fromValue(Value value$) throws IllegalArgumentException {
    Value recordValue$ = value$;
    DamlRecord record$ = recordValue$.asRecord().orElseThrow(() -> new IllegalArgumentException("Contracts must be constructed from Records"));
    List<DamlRecord.Field> fields$ = record$.getFields();
    int numberOfFields = fields$.size();
    if (numberOfFields != 4) {
      throw new IllegalArgumentException("Expected 4 arguments, got " + numberOfFields);
    }
    Account account = Account.fromValue(fields$.get(0).getValue());
    Asset asset = Asset.fromValue(fields$.get(1).getValue());
    Set<String> lockers = Set.<java.lang.String>fromValue(fields$.get(2).getValue(), v$0 -> v$0.asParty().orElseThrow(() -> new IllegalArgumentException("Expected lockers to be of type com.daml.ledger.javaapi.data.Party")).getValue());
    Set<String> observers = Set.<java.lang.String>fromValue(fields$.get(3).getValue(), v$0 -> v$0.asParty().orElseThrow(() -> new IllegalArgumentException("Expected observers to be of type com.daml.ledger.javaapi.data.Party")).getValue());
    return new com.daml.generated.da.finance.asset.AssetDeposit(account, asset, lockers, observers);
  }

  public DamlRecord toValue() {
    ArrayList<DamlRecord.Field> fields = new ArrayList<DamlRecord.Field>(4);
    fields.add(new DamlRecord.Field("account", this.account.toValue()));
    fields.add(new DamlRecord.Field("asset", this.asset.toValue()));
    fields.add(new DamlRecord.Field("lockers", this.lockers.toValue(v$0 -> new Party(v$0))));
    fields.add(new DamlRecord.Field("observers", this.observers.toValue(v$0 -> new Party(v$0))));
    return new DamlRecord(fields);
  }

  @Override
  public boolean equals(Object object) {
    if (this == object) {
      return true;
    }
    if (object == null) {
      return false;
    }
    if (!(object instanceof AssetDeposit)) {
      return false;
    }
    AssetDeposit other = (AssetDeposit) object;
    return this.account.equals(other.account) && this.asset.equals(other.asset) && this.lockers.equals(other.lockers) && this.observers.equals(other.observers);
  }

  @Override
  public int hashCode() {
    return Objects.hash(this.account, this.asset, this.lockers, this.observers);
  }

  @Override
  public String toString() {
    return String.format("com.daml.generated.da.finance.asset.AssetDeposit(%s, %s, %s, %s)", this.account, this.asset, this.lockers, this.observers);
  }

  public static final class ContractId extends com.daml.ledger.javaapi.data.codegen.ContractId<AssetDeposit> {
    public ContractId(String contractId) {
      super(contractId);
    }

    public ExerciseCommand exerciseAssetDeposit_Upgrade(AssetDeposit_Upgrade arg) {
      Value argValue = arg.toValue();
      return new ExerciseCommand(AssetDeposit.TEMPLATE_ID, this.contractId, "AssetDeposit_Upgrade", argValue);
    }

    public ExerciseCommand exerciseAssetDeposit_Upgrade(Long newVersion) {
      return exerciseAssetDeposit_Upgrade(new AssetDeposit_Upgrade(newVersion));
    }

    public ExerciseCommand exerciseAssetDeposit_Split(AssetDeposit_Split arg) {
      Value argValue = arg.toValue();
      return new ExerciseCommand(AssetDeposit.TEMPLATE_ID, this.contractId, "AssetDeposit_Split", argValue);
    }

    public ExerciseCommand exerciseAssetDeposit_Split(List<BigDecimal> quantities) {
      return exerciseAssetDeposit_Split(new AssetDeposit_Split(quantities));
    }

    public ExerciseCommand exerciseAssetDeposit_Lock(AssetDeposit_Lock arg) {
      Value argValue = arg.toValue();
      return new ExerciseCommand(AssetDeposit.TEMPLATE_ID, this.contractId, "AssetDeposit_Lock", argValue);
    }

    public ExerciseCommand exerciseAssetDeposit_Lock(Set<String> newLockers) {
      return exerciseAssetDeposit_Lock(new AssetDeposit_Lock(newLockers));
    }

    public ExerciseCommand exerciseAssetDeposit_Merge(AssetDeposit_Merge arg) {
      Value argValue = arg.toValue();
      return new ExerciseCommand(AssetDeposit.TEMPLATE_ID, this.contractId, "AssetDeposit_Merge", argValue);
    }

    public ExerciseCommand exerciseAssetDeposit_Merge(List<ContractId> depositCids) {
      return exerciseAssetDeposit_Merge(new AssetDeposit_Merge(depositCids));
    }

    public ExerciseCommand exerciseArchive(Archive arg) {
      Value argValue = arg.toValue();
      return new ExerciseCommand(AssetDeposit.TEMPLATE_ID, this.contractId, "Archive", argValue);
    }

    public ExerciseCommand exerciseAssetDeposit_SetObservers(AssetDeposit_SetObservers arg) {
      Value argValue = arg.toValue();
      return new ExerciseCommand(AssetDeposit.TEMPLATE_ID, this.contractId, "AssetDeposit_SetObservers", argValue);
    }

    public ExerciseCommand exerciseAssetDeposit_SetObservers(Set<String> newObservers) {
      return exerciseAssetDeposit_SetObservers(new AssetDeposit_SetObservers(newObservers));
    }

    public ExerciseCommand exerciseAssetDeposit_Transfer(AssetDeposit_Transfer arg) {
      Value argValue = arg.toValue();
      return new ExerciseCommand(AssetDeposit.TEMPLATE_ID, this.contractId, "AssetDeposit_Transfer", argValue);
    }

    public ExerciseCommand exerciseAssetDeposit_Transfer(Account receiverAccount) {
      return exerciseAssetDeposit_Transfer(new AssetDeposit_Transfer(receiverAccount));
    }

    public ExerciseCommand exerciseAssetDeposit_Unlock(AssetDeposit_Unlock arg) {
      Value argValue = arg.toValue();
      return new ExerciseCommand(AssetDeposit.TEMPLATE_ID, this.contractId, "AssetDeposit_Unlock", argValue);
    }

    public ExerciseCommand exerciseAssetDeposit_Unlock() {
      return exerciseAssetDeposit_Unlock(new AssetDeposit_Unlock());
    }
  }

  public static class Contract implements com.daml.ledger.javaapi.data.Contract {
    public final ContractId id;

    public final AssetDeposit data;

    public final Optional<String> agreementText;

    public final java.util.Set<String> signatories;

    public final java.util.Set<String> observers;

    public Contract(ContractId id, AssetDeposit data, Optional<String> agreementText,
        java.util.Set<String> signatories, java.util.Set<String> observers) {
      this.id = id;
      this.data = data;
      this.agreementText = agreementText;
      this.signatories = signatories;
      this.observers = observers;
    }

    public static Contract fromIdAndRecord(String contractId, DamlRecord record$,
        Optional<String> agreementText, java.util.Set<String> signatories,
        java.util.Set<String> observers) {
      ContractId id = new ContractId(contractId);
      AssetDeposit data = AssetDeposit.fromValue(record$);
      return new Contract(id, data, agreementText, signatories, observers);
    }

    @Deprecated
    public static Contract fromIdAndRecord(String contractId, DamlRecord record$) {
      ContractId id = new ContractId(contractId);
      AssetDeposit data = AssetDeposit.fromValue(record$);
      return new Contract(id, data, Optional.empty(), Collections.emptySet(), Collections.emptySet());
    }

    public static Contract fromCreatedEvent(CreatedEvent event) {
      return fromIdAndRecord(event.getContractId(), event.getArguments(), event.getAgreementText(), event.getSignatories(), event.getObservers());
    }

    @Override
    public boolean equals(Object object) {
      if (this == object) {
        return true;
      }
      if (object == null) {
        return false;
      }
      if (!(object instanceof Contract)) {
        return false;
      }
      Contract other = (Contract) object;
      return this.id.equals(other.id) && this.data.equals(other.data) && this.agreementText.equals(other.agreementText) && this.signatories.equals(other.signatories) && this.observers.equals(other.observers);
    }

    @Override
    public int hashCode() {
      return Objects.hash(this.id, this.data, this.agreementText, this.signatories, this.observers);
    }

    @Override
    public String toString() {
      return String.format("com.daml.generated.da.finance.asset.AssetDeposit.Contract(%s, %s, %s, %s, %s)", this.id, this.data, this.agreementText, this.signatories, this.observers);
    }
  }
}
