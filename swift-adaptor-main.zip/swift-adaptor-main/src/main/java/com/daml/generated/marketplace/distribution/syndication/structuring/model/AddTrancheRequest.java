package com.daml.generated.marketplace.distribution.syndication.structuring.model;

import com.daml.generated.da.finance.types.Id;
import com.daml.generated.da.internal.template.Archive;
import com.daml.generated.marketplace.settlement.hierarchical.SettlementMode;
import com.daml.ledger.javaapi.data.CreateAndExerciseCommand;
import com.daml.ledger.javaapi.data.CreateCommand;
import com.daml.ledger.javaapi.data.CreatedEvent;
import com.daml.ledger.javaapi.data.DamlRecord;
import com.daml.ledger.javaapi.data.ExerciseCommand;
import com.daml.ledger.javaapi.data.Identifier;
import com.daml.ledger.javaapi.data.Numeric;
import com.daml.ledger.javaapi.data.Party;
import com.daml.ledger.javaapi.data.Template;
import com.daml.ledger.javaapi.data.Text;
import com.daml.ledger.javaapi.data.Value;
import java.lang.Deprecated;
import java.lang.IllegalArgumentException;
import java.lang.Object;
import java.lang.Override;
import java.lang.String;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.Set;

public final class AddTrancheRequest extends Template {
  public static final Identifier TEMPLATE_ID = new Identifier("636e6e778aedec0710919591e9cb2a9404d6daab0581e4ddc515eeae03256f45", "Marketplace.Distribution.Syndication.Structuring.Model", "AddTrancheRequest");

  public final String operator;

  public final String provider;

  public final String customer;

  public final String settlementBank;

  public final String bndBank;

  public final String cashProvider;

  public final String bondRegistrar;

  public final String payingAgent;

  public final String dealId;

  public final String trancheId;

  public final Id deliveryId;

  public final Id paymentId;

  public final BigDecimal size;

  public final SettlementMode issuerSettlementMode;

  public final SettlementMode bndSettlementMode;

  public AddTrancheRequest(String operator, String provider, String customer, String settlementBank,
      String bndBank, String cashProvider, String bondRegistrar, String payingAgent, String dealId,
      String trancheId, Id deliveryId, Id paymentId, BigDecimal size,
      SettlementMode issuerSettlementMode, SettlementMode bndSettlementMode) {
    this.operator = operator;
    this.provider = provider;
    this.customer = customer;
    this.settlementBank = settlementBank;
    this.bndBank = bndBank;
    this.cashProvider = cashProvider;
    this.bondRegistrar = bondRegistrar;
    this.payingAgent = payingAgent;
    this.dealId = dealId;
    this.trancheId = trancheId;
    this.deliveryId = deliveryId;
    this.paymentId = paymentId;
    this.size = size;
    this.issuerSettlementMode = issuerSettlementMode;
    this.bndSettlementMode = bndSettlementMode;
  }

  public CreateCommand create() {
    return new CreateCommand(AddTrancheRequest.TEMPLATE_ID, this.toValue());
  }

  public CreateAndExerciseCommand createAndExerciseArchive(Archive arg) {
    Value argValue = arg.toValue();
    return new CreateAndExerciseCommand(AddTrancheRequest.TEMPLATE_ID, this.toValue(), "Archive", argValue);
  }

  public static CreateCommand create(String operator, String provider, String customer,
      String settlementBank, String bndBank, String cashProvider, String bondRegistrar,
      String payingAgent, String dealId, String trancheId, Id deliveryId, Id paymentId,
      BigDecimal size, SettlementMode issuerSettlementMode, SettlementMode bndSettlementMode) {
    return new AddTrancheRequest(operator, provider, customer, settlementBank, bndBank, cashProvider, bondRegistrar, payingAgent, dealId, trancheId, deliveryId, paymentId, size, issuerSettlementMode, bndSettlementMode).create();
  }

  public static AddTrancheRequest fromValue(Value value$) throws IllegalArgumentException {
    Value recordValue$ = value$;
    DamlRecord record$ = recordValue$.asRecord().orElseThrow(() -> new IllegalArgumentException("Contracts must be constructed from Records"));
    List<DamlRecord.Field> fields$ = record$.getFields();
    int numberOfFields = fields$.size();
    if (numberOfFields != 15) {
      throw new IllegalArgumentException("Expected 15 arguments, got " + numberOfFields);
    }
    String operator = fields$.get(0).getValue().asParty().orElseThrow(() -> new IllegalArgumentException("Expected operator to be of type com.daml.ledger.javaapi.data.Party")).getValue();
    String provider = fields$.get(1).getValue().asParty().orElseThrow(() -> new IllegalArgumentException("Expected provider to be of type com.daml.ledger.javaapi.data.Party")).getValue();
    String customer = fields$.get(2).getValue().asParty().orElseThrow(() -> new IllegalArgumentException("Expected customer to be of type com.daml.ledger.javaapi.data.Party")).getValue();
    String settlementBank = fields$.get(3).getValue().asParty().orElseThrow(() -> new IllegalArgumentException("Expected settlementBank to be of type com.daml.ledger.javaapi.data.Party")).getValue();
    String bndBank = fields$.get(4).getValue().asParty().orElseThrow(() -> new IllegalArgumentException("Expected bndBank to be of type com.daml.ledger.javaapi.data.Party")).getValue();
    String cashProvider = fields$.get(5).getValue().asParty().orElseThrow(() -> new IllegalArgumentException("Expected cashProvider to be of type com.daml.ledger.javaapi.data.Party")).getValue();
    String bondRegistrar = fields$.get(6).getValue().asParty().orElseThrow(() -> new IllegalArgumentException("Expected bondRegistrar to be of type com.daml.ledger.javaapi.data.Party")).getValue();
    String payingAgent = fields$.get(7).getValue().asParty().orElseThrow(() -> new IllegalArgumentException("Expected payingAgent to be of type com.daml.ledger.javaapi.data.Party")).getValue();
    String dealId = fields$.get(8).getValue().asText().orElseThrow(() -> new IllegalArgumentException("Expected dealId to be of type com.daml.ledger.javaapi.data.Text")).getValue();
    String trancheId = fields$.get(9).getValue().asText().orElseThrow(() -> new IllegalArgumentException("Expected trancheId to be of type com.daml.ledger.javaapi.data.Text")).getValue();
    Id deliveryId = Id.fromValue(fields$.get(10).getValue());
    Id paymentId = Id.fromValue(fields$.get(11).getValue());
    BigDecimal size = fields$.get(12).getValue().asNumeric().orElseThrow(() -> new IllegalArgumentException("Expected size to be of type com.daml.ledger.javaapi.data.Numeric")).getValue();
    SettlementMode issuerSettlementMode = SettlementMode.fromValue(fields$.get(13).getValue());
    SettlementMode bndSettlementMode = SettlementMode.fromValue(fields$.get(14).getValue());
    return new com.daml.generated.marketplace.distribution.syndication.structuring.model.AddTrancheRequest(operator, provider, customer, settlementBank, bndBank, cashProvider, bondRegistrar, payingAgent, dealId, trancheId, deliveryId, paymentId, size, issuerSettlementMode, bndSettlementMode);
  }

  public DamlRecord toValue() {
    ArrayList<DamlRecord.Field> fields = new ArrayList<DamlRecord.Field>(15);
    fields.add(new DamlRecord.Field("operator", new Party(this.operator)));
    fields.add(new DamlRecord.Field("provider", new Party(this.provider)));
    fields.add(new DamlRecord.Field("customer", new Party(this.customer)));
    fields.add(new DamlRecord.Field("settlementBank", new Party(this.settlementBank)));
    fields.add(new DamlRecord.Field("bndBank", new Party(this.bndBank)));
    fields.add(new DamlRecord.Field("cashProvider", new Party(this.cashProvider)));
    fields.add(new DamlRecord.Field("bondRegistrar", new Party(this.bondRegistrar)));
    fields.add(new DamlRecord.Field("payingAgent", new Party(this.payingAgent)));
    fields.add(new DamlRecord.Field("dealId", new Text(this.dealId)));
    fields.add(new DamlRecord.Field("trancheId", new Text(this.trancheId)));
    fields.add(new DamlRecord.Field("deliveryId", this.deliveryId.toValue()));
    fields.add(new DamlRecord.Field("paymentId", this.paymentId.toValue()));
    fields.add(new DamlRecord.Field("size", new Numeric(this.size)));
    fields.add(new DamlRecord.Field("issuerSettlementMode", this.issuerSettlementMode.toValue()));
    fields.add(new DamlRecord.Field("bndSettlementMode", this.bndSettlementMode.toValue()));
    return new DamlRecord(fields);
  }

  @Override
  public boolean equals(Object object) {
    if (this == object) {
      return true;
    }
    if (object == null) {
      return false;
    }
    if (!(object instanceof AddTrancheRequest)) {
      return false;
    }
    AddTrancheRequest other = (AddTrancheRequest) object;
    return this.operator.equals(other.operator) && this.provider.equals(other.provider) && this.customer.equals(other.customer) && this.settlementBank.equals(other.settlementBank) && this.bndBank.equals(other.bndBank) && this.cashProvider.equals(other.cashProvider) && this.bondRegistrar.equals(other.bondRegistrar) && this.payingAgent.equals(other.payingAgent) && this.dealId.equals(other.dealId) && this.trancheId.equals(other.trancheId) && this.deliveryId.equals(other.deliveryId) && this.paymentId.equals(other.paymentId) && this.size.equals(other.size) && this.issuerSettlementMode.equals(other.issuerSettlementMode) && this.bndSettlementMode.equals(other.bndSettlementMode);
  }

  @Override
  public int hashCode() {
    return Objects.hash(this.operator, this.provider, this.customer, this.settlementBank, this.bndBank, this.cashProvider, this.bondRegistrar, this.payingAgent, this.dealId, this.trancheId, this.deliveryId, this.paymentId, this.size, this.issuerSettlementMode, this.bndSettlementMode);
  }

  @Override
  public String toString() {
    return String.format("com.daml.generated.marketplace.distribution.syndication.structuring.model.AddTrancheRequest(%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)", this.operator, this.provider, this.customer, this.settlementBank, this.bndBank, this.cashProvider, this.bondRegistrar, this.payingAgent, this.dealId, this.trancheId, this.deliveryId, this.paymentId, this.size, this.issuerSettlementMode, this.bndSettlementMode);
  }

  public static final class ContractId extends com.daml.ledger.javaapi.data.codegen.ContractId<AddTrancheRequest> {
    public ContractId(String contractId) {
      super(contractId);
    }

    public ExerciseCommand exerciseArchive(Archive arg) {
      Value argValue = arg.toValue();
      return new ExerciseCommand(AddTrancheRequest.TEMPLATE_ID, this.contractId, "Archive", argValue);
    }
  }

  public static class Contract implements com.daml.ledger.javaapi.data.Contract {
    public final ContractId id;

    public final AddTrancheRequest data;

    public final Optional<String> agreementText;

    public final Set<String> signatories;

    public final Set<String> observers;

    public Contract(ContractId id, AddTrancheRequest data, Optional<String> agreementText,
        Set<String> signatories, Set<String> observers) {
      this.id = id;
      this.data = data;
      this.agreementText = agreementText;
      this.signatories = signatories;
      this.observers = observers;
    }

    public static Contract fromIdAndRecord(String contractId, DamlRecord record$,
        Optional<String> agreementText, Set<String> signatories, Set<String> observers) {
      ContractId id = new ContractId(contractId);
      AddTrancheRequest data = AddTrancheRequest.fromValue(record$);
      return new Contract(id, data, agreementText, signatories, observers);
    }

    @Deprecated
    public static Contract fromIdAndRecord(String contractId, DamlRecord record$) {
      ContractId id = new ContractId(contractId);
      AddTrancheRequest data = AddTrancheRequest.fromValue(record$);
      return new Contract(id, data, Optional.empty(), Collections.emptySet(), Collections.emptySet());
    }

    public static Contract fromCreatedEvent(CreatedEvent event) {
      return fromIdAndRecord(event.getContractId(), event.getArguments(), event.getAgreementText(), event.getSignatories(), event.getObservers());
    }

    @Override
    public boolean equals(Object object) {
      if (this == object) {
        return true;
      }
      if (object == null) {
        return false;
      }
      if (!(object instanceof Contract)) {
        return false;
      }
      Contract other = (Contract) object;
      return this.id.equals(other.id) && this.data.equals(other.data) && this.agreementText.equals(other.agreementText) && this.signatories.equals(other.signatories) && this.observers.equals(other.observers);
    }

    @Override
    public int hashCode() {
      return Objects.hash(this.id, this.data, this.agreementText, this.signatories, this.observers);
    }

    @Override
    public String toString() {
      return String.format("com.daml.generated.marketplace.distribution.syndication.structuring.model.AddTrancheRequest.Contract(%s, %s, %s, %s, %s)", this.id, this.data, this.agreementText, this.signatories, this.observers);
    }
  }
}
