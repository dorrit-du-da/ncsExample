package com.daml.generated.da.finance.base.rollconvention.rollconventionenum;

import com.daml.generated.da.finance.base.rollconvention.RollConventionEnum;
import com.daml.ledger.javaapi.data.Int64;
import com.daml.ledger.javaapi.data.Value;
import com.daml.ledger.javaapi.data.Variant;
import java.lang.IllegalArgumentException;
import java.lang.Long;
import java.lang.Object;
import java.lang.Override;
import java.lang.String;
import java.util.Objects;

public class DOM extends RollConventionEnum {
  public static final String _packageId = "636e6e778aedec0710919591e9cb2a9404d6daab0581e4ddc515eeae03256f45";

  public final Long longValue;

  public DOM(Long longValue) {
    this.longValue = longValue;
  }

  public Variant toValue() {
    return new Variant("DOM", new Int64(this.longValue));
  }

  public static DOM fromValue(Value value$) throws IllegalArgumentException {
    Variant variant$ = value$.asVariant().orElseThrow(() -> new IllegalArgumentException("Expected: Variant. Actual: " + value$.getClass().getName()));
    if (!"DOM".equals(variant$.getConstructor())) throw new IllegalArgumentException("Invalid constructor. Expected: DOM. Actual: " + variant$.getConstructor());
    Value variantValue$ = variant$.getValue();
    Long body = variantValue$.asInt64().orElseThrow(() -> new IllegalArgumentException("Expected body to be of type com.daml.ledger.javaapi.data.Int64")).getValue();
    return new DOM(body);
  }

  @Override
  public boolean equals(Object object) {
    if (this == object) {
      return true;
    }
    if (object == null) {
      return false;
    }
    if (!(object instanceof DOM)) {
      return false;
    }
    DOM other = (DOM) object;
    return this.longValue.equals(other.longValue);
  }

  @Override
  public int hashCode() {
    return Objects.hash(this.longValue);
  }

  @Override
  public String toString() {
    return String.format("DOM(%s)", this.longValue);
  }
}
