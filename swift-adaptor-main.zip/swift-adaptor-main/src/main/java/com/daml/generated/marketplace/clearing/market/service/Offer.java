package com.daml.generated.marketplace.clearing.market.service;

import com.daml.generated.da.internal.template.Archive;
import com.daml.ledger.javaapi.data.CreateAndExerciseCommand;
import com.daml.ledger.javaapi.data.CreateCommand;
import com.daml.ledger.javaapi.data.CreatedEvent;
import com.daml.ledger.javaapi.data.DamlRecord;
import com.daml.ledger.javaapi.data.ExerciseCommand;
import com.daml.ledger.javaapi.data.Identifier;
import com.daml.ledger.javaapi.data.Party;
import com.daml.ledger.javaapi.data.Template;
import com.daml.ledger.javaapi.data.Value;
import java.lang.Deprecated;
import java.lang.IllegalArgumentException;
import java.lang.Object;
import java.lang.Override;
import java.lang.String;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.Set;

public final class Offer extends Template {
  public static final Identifier TEMPLATE_ID = new Identifier("636e6e778aedec0710919591e9cb2a9404d6daab0581e4ddc515eeae03256f45", "Marketplace.Clearing.Market.Service", "Offer");

  public final String operator;

  public final String provider;

  public final String customer;

  public Offer(String operator, String provider, String customer) {
    this.operator = operator;
    this.provider = provider;
    this.customer = customer;
  }

  public CreateCommand create() {
    return new CreateCommand(Offer.TEMPLATE_ID, this.toValue());
  }

  public CreateAndExerciseCommand createAndExerciseAccept(Accept arg) {
    Value argValue = arg.toValue();
    return new CreateAndExerciseCommand(Offer.TEMPLATE_ID, this.toValue(), "Accept", argValue);
  }

  public CreateAndExerciseCommand createAndExerciseAccept() {
    return createAndExerciseAccept(new Accept());
  }

  public CreateAndExerciseCommand createAndExerciseDecline(Decline arg) {
    Value argValue = arg.toValue();
    return new CreateAndExerciseCommand(Offer.TEMPLATE_ID, this.toValue(), "Decline", argValue);
  }

  public CreateAndExerciseCommand createAndExerciseDecline() {
    return createAndExerciseDecline(new Decline());
  }

  public CreateAndExerciseCommand createAndExerciseWithdraw(Withdraw arg) {
    Value argValue = arg.toValue();
    return new CreateAndExerciseCommand(Offer.TEMPLATE_ID, this.toValue(), "Withdraw", argValue);
  }

  public CreateAndExerciseCommand createAndExerciseWithdraw() {
    return createAndExerciseWithdraw(new Withdraw());
  }

  public CreateAndExerciseCommand createAndExerciseArchive(Archive arg) {
    Value argValue = arg.toValue();
    return new CreateAndExerciseCommand(Offer.TEMPLATE_ID, this.toValue(), "Archive", argValue);
  }

  public static CreateCommand create(String operator, String provider, String customer) {
    return new Offer(operator, provider, customer).create();
  }

  public static Offer fromValue(Value value$) throws IllegalArgumentException {
    Value recordValue$ = value$;
    DamlRecord record$ = recordValue$.asRecord().orElseThrow(() -> new IllegalArgumentException("Contracts must be constructed from Records"));
    List<DamlRecord.Field> fields$ = record$.getFields();
    int numberOfFields = fields$.size();
    if (numberOfFields != 3) {
      throw new IllegalArgumentException("Expected 3 arguments, got " + numberOfFields);
    }
    String operator = fields$.get(0).getValue().asParty().orElseThrow(() -> new IllegalArgumentException("Expected operator to be of type com.daml.ledger.javaapi.data.Party")).getValue();
    String provider = fields$.get(1).getValue().asParty().orElseThrow(() -> new IllegalArgumentException("Expected provider to be of type com.daml.ledger.javaapi.data.Party")).getValue();
    String customer = fields$.get(2).getValue().asParty().orElseThrow(() -> new IllegalArgumentException("Expected customer to be of type com.daml.ledger.javaapi.data.Party")).getValue();
    return new com.daml.generated.marketplace.clearing.market.service.Offer(operator, provider, customer);
  }

  public DamlRecord toValue() {
    ArrayList<DamlRecord.Field> fields = new ArrayList<DamlRecord.Field>(3);
    fields.add(new DamlRecord.Field("operator", new Party(this.operator)));
    fields.add(new DamlRecord.Field("provider", new Party(this.provider)));
    fields.add(new DamlRecord.Field("customer", new Party(this.customer)));
    return new DamlRecord(fields);
  }

  @Override
  public boolean equals(Object object) {
    if (this == object) {
      return true;
    }
    if (object == null) {
      return false;
    }
    if (!(object instanceof Offer)) {
      return false;
    }
    Offer other = (Offer) object;
    return this.operator.equals(other.operator) && this.provider.equals(other.provider) && this.customer.equals(other.customer);
  }

  @Override
  public int hashCode() {
    return Objects.hash(this.operator, this.provider, this.customer);
  }

  @Override
  public String toString() {
    return String.format("com.daml.generated.marketplace.clearing.market.service.Offer(%s, %s, %s)", this.operator, this.provider, this.customer);
  }

  public static final class ContractId extends com.daml.ledger.javaapi.data.codegen.ContractId<Offer> {
    public ContractId(String contractId) {
      super(contractId);
    }

    public ExerciseCommand exerciseAccept(Accept arg) {
      Value argValue = arg.toValue();
      return new ExerciseCommand(Offer.TEMPLATE_ID, this.contractId, "Accept", argValue);
    }

    public ExerciseCommand exerciseAccept() {
      return exerciseAccept(new Accept());
    }

    public ExerciseCommand exerciseDecline(Decline arg) {
      Value argValue = arg.toValue();
      return new ExerciseCommand(Offer.TEMPLATE_ID, this.contractId, "Decline", argValue);
    }

    public ExerciseCommand exerciseDecline() {
      return exerciseDecline(new Decline());
    }

    public ExerciseCommand exerciseWithdraw(Withdraw arg) {
      Value argValue = arg.toValue();
      return new ExerciseCommand(Offer.TEMPLATE_ID, this.contractId, "Withdraw", argValue);
    }

    public ExerciseCommand exerciseWithdraw() {
      return exerciseWithdraw(new Withdraw());
    }

    public ExerciseCommand exerciseArchive(Archive arg) {
      Value argValue = arg.toValue();
      return new ExerciseCommand(Offer.TEMPLATE_ID, this.contractId, "Archive", argValue);
    }
  }

  public static class Contract implements com.daml.ledger.javaapi.data.Contract {
    public final ContractId id;

    public final Offer data;

    public final Optional<String> agreementText;

    public final Set<String> signatories;

    public final Set<String> observers;

    public Contract(ContractId id, Offer data, Optional<String> agreementText,
        Set<String> signatories, Set<String> observers) {
      this.id = id;
      this.data = data;
      this.agreementText = agreementText;
      this.signatories = signatories;
      this.observers = observers;
    }

    public static Contract fromIdAndRecord(String contractId, DamlRecord record$,
        Optional<String> agreementText, Set<String> signatories, Set<String> observers) {
      ContractId id = new ContractId(contractId);
      Offer data = Offer.fromValue(record$);
      return new Contract(id, data, agreementText, signatories, observers);
    }

    @Deprecated
    public static Contract fromIdAndRecord(String contractId, DamlRecord record$) {
      ContractId id = new ContractId(contractId);
      Offer data = Offer.fromValue(record$);
      return new Contract(id, data, Optional.empty(), Collections.emptySet(), Collections.emptySet());
    }

    public static Contract fromCreatedEvent(CreatedEvent event) {
      return fromIdAndRecord(event.getContractId(), event.getArguments(), event.getAgreementText(), event.getSignatories(), event.getObservers());
    }

    @Override
    public boolean equals(Object object) {
      if (this == object) {
        return true;
      }
      if (object == null) {
        return false;
      }
      if (!(object instanceof Contract)) {
        return false;
      }
      Contract other = (Contract) object;
      return this.id.equals(other.id) && this.data.equals(other.data) && this.agreementText.equals(other.agreementText) && this.signatories.equals(other.signatories) && this.observers.equals(other.observers);
    }

    @Override
    public int hashCode() {
      return Objects.hash(this.id, this.data, this.agreementText, this.signatories, this.observers);
    }

    @Override
    public String toString() {
      return String.format("com.daml.generated.marketplace.clearing.market.service.Offer.Contract(%s, %s, %s, %s, %s)", this.id, this.data, this.agreementText, this.signatories, this.observers);
    }
  }
}
