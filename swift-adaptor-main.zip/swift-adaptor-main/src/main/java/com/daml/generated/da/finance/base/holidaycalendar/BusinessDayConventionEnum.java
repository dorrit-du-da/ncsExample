package com.daml.generated.da.finance.base.holidaycalendar;

import com.daml.ledger.javaapi.data.DamlEnum;
import com.daml.ledger.javaapi.data.Value;
import java.lang.IllegalArgumentException;
import java.lang.String;
import java.util.HashMap;
import java.util.Map;

public enum BusinessDayConventionEnum {
  FOLLOWING,

  MODFOLLOWING,

  MODPRECEDING,

  NONE,

  PRECEDING;

  private static final DamlEnum[] __values$ = {new DamlEnum("FOLLOWING"), new DamlEnum("MODFOLLOWING"), new DamlEnum("MODPRECEDING"), new DamlEnum("NONE"), new DamlEnum("PRECEDING")};

  private static final Map<String, BusinessDayConventionEnum> __enums$ = BusinessDayConventionEnum.__buildEnumsMap$();

  private static final Map<String, BusinessDayConventionEnum> __buildEnumsMap$() {
    Map<String, BusinessDayConventionEnum> m = new HashMap<String, BusinessDayConventionEnum>();
    m.put("FOLLOWING", FOLLOWING);
    m.put("MODFOLLOWING", MODFOLLOWING);
    m.put("MODPRECEDING", MODPRECEDING);
    m.put("NONE", NONE);
    m.put("PRECEDING", PRECEDING);
    return m;
  }

  public static final BusinessDayConventionEnum fromValue(Value value$) {
    String constructor$ = value$.asEnum().orElseThrow(() -> new IllegalArgumentException("Expected DamlEnum to build an instance of the Enum BusinessDayConventionEnum")).getConstructor();
    if (!BusinessDayConventionEnum.__enums$.containsKey(constructor$)) throw new IllegalArgumentException("Expected a DamlEnum with BusinessDayConventionEnum constructor, found " + constructor$);
    return (BusinessDayConventionEnum) BusinessDayConventionEnum.__enums$.get(constructor$);
  }

  public final DamlEnum toValue() {
    return BusinessDayConventionEnum.__values$[ordinal()];
  }
}
