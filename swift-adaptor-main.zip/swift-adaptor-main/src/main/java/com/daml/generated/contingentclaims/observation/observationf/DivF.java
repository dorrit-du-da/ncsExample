package com.daml.generated.contingentclaims.observation.observationf;

import com.daml.generated.contingentclaims.observation.ObservationF;
import com.daml.generated.da.types.Tuple2;
import com.daml.ledger.javaapi.data.Value;
import com.daml.ledger.javaapi.data.Variant;
import java.lang.IllegalArgumentException;
import java.lang.Object;
import java.lang.Override;
import java.lang.String;
import java.util.Objects;
import java.util.function.Function;

public class DivF<t, x, b> extends ObservationF<t, x, b> {
  public static final String _packageId = "636e6e778aedec0710919591e9cb2a9404d6daab0581e4ddc515eeae03256f45";

  public final Tuple2<b, b> tuple2Value;

  public DivF(Tuple2<b, b> tuple2Value) {
    this.tuple2Value = tuple2Value;
  }

  public Variant toValue(Function<b, Value> toValueb) {
    return new Variant("DivF", this.tuple2Value.toValue(v$0 -> toValueb.apply(v$0),v$1 -> toValueb.apply(v$1)));
  }

  public static <t, x, b> DivF<t, x, b> fromValue(Value value$, Function<Value, b> fromValueb)
      throws IllegalArgumentException {
    Variant variant$ = value$.asVariant().orElseThrow(() -> new IllegalArgumentException("Expected: Variant. Actual: " + value$.getClass().getName()));
    if (!"DivF".equals(variant$.getConstructor())) throw new IllegalArgumentException("Invalid constructor. Expected: DivF. Actual: " + variant$.getConstructor());
    Value variantValue$ = variant$.getValue();
    Tuple2<b, b> body = Tuple2.<b, b>fromValue(variantValue$, v$0 -> fromValueb.apply(v$0), v$1 -> fromValueb.apply(v$1));
    return new DivF<t, x, b>(body);
  }

  public Variant toValue(Function<t, Value> toValuet, Function<x, Value> toValuex,
      Function<b, Value> toValueb) {
    return new Variant("DivF", this.tuple2Value.toValue(v$0 -> toValueb.apply(v$0),v$1 -> toValueb.apply(v$1)));
  }

  public static <t, x, b> DivF<t, x, b> fromValue(Value value$, Function<Value, t> fromValuet,
      Function<Value, x> fromValuex, Function<Value, b> fromValueb) throws
      IllegalArgumentException {
    Variant variant$ = value$.asVariant().orElseThrow(() -> new IllegalArgumentException("Expected: Variant. Actual: " + value$.getClass().getName()));
    if (!"DivF".equals(variant$.getConstructor())) throw new IllegalArgumentException("Invalid constructor. Expected: DivF. Actual: " + variant$.getConstructor());
    Value variantValue$ = variant$.getValue();
    Tuple2<b, b> body = Tuple2.<b, b>fromValue(variantValue$, v$0 -> fromValueb.apply(v$0), v$1 -> fromValueb.apply(v$1));
    return new DivF<t, x, b>(body);
  }

  @Override
  public boolean equals(Object object) {
    if (this == object) {
      return true;
    }
    if (object == null) {
      return false;
    }
    if (!(object instanceof DivF<?, ?, ?>)) {
      return false;
    }
    DivF<?, ?, ?> other = (DivF<?, ?, ?>) object;
    return this.tuple2Value.equals(other.tuple2Value);
  }

  @Override
  public int hashCode() {
    return Objects.hash(this.tuple2Value);
  }

  @Override
  public String toString() {
    return String.format("DivF(%s)", this.tuple2Value);
  }
}
