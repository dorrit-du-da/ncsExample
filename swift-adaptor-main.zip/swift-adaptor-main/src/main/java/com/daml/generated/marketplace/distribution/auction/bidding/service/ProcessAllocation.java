package com.daml.generated.marketplace.distribution.auction.bidding.service;

import com.daml.generated.marketplace.distribution.auction.bidding.model.Bid;
import com.daml.ledger.javaapi.data.DamlRecord;
import com.daml.ledger.javaapi.data.Numeric;
import com.daml.ledger.javaapi.data.Value;
import java.lang.IllegalArgumentException;
import java.lang.Object;
import java.lang.Override;
import java.lang.String;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

public class ProcessAllocation {
  public static final String _packageId = "636e6e778aedec0710919591e9cb2a9404d6daab0581e4ddc515eeae03256f45";

  public final Bid.ContractId bidCid;

  public final BigDecimal quantity;

  public final BigDecimal amount;

  public final BigDecimal price;

  public ProcessAllocation(Bid.ContractId bidCid, BigDecimal quantity, BigDecimal amount,
      BigDecimal price) {
    this.bidCid = bidCid;
    this.quantity = quantity;
    this.amount = amount;
    this.price = price;
  }

  public static ProcessAllocation fromValue(Value value$) throws IllegalArgumentException {
    Value recordValue$ = value$;
    DamlRecord record$ = recordValue$.asRecord().orElseThrow(() -> new IllegalArgumentException("Contracts must be constructed from Records"));
    List<DamlRecord.Field> fields$ = record$.getFields();
    int numberOfFields = fields$.size();
    if (numberOfFields != 4) {
      throw new IllegalArgumentException("Expected 4 arguments, got " + numberOfFields);
    }
    Bid.ContractId bidCid = new Bid.ContractId(fields$.get(0).getValue().asContractId().orElseThrow(() -> new IllegalArgumentException("Expected bidCid to be of type com.daml.ledger.javaapi.data.ContractId")).getValue());
    BigDecimal quantity = fields$.get(1).getValue().asNumeric().orElseThrow(() -> new IllegalArgumentException("Expected quantity to be of type com.daml.ledger.javaapi.data.Numeric")).getValue();
    BigDecimal amount = fields$.get(2).getValue().asNumeric().orElseThrow(() -> new IllegalArgumentException("Expected amount to be of type com.daml.ledger.javaapi.data.Numeric")).getValue();
    BigDecimal price = fields$.get(3).getValue().asNumeric().orElseThrow(() -> new IllegalArgumentException("Expected price to be of type com.daml.ledger.javaapi.data.Numeric")).getValue();
    return new com.daml.generated.marketplace.distribution.auction.bidding.service.ProcessAllocation(bidCid, quantity, amount, price);
  }

  public DamlRecord toValue() {
    ArrayList<DamlRecord.Field> fields = new ArrayList<DamlRecord.Field>(4);
    fields.add(new DamlRecord.Field("bidCid", this.bidCid.toValue()));
    fields.add(new DamlRecord.Field("quantity", new Numeric(this.quantity)));
    fields.add(new DamlRecord.Field("amount", new Numeric(this.amount)));
    fields.add(new DamlRecord.Field("price", new Numeric(this.price)));
    return new DamlRecord(fields);
  }

  @Override
  public boolean equals(Object object) {
    if (this == object) {
      return true;
    }
    if (object == null) {
      return false;
    }
    if (!(object instanceof ProcessAllocation)) {
      return false;
    }
    ProcessAllocation other = (ProcessAllocation) object;
    return this.bidCid.equals(other.bidCid) && this.quantity.equals(other.quantity) && this.amount.equals(other.amount) && this.price.equals(other.price);
  }

  @Override
  public int hashCode() {
    return Objects.hash(this.bidCid, this.quantity, this.amount, this.price);
  }

  @Override
  public String toString() {
    return String.format("com.daml.generated.marketplace.distribution.auction.bidding.service.ProcessAllocation(%s, %s, %s, %s)", this.bidCid, this.quantity, this.amount, this.price);
  }
}
