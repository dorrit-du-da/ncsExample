package com.daml.generated.da.finance.trade.settlementinstruction;

import com.daml.generated.da.finance.asset.AssetDeposit;
import com.daml.generated.da.finance.types.Asset;
import com.daml.generated.da.finance.types.Id;
import com.daml.generated.da.finance.types.MasterAgreement;
import com.daml.generated.da.internal.template.Archive;
import com.daml.generated.da.set.types.Set;
import com.daml.generated.da.types.Tuple3;
import com.daml.ledger.javaapi.data.CreateAndExerciseCommand;
import com.daml.ledger.javaapi.data.CreateCommand;
import com.daml.ledger.javaapi.data.CreatedEvent;
import com.daml.ledger.javaapi.data.DamlCollectors;
import com.daml.ledger.javaapi.data.DamlRecord;
import com.daml.ledger.javaapi.data.ExerciseByKeyCommand;
import com.daml.ledger.javaapi.data.ExerciseCommand;
import com.daml.ledger.javaapi.data.Identifier;
import com.daml.ledger.javaapi.data.Party;
import com.daml.ledger.javaapi.data.Template;
import com.daml.ledger.javaapi.data.Value;
import java.lang.Deprecated;
import java.lang.IllegalArgumentException;
import java.lang.Object;
import java.lang.Override;
import java.lang.String;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Objects;
import java.util.Optional;

public final class SettlementInstruction extends Template {
  public static final Identifier TEMPLATE_ID = new Identifier("636e6e778aedec0710919591e9cb2a9404d6daab0581e4ddc515eeae03256f45", "DA.Finance.Trade.SettlementInstruction", "SettlementInstruction");

  public final MasterAgreement masterAgreement;

  public final Id tradeId;

  public final Asset asset;

  public final List<SettlementDetails> steps;

  public final Set<String> observers;

  public SettlementInstruction(MasterAgreement masterAgreement, Id tradeId, Asset asset,
      List<SettlementDetails> steps, Set<String> observers) {
    this.masterAgreement = masterAgreement;
    this.tradeId = tradeId;
    this.asset = asset;
    this.steps = steps;
    this.observers = observers;
  }

  public CreateCommand create() {
    return new CreateCommand(SettlementInstruction.TEMPLATE_ID, this.toValue());
  }

  public static ExerciseByKeyCommand exerciseByKeySettlementInstruction_AllocateNext(
      Tuple3<Id, Id, Id> key, SettlementInstruction_AllocateNext arg) {
    return new ExerciseByKeyCommand(SettlementInstruction.TEMPLATE_ID, key.toValue(v$0 -> v$0.toValue(),v$1 -> v$1.toValue(),v$2 -> v$2.toValue()), "SettlementInstruction_AllocateNext", arg.toValue());
  }

  public static ExerciseByKeyCommand exerciseByKeySettlementInstruction_AllocateNext(
      Tuple3<Id, Id, Id> key, AssetDeposit.ContractId depositCid, String ctrl) {
    return SettlementInstruction.exerciseByKeySettlementInstruction_AllocateNext(key, new SettlementInstruction_AllocateNext(depositCid, ctrl));
  }

  public static ExerciseByKeyCommand exerciseByKeySettlementInstruction_Process(
      Tuple3<Id, Id, Id> key, SettlementInstruction_Process arg) {
    return new ExerciseByKeyCommand(SettlementInstruction.TEMPLATE_ID, key.toValue(v$0 -> v$0.toValue(),v$1 -> v$1.toValue(),v$2 -> v$2.toValue()), "SettlementInstruction_Process", arg.toValue());
  }

  public static ExerciseByKeyCommand exerciseByKeySettlementInstruction_Process(
      Tuple3<Id, Id, Id> key) {
    return SettlementInstruction.exerciseByKeySettlementInstruction_Process(key, new SettlementInstruction_Process());
  }

  public static ExerciseByKeyCommand exerciseByKeyArchive(Tuple3<Id, Id, Id> key, Archive arg) {
    return new ExerciseByKeyCommand(SettlementInstruction.TEMPLATE_ID, key.toValue(v$0 -> v$0.toValue(),v$1 -> v$1.toValue(),v$2 -> v$2.toValue()), "Archive", arg.toValue());
  }

  public static ExerciseByKeyCommand exerciseByKeySettlementInstruction_Archive(
      Tuple3<Id, Id, Id> key, SettlementInstruction_Archive arg) {
    return new ExerciseByKeyCommand(SettlementInstruction.TEMPLATE_ID, key.toValue(v$0 -> v$0.toValue(),v$1 -> v$1.toValue(),v$2 -> v$2.toValue()), "SettlementInstruction_Archive", arg.toValue());
  }

  public static ExerciseByKeyCommand exerciseByKeySettlementInstruction_Archive(
      Tuple3<Id, Id, Id> key) {
    return SettlementInstruction.exerciseByKeySettlementInstruction_Archive(key, new SettlementInstruction_Archive());
  }

  public CreateAndExerciseCommand createAndExerciseSettlementInstruction_AllocateNext(
      SettlementInstruction_AllocateNext arg) {
    Value argValue = arg.toValue();
    return new CreateAndExerciseCommand(SettlementInstruction.TEMPLATE_ID, this.toValue(), "SettlementInstruction_AllocateNext", argValue);
  }

  public CreateAndExerciseCommand createAndExerciseSettlementInstruction_AllocateNext(
      AssetDeposit.ContractId depositCid, String ctrl) {
    return createAndExerciseSettlementInstruction_AllocateNext(new SettlementInstruction_AllocateNext(depositCid, ctrl));
  }

  public CreateAndExerciseCommand createAndExerciseSettlementInstruction_Process(
      SettlementInstruction_Process arg) {
    Value argValue = arg.toValue();
    return new CreateAndExerciseCommand(SettlementInstruction.TEMPLATE_ID, this.toValue(), "SettlementInstruction_Process", argValue);
  }

  public CreateAndExerciseCommand createAndExerciseSettlementInstruction_Process() {
    return createAndExerciseSettlementInstruction_Process(new SettlementInstruction_Process());
  }

  public CreateAndExerciseCommand createAndExerciseArchive(Archive arg) {
    Value argValue = arg.toValue();
    return new CreateAndExerciseCommand(SettlementInstruction.TEMPLATE_ID, this.toValue(), "Archive", argValue);
  }

  public CreateAndExerciseCommand createAndExerciseSettlementInstruction_Archive(
      SettlementInstruction_Archive arg) {
    Value argValue = arg.toValue();
    return new CreateAndExerciseCommand(SettlementInstruction.TEMPLATE_ID, this.toValue(), "SettlementInstruction_Archive", argValue);
  }

  public CreateAndExerciseCommand createAndExerciseSettlementInstruction_Archive() {
    return createAndExerciseSettlementInstruction_Archive(new SettlementInstruction_Archive());
  }

  public static CreateCommand create(MasterAgreement masterAgreement, Id tradeId, Asset asset,
      List<SettlementDetails> steps, Set<String> observers) {
    return new SettlementInstruction(masterAgreement, tradeId, asset, steps, observers).create();
  }

  public static SettlementInstruction fromValue(Value value$) throws IllegalArgumentException {
    Value recordValue$ = value$;
    DamlRecord record$ = recordValue$.asRecord().orElseThrow(() -> new IllegalArgumentException("Contracts must be constructed from Records"));
    List<DamlRecord.Field> fields$ = record$.getFields();
    int numberOfFields = fields$.size();
    if (numberOfFields != 5) {
      throw new IllegalArgumentException("Expected 5 arguments, got " + numberOfFields);
    }
    MasterAgreement masterAgreement = MasterAgreement.fromValue(fields$.get(0).getValue());
    Id tradeId = Id.fromValue(fields$.get(1).getValue());
    Asset asset = Asset.fromValue(fields$.get(2).getValue());
    List<SettlementDetails> steps = fields$.get(3).getValue().asList()
            .map(v$0 -> v$0.toList(v$1 ->
                SettlementDetails.fromValue(v$1)
            ))
            .orElseThrow(() -> new IllegalArgumentException("Expected steps to be of type com.daml.ledger.javaapi.data.DamlList"))
        ;
    Set<String> observers = Set.<java.lang.String>fromValue(fields$.get(4).getValue(), v$0 -> v$0.asParty().orElseThrow(() -> new IllegalArgumentException("Expected observers to be of type com.daml.ledger.javaapi.data.Party")).getValue());
    return new com.daml.generated.da.finance.trade.settlementinstruction.SettlementInstruction(masterAgreement, tradeId, asset, steps, observers);
  }

  public DamlRecord toValue() {
    ArrayList<DamlRecord.Field> fields = new ArrayList<DamlRecord.Field>(5);
    fields.add(new DamlRecord.Field("masterAgreement", this.masterAgreement.toValue()));
    fields.add(new DamlRecord.Field("tradeId", this.tradeId.toValue()));
    fields.add(new DamlRecord.Field("asset", this.asset.toValue()));
    fields.add(new DamlRecord.Field("steps", this.steps.stream().collect(DamlCollectors.toDamlList(v$0 -> v$0.toValue()))));
    fields.add(new DamlRecord.Field("observers", this.observers.toValue(v$0 -> new Party(v$0))));
    return new DamlRecord(fields);
  }

  @Override
  public boolean equals(Object object) {
    if (this == object) {
      return true;
    }
    if (object == null) {
      return false;
    }
    if (!(object instanceof SettlementInstruction)) {
      return false;
    }
    SettlementInstruction other = (SettlementInstruction) object;
    return this.masterAgreement.equals(other.masterAgreement) && this.tradeId.equals(other.tradeId) && this.asset.equals(other.asset) && this.steps.equals(other.steps) && this.observers.equals(other.observers);
  }

  @Override
  public int hashCode() {
    return Objects.hash(this.masterAgreement, this.tradeId, this.asset, this.steps, this.observers);
  }

  @Override
  public String toString() {
    return String.format("com.daml.generated.da.finance.trade.settlementinstruction.SettlementInstruction(%s, %s, %s, %s, %s)", this.masterAgreement, this.tradeId, this.asset, this.steps, this.observers);
  }

  public static final class ContractId extends com.daml.ledger.javaapi.data.codegen.ContractId<SettlementInstruction> {
    public ContractId(String contractId) {
      super(contractId);
    }

    public ExerciseCommand exerciseSettlementInstruction_AllocateNext(
        SettlementInstruction_AllocateNext arg) {
      Value argValue = arg.toValue();
      return new ExerciseCommand(SettlementInstruction.TEMPLATE_ID, this.contractId, "SettlementInstruction_AllocateNext", argValue);
    }

    public ExerciseCommand exerciseSettlementInstruction_AllocateNext(
        AssetDeposit.ContractId depositCid, String ctrl) {
      return exerciseSettlementInstruction_AllocateNext(new SettlementInstruction_AllocateNext(depositCid, ctrl));
    }

    public ExerciseCommand exerciseSettlementInstruction_Process(
        SettlementInstruction_Process arg) {
      Value argValue = arg.toValue();
      return new ExerciseCommand(SettlementInstruction.TEMPLATE_ID, this.contractId, "SettlementInstruction_Process", argValue);
    }

    public ExerciseCommand exerciseSettlementInstruction_Process() {
      return exerciseSettlementInstruction_Process(new SettlementInstruction_Process());
    }

    public ExerciseCommand exerciseArchive(Archive arg) {
      Value argValue = arg.toValue();
      return new ExerciseCommand(SettlementInstruction.TEMPLATE_ID, this.contractId, "Archive", argValue);
    }

    public ExerciseCommand exerciseSettlementInstruction_Archive(
        SettlementInstruction_Archive arg) {
      Value argValue = arg.toValue();
      return new ExerciseCommand(SettlementInstruction.TEMPLATE_ID, this.contractId, "SettlementInstruction_Archive", argValue);
    }

    public ExerciseCommand exerciseSettlementInstruction_Archive() {
      return exerciseSettlementInstruction_Archive(new SettlementInstruction_Archive());
    }
  }

  public static class Contract implements com.daml.ledger.javaapi.data.Contract {
    public final ContractId id;

    public final SettlementInstruction data;

    public final Optional<String> agreementText;

    public final Optional<Tuple3<Id, Id, Id>> key;

    public final java.util.Set<String> signatories;

    public final java.util.Set<String> observers;

    public Contract(ContractId id, SettlementInstruction data, Optional<String> agreementText,
        Optional<Tuple3<Id, Id, Id>> key, java.util.Set<String> signatories,
        java.util.Set<String> observers) {
      this.id = id;
      this.data = data;
      this.agreementText = agreementText;
      this.key = key;
      this.signatories = signatories;
      this.observers = observers;
    }

    public static Contract fromIdAndRecord(String contractId, DamlRecord record$,
        Optional<String> agreementText, Optional<Tuple3<Id, Id, Id>> key,
        java.util.Set<String> signatories, java.util.Set<String> observers) {
      ContractId id = new ContractId(contractId);
      SettlementInstruction data = SettlementInstruction.fromValue(record$);
      return new Contract(id, data, agreementText, key, signatories, observers);
    }

    @Deprecated
    public static Contract fromIdAndRecord(String contractId, DamlRecord record$) {
      ContractId id = new ContractId(contractId);
      SettlementInstruction data = SettlementInstruction.fromValue(record$);
      return new Contract(id, data, Optional.empty(), Optional.empty(), Collections.emptySet(), Collections.emptySet());
    }

    public static Contract fromCreatedEvent(CreatedEvent event) {
      return fromIdAndRecord(event.getContractId(), event.getArguments(), event.getAgreementText(), event.getContractKey().map(e -> Tuple3.<com.daml.generated.da.finance.types.Id, com.daml.generated.da.finance.types.Id, com.daml.generated.da.finance.types.Id>fromValue(e, v$0 -> Id.fromValue(v$0), v$1 -> Id.fromValue(v$1), v$2 -> Id.fromValue(v$2))), event.getSignatories(), event.getObservers());
    }

    @Override
    public boolean equals(Object object) {
      if (this == object) {
        return true;
      }
      if (object == null) {
        return false;
      }
      if (!(object instanceof Contract)) {
        return false;
      }
      Contract other = (Contract) object;
      return this.id.equals(other.id) && this.data.equals(other.data) && this.agreementText.equals(other.agreementText) && this.key.equals(other.key) && this.signatories.equals(other.signatories) && this.observers.equals(other.observers);
    }

    @Override
    public int hashCode() {
      return Objects.hash(this.id, this.data, this.agreementText, this.key, this.signatories, this.observers);
    }

    @Override
    public String toString() {
      return String.format("com.daml.generated.da.finance.trade.settlementinstruction.SettlementInstruction.Contract(%s, %s, %s, %s, %s, %s)", this.id, this.data, this.agreementText, this.key, this.signatories, this.observers);
    }
  }
}
