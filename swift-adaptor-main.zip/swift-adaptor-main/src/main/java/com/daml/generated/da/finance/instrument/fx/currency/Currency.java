package com.daml.generated.da.finance.instrument.fx.currency;

import com.daml.generated.da.finance.types.Id;
import com.daml.generated.da.internal.template.Archive;
import com.daml.generated.da.set.types.Set;
import com.daml.ledger.javaapi.data.CreateAndExerciseCommand;
import com.daml.ledger.javaapi.data.CreateCommand;
import com.daml.ledger.javaapi.data.CreatedEvent;
import com.daml.ledger.javaapi.data.DamlRecord;
import com.daml.ledger.javaapi.data.ExerciseByKeyCommand;
import com.daml.ledger.javaapi.data.ExerciseCommand;
import com.daml.ledger.javaapi.data.Identifier;
import com.daml.ledger.javaapi.data.Party;
import com.daml.ledger.javaapi.data.Template;
import com.daml.ledger.javaapi.data.Text;
import com.daml.ledger.javaapi.data.Value;
import java.lang.Deprecated;
import java.lang.IllegalArgumentException;
import java.lang.Object;
import java.lang.Override;
import java.lang.String;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Objects;
import java.util.Optional;

public final class Currency extends Template {
  public static final Identifier TEMPLATE_ID = new Identifier("636e6e778aedec0710919591e9cb2a9404d6daab0581e4ddc515eeae03256f45", "DA.Finance.Instrument.FX.Currency", "Currency");

  public final Id id;

  public final String isoCode;

  public final Set<String> observers;

  public Currency(Id id, String isoCode, Set<String> observers) {
    this.id = id;
    this.isoCode = isoCode;
    this.observers = observers;
  }

  public CreateCommand create() {
    return new CreateCommand(Currency.TEMPLATE_ID, this.toValue());
  }

  public static ExerciseByKeyCommand exerciseByKeyArchive(Id key, Archive arg) {
    return new ExerciseByKeyCommand(Currency.TEMPLATE_ID, key.toValue(), "Archive", arg.toValue());
  }

  public static ExerciseByKeyCommand exerciseByKeyEquityStock_SetObservers(Id key,
      EquityStock_SetObservers arg) {
    return new ExerciseByKeyCommand(Currency.TEMPLATE_ID, key.toValue(), "EquityStock_SetObservers", arg.toValue());
  }

  public static ExerciseByKeyCommand exerciseByKeyEquityStock_SetObservers(Id key,
      Set<String> newObservers) {
    return Currency.exerciseByKeyEquityStock_SetObservers(key, new EquityStock_SetObservers(newObservers));
  }

  public CreateAndExerciseCommand createAndExerciseArchive(Archive arg) {
    Value argValue = arg.toValue();
    return new CreateAndExerciseCommand(Currency.TEMPLATE_ID, this.toValue(), "Archive", argValue);
  }

  public CreateAndExerciseCommand createAndExerciseEquityStock_SetObservers(
      EquityStock_SetObservers arg) {
    Value argValue = arg.toValue();
    return new CreateAndExerciseCommand(Currency.TEMPLATE_ID, this.toValue(), "EquityStock_SetObservers", argValue);
  }

  public CreateAndExerciseCommand createAndExerciseEquityStock_SetObservers(
      Set<String> newObservers) {
    return createAndExerciseEquityStock_SetObservers(new EquityStock_SetObservers(newObservers));
  }

  public static CreateCommand create(Id id, String isoCode, Set<String> observers) {
    return new Currency(id, isoCode, observers).create();
  }

  public static Currency fromValue(Value value$) throws IllegalArgumentException {
    Value recordValue$ = value$;
    DamlRecord record$ = recordValue$.asRecord().orElseThrow(() -> new IllegalArgumentException("Contracts must be constructed from Records"));
    List<DamlRecord.Field> fields$ = record$.getFields();
    int numberOfFields = fields$.size();
    if (numberOfFields != 3) {
      throw new IllegalArgumentException("Expected 3 arguments, got " + numberOfFields);
    }
    Id id = Id.fromValue(fields$.get(0).getValue());
    String isoCode = fields$.get(1).getValue().asText().orElseThrow(() -> new IllegalArgumentException("Expected isoCode to be of type com.daml.ledger.javaapi.data.Text")).getValue();
    Set<String> observers = Set.<java.lang.String>fromValue(fields$.get(2).getValue(), v$0 -> v$0.asParty().orElseThrow(() -> new IllegalArgumentException("Expected observers to be of type com.daml.ledger.javaapi.data.Party")).getValue());
    return new com.daml.generated.da.finance.instrument.fx.currency.Currency(id, isoCode, observers);
  }

  public DamlRecord toValue() {
    ArrayList<DamlRecord.Field> fields = new ArrayList<DamlRecord.Field>(3);
    fields.add(new DamlRecord.Field("id", this.id.toValue()));
    fields.add(new DamlRecord.Field("isoCode", new Text(this.isoCode)));
    fields.add(new DamlRecord.Field("observers", this.observers.toValue(v$0 -> new Party(v$0))));
    return new DamlRecord(fields);
  }

  @Override
  public boolean equals(Object object) {
    if (this == object) {
      return true;
    }
    if (object == null) {
      return false;
    }
    if (!(object instanceof Currency)) {
      return false;
    }
    Currency other = (Currency) object;
    return this.id.equals(other.id) && this.isoCode.equals(other.isoCode) && this.observers.equals(other.observers);
  }

  @Override
  public int hashCode() {
    return Objects.hash(this.id, this.isoCode, this.observers);
  }

  @Override
  public String toString() {
    return String.format("com.daml.generated.da.finance.instrument.fx.currency.Currency(%s, %s, %s)", this.id, this.isoCode, this.observers);
  }

  public static final class ContractId extends com.daml.ledger.javaapi.data.codegen.ContractId<Currency> {
    public ContractId(String contractId) {
      super(contractId);
    }

    public ExerciseCommand exerciseArchive(Archive arg) {
      Value argValue = arg.toValue();
      return new ExerciseCommand(Currency.TEMPLATE_ID, this.contractId, "Archive", argValue);
    }

    public ExerciseCommand exerciseEquityStock_SetObservers(EquityStock_SetObservers arg) {
      Value argValue = arg.toValue();
      return new ExerciseCommand(Currency.TEMPLATE_ID, this.contractId, "EquityStock_SetObservers", argValue);
    }

    public ExerciseCommand exerciseEquityStock_SetObservers(Set<String> newObservers) {
      return exerciseEquityStock_SetObservers(new EquityStock_SetObservers(newObservers));
    }
  }

  public static class Contract implements com.daml.ledger.javaapi.data.Contract {
    public final ContractId id;

    public final Currency data;

    public final Optional<String> agreementText;

    public final Optional<Id> key;

    public final java.util.Set<String> signatories;

    public final java.util.Set<String> observers;

    public Contract(ContractId id, Currency data, Optional<String> agreementText, Optional<Id> key,
        java.util.Set<String> signatories, java.util.Set<String> observers) {
      this.id = id;
      this.data = data;
      this.agreementText = agreementText;
      this.key = key;
      this.signatories = signatories;
      this.observers = observers;
    }

    public static Contract fromIdAndRecord(String contractId, DamlRecord record$,
        Optional<String> agreementText, Optional<Id> key, java.util.Set<String> signatories,
        java.util.Set<String> observers) {
      ContractId id = new ContractId(contractId);
      Currency data = Currency.fromValue(record$);
      return new Contract(id, data, agreementText, key, signatories, observers);
    }

    @Deprecated
    public static Contract fromIdAndRecord(String contractId, DamlRecord record$) {
      ContractId id = new ContractId(contractId);
      Currency data = Currency.fromValue(record$);
      return new Contract(id, data, Optional.empty(), Optional.empty(), Collections.emptySet(), Collections.emptySet());
    }

    public static Contract fromCreatedEvent(CreatedEvent event) {
      return fromIdAndRecord(event.getContractId(), event.getArguments(), event.getAgreementText(), event.getContractKey().map(e -> Id.fromValue(e)), event.getSignatories(), event.getObservers());
    }

    @Override
    public boolean equals(Object object) {
      if (this == object) {
        return true;
      }
      if (object == null) {
        return false;
      }
      if (!(object instanceof Contract)) {
        return false;
      }
      Contract other = (Contract) object;
      return this.id.equals(other.id) && this.data.equals(other.data) && this.agreementText.equals(other.agreementText) && this.key.equals(other.key) && this.signatories.equals(other.signatories) && this.observers.equals(other.observers);
    }

    @Override
    public int hashCode() {
      return Objects.hash(this.id, this.data, this.agreementText, this.key, this.signatories, this.observers);
    }

    @Override
    public String toString() {
      return String.format("com.daml.generated.da.finance.instrument.fx.currency.Currency.Contract(%s, %s, %s, %s, %s, %s)", this.id, this.data, this.agreementText, this.key, this.signatories, this.observers);
    }
  }
}
