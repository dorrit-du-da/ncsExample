package com.daml.generated.marketplace.distribution.auction.model.status;

import com.daml.generated.marketplace.distribution.auction.model.Status;
import com.daml.ledger.javaapi.data.DamlRecord;
import com.daml.ledger.javaapi.data.Numeric;
import com.daml.ledger.javaapi.data.Value;
import com.daml.ledger.javaapi.data.Variant;
import java.lang.IllegalArgumentException;
import java.lang.Object;
import java.lang.Override;
import java.lang.String;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

public class PartiallyAllocated extends Status {
  public static final String _packageId = "636e6e778aedec0710919591e9cb2a9404d6daab0581e4ddc515eeae03256f45";

  public final BigDecimal finalPrice;

  public final BigDecimal remaining;

  public PartiallyAllocated(BigDecimal finalPrice, BigDecimal remaining) {
    this.finalPrice = finalPrice;
    this.remaining = remaining;
  }

  public Variant toValue() {
    ArrayList<DamlRecord.Field> fields = new ArrayList<DamlRecord.Field>(2);
    fields.add(new DamlRecord.Field("finalPrice", new Numeric(this.finalPrice)));
    fields.add(new DamlRecord.Field("remaining", new Numeric(this.remaining)));
    return new Variant("PartiallyAllocated", new DamlRecord(fields));
  }

  public static PartiallyAllocated fromValue(Value value$) throws IllegalArgumentException {
    Variant variant$ = value$.asVariant().orElseThrow(() -> new IllegalArgumentException("Expected: Variant. Actual: " + value$.getClass().getName()));
    if (!"PartiallyAllocated".equals(variant$.getConstructor())) throw new IllegalArgumentException("Invalid constructor. Expected: PartiallyAllocated. Actual: " + variant$.getConstructor());
    Value recordValue$ = variant$.getValue();
    DamlRecord record$ = recordValue$.asRecord().orElseThrow(() -> new IllegalArgumentException("Contracts must be constructed from Records"));
    List<DamlRecord.Field> fields$ = record$.getFields();
    int numberOfFields = fields$.size();
    if (numberOfFields != 2) {
      throw new IllegalArgumentException("Expected 2 arguments, got " + numberOfFields);
    }
    BigDecimal finalPrice = fields$.get(0).getValue().asNumeric().orElseThrow(() -> new IllegalArgumentException("Expected finalPrice to be of type com.daml.ledger.javaapi.data.Numeric")).getValue();
    BigDecimal remaining = fields$.get(1).getValue().asNumeric().orElseThrow(() -> new IllegalArgumentException("Expected remaining to be of type com.daml.ledger.javaapi.data.Numeric")).getValue();
    return new PartiallyAllocated(finalPrice, remaining);
  }

  @Override
  public boolean equals(Object object) {
    if (this == object) {
      return true;
    }
    if (object == null) {
      return false;
    }
    if (!(object instanceof PartiallyAllocated)) {
      return false;
    }
    PartiallyAllocated other = (PartiallyAllocated) object;
    return this.finalPrice.equals(other.finalPrice) && this.remaining.equals(other.remaining);
  }

  @Override
  public int hashCode() {
    return Objects.hash(this.finalPrice, this.remaining);
  }

  @Override
  public String toString() {
    return String.format("PartiallyAllocated(%s, %s)", this.finalPrice, this.remaining);
  }
}
