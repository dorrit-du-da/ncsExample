package com.daml.generated.marketplace.distribution.auction.bidding.service;

import com.daml.generated.da.finance.types.Asset;
import com.daml.generated.da.finance.types.Id;
import com.daml.generated.marketplace.distribution.auction.bidding.model.Bid;
import com.daml.ledger.javaapi.data.DamlCollectors;
import com.daml.ledger.javaapi.data.DamlRecord;
import com.daml.ledger.javaapi.data.Party;
import com.daml.ledger.javaapi.data.Text;
import com.daml.ledger.javaapi.data.Value;
import java.lang.IllegalArgumentException;
import java.lang.Object;
import java.lang.Override;
import java.lang.String;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

public class RequestBid {
  public static final String _packageId = "636e6e778aedec0710919591e9cb2a9404d6daab0581e4ddc515eeae03256f45";

  public final String issuer;

  public final String auctionId;

  public final Asset asset;

  public final Id quotedAssetId;

  public final List<Bid.ContractId> publishedBidCids;

  public RequestBid(String issuer, String auctionId, Asset asset, Id quotedAssetId,
      List<Bid.ContractId> publishedBidCids) {
    this.issuer = issuer;
    this.auctionId = auctionId;
    this.asset = asset;
    this.quotedAssetId = quotedAssetId;
    this.publishedBidCids = publishedBidCids;
  }

  public static RequestBid fromValue(Value value$) throws IllegalArgumentException {
    Value recordValue$ = value$;
    DamlRecord record$ = recordValue$.asRecord().orElseThrow(() -> new IllegalArgumentException("Contracts must be constructed from Records"));
    List<DamlRecord.Field> fields$ = record$.getFields();
    int numberOfFields = fields$.size();
    if (numberOfFields != 5) {
      throw new IllegalArgumentException("Expected 5 arguments, got " + numberOfFields);
    }
    String issuer = fields$.get(0).getValue().asParty().orElseThrow(() -> new IllegalArgumentException("Expected issuer to be of type com.daml.ledger.javaapi.data.Party")).getValue();
    String auctionId = fields$.get(1).getValue().asText().orElseThrow(() -> new IllegalArgumentException("Expected auctionId to be of type com.daml.ledger.javaapi.data.Text")).getValue();
    Asset asset = Asset.fromValue(fields$.get(2).getValue());
    Id quotedAssetId = Id.fromValue(fields$.get(3).getValue());
    List<Bid.ContractId> publishedBidCids = fields$.get(4).getValue().asList()
            .map(v$0 -> v$0.toList(v$1 ->
                new Bid.ContractId(v$1.asContractId().orElseThrow(() -> new IllegalArgumentException("Expected v$1 to be of type com.daml.ledger.javaapi.data.ContractId")).getValue())
            ))
            .orElseThrow(() -> new IllegalArgumentException("Expected publishedBidCids to be of type com.daml.ledger.javaapi.data.DamlList"))
        ;
    return new com.daml.generated.marketplace.distribution.auction.bidding.service.RequestBid(issuer, auctionId, asset, quotedAssetId, publishedBidCids);
  }

  public DamlRecord toValue() {
    ArrayList<DamlRecord.Field> fields = new ArrayList<DamlRecord.Field>(5);
    fields.add(new DamlRecord.Field("issuer", new Party(this.issuer)));
    fields.add(new DamlRecord.Field("auctionId", new Text(this.auctionId)));
    fields.add(new DamlRecord.Field("asset", this.asset.toValue()));
    fields.add(new DamlRecord.Field("quotedAssetId", this.quotedAssetId.toValue()));
    fields.add(new DamlRecord.Field("publishedBidCids", this.publishedBidCids.stream().collect(DamlCollectors.toDamlList(v$0 -> v$0.toValue()))));
    return new DamlRecord(fields);
  }

  @Override
  public boolean equals(Object object) {
    if (this == object) {
      return true;
    }
    if (object == null) {
      return false;
    }
    if (!(object instanceof RequestBid)) {
      return false;
    }
    RequestBid other = (RequestBid) object;
    return this.issuer.equals(other.issuer) && this.auctionId.equals(other.auctionId) && this.asset.equals(other.asset) && this.quotedAssetId.equals(other.quotedAssetId) && this.publishedBidCids.equals(other.publishedBidCids);
  }

  @Override
  public int hashCode() {
    return Objects.hash(this.issuer, this.auctionId, this.asset, this.quotedAssetId, this.publishedBidCids);
  }

  @Override
  public String toString() {
    return String.format("com.daml.generated.marketplace.distribution.auction.bidding.service.RequestBid(%s, %s, %s, %s, %s)", this.issuer, this.auctionId, this.asset, this.quotedAssetId, this.publishedBidCids);
  }
}
