package com.daml.generated.da.finance.instrument.equity.acbrc;

import com.daml.generated.da.finance.types.Id;
import com.daml.generated.da.internal.template.Archive;
import com.daml.generated.da.set.types.Set;
import com.daml.ledger.javaapi.data.Bool;
import com.daml.ledger.javaapi.data.CreateAndExerciseCommand;
import com.daml.ledger.javaapi.data.CreateCommand;
import com.daml.ledger.javaapi.data.CreatedEvent;
import com.daml.ledger.javaapi.data.DamlCollectors;
import com.daml.ledger.javaapi.data.DamlRecord;
import com.daml.ledger.javaapi.data.Date;
import com.daml.ledger.javaapi.data.ExerciseByKeyCommand;
import com.daml.ledger.javaapi.data.ExerciseCommand;
import com.daml.ledger.javaapi.data.Identifier;
import com.daml.ledger.javaapi.data.Int64;
import com.daml.ledger.javaapi.data.Numeric;
import com.daml.ledger.javaapi.data.Party;
import com.daml.ledger.javaapi.data.Template;
import com.daml.ledger.javaapi.data.Value;
import java.lang.Boolean;
import java.lang.Deprecated;
import java.lang.IllegalArgumentException;
import java.lang.Long;
import java.lang.Object;
import java.lang.Override;
import java.lang.String;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Objects;
import java.util.Optional;

public final class ACBRC extends Template {
  public static final Identifier TEMPLATE_ID = new Identifier("636e6e778aedec0710919591e9cb2a9404d6daab0581e4ddc515eeae03256f45", "DA.Finance.Instrument.Equity.ACBRC", "ACBRC");

  public final Id id;

  public final Id underlyingId;

  public final Id currencyId;

  public final BigDecimal knockInBarrier;

  public final Boolean knockInBarrierHit;

  public final BigDecimal callBarrier;

  public final Boolean callBarrierHit;

  public final List<LocalDate> fixingDates;

  public final Long fixingIdx;

  public final BigDecimal coupon;

  public final BigDecimal initialFixing;

  public final Set<String> observers;

  public ACBRC(Id id, Id underlyingId, Id currencyId, BigDecimal knockInBarrier,
      Boolean knockInBarrierHit, BigDecimal callBarrier, Boolean callBarrierHit,
      List<LocalDate> fixingDates, Long fixingIdx, BigDecimal coupon, BigDecimal initialFixing,
      Set<String> observers) {
    this.id = id;
    this.underlyingId = underlyingId;
    this.currencyId = currencyId;
    this.knockInBarrier = knockInBarrier;
    this.knockInBarrierHit = knockInBarrierHit;
    this.callBarrier = callBarrier;
    this.callBarrierHit = callBarrierHit;
    this.fixingDates = fixingDates;
    this.fixingIdx = fixingIdx;
    this.coupon = coupon;
    this.initialFixing = initialFixing;
    this.observers = observers;
  }

  public CreateCommand create() {
    return new CreateCommand(ACBRC.TEMPLATE_ID, this.toValue());
  }

  public static ExerciseByKeyCommand exerciseByKeyArchive(Id key, Archive arg) {
    return new ExerciseByKeyCommand(ACBRC.TEMPLATE_ID, key.toValue(), "Archive", arg.toValue());
  }

  public CreateAndExerciseCommand createAndExerciseArchive(Archive arg) {
    Value argValue = arg.toValue();
    return new CreateAndExerciseCommand(ACBRC.TEMPLATE_ID, this.toValue(), "Archive", argValue);
  }

  public static CreateCommand create(Id id, Id underlyingId, Id currencyId,
      BigDecimal knockInBarrier, Boolean knockInBarrierHit, BigDecimal callBarrier,
      Boolean callBarrierHit, List<LocalDate> fixingDates, Long fixingIdx, BigDecimal coupon,
      BigDecimal initialFixing, Set<String> observers) {
    return new ACBRC(id, underlyingId, currencyId, knockInBarrier, knockInBarrierHit, callBarrier, callBarrierHit, fixingDates, fixingIdx, coupon, initialFixing, observers).create();
  }

  public static ACBRC fromValue(Value value$) throws IllegalArgumentException {
    Value recordValue$ = value$;
    DamlRecord record$ = recordValue$.asRecord().orElseThrow(() -> new IllegalArgumentException("Contracts must be constructed from Records"));
    List<DamlRecord.Field> fields$ = record$.getFields();
    int numberOfFields = fields$.size();
    if (numberOfFields != 12) {
      throw new IllegalArgumentException("Expected 12 arguments, got " + numberOfFields);
    }
    Id id = Id.fromValue(fields$.get(0).getValue());
    Id underlyingId = Id.fromValue(fields$.get(1).getValue());
    Id currencyId = Id.fromValue(fields$.get(2).getValue());
    BigDecimal knockInBarrier = fields$.get(3).getValue().asNumeric().orElseThrow(() -> new IllegalArgumentException("Expected knockInBarrier to be of type com.daml.ledger.javaapi.data.Numeric")).getValue();
    Boolean knockInBarrierHit = fields$.get(4).getValue().asBool().orElseThrow(() -> new IllegalArgumentException("Expected knockInBarrierHit to be of type com.daml.ledger.javaapi.data.Bool")).getValue();
    BigDecimal callBarrier = fields$.get(5).getValue().asNumeric().orElseThrow(() -> new IllegalArgumentException("Expected callBarrier to be of type com.daml.ledger.javaapi.data.Numeric")).getValue();
    Boolean callBarrierHit = fields$.get(6).getValue().asBool().orElseThrow(() -> new IllegalArgumentException("Expected callBarrierHit to be of type com.daml.ledger.javaapi.data.Bool")).getValue();
    List<LocalDate> fixingDates = fields$.get(7).getValue().asList()
            .map(v$0 -> v$0.toList(v$1 ->
                v$1.asDate().orElseThrow(() -> new IllegalArgumentException("Expected v$1 to be of type com.daml.ledger.javaapi.data.Date")).getValue()
            ))
            .orElseThrow(() -> new IllegalArgumentException("Expected fixingDates to be of type com.daml.ledger.javaapi.data.DamlList"))
        ;
    Long fixingIdx = fields$.get(8).getValue().asInt64().orElseThrow(() -> new IllegalArgumentException("Expected fixingIdx to be of type com.daml.ledger.javaapi.data.Int64")).getValue();
    BigDecimal coupon = fields$.get(9).getValue().asNumeric().orElseThrow(() -> new IllegalArgumentException("Expected coupon to be of type com.daml.ledger.javaapi.data.Numeric")).getValue();
    BigDecimal initialFixing = fields$.get(10).getValue().asNumeric().orElseThrow(() -> new IllegalArgumentException("Expected initialFixing to be of type com.daml.ledger.javaapi.data.Numeric")).getValue();
    Set<String> observers = Set.<java.lang.String>fromValue(fields$.get(11).getValue(), v$0 -> v$0.asParty().orElseThrow(() -> new IllegalArgumentException("Expected observers to be of type com.daml.ledger.javaapi.data.Party")).getValue());
    return new com.daml.generated.da.finance.instrument.equity.acbrc.ACBRC(id, underlyingId, currencyId, knockInBarrier, knockInBarrierHit, callBarrier, callBarrierHit, fixingDates, fixingIdx, coupon, initialFixing, observers);
  }

  public DamlRecord toValue() {
    ArrayList<DamlRecord.Field> fields = new ArrayList<DamlRecord.Field>(12);
    fields.add(new DamlRecord.Field("id", this.id.toValue()));
    fields.add(new DamlRecord.Field("underlyingId", this.underlyingId.toValue()));
    fields.add(new DamlRecord.Field("currencyId", this.currencyId.toValue()));
    fields.add(new DamlRecord.Field("knockInBarrier", new Numeric(this.knockInBarrier)));
    fields.add(new DamlRecord.Field("knockInBarrierHit", new Bool(this.knockInBarrierHit)));
    fields.add(new DamlRecord.Field("callBarrier", new Numeric(this.callBarrier)));
    fields.add(new DamlRecord.Field("callBarrierHit", new Bool(this.callBarrierHit)));
    fields.add(new DamlRecord.Field("fixingDates", this.fixingDates.stream().collect(DamlCollectors.toDamlList(v$0 -> new Date((int) v$0.toEpochDay())))));
    fields.add(new DamlRecord.Field("fixingIdx", new Int64(this.fixingIdx)));
    fields.add(new DamlRecord.Field("coupon", new Numeric(this.coupon)));
    fields.add(new DamlRecord.Field("initialFixing", new Numeric(this.initialFixing)));
    fields.add(new DamlRecord.Field("observers", this.observers.toValue(v$0 -> new Party(v$0))));
    return new DamlRecord(fields);
  }

  @Override
  public boolean equals(Object object) {
    if (this == object) {
      return true;
    }
    if (object == null) {
      return false;
    }
    if (!(object instanceof ACBRC)) {
      return false;
    }
    ACBRC other = (ACBRC) object;
    return this.id.equals(other.id) && this.underlyingId.equals(other.underlyingId) && this.currencyId.equals(other.currencyId) && this.knockInBarrier.equals(other.knockInBarrier) && this.knockInBarrierHit.equals(other.knockInBarrierHit) && this.callBarrier.equals(other.callBarrier) && this.callBarrierHit.equals(other.callBarrierHit) && this.fixingDates.equals(other.fixingDates) && this.fixingIdx.equals(other.fixingIdx) && this.coupon.equals(other.coupon) && this.initialFixing.equals(other.initialFixing) && this.observers.equals(other.observers);
  }

  @Override
  public int hashCode() {
    return Objects.hash(this.id, this.underlyingId, this.currencyId, this.knockInBarrier, this.knockInBarrierHit, this.callBarrier, this.callBarrierHit, this.fixingDates, this.fixingIdx, this.coupon, this.initialFixing, this.observers);
  }

  @Override
  public String toString() {
    return String.format("com.daml.generated.da.finance.instrument.equity.acbrc.ACBRC(%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)", this.id, this.underlyingId, this.currencyId, this.knockInBarrier, this.knockInBarrierHit, this.callBarrier, this.callBarrierHit, this.fixingDates, this.fixingIdx, this.coupon, this.initialFixing, this.observers);
  }

  public static final class ContractId extends com.daml.ledger.javaapi.data.codegen.ContractId<ACBRC> {
    public ContractId(String contractId) {
      super(contractId);
    }

    public ExerciseCommand exerciseArchive(Archive arg) {
      Value argValue = arg.toValue();
      return new ExerciseCommand(ACBRC.TEMPLATE_ID, this.contractId, "Archive", argValue);
    }
  }

  public static class Contract implements com.daml.ledger.javaapi.data.Contract {
    public final ContractId id;

    public final ACBRC data;

    public final Optional<String> agreementText;

    public final Optional<Id> key;

    public final java.util.Set<String> signatories;

    public final java.util.Set<String> observers;

    public Contract(ContractId id, ACBRC data, Optional<String> agreementText, Optional<Id> key,
        java.util.Set<String> signatories, java.util.Set<String> observers) {
      this.id = id;
      this.data = data;
      this.agreementText = agreementText;
      this.key = key;
      this.signatories = signatories;
      this.observers = observers;
    }

    public static Contract fromIdAndRecord(String contractId, DamlRecord record$,
        Optional<String> agreementText, Optional<Id> key, java.util.Set<String> signatories,
        java.util.Set<String> observers) {
      ContractId id = new ContractId(contractId);
      ACBRC data = ACBRC.fromValue(record$);
      return new Contract(id, data, agreementText, key, signatories, observers);
    }

    @Deprecated
    public static Contract fromIdAndRecord(String contractId, DamlRecord record$) {
      ContractId id = new ContractId(contractId);
      ACBRC data = ACBRC.fromValue(record$);
      return new Contract(id, data, Optional.empty(), Optional.empty(), Collections.emptySet(), Collections.emptySet());
    }

    public static Contract fromCreatedEvent(CreatedEvent event) {
      return fromIdAndRecord(event.getContractId(), event.getArguments(), event.getAgreementText(), event.getContractKey().map(e -> Id.fromValue(e)), event.getSignatories(), event.getObservers());
    }

    @Override
    public boolean equals(Object object) {
      if (this == object) {
        return true;
      }
      if (object == null) {
        return false;
      }
      if (!(object instanceof Contract)) {
        return false;
      }
      Contract other = (Contract) object;
      return this.id.equals(other.id) && this.data.equals(other.data) && this.agreementText.equals(other.agreementText) && this.key.equals(other.key) && this.signatories.equals(other.signatories) && this.observers.equals(other.observers);
    }

    @Override
    public int hashCode() {
      return Objects.hash(this.id, this.data, this.agreementText, this.key, this.signatories, this.observers);
    }

    @Override
    public String toString() {
      return String.format("com.daml.generated.da.finance.instrument.equity.acbrc.ACBRC.Contract(%s, %s, %s, %s, %s, %s)", this.id, this.data, this.agreementText, this.key, this.signatories, this.observers);
    }
  }
}
