package com.daml.generated.marketplace.clearing.service;

import com.daml.ledger.javaapi.data.Value;
import com.daml.ledger.javaapi.data.Variant;
import java.lang.String;
import java.util.function.Function;

public abstract class CalculationResult<a, b> {
  public static final String _packageId = "636e6e778aedec0710919591e9cb2a9404d6daab0581e4ddc515eeae03256f45";

  public CalculationResult() {
  }

  public abstract Value toValue(Function<a, Value> toValuea, Function<b, Value> toValueb);

  public static <a, b> CalculationResult<a, b> fromValue(Value value$,
      Function<Value, a> fromValuea, Function<Value, b> fromValueb) {
    Variant variant$ = value$.asVariant().orElseThrow(() -> new IllegalArgumentException("Expected Variant to build an instance of the Variant com.daml.generated.marketplace.clearing.service.CalculationResult"));
    if ("CalculationSuccess".equals(variant$.getConstructor())) {
      return com.daml.generated.marketplace.clearing.service.calculationresult.CalculationSuccess.fromValue(variant$, fromValuea, fromValueb);
    }
    if ("CalculationFailure".equals(variant$.getConstructor())) {
      return com.daml.generated.marketplace.clearing.service.calculationresult.CalculationFailure.fromValue(variant$, fromValuea, fromValueb);
    }
    throw new IllegalArgumentException("Found unknown constructor variant$.getConstructor() for variant com.daml.generated.marketplace.clearing.service.CalculationResult, expected one of [CalculationSuccess, CalculationFailure]");
  }
}
