package com.daml.generated.marketplace.clearing.market.service;

import com.daml.generated.da.finance.types.Id;
import com.daml.ledger.javaapi.data.DamlCollectors;
import com.daml.ledger.javaapi.data.DamlRecord;
import com.daml.ledger.javaapi.data.Party;
import com.daml.ledger.javaapi.data.Text;
import com.daml.ledger.javaapi.data.Timestamp;
import com.daml.ledger.javaapi.data.Value;
import java.lang.IllegalArgumentException;
import java.lang.Object;
import java.lang.Override;
import java.lang.String;
import java.time.Instant;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

public class RequestFairValues {
  public static final String _packageId = "636e6e778aedec0710919591e9cb2a9404d6daab0581e4ddc515eeae03256f45";

  public final String party;

  public final List<String> listingIds;

  public final String calculationId;

  public final Instant upTo;

  public final Id currency;

  public RequestFairValues(String party, List<String> listingIds, String calculationId,
      Instant upTo, Id currency) {
    this.party = party;
    this.listingIds = listingIds;
    this.calculationId = calculationId;
    this.upTo = upTo;
    this.currency = currency;
  }

  public static RequestFairValues fromValue(Value value$) throws IllegalArgumentException {
    Value recordValue$ = value$;
    DamlRecord record$ = recordValue$.asRecord().orElseThrow(() -> new IllegalArgumentException("Contracts must be constructed from Records"));
    List<DamlRecord.Field> fields$ = record$.getFields();
    int numberOfFields = fields$.size();
    if (numberOfFields != 5) {
      throw new IllegalArgumentException("Expected 5 arguments, got " + numberOfFields);
    }
    String party = fields$.get(0).getValue().asParty().orElseThrow(() -> new IllegalArgumentException("Expected party to be of type com.daml.ledger.javaapi.data.Party")).getValue();
    List<String> listingIds = fields$.get(1).getValue().asList()
            .map(v$0 -> v$0.toList(v$1 ->
                v$1.asText().orElseThrow(() -> new IllegalArgumentException("Expected v$1 to be of type com.daml.ledger.javaapi.data.Text")).getValue()
            ))
            .orElseThrow(() -> new IllegalArgumentException("Expected listingIds to be of type com.daml.ledger.javaapi.data.DamlList"))
        ;
    String calculationId = fields$.get(2).getValue().asText().orElseThrow(() -> new IllegalArgumentException("Expected calculationId to be of type com.daml.ledger.javaapi.data.Text")).getValue();
    Instant upTo = fields$.get(3).getValue().asTimestamp().orElseThrow(() -> new IllegalArgumentException("Expected upTo to be of type com.daml.ledger.javaapi.data.Timestamp")).getValue();
    Id currency = Id.fromValue(fields$.get(4).getValue());
    return new com.daml.generated.marketplace.clearing.market.service.RequestFairValues(party, listingIds, calculationId, upTo, currency);
  }

  public DamlRecord toValue() {
    ArrayList<DamlRecord.Field> fields = new ArrayList<DamlRecord.Field>(5);
    fields.add(new DamlRecord.Field("party", new Party(this.party)));
    fields.add(new DamlRecord.Field("listingIds", this.listingIds.stream().collect(DamlCollectors.toDamlList(v$0 -> new Text(v$0)))));
    fields.add(new DamlRecord.Field("calculationId", new Text(this.calculationId)));
    fields.add(new DamlRecord.Field("upTo", Timestamp.fromInstant(this.upTo)));
    fields.add(new DamlRecord.Field("currency", this.currency.toValue()));
    return new DamlRecord(fields);
  }

  @Override
  public boolean equals(Object object) {
    if (this == object) {
      return true;
    }
    if (object == null) {
      return false;
    }
    if (!(object instanceof RequestFairValues)) {
      return false;
    }
    RequestFairValues other = (RequestFairValues) object;
    return this.party.equals(other.party) && this.listingIds.equals(other.listingIds) && this.calculationId.equals(other.calculationId) && this.upTo.equals(other.upTo) && this.currency.equals(other.currency);
  }

  @Override
  public int hashCode() {
    return Objects.hash(this.party, this.listingIds, this.calculationId, this.upTo, this.currency);
  }

  @Override
  public String toString() {
    return String.format("com.daml.generated.marketplace.clearing.market.service.RequestFairValues(%s, %s, %s, %s, %s)", this.party, this.listingIds, this.calculationId, this.upTo, this.currency);
  }
}
