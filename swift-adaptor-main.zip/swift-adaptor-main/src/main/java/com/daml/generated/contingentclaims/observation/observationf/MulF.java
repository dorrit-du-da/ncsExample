package com.daml.generated.contingentclaims.observation.observationf;

import com.daml.generated.contingentclaims.observation.ObservationF;
import com.daml.generated.da.types.Tuple2;
import com.daml.ledger.javaapi.data.Value;
import com.daml.ledger.javaapi.data.Variant;
import java.lang.IllegalArgumentException;
import java.lang.Object;
import java.lang.Override;
import java.lang.String;
import java.util.Objects;
import java.util.function.Function;

public class MulF<t, x, b> extends ObservationF<t, x, b> {
  public static final String _packageId = "636e6e778aedec0710919591e9cb2a9404d6daab0581e4ddc515eeae03256f45";

  public final Tuple2<b, b> tuple2Value;

  public MulF(Tuple2<b, b> tuple2Value) {
    this.tuple2Value = tuple2Value;
  }

  public Variant toValue(Function<b, Value> toValueb) {
    return new Variant("MulF", this.tuple2Value.toValue(v$0 -> toValueb.apply(v$0),v$1 -> toValueb.apply(v$1)));
  }

  public static <t, x, b> MulF<t, x, b> fromValue(Value value$, Function<Value, b> fromValueb)
      throws IllegalArgumentException {
    Variant variant$ = value$.asVariant().orElseThrow(() -> new IllegalArgumentException("Expected: Variant. Actual: " + value$.getClass().getName()));
    if (!"MulF".equals(variant$.getConstructor())) throw new IllegalArgumentException("Invalid constructor. Expected: MulF. Actual: " + variant$.getConstructor());
    Value variantValue$ = variant$.getValue();
    Tuple2<b, b> body = Tuple2.<b, b>fromValue(variantValue$, v$0 -> fromValueb.apply(v$0), v$1 -> fromValueb.apply(v$1));
    return new MulF<t, x, b>(body);
  }

  public Variant toValue(Function<t, Value> toValuet, Function<x, Value> toValuex,
      Function<b, Value> toValueb) {
    return new Variant("MulF", this.tuple2Value.toValue(v$0 -> toValueb.apply(v$0),v$1 -> toValueb.apply(v$1)));
  }

  public static <t, x, b> MulF<t, x, b> fromValue(Value value$, Function<Value, t> fromValuet,
      Function<Value, x> fromValuex, Function<Value, b> fromValueb) throws
      IllegalArgumentException {
    Variant variant$ = value$.asVariant().orElseThrow(() -> new IllegalArgumentException("Expected: Variant. Actual: " + value$.getClass().getName()));
    if (!"MulF".equals(variant$.getConstructor())) throw new IllegalArgumentException("Invalid constructor. Expected: MulF. Actual: " + variant$.getConstructor());
    Value variantValue$ = variant$.getValue();
    Tuple2<b, b> body = Tuple2.<b, b>fromValue(variantValue$, v$0 -> fromValueb.apply(v$0), v$1 -> fromValueb.apply(v$1));
    return new MulF<t, x, b>(body);
  }

  @Override
  public boolean equals(Object object) {
    if (this == object) {
      return true;
    }
    if (object == null) {
      return false;
    }
    if (!(object instanceof MulF<?, ?, ?>)) {
      return false;
    }
    MulF<?, ?, ?> other = (MulF<?, ?, ?>) object;
    return this.tuple2Value.equals(other.tuple2Value);
  }

  @Override
  public int hashCode() {
    return Objects.hash(this.tuple2Value);
  }

  @Override
  public String toString() {
    return String.format("MulF(%s)", this.tuple2Value);
  }
}
