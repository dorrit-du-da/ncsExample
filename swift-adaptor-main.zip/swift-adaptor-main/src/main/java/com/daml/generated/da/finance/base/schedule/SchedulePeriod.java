package com.daml.generated.da.finance.base.schedule;

import com.daml.ledger.javaapi.data.DamlRecord;
import com.daml.ledger.javaapi.data.Date;
import com.daml.ledger.javaapi.data.Value;
import java.lang.IllegalArgumentException;
import java.lang.Object;
import java.lang.Override;
import java.lang.String;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

public class SchedulePeriod {
  public static final String _packageId = "636e6e778aedec0710919591e9cb2a9404d6daab0581e4ddc515eeae03256f45";

  public final LocalDate adjustedEndDate;

  public final LocalDate adjustedStartDate;

  public final LocalDate unadjustedEndDate;

  public final LocalDate unadjustedStartDate;

  public SchedulePeriod(LocalDate adjustedEndDate, LocalDate adjustedStartDate,
      LocalDate unadjustedEndDate, LocalDate unadjustedStartDate) {
    this.adjustedEndDate = adjustedEndDate;
    this.adjustedStartDate = adjustedStartDate;
    this.unadjustedEndDate = unadjustedEndDate;
    this.unadjustedStartDate = unadjustedStartDate;
  }

  public static SchedulePeriod fromValue(Value value$) throws IllegalArgumentException {
    Value recordValue$ = value$;
    DamlRecord record$ = recordValue$.asRecord().orElseThrow(() -> new IllegalArgumentException("Contracts must be constructed from Records"));
    List<DamlRecord.Field> fields$ = record$.getFields();
    int numberOfFields = fields$.size();
    if (numberOfFields != 4) {
      throw new IllegalArgumentException("Expected 4 arguments, got " + numberOfFields);
    }
    LocalDate adjustedEndDate = fields$.get(0).getValue().asDate().orElseThrow(() -> new IllegalArgumentException("Expected adjustedEndDate to be of type com.daml.ledger.javaapi.data.Date")).getValue();
    LocalDate adjustedStartDate = fields$.get(1).getValue().asDate().orElseThrow(() -> new IllegalArgumentException("Expected adjustedStartDate to be of type com.daml.ledger.javaapi.data.Date")).getValue();
    LocalDate unadjustedEndDate = fields$.get(2).getValue().asDate().orElseThrow(() -> new IllegalArgumentException("Expected unadjustedEndDate to be of type com.daml.ledger.javaapi.data.Date")).getValue();
    LocalDate unadjustedStartDate = fields$.get(3).getValue().asDate().orElseThrow(() -> new IllegalArgumentException("Expected unadjustedStartDate to be of type com.daml.ledger.javaapi.data.Date")).getValue();
    return new com.daml.generated.da.finance.base.schedule.SchedulePeriod(adjustedEndDate, adjustedStartDate, unadjustedEndDate, unadjustedStartDate);
  }

  public DamlRecord toValue() {
    ArrayList<DamlRecord.Field> fields = new ArrayList<DamlRecord.Field>(4);
    fields.add(new DamlRecord.Field("adjustedEndDate", new Date((int) this.adjustedEndDate.toEpochDay())));
    fields.add(new DamlRecord.Field("adjustedStartDate", new Date((int) this.adjustedStartDate.toEpochDay())));
    fields.add(new DamlRecord.Field("unadjustedEndDate", new Date((int) this.unadjustedEndDate.toEpochDay())));
    fields.add(new DamlRecord.Field("unadjustedStartDate", new Date((int) this.unadjustedStartDate.toEpochDay())));
    return new DamlRecord(fields);
  }

  @Override
  public boolean equals(Object object) {
    if (this == object) {
      return true;
    }
    if (object == null) {
      return false;
    }
    if (!(object instanceof SchedulePeriod)) {
      return false;
    }
    SchedulePeriod other = (SchedulePeriod) object;
    return this.adjustedEndDate.equals(other.adjustedEndDate) && this.adjustedStartDate.equals(other.adjustedStartDate) && this.unadjustedEndDate.equals(other.unadjustedEndDate) && this.unadjustedStartDate.equals(other.unadjustedStartDate);
  }

  @Override
  public int hashCode() {
    return Objects.hash(this.adjustedEndDate, this.adjustedStartDate, this.unadjustedEndDate, this.unadjustedStartDate);
  }

  @Override
  public String toString() {
    return String.format("com.daml.generated.da.finance.base.schedule.SchedulePeriod(%s, %s, %s, %s)", this.adjustedEndDate, this.adjustedStartDate, this.unadjustedEndDate, this.unadjustedStartDate);
  }
}
