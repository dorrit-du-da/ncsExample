package com.daml.generated.daml.data.ior;

import com.daml.ledger.javaapi.data.Value;
import com.daml.ledger.javaapi.data.Variant;
import java.lang.String;
import java.util.function.Function;

public abstract class IOr<a, b> {
  public static final String _packageId = "636e6e778aedec0710919591e9cb2a9404d6daab0581e4ddc515eeae03256f45";

  public IOr() {
  }

  public abstract Value toValue(Function<a, Value> toValuea, Function<b, Value> toValueb);

  public static <a, b> IOr<a, b> fromValue(Value value$, Function<Value, a> fromValuea,
      Function<Value, b> fromValueb) {
    Variant variant$ = value$.asVariant().orElseThrow(() -> new IllegalArgumentException("Expected Variant to build an instance of the Variant com.daml.generated.daml.data.ior.IOr"));
    if ("Left".equals(variant$.getConstructor())) {
      return com.daml.generated.daml.data.ior.ior.Left.fromValue(variant$, fromValuea, fromValueb);
    }
    if ("Right".equals(variant$.getConstructor())) {
      return com.daml.generated.daml.data.ior.ior.Right.fromValue(variant$, fromValuea, fromValueb);
    }
    if ("Both".equals(variant$.getConstructor())) {
      return com.daml.generated.daml.data.ior.ior.Both.fromValue(variant$, fromValuea, fromValueb);
    }
    throw new IllegalArgumentException("Found unknown constructor variant$.getConstructor() for variant com.daml.generated.daml.data.ior.IOr, expected one of [Left, Right, Both]");
  }
}
