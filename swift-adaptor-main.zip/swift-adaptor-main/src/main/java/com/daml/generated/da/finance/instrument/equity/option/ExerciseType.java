package com.daml.generated.da.finance.instrument.equity.option;

import com.daml.ledger.javaapi.data.DamlEnum;
import com.daml.ledger.javaapi.data.Value;
import java.lang.IllegalArgumentException;
import java.lang.String;
import java.util.HashMap;
import java.util.Map;

public enum ExerciseType {
  EUROPEAN,

  AMERICAN;

  private static final DamlEnum[] __values$ = {new DamlEnum("EUROPEAN"), new DamlEnum("AMERICAN")};

  private static final Map<String, ExerciseType> __enums$ = ExerciseType.__buildEnumsMap$();

  private static final Map<String, ExerciseType> __buildEnumsMap$() {
    Map<String, ExerciseType> m = new HashMap<String, ExerciseType>();
    m.put("EUROPEAN", EUROPEAN);
    m.put("AMERICAN", AMERICAN);
    return m;
  }

  public static final ExerciseType fromValue(Value value$) {
    String constructor$ = value$.asEnum().orElseThrow(() -> new IllegalArgumentException("Expected DamlEnum to build an instance of the Enum ExerciseType")).getConstructor();
    if (!ExerciseType.__enums$.containsKey(constructor$)) throw new IllegalArgumentException("Expected a DamlEnum with ExerciseType constructor, found " + constructor$);
    return (ExerciseType) ExerciseType.__enums$.get(constructor$);
  }

  public final DamlEnum toValue() {
    return ExerciseType.__values$[ordinal()];
  }
}
