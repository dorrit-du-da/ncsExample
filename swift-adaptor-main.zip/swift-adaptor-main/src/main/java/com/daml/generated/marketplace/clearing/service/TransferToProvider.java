package com.daml.generated.marketplace.clearing.service;

import com.daml.generated.da.finance.asset.AssetDeposit;
import com.daml.ledger.javaapi.data.DamlCollectors;
import com.daml.ledger.javaapi.data.DamlRecord;
import com.daml.ledger.javaapi.data.Numeric;
import com.daml.ledger.javaapi.data.Value;
import java.lang.IllegalArgumentException;
import java.lang.Object;
import java.lang.Override;
import java.lang.String;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

public class TransferToProvider {
  public static final String _packageId = "636e6e778aedec0710919591e9cb2a9404d6daab0581e4ddc515eeae03256f45";

  public final BigDecimal amount;

  public final List<AssetDeposit.ContractId> depositCids;

  public TransferToProvider(BigDecimal amount, List<AssetDeposit.ContractId> depositCids) {
    this.amount = amount;
    this.depositCids = depositCids;
  }

  public static TransferToProvider fromValue(Value value$) throws IllegalArgumentException {
    Value recordValue$ = value$;
    DamlRecord record$ = recordValue$.asRecord().orElseThrow(() -> new IllegalArgumentException("Contracts must be constructed from Records"));
    List<DamlRecord.Field> fields$ = record$.getFields();
    int numberOfFields = fields$.size();
    if (numberOfFields != 2) {
      throw new IllegalArgumentException("Expected 2 arguments, got " + numberOfFields);
    }
    BigDecimal amount = fields$.get(0).getValue().asNumeric().orElseThrow(() -> new IllegalArgumentException("Expected amount to be of type com.daml.ledger.javaapi.data.Numeric")).getValue();
    List<AssetDeposit.ContractId> depositCids = fields$.get(1).getValue().asList()
            .map(v$0 -> v$0.toList(v$1 ->
                new AssetDeposit.ContractId(v$1.asContractId().orElseThrow(() -> new IllegalArgumentException("Expected v$1 to be of type com.daml.ledger.javaapi.data.ContractId")).getValue())
            ))
            .orElseThrow(() -> new IllegalArgumentException("Expected depositCids to be of type com.daml.ledger.javaapi.data.DamlList"))
        ;
    return new com.daml.generated.marketplace.clearing.service.TransferToProvider(amount, depositCids);
  }

  public DamlRecord toValue() {
    ArrayList<DamlRecord.Field> fields = new ArrayList<DamlRecord.Field>(2);
    fields.add(new DamlRecord.Field("amount", new Numeric(this.amount)));
    fields.add(new DamlRecord.Field("depositCids", this.depositCids.stream().collect(DamlCollectors.toDamlList(v$0 -> v$0.toValue()))));
    return new DamlRecord(fields);
  }

  @Override
  public boolean equals(Object object) {
    if (this == object) {
      return true;
    }
    if (object == null) {
      return false;
    }
    if (!(object instanceof TransferToProvider)) {
      return false;
    }
    TransferToProvider other = (TransferToProvider) object;
    return this.amount.equals(other.amount) && this.depositCids.equals(other.depositCids);
  }

  @Override
  public int hashCode() {
    return Objects.hash(this.amount, this.depositCids);
  }

  @Override
  public String toString() {
    return String.format("com.daml.generated.marketplace.clearing.service.TransferToProvider(%s, %s)", this.amount, this.depositCids);
  }
}
