package com.daml.generated.marketplace.distribution.syndication.structuring.model;

import com.daml.generated.da.finance.types.Id;
import com.daml.generated.marketplace.settlement.hierarchical.SettlementMode;
import com.daml.ledger.javaapi.data.DamlRecord;
import com.daml.ledger.javaapi.data.Numeric;
import com.daml.ledger.javaapi.data.Party;
import com.daml.ledger.javaapi.data.Text;
import com.daml.ledger.javaapi.data.Value;
import java.lang.IllegalArgumentException;
import java.lang.Object;
import java.lang.Override;
import java.lang.String;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

public class CreateTranche {
  public static final String _packageId = "636e6e778aedec0710919591e9cb2a9404d6daab0581e4ddc515eeae03256f45";

  public final String trancheId;

  public final Id deliveryId;

  public final Id paymentId;

  public final BigDecimal size;

  public final String settlementBank;

  public final String bndBank;

  public final String cashProvider;

  public final String bondRegistrar;

  public final String payingAgent;

  public final SettlementMode issuerSettlementMode;

  public final SettlementMode bndSettlementMode;

  public CreateTranche(String trancheId, Id deliveryId, Id paymentId, BigDecimal size,
      String settlementBank, String bndBank, String cashProvider, String bondRegistrar,
      String payingAgent, SettlementMode issuerSettlementMode, SettlementMode bndSettlementMode) {
    this.trancheId = trancheId;
    this.deliveryId = deliveryId;
    this.paymentId = paymentId;
    this.size = size;
    this.settlementBank = settlementBank;
    this.bndBank = bndBank;
    this.cashProvider = cashProvider;
    this.bondRegistrar = bondRegistrar;
    this.payingAgent = payingAgent;
    this.issuerSettlementMode = issuerSettlementMode;
    this.bndSettlementMode = bndSettlementMode;
  }

  public static CreateTranche fromValue(Value value$) throws IllegalArgumentException {
    Value recordValue$ = value$;
    DamlRecord record$ = recordValue$.asRecord().orElseThrow(() -> new IllegalArgumentException("Contracts must be constructed from Records"));
    List<DamlRecord.Field> fields$ = record$.getFields();
    int numberOfFields = fields$.size();
    if (numberOfFields != 11) {
      throw new IllegalArgumentException("Expected 11 arguments, got " + numberOfFields);
    }
    String trancheId = fields$.get(0).getValue().asText().orElseThrow(() -> new IllegalArgumentException("Expected trancheId to be of type com.daml.ledger.javaapi.data.Text")).getValue();
    Id deliveryId = Id.fromValue(fields$.get(1).getValue());
    Id paymentId = Id.fromValue(fields$.get(2).getValue());
    BigDecimal size = fields$.get(3).getValue().asNumeric().orElseThrow(() -> new IllegalArgumentException("Expected size to be of type com.daml.ledger.javaapi.data.Numeric")).getValue();
    String settlementBank = fields$.get(4).getValue().asParty().orElseThrow(() -> new IllegalArgumentException("Expected settlementBank to be of type com.daml.ledger.javaapi.data.Party")).getValue();
    String bndBank = fields$.get(5).getValue().asParty().orElseThrow(() -> new IllegalArgumentException("Expected bndBank to be of type com.daml.ledger.javaapi.data.Party")).getValue();
    String cashProvider = fields$.get(6).getValue().asParty().orElseThrow(() -> new IllegalArgumentException("Expected cashProvider to be of type com.daml.ledger.javaapi.data.Party")).getValue();
    String bondRegistrar = fields$.get(7).getValue().asParty().orElseThrow(() -> new IllegalArgumentException("Expected bondRegistrar to be of type com.daml.ledger.javaapi.data.Party")).getValue();
    String payingAgent = fields$.get(8).getValue().asParty().orElseThrow(() -> new IllegalArgumentException("Expected payingAgent to be of type com.daml.ledger.javaapi.data.Party")).getValue();
    SettlementMode issuerSettlementMode = SettlementMode.fromValue(fields$.get(9).getValue());
    SettlementMode bndSettlementMode = SettlementMode.fromValue(fields$.get(10).getValue());
    return new com.daml.generated.marketplace.distribution.syndication.structuring.model.CreateTranche(trancheId, deliveryId, paymentId, size, settlementBank, bndBank, cashProvider, bondRegistrar, payingAgent, issuerSettlementMode, bndSettlementMode);
  }

  public DamlRecord toValue() {
    ArrayList<DamlRecord.Field> fields = new ArrayList<DamlRecord.Field>(11);
    fields.add(new DamlRecord.Field("trancheId", new Text(this.trancheId)));
    fields.add(new DamlRecord.Field("deliveryId", this.deliveryId.toValue()));
    fields.add(new DamlRecord.Field("paymentId", this.paymentId.toValue()));
    fields.add(new DamlRecord.Field("size", new Numeric(this.size)));
    fields.add(new DamlRecord.Field("settlementBank", new Party(this.settlementBank)));
    fields.add(new DamlRecord.Field("bndBank", new Party(this.bndBank)));
    fields.add(new DamlRecord.Field("cashProvider", new Party(this.cashProvider)));
    fields.add(new DamlRecord.Field("bondRegistrar", new Party(this.bondRegistrar)));
    fields.add(new DamlRecord.Field("payingAgent", new Party(this.payingAgent)));
    fields.add(new DamlRecord.Field("issuerSettlementMode", this.issuerSettlementMode.toValue()));
    fields.add(new DamlRecord.Field("bndSettlementMode", this.bndSettlementMode.toValue()));
    return new DamlRecord(fields);
  }

  @Override
  public boolean equals(Object object) {
    if (this == object) {
      return true;
    }
    if (object == null) {
      return false;
    }
    if (!(object instanceof CreateTranche)) {
      return false;
    }
    CreateTranche other = (CreateTranche) object;
    return this.trancheId.equals(other.trancheId) && this.deliveryId.equals(other.deliveryId) && this.paymentId.equals(other.paymentId) && this.size.equals(other.size) && this.settlementBank.equals(other.settlementBank) && this.bndBank.equals(other.bndBank) && this.cashProvider.equals(other.cashProvider) && this.bondRegistrar.equals(other.bondRegistrar) && this.payingAgent.equals(other.payingAgent) && this.issuerSettlementMode.equals(other.issuerSettlementMode) && this.bndSettlementMode.equals(other.bndSettlementMode);
  }

  @Override
  public int hashCode() {
    return Objects.hash(this.trancheId, this.deliveryId, this.paymentId, this.size, this.settlementBank, this.bndBank, this.cashProvider, this.bondRegistrar, this.payingAgent, this.issuerSettlementMode, this.bndSettlementMode);
  }

  @Override
  public String toString() {
    return String.format("com.daml.generated.marketplace.distribution.syndication.structuring.model.CreateTranche(%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)", this.trancheId, this.deliveryId, this.paymentId, this.size, this.settlementBank, this.bndBank, this.cashProvider, this.bondRegistrar, this.payingAgent, this.issuerSettlementMode, this.bndSettlementMode);
  }
}
