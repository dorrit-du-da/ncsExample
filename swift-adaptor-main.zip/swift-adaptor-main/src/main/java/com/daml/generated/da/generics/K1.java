package com.daml.generated.da.generics;

import com.daml.ledger.javaapi.data.DamlRecord;
import com.daml.ledger.javaapi.data.Value;
import java.lang.IllegalArgumentException;
import java.lang.Object;
import java.lang.Override;
import java.lang.String;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.function.Function;

public class K1<i, c, p> {
  public static final String _packageId = "c0d4d4f403a005dd475fa9ffc964883444508dc762c7010507259956f2c5f2bd";

  public final c unK1;

  public K1(c unK1) {
    this.unK1 = unK1;
  }

  public static <i, c, p> K1<i, c, p> fromValue(Value value$, Function<Value, c> fromValuec) throws
      IllegalArgumentException {
    Value recordValue$ = value$;
    DamlRecord record$ = recordValue$.asRecord().orElseThrow(() -> new IllegalArgumentException("Contracts must be constructed from Records"));
    List<DamlRecord.Field> fields$ = record$.getFields();
    int numberOfFields = fields$.size();
    if (numberOfFields != 1) {
      throw new IllegalArgumentException("Expected 1 arguments, got " + numberOfFields);
    }
    c unK1 = fromValuec.apply(fields$.get(0).getValue());
    return new com.daml.generated.da.generics.K1<i, c, p>(unK1);
  }

  public DamlRecord toValue(Function<c, Value> toValuec) {
    ArrayList<DamlRecord.Field> fields = new ArrayList<DamlRecord.Field>(1);
    fields.add(new DamlRecord.Field("unK1", toValuec.apply(this.unK1)));
    return new DamlRecord(fields);
  }

  public static <i, c, p> K1<i, c, p> fromValue(Value value$, Function<Value, i> fromValuei,
      Function<Value, c> fromValuec, Function<Value, p> fromValuep) throws
      IllegalArgumentException {
    Value recordValue$ = value$;
    DamlRecord record$ = recordValue$.asRecord().orElseThrow(() -> new IllegalArgumentException("Contracts must be constructed from Records"));
    List<DamlRecord.Field> fields$ = record$.getFields();
    int numberOfFields = fields$.size();
    if (numberOfFields != 1) {
      throw new IllegalArgumentException("Expected 1 arguments, got " + numberOfFields);
    }
    c unK1 = fromValuec.apply(fields$.get(0).getValue());
    return new com.daml.generated.da.generics.K1<i, c, p>(unK1);
  }

  public DamlRecord toValue(Function<i, Value> toValuei, Function<c, Value> toValuec,
      Function<p, Value> toValuep) {
    ArrayList<DamlRecord.Field> fields = new ArrayList<DamlRecord.Field>(1);
    fields.add(new DamlRecord.Field("unK1", toValuec.apply(this.unK1)));
    return new DamlRecord(fields);
  }

  @Override
  public boolean equals(Object object) {
    if (this == object) {
      return true;
    }
    if (object == null) {
      return false;
    }
    if (!(object instanceof K1<?, ?, ?>)) {
      return false;
    }
    K1<?, ?, ?> other = (K1<?, ?, ?>) object;
    return this.unK1.equals(other.unK1);
  }

  @Override
  public int hashCode() {
    return Objects.hash(this.unK1);
  }

  @Override
  public String toString() {
    return String.format("com.daml.generated.da.generics.K1(%s)", this.unK1);
  }
}
