package com.daml.generated.da.random;

import com.daml.ledger.javaapi.data.Value;
import com.daml.ledger.javaapi.data.Variant;
import java.lang.String;

public abstract class Minstd {
  public static final String _packageId = "c0d4d4f403a005dd475fa9ffc964883444508dc762c7010507259956f2c5f2bd";

  public Minstd() {
  }

  public abstract Value toValue();

  public static Minstd fromValue(Value value$) {
    Variant variant$ = value$.asVariant().orElseThrow(() -> new IllegalArgumentException("Expected Variant to build an instance of the Variant com.daml.generated.da.random.Minstd"));
    if ("Minstd".equals(variant$.getConstructor())) {
      return com.daml.generated.da.random.minstd.Minstd.fromValue(variant$);
    }
    throw new IllegalArgumentException("Found unknown constructor variant$.getConstructor() for variant com.daml.generated.da.random.Minstd, expected one of [Minstd]");
  }
}
