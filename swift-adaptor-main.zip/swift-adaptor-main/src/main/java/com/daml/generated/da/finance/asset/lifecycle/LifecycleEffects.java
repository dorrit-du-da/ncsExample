package com.daml.generated.da.finance.asset.lifecycle;

import com.daml.generated.da.finance.types.Asset;
import com.daml.generated.da.finance.types.Id;
import com.daml.generated.da.internal.template.Archive;
import com.daml.generated.da.set.types.Set;
import com.daml.ledger.javaapi.data.CreateAndExerciseCommand;
import com.daml.ledger.javaapi.data.CreateCommand;
import com.daml.ledger.javaapi.data.CreatedEvent;
import com.daml.ledger.javaapi.data.DamlCollectors;
import com.daml.ledger.javaapi.data.DamlRecord;
import com.daml.ledger.javaapi.data.ExerciseByKeyCommand;
import com.daml.ledger.javaapi.data.ExerciseCommand;
import com.daml.ledger.javaapi.data.Identifier;
import com.daml.ledger.javaapi.data.Party;
import com.daml.ledger.javaapi.data.Template;
import com.daml.ledger.javaapi.data.Text;
import com.daml.ledger.javaapi.data.Value;
import java.lang.Deprecated;
import java.lang.IllegalArgumentException;
import java.lang.Object;
import java.lang.Override;
import java.lang.String;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Objects;
import java.util.Optional;

public final class LifecycleEffects extends Template {
  public static final Identifier TEMPLATE_ID = new Identifier("636e6e778aedec0710919591e9cb2a9404d6daab0581e4ddc515eeae03256f45", "DA.Finance.Asset.Lifecycle", "LifecycleEffects");

  public final Id id;

  public final String label;

  public final List<Asset> consuming;

  public final List<Asset> effects;

  public final Set<String> observers;

  public LifecycleEffects(Id id, String label, List<Asset> consuming, List<Asset> effects,
      Set<String> observers) {
    this.id = id;
    this.label = label;
    this.consuming = consuming;
    this.effects = effects;
    this.observers = observers;
  }

  public CreateCommand create() {
    return new CreateCommand(LifecycleEffects.TEMPLATE_ID, this.toValue());
  }

  public static ExerciseByKeyCommand exerciseByKeyArchive(Id key, Archive arg) {
    return new ExerciseByKeyCommand(LifecycleEffects.TEMPLATE_ID, key.toValue(), "Archive", arg.toValue());
  }

  public static ExerciseByKeyCommand exerciseByKeyLifecycleEffects_SetObservers(Id key,
      LifecycleEffects_SetObservers arg) {
    return new ExerciseByKeyCommand(LifecycleEffects.TEMPLATE_ID, key.toValue(), "LifecycleEffects_SetObservers", arg.toValue());
  }

  public static ExerciseByKeyCommand exerciseByKeyLifecycleEffects_SetObservers(Id key,
      Set<String> newObservers) {
    return LifecycleEffects.exerciseByKeyLifecycleEffects_SetObservers(key, new LifecycleEffects_SetObservers(newObservers));
  }

  public CreateAndExerciseCommand createAndExerciseArchive(Archive arg) {
    Value argValue = arg.toValue();
    return new CreateAndExerciseCommand(LifecycleEffects.TEMPLATE_ID, this.toValue(), "Archive", argValue);
  }

  public CreateAndExerciseCommand createAndExerciseLifecycleEffects_SetObservers(
      LifecycleEffects_SetObservers arg) {
    Value argValue = arg.toValue();
    return new CreateAndExerciseCommand(LifecycleEffects.TEMPLATE_ID, this.toValue(), "LifecycleEffects_SetObservers", argValue);
  }

  public CreateAndExerciseCommand createAndExerciseLifecycleEffects_SetObservers(
      Set<String> newObservers) {
    return createAndExerciseLifecycleEffects_SetObservers(new LifecycleEffects_SetObservers(newObservers));
  }

  public static CreateCommand create(Id id, String label, List<Asset> consuming,
      List<Asset> effects, Set<String> observers) {
    return new LifecycleEffects(id, label, consuming, effects, observers).create();
  }

  public static LifecycleEffects fromValue(Value value$) throws IllegalArgumentException {
    Value recordValue$ = value$;
    DamlRecord record$ = recordValue$.asRecord().orElseThrow(() -> new IllegalArgumentException("Contracts must be constructed from Records"));
    List<DamlRecord.Field> fields$ = record$.getFields();
    int numberOfFields = fields$.size();
    if (numberOfFields != 5) {
      throw new IllegalArgumentException("Expected 5 arguments, got " + numberOfFields);
    }
    Id id = Id.fromValue(fields$.get(0).getValue());
    String label = fields$.get(1).getValue().asText().orElseThrow(() -> new IllegalArgumentException("Expected label to be of type com.daml.ledger.javaapi.data.Text")).getValue();
    List<Asset> consuming = fields$.get(2).getValue().asList()
            .map(v$0 -> v$0.toList(v$1 ->
                Asset.fromValue(v$1)
            ))
            .orElseThrow(() -> new IllegalArgumentException("Expected consuming to be of type com.daml.ledger.javaapi.data.DamlList"))
        ;
    List<Asset> effects = fields$.get(3).getValue().asList()
            .map(v$0 -> v$0.toList(v$1 ->
                Asset.fromValue(v$1)
            ))
            .orElseThrow(() -> new IllegalArgumentException("Expected effects to be of type com.daml.ledger.javaapi.data.DamlList"))
        ;
    Set<String> observers = Set.<java.lang.String>fromValue(fields$.get(4).getValue(), v$0 -> v$0.asParty().orElseThrow(() -> new IllegalArgumentException("Expected observers to be of type com.daml.ledger.javaapi.data.Party")).getValue());
    return new com.daml.generated.da.finance.asset.lifecycle.LifecycleEffects(id, label, consuming, effects, observers);
  }

  public DamlRecord toValue() {
    ArrayList<DamlRecord.Field> fields = new ArrayList<DamlRecord.Field>(5);
    fields.add(new DamlRecord.Field("id", this.id.toValue()));
    fields.add(new DamlRecord.Field("label", new Text(this.label)));
    fields.add(new DamlRecord.Field("consuming", this.consuming.stream().collect(DamlCollectors.toDamlList(v$0 -> v$0.toValue()))));
    fields.add(new DamlRecord.Field("effects", this.effects.stream().collect(DamlCollectors.toDamlList(v$0 -> v$0.toValue()))));
    fields.add(new DamlRecord.Field("observers", this.observers.toValue(v$0 -> new Party(v$0))));
    return new DamlRecord(fields);
  }

  @Override
  public boolean equals(Object object) {
    if (this == object) {
      return true;
    }
    if (object == null) {
      return false;
    }
    if (!(object instanceof LifecycleEffects)) {
      return false;
    }
    LifecycleEffects other = (LifecycleEffects) object;
    return this.id.equals(other.id) && this.label.equals(other.label) && this.consuming.equals(other.consuming) && this.effects.equals(other.effects) && this.observers.equals(other.observers);
  }

  @Override
  public int hashCode() {
    return Objects.hash(this.id, this.label, this.consuming, this.effects, this.observers);
  }

  @Override
  public String toString() {
    return String.format("com.daml.generated.da.finance.asset.lifecycle.LifecycleEffects(%s, %s, %s, %s, %s)", this.id, this.label, this.consuming, this.effects, this.observers);
  }

  public static final class ContractId extends com.daml.ledger.javaapi.data.codegen.ContractId<LifecycleEffects> {
    public ContractId(String contractId) {
      super(contractId);
    }

    public ExerciseCommand exerciseArchive(Archive arg) {
      Value argValue = arg.toValue();
      return new ExerciseCommand(LifecycleEffects.TEMPLATE_ID, this.contractId, "Archive", argValue);
    }

    public ExerciseCommand exerciseLifecycleEffects_SetObservers(
        LifecycleEffects_SetObservers arg) {
      Value argValue = arg.toValue();
      return new ExerciseCommand(LifecycleEffects.TEMPLATE_ID, this.contractId, "LifecycleEffects_SetObservers", argValue);
    }

    public ExerciseCommand exerciseLifecycleEffects_SetObservers(Set<String> newObservers) {
      return exerciseLifecycleEffects_SetObservers(new LifecycleEffects_SetObservers(newObservers));
    }
  }

  public static class Contract implements com.daml.ledger.javaapi.data.Contract {
    public final ContractId id;

    public final LifecycleEffects data;

    public final Optional<String> agreementText;

    public final Optional<Id> key;

    public final java.util.Set<String> signatories;

    public final java.util.Set<String> observers;

    public Contract(ContractId id, LifecycleEffects data, Optional<String> agreementText,
        Optional<Id> key, java.util.Set<String> signatories, java.util.Set<String> observers) {
      this.id = id;
      this.data = data;
      this.agreementText = agreementText;
      this.key = key;
      this.signatories = signatories;
      this.observers = observers;
    }

    public static Contract fromIdAndRecord(String contractId, DamlRecord record$,
        Optional<String> agreementText, Optional<Id> key, java.util.Set<String> signatories,
        java.util.Set<String> observers) {
      ContractId id = new ContractId(contractId);
      LifecycleEffects data = LifecycleEffects.fromValue(record$);
      return new Contract(id, data, agreementText, key, signatories, observers);
    }

    @Deprecated
    public static Contract fromIdAndRecord(String contractId, DamlRecord record$) {
      ContractId id = new ContractId(contractId);
      LifecycleEffects data = LifecycleEffects.fromValue(record$);
      return new Contract(id, data, Optional.empty(), Optional.empty(), Collections.emptySet(), Collections.emptySet());
    }

    public static Contract fromCreatedEvent(CreatedEvent event) {
      return fromIdAndRecord(event.getContractId(), event.getArguments(), event.getAgreementText(), event.getContractKey().map(e -> Id.fromValue(e)), event.getSignatories(), event.getObservers());
    }

    @Override
    public boolean equals(Object object) {
      if (this == object) {
        return true;
      }
      if (object == null) {
        return false;
      }
      if (!(object instanceof Contract)) {
        return false;
      }
      Contract other = (Contract) object;
      return this.id.equals(other.id) && this.data.equals(other.data) && this.agreementText.equals(other.agreementText) && this.key.equals(other.key) && this.signatories.equals(other.signatories) && this.observers.equals(other.observers);
    }

    @Override
    public int hashCode() {
      return Objects.hash(this.id, this.data, this.agreementText, this.key, this.signatories, this.observers);
    }

    @Override
    public String toString() {
      return String.format("com.daml.generated.da.finance.asset.lifecycle.LifecycleEffects.Contract(%s, %s, %s, %s, %s, %s)", this.id, this.data, this.agreementText, this.key, this.signatories, this.observers);
    }
  }
}
