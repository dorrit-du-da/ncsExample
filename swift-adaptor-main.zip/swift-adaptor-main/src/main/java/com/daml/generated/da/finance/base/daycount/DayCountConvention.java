package com.daml.generated.da.finance.base.daycount;

import com.daml.ledger.javaapi.data.DamlEnum;
import com.daml.ledger.javaapi.data.Value;
import java.lang.IllegalArgumentException;
import java.lang.String;
import java.util.HashMap;
import java.util.Map;

public enum DayCountConvention {
  DC_30_360,

  DC_30_360_BONDBASIS,

  DC_30_360_US,

  DC_30E_360,

  DC_30E_360_ISDA,

  DC_ACT_ACT_ICMA,

  DC_ACT_ACT_ISDA,

  DC_ACT_365_FIXED,

  DC_ACT_360,

  DC_ACT_364,

  DC_ACT_365L,

  DC_ACT_ACT_AFB;

  private static final DamlEnum[] __values$ = {new DamlEnum("DC_30_360"), new DamlEnum("DC_30_360_BondBasis"), new DamlEnum("DC_30_360_US"), new DamlEnum("DC_30E_360"), new DamlEnum("DC_30E_360_ISDA"), new DamlEnum("DC_Act_Act_ICMA"), new DamlEnum("DC_Act_Act_ISDA"), new DamlEnum("DC_Act_365_Fixed"), new DamlEnum("DC_Act_360"), new DamlEnum("DC_Act_364"), new DamlEnum("DC_Act_365L"), new DamlEnum("DC_Act_Act_AFB")};

  private static final Map<String, DayCountConvention> __enums$ = DayCountConvention.__buildEnumsMap$();

  private static final Map<String, DayCountConvention> __buildEnumsMap$() {
    Map<String, DayCountConvention> m = new HashMap<String, DayCountConvention>();
    m.put("DC_30_360", DC_30_360);
    m.put("DC_30_360_BondBasis", DC_30_360_BONDBASIS);
    m.put("DC_30_360_US", DC_30_360_US);
    m.put("DC_30E_360", DC_30E_360);
    m.put("DC_30E_360_ISDA", DC_30E_360_ISDA);
    m.put("DC_Act_Act_ICMA", DC_ACT_ACT_ICMA);
    m.put("DC_Act_Act_ISDA", DC_ACT_ACT_ISDA);
    m.put("DC_Act_365_Fixed", DC_ACT_365_FIXED);
    m.put("DC_Act_360", DC_ACT_360);
    m.put("DC_Act_364", DC_ACT_364);
    m.put("DC_Act_365L", DC_ACT_365L);
    m.put("DC_Act_Act_AFB", DC_ACT_ACT_AFB);
    return m;
  }

  public static final DayCountConvention fromValue(Value value$) {
    String constructor$ = value$.asEnum().orElseThrow(() -> new IllegalArgumentException("Expected DamlEnum to build an instance of the Enum DayCountConvention")).getConstructor();
    if (!DayCountConvention.__enums$.containsKey(constructor$)) throw new IllegalArgumentException("Expected a DamlEnum with DayCountConvention constructor, found " + constructor$);
    return (DayCountConvention) DayCountConvention.__enums$.get(constructor$);
  }

  public final DamlEnum toValue() {
    return DayCountConvention.__values$[ordinal()];
  }
}
