package com.daml.generated.daml.data.functor.const$;

import com.daml.ledger.javaapi.data.DamlRecord;
import com.daml.ledger.javaapi.data.Value;
import java.lang.IllegalArgumentException;
import java.lang.Object;
import java.lang.Override;
import java.lang.String;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.function.Function;

public class Const<a, b> {
  public static final String _packageId = "636e6e778aedec0710919591e9cb2a9404d6daab0581e4ddc515eeae03256f45";

  public final a run;

  public Const(a run) {
    this.run = run;
  }

  public static <a, b> Const<a, b> fromValue(Value value$, Function<Value, a> fromValuea) throws
      IllegalArgumentException {
    Value recordValue$ = value$;
    DamlRecord record$ = recordValue$.asRecord().orElseThrow(() -> new IllegalArgumentException("Contracts must be constructed from Records"));
    List<DamlRecord.Field> fields$ = record$.getFields();
    int numberOfFields = fields$.size();
    if (numberOfFields != 1) {
      throw new IllegalArgumentException("Expected 1 arguments, got " + numberOfFields);
    }
    a run = fromValuea.apply(fields$.get(0).getValue());
    return new com.daml.generated.daml.data.functor.const$.Const<a, b>(run);
  }

  public DamlRecord toValue(Function<a, Value> toValuea) {
    ArrayList<DamlRecord.Field> fields = new ArrayList<DamlRecord.Field>(1);
    fields.add(new DamlRecord.Field("run", toValuea.apply(this.run)));
    return new DamlRecord(fields);
  }

  public static <a, b> Const<a, b> fromValue(Value value$, Function<Value, a> fromValuea,
      Function<Value, b> fromValueb) throws IllegalArgumentException {
    Value recordValue$ = value$;
    DamlRecord record$ = recordValue$.asRecord().orElseThrow(() -> new IllegalArgumentException("Contracts must be constructed from Records"));
    List<DamlRecord.Field> fields$ = record$.getFields();
    int numberOfFields = fields$.size();
    if (numberOfFields != 1) {
      throw new IllegalArgumentException("Expected 1 arguments, got " + numberOfFields);
    }
    a run = fromValuea.apply(fields$.get(0).getValue());
    return new com.daml.generated.daml.data.functor.const$.Const<a, b>(run);
  }

  public DamlRecord toValue(Function<a, Value> toValuea, Function<b, Value> toValueb) {
    ArrayList<DamlRecord.Field> fields = new ArrayList<DamlRecord.Field>(1);
    fields.add(new DamlRecord.Field("run", toValuea.apply(this.run)));
    return new DamlRecord(fields);
  }

  @Override
  public boolean equals(Object object) {
    if (this == object) {
      return true;
    }
    if (object == null) {
      return false;
    }
    if (!(object instanceof Const<?, ?>)) {
      return false;
    }
    Const<?, ?> other = (Const<?, ?>) object;
    return this.run.equals(other.run);
  }

  @Override
  public int hashCode() {
    return Objects.hash(this.run);
  }

  @Override
  public String toString() {
    return String.format("com.daml.generated.daml.data.functor.const$.Const(%s)", this.run);
  }
}
