package com.daml.generated.marketplace.clearing.model;

import com.daml.generated.da.finance.types.Id;
import com.daml.generated.da.internal.template.Archive;
import com.daml.generated.da.types.Tuple3;
import com.daml.ledger.javaapi.data.CreateAndExerciseCommand;
import com.daml.ledger.javaapi.data.CreateCommand;
import com.daml.ledger.javaapi.data.CreatedEvent;
import com.daml.ledger.javaapi.data.DamlRecord;
import com.daml.ledger.javaapi.data.ExerciseByKeyCommand;
import com.daml.ledger.javaapi.data.ExerciseCommand;
import com.daml.ledger.javaapi.data.Identifier;
import com.daml.ledger.javaapi.data.Numeric;
import com.daml.ledger.javaapi.data.Party;
import com.daml.ledger.javaapi.data.Template;
import com.daml.ledger.javaapi.data.Text;
import com.daml.ledger.javaapi.data.Timestamp;
import com.daml.ledger.javaapi.data.Value;
import java.lang.Deprecated;
import java.lang.IllegalArgumentException;
import java.lang.Object;
import java.lang.Override;
import java.lang.String;
import java.math.BigDecimal;
import java.time.Instant;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.Set;

public final class MarginCalculation extends Template {
  public static final Identifier TEMPLATE_ID = new Identifier("636e6e778aedec0710919591e9cb2a9404d6daab0581e4ddc515eeae03256f45", "Marketplace.Clearing.Model", "MarginCalculation");

  public final String provider;

  public final String customer;

  public final Id accountId;

  public final Id currency;

  public final BigDecimal targetAmount;

  public final Instant calculationTime;

  public final String calculationId;

  public MarginCalculation(String provider, String customer, Id accountId, Id currency,
      BigDecimal targetAmount, Instant calculationTime, String calculationId) {
    this.provider = provider;
    this.customer = customer;
    this.accountId = accountId;
    this.currency = currency;
    this.targetAmount = targetAmount;
    this.calculationTime = calculationTime;
    this.calculationId = calculationId;
  }

  public CreateCommand create() {
    return new CreateCommand(MarginCalculation.TEMPLATE_ID, this.toValue());
  }

  public static ExerciseByKeyCommand exerciseByKeyArchive(Tuple3<String, String, String> key,
      Archive arg) {
    return new ExerciseByKeyCommand(MarginCalculation.TEMPLATE_ID, key.toValue(v$0 -> new Party(v$0),v$1 -> new Party(v$1),v$2 -> new Text(v$2)), "Archive", arg.toValue());
  }

  public static ExerciseByKeyCommand exerciseByKeyMarginCalculation_Resolve(
      Tuple3<String, String, String> key, MarginCalculation_Resolve arg) {
    return new ExerciseByKeyCommand(MarginCalculation.TEMPLATE_ID, key.toValue(v$0 -> new Party(v$0),v$1 -> new Party(v$1),v$2 -> new Text(v$2)), "MarginCalculation_Resolve", arg.toValue());
  }

  public static ExerciseByKeyCommand exerciseByKeyMarginCalculation_Resolve(
      Tuple3<String, String, String> key, String note) {
    return MarginCalculation.exerciseByKeyMarginCalculation_Resolve(key, new MarginCalculation_Resolve(note));
  }

  public static ExerciseByKeyCommand exerciseByKeyMarginCalculation_Reject(
      Tuple3<String, String, String> key, MarginCalculation_Reject arg) {
    return new ExerciseByKeyCommand(MarginCalculation.TEMPLATE_ID, key.toValue(v$0 -> new Party(v$0),v$1 -> new Party(v$1),v$2 -> new Text(v$2)), "MarginCalculation_Reject", arg.toValue());
  }

  public static ExerciseByKeyCommand exerciseByKeyMarginCalculation_Reject(
      Tuple3<String, String, String> key, String note) {
    return MarginCalculation.exerciseByKeyMarginCalculation_Reject(key, new MarginCalculation_Reject(note));
  }

  public CreateAndExerciseCommand createAndExerciseArchive(Archive arg) {
    Value argValue = arg.toValue();
    return new CreateAndExerciseCommand(MarginCalculation.TEMPLATE_ID, this.toValue(), "Archive", argValue);
  }

  public CreateAndExerciseCommand createAndExerciseMarginCalculation_Resolve(
      MarginCalculation_Resolve arg) {
    Value argValue = arg.toValue();
    return new CreateAndExerciseCommand(MarginCalculation.TEMPLATE_ID, this.toValue(), "MarginCalculation_Resolve", argValue);
  }

  public CreateAndExerciseCommand createAndExerciseMarginCalculation_Resolve(String note) {
    return createAndExerciseMarginCalculation_Resolve(new MarginCalculation_Resolve(note));
  }

  public CreateAndExerciseCommand createAndExerciseMarginCalculation_Reject(
      MarginCalculation_Reject arg) {
    Value argValue = arg.toValue();
    return new CreateAndExerciseCommand(MarginCalculation.TEMPLATE_ID, this.toValue(), "MarginCalculation_Reject", argValue);
  }

  public CreateAndExerciseCommand createAndExerciseMarginCalculation_Reject(String note) {
    return createAndExerciseMarginCalculation_Reject(new MarginCalculation_Reject(note));
  }

  public static CreateCommand create(String provider, String customer, Id accountId, Id currency,
      BigDecimal targetAmount, Instant calculationTime, String calculationId) {
    return new MarginCalculation(provider, customer, accountId, currency, targetAmount, calculationTime, calculationId).create();
  }

  public static MarginCalculation fromValue(Value value$) throws IllegalArgumentException {
    Value recordValue$ = value$;
    DamlRecord record$ = recordValue$.asRecord().orElseThrow(() -> new IllegalArgumentException("Contracts must be constructed from Records"));
    List<DamlRecord.Field> fields$ = record$.getFields();
    int numberOfFields = fields$.size();
    if (numberOfFields != 7) {
      throw new IllegalArgumentException("Expected 7 arguments, got " + numberOfFields);
    }
    String provider = fields$.get(0).getValue().asParty().orElseThrow(() -> new IllegalArgumentException("Expected provider to be of type com.daml.ledger.javaapi.data.Party")).getValue();
    String customer = fields$.get(1).getValue().asParty().orElseThrow(() -> new IllegalArgumentException("Expected customer to be of type com.daml.ledger.javaapi.data.Party")).getValue();
    Id accountId = Id.fromValue(fields$.get(2).getValue());
    Id currency = Id.fromValue(fields$.get(3).getValue());
    BigDecimal targetAmount = fields$.get(4).getValue().asNumeric().orElseThrow(() -> new IllegalArgumentException("Expected targetAmount to be of type com.daml.ledger.javaapi.data.Numeric")).getValue();
    Instant calculationTime = fields$.get(5).getValue().asTimestamp().orElseThrow(() -> new IllegalArgumentException("Expected calculationTime to be of type com.daml.ledger.javaapi.data.Timestamp")).getValue();
    String calculationId = fields$.get(6).getValue().asText().orElseThrow(() -> new IllegalArgumentException("Expected calculationId to be of type com.daml.ledger.javaapi.data.Text")).getValue();
    return new com.daml.generated.marketplace.clearing.model.MarginCalculation(provider, customer, accountId, currency, targetAmount, calculationTime, calculationId);
  }

  public DamlRecord toValue() {
    ArrayList<DamlRecord.Field> fields = new ArrayList<DamlRecord.Field>(7);
    fields.add(new DamlRecord.Field("provider", new Party(this.provider)));
    fields.add(new DamlRecord.Field("customer", new Party(this.customer)));
    fields.add(new DamlRecord.Field("accountId", this.accountId.toValue()));
    fields.add(new DamlRecord.Field("currency", this.currency.toValue()));
    fields.add(new DamlRecord.Field("targetAmount", new Numeric(this.targetAmount)));
    fields.add(new DamlRecord.Field("calculationTime", Timestamp.fromInstant(this.calculationTime)));
    fields.add(new DamlRecord.Field("calculationId", new Text(this.calculationId)));
    return new DamlRecord(fields);
  }

  @Override
  public boolean equals(Object object) {
    if (this == object) {
      return true;
    }
    if (object == null) {
      return false;
    }
    if (!(object instanceof MarginCalculation)) {
      return false;
    }
    MarginCalculation other = (MarginCalculation) object;
    return this.provider.equals(other.provider) && this.customer.equals(other.customer) && this.accountId.equals(other.accountId) && this.currency.equals(other.currency) && this.targetAmount.equals(other.targetAmount) && this.calculationTime.equals(other.calculationTime) && this.calculationId.equals(other.calculationId);
  }

  @Override
  public int hashCode() {
    return Objects.hash(this.provider, this.customer, this.accountId, this.currency, this.targetAmount, this.calculationTime, this.calculationId);
  }

  @Override
  public String toString() {
    return String.format("com.daml.generated.marketplace.clearing.model.MarginCalculation(%s, %s, %s, %s, %s, %s, %s)", this.provider, this.customer, this.accountId, this.currency, this.targetAmount, this.calculationTime, this.calculationId);
  }

  public static final class ContractId extends com.daml.ledger.javaapi.data.codegen.ContractId<MarginCalculation> {
    public ContractId(String contractId) {
      super(contractId);
    }

    public ExerciseCommand exerciseArchive(Archive arg) {
      Value argValue = arg.toValue();
      return new ExerciseCommand(MarginCalculation.TEMPLATE_ID, this.contractId, "Archive", argValue);
    }

    public ExerciseCommand exerciseMarginCalculation_Resolve(MarginCalculation_Resolve arg) {
      Value argValue = arg.toValue();
      return new ExerciseCommand(MarginCalculation.TEMPLATE_ID, this.contractId, "MarginCalculation_Resolve", argValue);
    }

    public ExerciseCommand exerciseMarginCalculation_Resolve(String note) {
      return exerciseMarginCalculation_Resolve(new MarginCalculation_Resolve(note));
    }

    public ExerciseCommand exerciseMarginCalculation_Reject(MarginCalculation_Reject arg) {
      Value argValue = arg.toValue();
      return new ExerciseCommand(MarginCalculation.TEMPLATE_ID, this.contractId, "MarginCalculation_Reject", argValue);
    }

    public ExerciseCommand exerciseMarginCalculation_Reject(String note) {
      return exerciseMarginCalculation_Reject(new MarginCalculation_Reject(note));
    }
  }

  public static class Contract implements com.daml.ledger.javaapi.data.Contract {
    public final ContractId id;

    public final MarginCalculation data;

    public final Optional<String> agreementText;

    public final Optional<Tuple3<String, String, String>> key;

    public final Set<String> signatories;

    public final Set<String> observers;

    public Contract(ContractId id, MarginCalculation data, Optional<String> agreementText,
        Optional<Tuple3<String, String, String>> key, Set<String> signatories,
        Set<String> observers) {
      this.id = id;
      this.data = data;
      this.agreementText = agreementText;
      this.key = key;
      this.signatories = signatories;
      this.observers = observers;
    }

    public static Contract fromIdAndRecord(String contractId, DamlRecord record$,
        Optional<String> agreementText, Optional<Tuple3<String, String, String>> key,
        Set<String> signatories, Set<String> observers) {
      ContractId id = new ContractId(contractId);
      MarginCalculation data = MarginCalculation.fromValue(record$);
      return new Contract(id, data, agreementText, key, signatories, observers);
    }

    @Deprecated
    public static Contract fromIdAndRecord(String contractId, DamlRecord record$) {
      ContractId id = new ContractId(contractId);
      MarginCalculation data = MarginCalculation.fromValue(record$);
      return new Contract(id, data, Optional.empty(), Optional.empty(), Collections.emptySet(), Collections.emptySet());
    }

    public static Contract fromCreatedEvent(CreatedEvent event) {
      return fromIdAndRecord(event.getContractId(), event.getArguments(), event.getAgreementText(), event.getContractKey().map(e -> Tuple3.<java.lang.String, java.lang.String, java.lang.String>fromValue(e, v$0 -> v$0.asParty().orElseThrow(() -> new IllegalArgumentException("Expected e to be of type com.daml.ledger.javaapi.data.Party")).getValue(), v$1 -> v$1.asParty().orElseThrow(() -> new IllegalArgumentException("Expected e to be of type com.daml.ledger.javaapi.data.Party")).getValue(), v$2 -> v$2.asText().orElseThrow(() -> new IllegalArgumentException("Expected e to be of type com.daml.ledger.javaapi.data.Text")).getValue())), event.getSignatories(), event.getObservers());
    }

    @Override
    public boolean equals(Object object) {
      if (this == object) {
        return true;
      }
      if (object == null) {
        return false;
      }
      if (!(object instanceof Contract)) {
        return false;
      }
      Contract other = (Contract) object;
      return this.id.equals(other.id) && this.data.equals(other.data) && this.agreementText.equals(other.agreementText) && this.key.equals(other.key) && this.signatories.equals(other.signatories) && this.observers.equals(other.observers);
    }

    @Override
    public int hashCode() {
      return Objects.hash(this.id, this.data, this.agreementText, this.key, this.signatories, this.observers);
    }

    @Override
    public String toString() {
      return String.format("com.daml.generated.marketplace.clearing.model.MarginCalculation.Contract(%s, %s, %s, %s, %s, %s)", this.id, this.data, this.agreementText, this.key, this.signatories, this.observers);
    }
  }
}
