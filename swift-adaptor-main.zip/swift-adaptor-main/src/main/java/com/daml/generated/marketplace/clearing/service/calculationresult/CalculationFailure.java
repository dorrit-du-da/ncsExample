package com.daml.generated.marketplace.clearing.service.calculationresult;

import com.daml.generated.marketplace.clearing.service.CalculationResult;
import com.daml.ledger.javaapi.data.DamlRecord;
import com.daml.ledger.javaapi.data.Value;
import com.daml.ledger.javaapi.data.Variant;
import com.daml.ledger.javaapi.data.codegen.ContractId;
import java.lang.IllegalArgumentException;
import java.lang.Object;
import java.lang.Override;
import java.lang.String;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.function.Function;

public class CalculationFailure<a, b> extends CalculationResult<a, b> {
  public static final String _packageId = "636e6e778aedec0710919591e9cb2a9404d6daab0581e4ddc515eeae03256f45";

  public final ContractId<b> failureCid;

  public CalculationFailure(ContractId<b> failureCid) {
    this.failureCid = failureCid;
  }

  public Variant toValue(Function<b, Value> toValueb) {
    ArrayList<DamlRecord.Field> fields = new ArrayList<DamlRecord.Field>(1);
    fields.add(new DamlRecord.Field("failureCid", this.failureCid.toValue()));
    return new Variant("CalculationFailure", new DamlRecord(fields));
  }

  public static <a, b> CalculationFailure<a, b> fromValue(Value value$,
      Function<Value, b> fromValueb) throws IllegalArgumentException {
    Variant variant$ = value$.asVariant().orElseThrow(() -> new IllegalArgumentException("Expected: Variant. Actual: " + value$.getClass().getName()));
    if (!"CalculationFailure".equals(variant$.getConstructor())) throw new IllegalArgumentException("Invalid constructor. Expected: CalculationFailure. Actual: " + variant$.getConstructor());
    Value recordValue$ = variant$.getValue();
    DamlRecord record$ = recordValue$.asRecord().orElseThrow(() -> new IllegalArgumentException("Contracts must be constructed from Records"));
    List<DamlRecord.Field> fields$ = record$.getFields();
    int numberOfFields = fields$.size();
    if (numberOfFields != 1) {
      throw new IllegalArgumentException("Expected 1 arguments, got " + numberOfFields);
    }
    ContractId<b> failureCid = new ContractId<b>(fields$.get(0).getValue().asContractId().orElseThrow(() -> new IllegalArgumentException("Expected failureCid to be of type com.daml.ledger.javaapi.data.ContractId")).getValue());
    return new CalculationFailure<a, b>(failureCid);
  }

  public Variant toValue(Function<a, Value> toValuea, Function<b, Value> toValueb) {
    ArrayList<DamlRecord.Field> fields = new ArrayList<DamlRecord.Field>(1);
    fields.add(new DamlRecord.Field("failureCid", this.failureCid.toValue()));
    return new Variant("CalculationFailure", new DamlRecord(fields));
  }

  public static <a, b> CalculationFailure<a, b> fromValue(Value value$,
      Function<Value, a> fromValuea, Function<Value, b> fromValueb) throws
      IllegalArgumentException {
    Variant variant$ = value$.asVariant().orElseThrow(() -> new IllegalArgumentException("Expected: Variant. Actual: " + value$.getClass().getName()));
    if (!"CalculationFailure".equals(variant$.getConstructor())) throw new IllegalArgumentException("Invalid constructor. Expected: CalculationFailure. Actual: " + variant$.getConstructor());
    Value recordValue$ = variant$.getValue();
    DamlRecord record$ = recordValue$.asRecord().orElseThrow(() -> new IllegalArgumentException("Contracts must be constructed from Records"));
    List<DamlRecord.Field> fields$ = record$.getFields();
    int numberOfFields = fields$.size();
    if (numberOfFields != 1) {
      throw new IllegalArgumentException("Expected 1 arguments, got " + numberOfFields);
    }
    ContractId<b> failureCid = new ContractId<b>(fields$.get(0).getValue().asContractId().orElseThrow(() -> new IllegalArgumentException("Expected failureCid to be of type com.daml.ledger.javaapi.data.ContractId")).getValue());
    return new CalculationFailure<a, b>(failureCid);
  }

  @Override
  public boolean equals(Object object) {
    if (this == object) {
      return true;
    }
    if (object == null) {
      return false;
    }
    if (!(object instanceof CalculationFailure<?, ?>)) {
      return false;
    }
    CalculationFailure<?, ?> other = (CalculationFailure<?, ?>) object;
    return this.failureCid.equals(other.failureCid);
  }

  @Override
  public int hashCode() {
    return Objects.hash(this.failureCid);
  }

  @Override
  public String toString() {
    return String.format("CalculationFailure(%s)", this.failureCid);
  }
}
