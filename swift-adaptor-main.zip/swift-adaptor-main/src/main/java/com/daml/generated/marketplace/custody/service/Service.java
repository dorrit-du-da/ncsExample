package com.daml.generated.marketplace.custody.service;

import com.daml.generated.da.finance.asset.AssetDeposit;
import com.daml.generated.da.finance.types.Account;
import com.daml.generated.da.finance.types.Asset;
import com.daml.generated.da.internal.template.Archive;
import com.daml.generated.da.types.Tuple3;
import com.daml.generated.marketplace.custody.model.Channel;
import com.daml.generated.marketplace.custody.model.CloseAccountRequest;
import com.daml.generated.marketplace.custody.model.DepositRequest;
import com.daml.generated.marketplace.custody.model.DepositRequestAcknowledged;
import com.daml.generated.marketplace.custody.model.OpenAccountRequest;
import com.daml.generated.marketplace.custody.model.WithdrawalRequest;
import com.daml.generated.marketplace.custody.model.WithdrawalRequestAcknowledged;
import com.daml.ledger.javaapi.data.CreateAndExerciseCommand;
import com.daml.ledger.javaapi.data.CreateCommand;
import com.daml.ledger.javaapi.data.CreatedEvent;
import com.daml.ledger.javaapi.data.DamlRecord;
import com.daml.ledger.javaapi.data.ExerciseByKeyCommand;
import com.daml.ledger.javaapi.data.ExerciseCommand;
import com.daml.ledger.javaapi.data.Identifier;
import com.daml.ledger.javaapi.data.Party;
import com.daml.ledger.javaapi.data.Template;
import com.daml.ledger.javaapi.data.Value;
import java.lang.Deprecated;
import java.lang.IllegalArgumentException;
import java.lang.Object;
import java.lang.Override;
import java.lang.String;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.Set;

public final class Service extends Template {
  public static final Identifier TEMPLATE_ID = new Identifier("636e6e778aedec0710919591e9cb2a9404d6daab0581e4ddc515eeae03256f45", "Marketplace.Custody.Service", "Service");

  public final String operator;

  public final String provider;

  public final String customer;

  public Service(String operator, String provider, String customer) {
    this.operator = operator;
    this.provider = provider;
    this.customer = customer;
  }

  public CreateCommand create() {
    return new CreateCommand(Service.TEMPLATE_ID, this.toValue());
  }

  public static ExerciseByKeyCommand exerciseByKeyRequestWithdrawal(
      Tuple3<String, String, String> key, RequestWithdrawal arg) {
    return new ExerciseByKeyCommand(Service.TEMPLATE_ID, key.toValue(v$0 -> new Party(v$0),v$1 -> new Party(v$1),v$2 -> new Party(v$2)), "RequestWithdrawal", arg.toValue());
  }

  public static ExerciseByKeyCommand exerciseByKeyRequestWithdrawal(
      Tuple3<String, String, String> key, AssetDeposit.ContractId depositCid,
      Channel withdrawalChannel) {
    return Service.exerciseByKeyRequestWithdrawal(key, new RequestWithdrawal(depositCid, withdrawalChannel));
  }

  public static ExerciseByKeyCommand exerciseByKeyRequestOpenAccount(
      Tuple3<String, String, String> key, RequestOpenAccount arg) {
    return new ExerciseByKeyCommand(Service.TEMPLATE_ID, key.toValue(v$0 -> new Party(v$0),v$1 -> new Party(v$1),v$2 -> new Party(v$2)), "RequestOpenAccount", arg.toValue());
  }

  public static ExerciseByKeyCommand exerciseByKeyRequestOpenAccount(
      Tuple3<String, String, String> key, String label) {
    return Service.exerciseByKeyRequestOpenAccount(key, new RequestOpenAccount(label));
  }

  public static ExerciseByKeyCommand exerciseByKeyRequestDeposit(Tuple3<String, String, String> key,
      RequestDeposit arg) {
    return new ExerciseByKeyCommand(Service.TEMPLATE_ID, key.toValue(v$0 -> new Party(v$0),v$1 -> new Party(v$1),v$2 -> new Party(v$2)), "RequestDeposit", arg.toValue());
  }

  public static ExerciseByKeyCommand exerciseByKeyRequestDeposit(Tuple3<String, String, String> key,
      Asset asset, Account account, Channel depositChannel) {
    return Service.exerciseByKeyRequestDeposit(key, new RequestDeposit(asset, account, depositChannel));
  }

  public static ExerciseByKeyCommand exerciseByKeyDeposit(Tuple3<String, String, String> key,
      Deposit arg) {
    return new ExerciseByKeyCommand(Service.TEMPLATE_ID, key.toValue(v$0 -> new Party(v$0),v$1 -> new Party(v$1),v$2 -> new Party(v$2)), "Deposit", arg.toValue());
  }

  public static ExerciseByKeyCommand exerciseByKeyDeposit(Tuple3<String, String, String> key,
      DepositRequest.ContractId depositRequestCid) {
    return Service.exerciseByKeyDeposit(key, new Deposit(depositRequestCid));
  }

  public static ExerciseByKeyCommand exerciseByKeyOpenAccount(Tuple3<String, String, String> key,
      OpenAccount arg) {
    return new ExerciseByKeyCommand(Service.TEMPLATE_ID, key.toValue(v$0 -> new Party(v$0),v$1 -> new Party(v$1),v$2 -> new Party(v$2)), "OpenAccount", arg.toValue());
  }

  public static ExerciseByKeyCommand exerciseByKeyOpenAccount(Tuple3<String, String, String> key,
      OpenAccountRequest.ContractId requestCid) {
    return Service.exerciseByKeyOpenAccount(key, new OpenAccount(requestCid));
  }

  public static ExerciseByKeyCommand exerciseByKeyExternalDeposit(
      Tuple3<String, String, String> key, ExternalDeposit arg) {
    return new ExerciseByKeyCommand(Service.TEMPLATE_ID, key.toValue(v$0 -> new Party(v$0),v$1 -> new Party(v$1),v$2 -> new Party(v$2)), "ExternalDeposit", arg.toValue());
  }

  public static ExerciseByKeyCommand exerciseByKeyExternalDeposit(
      Tuple3<String, String, String> key,
      DepositRequestAcknowledged.ContractId depositRequestAcknowledgedCid) {
    return Service.exerciseByKeyExternalDeposit(key, new ExternalDeposit(depositRequestAcknowledgedCid));
  }

  public static ExerciseByKeyCommand exerciseByKeyExternalWithdrawal(
      Tuple3<String, String, String> key, ExternalWithdrawal arg) {
    return new ExerciseByKeyCommand(Service.TEMPLATE_ID, key.toValue(v$0 -> new Party(v$0),v$1 -> new Party(v$1),v$2 -> new Party(v$2)), "ExternalWithdrawal", arg.toValue());
  }

  public static ExerciseByKeyCommand exerciseByKeyExternalWithdrawal(
      Tuple3<String, String, String> key,
      WithdrawalRequestAcknowledged.ContractId withdrawalRequestAcknowledgedCid) {
    return Service.exerciseByKeyExternalWithdrawal(key, new ExternalWithdrawal(withdrawalRequestAcknowledgedCid));
  }

  public static ExerciseByKeyCommand exerciseByKeyArchive(Tuple3<String, String, String> key,
      Archive arg) {
    return new ExerciseByKeyCommand(Service.TEMPLATE_ID, key.toValue(v$0 -> new Party(v$0),v$1 -> new Party(v$1),v$2 -> new Party(v$2)), "Archive", arg.toValue());
  }

  public static ExerciseByKeyCommand exerciseByKeyWithdrawal(Tuple3<String, String, String> key,
      Withdrawal arg) {
    return new ExerciseByKeyCommand(Service.TEMPLATE_ID, key.toValue(v$0 -> new Party(v$0),v$1 -> new Party(v$1),v$2 -> new Party(v$2)), "Withdrawal", arg.toValue());
  }

  public static ExerciseByKeyCommand exerciseByKeyWithdrawal(Tuple3<String, String, String> key,
      WithdrawalRequest.ContractId withdrawalRequestCid) {
    return Service.exerciseByKeyWithdrawal(key, new Withdrawal(withdrawalRequestCid));
  }

  public static ExerciseByKeyCommand exerciseByKeyTerminate(Tuple3<String, String, String> key,
      Terminate arg) {
    return new ExerciseByKeyCommand(Service.TEMPLATE_ID, key.toValue(v$0 -> new Party(v$0),v$1 -> new Party(v$1),v$2 -> new Party(v$2)), "Terminate", arg.toValue());
  }

  public static ExerciseByKeyCommand exerciseByKeyTerminate(Tuple3<String, String, String> key,
      String ctrl) {
    return Service.exerciseByKeyTerminate(key, new Terminate(ctrl));
  }

  public static ExerciseByKeyCommand exerciseByKeyCloseAccount(Tuple3<String, String, String> key,
      CloseAccount arg) {
    return new ExerciseByKeyCommand(Service.TEMPLATE_ID, key.toValue(v$0 -> new Party(v$0),v$1 -> new Party(v$1),v$2 -> new Party(v$2)), "CloseAccount", arg.toValue());
  }

  public static ExerciseByKeyCommand exerciseByKeyCloseAccount(Tuple3<String, String, String> key,
      CloseAccountRequest.ContractId requestCid) {
    return Service.exerciseByKeyCloseAccount(key, new CloseAccount(requestCid));
  }

  public CreateAndExerciseCommand createAndExerciseRequestWithdrawal(RequestWithdrawal arg) {
    Value argValue = arg.toValue();
    return new CreateAndExerciseCommand(Service.TEMPLATE_ID, this.toValue(), "RequestWithdrawal", argValue);
  }

  public CreateAndExerciseCommand createAndExerciseRequestWithdrawal(
      AssetDeposit.ContractId depositCid, Channel withdrawalChannel) {
    return createAndExerciseRequestWithdrawal(new RequestWithdrawal(depositCid, withdrawalChannel));
  }

  public CreateAndExerciseCommand createAndExerciseRequestOpenAccount(RequestOpenAccount arg) {
    Value argValue = arg.toValue();
    return new CreateAndExerciseCommand(Service.TEMPLATE_ID, this.toValue(), "RequestOpenAccount", argValue);
  }

  public CreateAndExerciseCommand createAndExerciseRequestOpenAccount(String label) {
    return createAndExerciseRequestOpenAccount(new RequestOpenAccount(label));
  }

  public CreateAndExerciseCommand createAndExerciseRequestDeposit(RequestDeposit arg) {
    Value argValue = arg.toValue();
    return new CreateAndExerciseCommand(Service.TEMPLATE_ID, this.toValue(), "RequestDeposit", argValue);
  }

  public CreateAndExerciseCommand createAndExerciseRequestDeposit(Asset asset, Account account,
      Channel depositChannel) {
    return createAndExerciseRequestDeposit(new RequestDeposit(asset, account, depositChannel));
  }

  public CreateAndExerciseCommand createAndExerciseDeposit(Deposit arg) {
    Value argValue = arg.toValue();
    return new CreateAndExerciseCommand(Service.TEMPLATE_ID, this.toValue(), "Deposit", argValue);
  }

  public CreateAndExerciseCommand createAndExerciseDeposit(
      DepositRequest.ContractId depositRequestCid) {
    return createAndExerciseDeposit(new Deposit(depositRequestCid));
  }

  public CreateAndExerciseCommand createAndExerciseOpenAccount(OpenAccount arg) {
    Value argValue = arg.toValue();
    return new CreateAndExerciseCommand(Service.TEMPLATE_ID, this.toValue(), "OpenAccount", argValue);
  }

  public CreateAndExerciseCommand createAndExerciseOpenAccount(
      OpenAccountRequest.ContractId requestCid) {
    return createAndExerciseOpenAccount(new OpenAccount(requestCid));
  }

  public CreateAndExerciseCommand createAndExerciseExternalDeposit(ExternalDeposit arg) {
    Value argValue = arg.toValue();
    return new CreateAndExerciseCommand(Service.TEMPLATE_ID, this.toValue(), "ExternalDeposit", argValue);
  }

  public CreateAndExerciseCommand createAndExerciseExternalDeposit(
      DepositRequestAcknowledged.ContractId depositRequestAcknowledgedCid) {
    return createAndExerciseExternalDeposit(new ExternalDeposit(depositRequestAcknowledgedCid));
  }

  public CreateAndExerciseCommand createAndExerciseExternalWithdrawal(ExternalWithdrawal arg) {
    Value argValue = arg.toValue();
    return new CreateAndExerciseCommand(Service.TEMPLATE_ID, this.toValue(), "ExternalWithdrawal", argValue);
  }

  public CreateAndExerciseCommand createAndExerciseExternalWithdrawal(
      WithdrawalRequestAcknowledged.ContractId withdrawalRequestAcknowledgedCid) {
    return createAndExerciseExternalWithdrawal(new ExternalWithdrawal(withdrawalRequestAcknowledgedCid));
  }

  public CreateAndExerciseCommand createAndExerciseArchive(Archive arg) {
    Value argValue = arg.toValue();
    return new CreateAndExerciseCommand(Service.TEMPLATE_ID, this.toValue(), "Archive", argValue);
  }

  public CreateAndExerciseCommand createAndExerciseWithdrawal(Withdrawal arg) {
    Value argValue = arg.toValue();
    return new CreateAndExerciseCommand(Service.TEMPLATE_ID, this.toValue(), "Withdrawal", argValue);
  }

  public CreateAndExerciseCommand createAndExerciseWithdrawal(
      WithdrawalRequest.ContractId withdrawalRequestCid) {
    return createAndExerciseWithdrawal(new Withdrawal(withdrawalRequestCid));
  }

  public CreateAndExerciseCommand createAndExerciseTerminate(Terminate arg) {
    Value argValue = arg.toValue();
    return new CreateAndExerciseCommand(Service.TEMPLATE_ID, this.toValue(), "Terminate", argValue);
  }

  public CreateAndExerciseCommand createAndExerciseTerminate(String ctrl) {
    return createAndExerciseTerminate(new Terminate(ctrl));
  }

  public CreateAndExerciseCommand createAndExerciseCloseAccount(CloseAccount arg) {
    Value argValue = arg.toValue();
    return new CreateAndExerciseCommand(Service.TEMPLATE_ID, this.toValue(), "CloseAccount", argValue);
  }

  public CreateAndExerciseCommand createAndExerciseCloseAccount(
      CloseAccountRequest.ContractId requestCid) {
    return createAndExerciseCloseAccount(new CloseAccount(requestCid));
  }

  public static CreateCommand create(String operator, String provider, String customer) {
    return new Service(operator, provider, customer).create();
  }

  public static Service fromValue(Value value$) throws IllegalArgumentException {
    Value recordValue$ = value$;
    DamlRecord record$ = recordValue$.asRecord().orElseThrow(() -> new IllegalArgumentException("Contracts must be constructed from Records"));
    List<DamlRecord.Field> fields$ = record$.getFields();
    int numberOfFields = fields$.size();
    if (numberOfFields != 3) {
      throw new IllegalArgumentException("Expected 3 arguments, got " + numberOfFields);
    }
    String operator = fields$.get(0).getValue().asParty().orElseThrow(() -> new IllegalArgumentException("Expected operator to be of type com.daml.ledger.javaapi.data.Party")).getValue();
    String provider = fields$.get(1).getValue().asParty().orElseThrow(() -> new IllegalArgumentException("Expected provider to be of type com.daml.ledger.javaapi.data.Party")).getValue();
    String customer = fields$.get(2).getValue().asParty().orElseThrow(() -> new IllegalArgumentException("Expected customer to be of type com.daml.ledger.javaapi.data.Party")).getValue();
    return new com.daml.generated.marketplace.custody.service.Service(operator, provider, customer);
  }

  public DamlRecord toValue() {
    ArrayList<DamlRecord.Field> fields = new ArrayList<DamlRecord.Field>(3);
    fields.add(new DamlRecord.Field("operator", new Party(this.operator)));
    fields.add(new DamlRecord.Field("provider", new Party(this.provider)));
    fields.add(new DamlRecord.Field("customer", new Party(this.customer)));
    return new DamlRecord(fields);
  }

  @Override
  public boolean equals(Object object) {
    if (this == object) {
      return true;
    }
    if (object == null) {
      return false;
    }
    if (!(object instanceof Service)) {
      return false;
    }
    Service other = (Service) object;
    return this.operator.equals(other.operator) && this.provider.equals(other.provider) && this.customer.equals(other.customer);
  }

  @Override
  public int hashCode() {
    return Objects.hash(this.operator, this.provider, this.customer);
  }

  @Override
  public String toString() {
    return String.format("com.daml.generated.marketplace.custody.service.Service(%s, %s, %s)", this.operator, this.provider, this.customer);
  }

  public static final class ContractId extends com.daml.ledger.javaapi.data.codegen.ContractId<Service> {
    public ContractId(String contractId) {
      super(contractId);
    }

    public ExerciseCommand exerciseRequestWithdrawal(RequestWithdrawal arg) {
      Value argValue = arg.toValue();
      return new ExerciseCommand(Service.TEMPLATE_ID, this.contractId, "RequestWithdrawal", argValue);
    }

    public ExerciseCommand exerciseRequestWithdrawal(AssetDeposit.ContractId depositCid,
        Channel withdrawalChannel) {
      return exerciseRequestWithdrawal(new RequestWithdrawal(depositCid, withdrawalChannel));
    }

    public ExerciseCommand exerciseRequestOpenAccount(RequestOpenAccount arg) {
      Value argValue = arg.toValue();
      return new ExerciseCommand(Service.TEMPLATE_ID, this.contractId, "RequestOpenAccount", argValue);
    }

    public ExerciseCommand exerciseRequestOpenAccount(String label) {
      return exerciseRequestOpenAccount(new RequestOpenAccount(label));
    }

    public ExerciseCommand exerciseRequestDeposit(RequestDeposit arg) {
      Value argValue = arg.toValue();
      return new ExerciseCommand(Service.TEMPLATE_ID, this.contractId, "RequestDeposit", argValue);
    }

    public ExerciseCommand exerciseRequestDeposit(Asset asset, Account account,
        Channel depositChannel) {
      return exerciseRequestDeposit(new RequestDeposit(asset, account, depositChannel));
    }

    public ExerciseCommand exerciseDeposit(Deposit arg) {
      Value argValue = arg.toValue();
      return new ExerciseCommand(Service.TEMPLATE_ID, this.contractId, "Deposit", argValue);
    }

    public ExerciseCommand exerciseDeposit(DepositRequest.ContractId depositRequestCid) {
      return exerciseDeposit(new Deposit(depositRequestCid));
    }

    public ExerciseCommand exerciseOpenAccount(OpenAccount arg) {
      Value argValue = arg.toValue();
      return new ExerciseCommand(Service.TEMPLATE_ID, this.contractId, "OpenAccount", argValue);
    }

    public ExerciseCommand exerciseOpenAccount(OpenAccountRequest.ContractId requestCid) {
      return exerciseOpenAccount(new OpenAccount(requestCid));
    }

    public ExerciseCommand exerciseExternalDeposit(ExternalDeposit arg) {
      Value argValue = arg.toValue();
      return new ExerciseCommand(Service.TEMPLATE_ID, this.contractId, "ExternalDeposit", argValue);
    }

    public ExerciseCommand exerciseExternalDeposit(
        DepositRequestAcknowledged.ContractId depositRequestAcknowledgedCid) {
      return exerciseExternalDeposit(new ExternalDeposit(depositRequestAcknowledgedCid));
    }

    public ExerciseCommand exerciseExternalWithdrawal(ExternalWithdrawal arg) {
      Value argValue = arg.toValue();
      return new ExerciseCommand(Service.TEMPLATE_ID, this.contractId, "ExternalWithdrawal", argValue);
    }

    public ExerciseCommand exerciseExternalWithdrawal(
        WithdrawalRequestAcknowledged.ContractId withdrawalRequestAcknowledgedCid) {
      return exerciseExternalWithdrawal(new ExternalWithdrawal(withdrawalRequestAcknowledgedCid));
    }

    public ExerciseCommand exerciseArchive(Archive arg) {
      Value argValue = arg.toValue();
      return new ExerciseCommand(Service.TEMPLATE_ID, this.contractId, "Archive", argValue);
    }

    public ExerciseCommand exerciseWithdrawal(Withdrawal arg) {
      Value argValue = arg.toValue();
      return new ExerciseCommand(Service.TEMPLATE_ID, this.contractId, "Withdrawal", argValue);
    }

    public ExerciseCommand exerciseWithdrawal(WithdrawalRequest.ContractId withdrawalRequestCid) {
      return exerciseWithdrawal(new Withdrawal(withdrawalRequestCid));
    }

    public ExerciseCommand exerciseTerminate(Terminate arg) {
      Value argValue = arg.toValue();
      return new ExerciseCommand(Service.TEMPLATE_ID, this.contractId, "Terminate", argValue);
    }

    public ExerciseCommand exerciseTerminate(String ctrl) {
      return exerciseTerminate(new Terminate(ctrl));
    }

    public ExerciseCommand exerciseCloseAccount(CloseAccount arg) {
      Value argValue = arg.toValue();
      return new ExerciseCommand(Service.TEMPLATE_ID, this.contractId, "CloseAccount", argValue);
    }

    public ExerciseCommand exerciseCloseAccount(CloseAccountRequest.ContractId requestCid) {
      return exerciseCloseAccount(new CloseAccount(requestCid));
    }
  }

  public static class Contract implements com.daml.ledger.javaapi.data.Contract {
    public final ContractId id;

    public final Service data;

    public final Optional<String> agreementText;

    public final Optional<Tuple3<String, String, String>> key;

    public final Set<String> signatories;

    public final Set<String> observers;

    public Contract(ContractId id, Service data, Optional<String> agreementText,
        Optional<Tuple3<String, String, String>> key, Set<String> signatories,
        Set<String> observers) {
      this.id = id;
      this.data = data;
      this.agreementText = agreementText;
      this.key = key;
      this.signatories = signatories;
      this.observers = observers;
    }

    public static Contract fromIdAndRecord(String contractId, DamlRecord record$,
        Optional<String> agreementText, Optional<Tuple3<String, String, String>> key,
        Set<String> signatories, Set<String> observers) {
      ContractId id = new ContractId(contractId);
      Service data = Service.fromValue(record$);
      return new Contract(id, data, agreementText, key, signatories, observers);
    }

    @Deprecated
    public static Contract fromIdAndRecord(String contractId, DamlRecord record$) {
      ContractId id = new ContractId(contractId);
      Service data = Service.fromValue(record$);
      return new Contract(id, data, Optional.empty(), Optional.empty(), Collections.emptySet(), Collections.emptySet());
    }

    public static Contract fromCreatedEvent(CreatedEvent event) {
      return fromIdAndRecord(event.getContractId(), event.getArguments(), event.getAgreementText(), event.getContractKey().map(e -> Tuple3.<java.lang.String, java.lang.String, java.lang.String>fromValue(e, v$0 -> v$0.asParty().orElseThrow(() -> new IllegalArgumentException("Expected e to be of type com.daml.ledger.javaapi.data.Party")).getValue(), v$1 -> v$1.asParty().orElseThrow(() -> new IllegalArgumentException("Expected e to be of type com.daml.ledger.javaapi.data.Party")).getValue(), v$2 -> v$2.asParty().orElseThrow(() -> new IllegalArgumentException("Expected e to be of type com.daml.ledger.javaapi.data.Party")).getValue())), event.getSignatories(), event.getObservers());
    }

    @Override
    public boolean equals(Object object) {
      if (this == object) {
        return true;
      }
      if (object == null) {
        return false;
      }
      if (!(object instanceof Contract)) {
        return false;
      }
      Contract other = (Contract) object;
      return this.id.equals(other.id) && this.data.equals(other.data) && this.agreementText.equals(other.agreementText) && this.key.equals(other.key) && this.signatories.equals(other.signatories) && this.observers.equals(other.observers);
    }

    @Override
    public int hashCode() {
      return Objects.hash(this.id, this.data, this.agreementText, this.key, this.signatories, this.observers);
    }

    @Override
    public String toString() {
      return String.format("com.daml.generated.marketplace.custody.service.Service.Contract(%s, %s, %s, %s, %s, %s)", this.id, this.data, this.agreementText, this.key, this.signatories, this.observers);
    }
  }
}
